﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using LogicalSize = Hnc.Type.Size;
using LogicalPoint = Hnc.Type.Point;
using Logical = System.Int32;
using LogicalRect = Hnc.Type.Rect;
using Int = System.Int32;

namespace Hnc.Type {
    // rect : null 일 수 있음
    // angle : 디폴트 0
    public sealed class Transformation {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public LogicalRect Rect { get; set; }
        public Degree Angle { get; set; }
        public Bool VFlip { 
            get {
                return Rect == null ? false : (Rect.Width < 0) ? true : false;
            } 
        }
        public Bool HFlip {
            get {
                return Rect == null ? false : (Rect.Height < 0) ? true : false;
            } 
        }

         // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Transformation() {
        }
        private Transformation(Transformation other) {
            Debug.AssertThrow(other != null, eErrorCode.NullArgument);

            Rect = other.Rect == null ? null : other.Rect.Clone();
            Angle = other.Angle == null ? null : other.Angle.Clone();
        }
        public static Transformation Create() {
            return new Transformation();
        }
        // width, height 가 음수면 flip된다.
        public static Transformation Create(LogicalRect rect, Degree angle) {
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);
            Transformation result = Transformation.Create();
            result.Rect = rect;
            result.Angle = angle;

            return result;
        }
        public Transformation Clone() {
            return new Transformation(this);
        }

        #region 비교연산

        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }
            Transformation other = obj as Transformation;
            Debug.Assert(other != null);

            return (Rect == other.Rect) && 
                (Angle == other.Angle);
        }
        public static Bool operator ==(Transformation left, Transformation right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Transformation left, Transformation right) {
            return !(left == right);
        }
        #endregion
       
        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }
    }
}
