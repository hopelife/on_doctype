﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Ratio = System.Single;
using Index = System.Int32;
using Byte = System.Byte;
using Count = System.Int32;
using Pixel = System.UInt32;

namespace Hnc.Presenter.ImageEffect {
    public class HslChannel {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Byte[] A; 
        public Float[] H; // h는 0 ~ 360
        public Ratio[] S; // 0 ~ 1 
        public Ratio[] L; // 0 ~ 1

        public Count Width { get; private set; }
        public Count Height { get; private set; }
        
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private HslChannel(Count width, Count height) {
            A = new Byte[width * height];
            H = new Float[width * height];
            S = new Float[width * height];
            L = new Float[width * height];

            Width = width;
            Height = height;

        }

        public static HslChannel Create(Pixels pixels) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(pixels.Data.Length != 0, eErrorCode.NullArgument);

            HslChannel result = new HslChannel(pixels.Width, pixels.Height);


            for (Index i = 0; i < pixels.Data.Length; ++i) {
                ColorUtil.RgbToHsl(
                    (Byte)((pixels.Data[i] >> 16) & 0xFF),
                    (Byte)((pixels.Data[i] >> 8) & 0xFF),
                    (Byte)((pixels.Data[i]) & 0xFF),
                    ref result.H[i], ref result.S[i], ref result.L[i]
                );

                result.A[i] = (Byte)((pixels.Data[i] >> 24) & 0xFF);
                result.H[i] = Degree.Constraint(result.H[i]);
                result.S[i] = MathUtil.Clamp(result.S[i], 0, 1);
                result.L[i] = MathUtil.Clamp(result.L[i], 0, 1);
            }

            return result;
        }

        public static HslChannel Create(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            HslChannel result = new HslChannel(pixels.Width, pixels.Height);


            for (Index i = 0; i < pixels.R.Length; ++i) {
                ColorUtil.RgbToHsl(
                    pixels.R[i],
                    pixels.G[i],
                    pixels.B[i],
                    ref result.H[i], ref result.S[i], ref result.L[i]
                );

                result.A[i] = pixels.A[i];
                result.H[i] = Degree.Constraint(result.H[i]);
                result.S[i] = MathUtil.Clamp(result.S[i], 0, 1);
                result.L[i] = MathUtil.Clamp(result.L[i], 0, 1);
            }

            return result;
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public ArgbChannel ToArgb() {
            ArgbChannel result = ArgbChannel.Create(Width, Height);

            for (Index i = 0; i < H.Length; ++i) {
                result.A[i] = A[i];
                ColorUtil.HslToRgb(H[i], S[i], L[i], ref result.R[i], ref result.G[i], ref result.B[i]);
            }

            return result;
        }
        public Pixel[] ToPixels() {
            Pixel[] result = new Pixel[A.Length];

            Byte r = 0;
            Byte g = 0;
            Byte b = 0;

            for (Index i = 0; i < H.Length; ++i) {
                ColorUtil.HslToRgb(H[i], S[i], L[i], ref r, ref g, ref b);

                result[i] = (Pixel)((A[i] << 24) | (r << 16) | (g << 8) | b);
            }

            return result;
        }
    }
}
