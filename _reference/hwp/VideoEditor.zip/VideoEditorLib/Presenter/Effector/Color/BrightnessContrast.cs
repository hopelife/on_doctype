﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Int = System.Int32;
using Float = System.Single;
using Ratio = System.Single;
using Byte = System.Byte;
using Index = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // 밝기 대조
    public class BrightnessContrast {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private LookupTable LookupTable = LookupTable.Create();


        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private BrightnessContrast(Ratio brightness, Ratio contrast) {

            brightness = MathUtil.Clamp(brightness, -1, 1);
            contrast = MathUtil.Clamp(contrast, -1, 1);

            Int value;

            if (contrast == 0) {
                for (Int i = 0; i < 256; ++i) {
                    value = (Int)(brightness * 255.0 + i);
                    if (value < 0) value = 0;
                    else if (255 < value) value = 255;
                    LookupTable.Data[i] = (Byte)(value);
                }
            }
            else if (contrast == 1) {
                Float y0 = 128 - brightness * 128;
                for (Int i = 0; i < 256; ++i) {
                    value = i;
                    if (value < y0) value = 0;
                    else if (y0 <= value) value = 255;
                    LookupTable.Data[i] = (Byte)(value);
                }
            }
            else if (contrast == -1) {
                value = (Int)(brightness * 128 + 128);
                if (value < 0) value = 0;
                else if (255 < value) value = 255;

                for (Int i = 0; i < 256; ++i) {
                    LookupTable.Data[i] = (Byte)(value);
                }
            }
            else {

                Float slope;
                if (contrast > 0.0f) {
                    slope = 1.0F / (1.0F - contrast);
                }
                else {
                    slope = (1.0F + contrast);
                }

                Float y0 = 128 - slope * 128;
                Float intercept = y0 + (255 - y0) * brightness;

                for (Int i = 0; i < 256; ++i) {
                    value = (Int)(slope * i + intercept);
                    if (value < 0) value = 0;
                    else if (255 < value) value = 255;
                    LookupTable.Data[i] = (Byte)(value);
                }
            }
        }

        public static BrightnessContrast Create(Ratio brightness, Ratio contrast) {
            return new BrightnessContrast(brightness, contrast);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
         public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.R.Length; ++i) {
                pixels.R[i] = LookupTable.Data[pixels.R[i]];
                pixels.G[i] = LookupTable.Data[pixels.G[i]];
                pixels.B[i] = LookupTable.Data[pixels.B[i]];
            }
        }
    }

}