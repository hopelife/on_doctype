﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;
using Hnc.DataLogic;


using String = System.String;
using Byte = System.Byte;
using Float = System.Single;
using Pixel = System.UInt32;
using Bool = System.Boolean;
using System.Windows.Media.Imaging;

namespace Hnc.Presenter {


    public class PixelsUtil {

        // Pixels 정보를 UX에서 표시할 수 있도록 BitmapSource로 변경한다.
        public static System.Windows.Media.Imaging.BitmapSource PixelsToBitmapSource(Pixels pixels) {

            if (pixels == null || pixels.Data == null) {
                return null;
            }

            return System.Windows.Media.Imaging.BitmapSource.Create(
                pixels.Width,
                pixels.Height,
                pixels.WidthDpi,
                pixels.HeightDpi,
                System.Windows.Media.PixelFormats.Bgra32, // Int32로 읽으면 AARRGGBB의 배열로 읽혀짐. Byte로 읽으면 Bgra로 읽혀짐
                null,
                pixels.Data,
                pixels.Stride
            );
        }

        public static Pixels BitmapSourceToPixels(System.Windows.Media.Imaging.BitmapSource bs) {
            Debug.AssertThrow(bs != null, eErrorCode.NullArgument);

            if (bs.Format == System.Windows.Media.PixelFormats.Default) {
                Debug.AssertThrow(false, eErrorCode.InvalidArgument);
                return null;
            }

            // BitmapImage로부터 Bgra32 픽셀 추출
            // 픽셀 포멧이 다르다면, 인코딩/디코딩이 필요하다.
            // Bgr32, Bgra32 ->변환이 필요없음
            // Bgr101010, Bgr24, Bgr555,Bgr565 
            // BlackWhite, Cmyk32 
            // Gray16, Gray2,Gray32Float, Gray4 
            // Indexed1, Indexed2, Indexed4, Indexed8 
            // Pbgra32, Prgba128Float, Prgba64,
            // Rgb128Float, Rgb24, Rgb48, Rgba128Float, Rgba64 

            System.Windows.Media.Imaging.BitmapSource source = null;

            // Bgr 계열의 포멧은 변환없이 사용 가능
            if (
                bs.Format == System.Windows.Media.PixelFormats.Bgr32 ||
                bs.Format == System.Windows.Media.PixelFormats.Bgra32) {

                source = bs;
            }
            else {

                // Bgra32로 변환
                System.Windows.Media.Imaging.FormatConvertedBitmap convertedBitmap = new System.Windows.Media.Imaging.FormatConvertedBitmap();

                convertedBitmap.BeginInit();
                {
                    convertedBitmap.Source = bs;
                    convertedBitmap.DestinationFormat = System.Windows.Media.PixelFormats.Bgra32;
                }

                convertedBitmap.EndInit();

                source = convertedBitmap;

            }

            // 픽셀 복사
            Pixel[] data = new Pixel[source.PixelWidth * source.PixelHeight];
            source.CopyPixels(data, source.PixelWidth * 4, 0);

            Pixels pixels = Pixels.Create(data, bs.PixelWidth, bs.PixelHeight, (Float)bs.DpiX, (Float)bs.DpiY);
            Debug.Assert(pixels != null);
            return pixels;

        }

        // stream으로 부터 Pixels 를 읽는다.null을 전달하거나 loading 실패시 null
        public static Pixels Load(Stream stream) {

            if (stream == null) {
                return null;
            }

            // Stream으로부터 BitmapImage 생성
            System.Windows.Media.Imaging.BitmapImage bi = new System.Windows.Media.Imaging.BitmapImage();
            try {
                bi.BeginInit(); // bi.StreamSource에 접근하기위해 반드시 BeginInit - EndInit 블럭으로 감쌀것
                {
                    stream.Data.Seek(0, System.IO.SeekOrigin.Begin);
                    bi.StreamSource = stream.Data;
                }
                bi.EndInit();
            } catch {
                // 이미지 초기화 실패
                return null;
            }


            return BitmapSourceToPixels(bi);
        }

    }

    // Pixels의 크기를 바꾼다. 
    // System 의존적이므로 Service 레이어 에서 구현한다.
    public sealed class PixelsResizerImpl : PixelsResizer {

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private PixelsResizerImpl() {
        }
        public static PixelsResizerImpl Create() {
            return new PixelsResizerImpl();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region PixelsResizer 구현
        public Pixels Resize(Pixels source, Size targetSize) {
            Debug.AssertThrow(source != null && source.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(targetSize != null, eErrorCode.NullArgument);
            Debug.AssertThrow(0 < targetSize.CX && 0 < targetSize.CY, eErrorCode.InvalidArgument);
            Debug.AssertThrow(0 < source.Width && 0 < source.Height, eErrorCode.DevideZero);

            // 그림 크기가 동일하면 그대로 리턴
            if (source.Width == targetSize.CX && source.Height == targetSize.CY) {
                return source;
            }

            // 원본 BitmapSource
            System.Windows.Media.Imaging.BitmapSource bi = PixelsUtil.PixelsToBitmapSource(source);            
            Debug.Assert(bi != null);

            // 크기를 변경할 BitmapSource
            System.Windows.Media.Imaging.TransformedBitmap tb = new System.Windows.Media.Imaging.TransformedBitmap();
            tb.BeginInit();
            {
                tb.Source = bi;
                tb.Transform = new System.Windows.Media.ScaleTransform((Float)targetSize.CX / source.Width, (Float)targetSize.CY / source.Height);
            }
            tb.EndInit();            

            return PixelsUtil.BitmapSourceToPixels(tb);

        }
        #endregion
    }

    // Pixels를 crop 한다. 
    // System 의존적이므로 Service 레이어 에서 구현한다.
    public sealed class PixelsCropperImpl : PixelsCropper {
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private PixelsCropperImpl() {
        }
        public static PixelsCropperImpl Create() {
            return new PixelsCropperImpl();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region PixelsCropper 구현
        public Pixels Crop(Pixels source, OffsetRect rect, Degree angle) {
            Debug.AssertThrow(source != null && source.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(angle != null, eErrorCode.NullArgument);

            // 동일하면 그대로 리턴
            if (rect == OffsetRect.Create(0, 0, 0, 0) && angle == Degree.Create(0)) {
                return source;
            }

            Rect cropRect = MathUtil.GetRect(rect, Rect.Create(0, 0, source.Width, source.Height));
            cropRect.Normalize();
            if (cropRect.Width < 1) cropRect.Width = 1;
            if (cropRect.Height < 1) cropRect.Height = 1;

            System.Windows.Media.DrawingVisual visual = new System.Windows.Media.DrawingVisual();
            System.Windows.Media.DrawingContext dc = visual.RenderOpen();

            dc.PushTransform(new System.Windows.Media.TranslateTransform(-cropRect.X, -cropRect.Y));
            dc.PushTransform(new System.Windows.Media.RotateTransform(angle.Value, cropRect.Center.X, cropRect.Center.Y));

            dc.DrawImage(PixelsUtil.PixelsToBitmapSource(source), new System.Windows.Rect(0, 0, source.Width, source.Height));

            dc.Pop();
            dc.Pop();

            dc.Close();

            System.Windows.Media.Imaging.RenderTargetBitmap bmp = new System.Windows.Media.Imaging.RenderTargetBitmap(cropRect.Width, cropRect.Height, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
            bmp.Render(visual);

            return PixelsUtil.BitmapSourceToPixels(bmp);

        }
        #endregion
    }

    public sealed class PixelsLoaderImpl : PixelsLoader {
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private PixelsLoaderImpl() {
        }
        public static PixelsLoaderImpl Create() {
            return new PixelsLoaderImpl();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region PixelsLoader 구현
        public Pixels Load(Stream stream) {
            return PixelsUtil.Load(stream);
        }
        #endregion
    }



    // 해당 경로에 파일이 있다면 덮어쓰며, 투명한 이미지가 되었을 수 있으므로 Png 포멧으로만 저장한다.
    public sealed class PixelsSaverImpl : PixelsSaver { 
         // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        // 해당 경로에 파일이 있다면 덮어씀
        private String PathName { get; set; }
   
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private PixelsSaverImpl(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            PathName = pathName;
        }

        public static PixelsSaverImpl Create(String pathName) {
            return new PixelsSaverImpl(pathName);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region PixelsSaver 구현
        public Bool Save(Pixels pixels, String metaTag) {
            if (pixels == null) {
                return false;
            }

            try {              
                using (System.IO.FileStream stream = new System.IO.FileStream(PathName, System.IO.FileMode.Create)) {

                    BitmapSource bs = PixelsUtil.PixelsToBitmapSource(pixels);
                    Debug.Assert(bs != null);


                    // Metadata 쓰기

                    BitmapMetadata metadata = new BitmapMetadata("png");
                    metadata.SetQuery("/Text/Tag", metaTag);

                    BitmapFrame bf = BitmapFrame.Create(bs, bs, metadata, null);
                   

                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(bf);


                    encoder.Save(stream);
                }
                return true;

            }
            catch {
                Debug.Assert(false, "저장 실패");
                return false;
            }
        }
        #endregion
    }


}

