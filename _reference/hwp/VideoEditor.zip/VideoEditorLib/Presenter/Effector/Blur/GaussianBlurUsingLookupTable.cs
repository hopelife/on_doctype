﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {
    // 속도계산을 위해 정규분포계산을 정수형으로 하고 lookupTable을 이용하여 곱셈식을 캐쉬한 버전.
    // 의외로 원본 GaussianBlur보다 빠르진 않다.
    // 다른 OS에서는 효과가 있을듯 하여 사용하지 않지만 코드를 보존한다.
    public class GaussianBlurUsingLookupTable {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Int[] kernel;
        private Int[,] lookupTable; // GaussianKernel값과 0 ~ 255의 값을 미리 계산해서 세팅해 둔다.

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private GaussianBlurUsingLookupTable(Count radius) {
            Debug.AssertThrow(0 < radius, eErrorCode.OutOfBoundary);

            radius = (radius < 1) ? 1 : radius;
            Count count = radius * 2 + 1; // 항상 홀수임
 
            kernel = new Int[count];
            lookupTable = new Int[count, 256]; 

            // 커널항목에 따라 0~255 의 곱셈 값을 미리 계산해 둔다.
            for (Int i = 1; i < radius; ++i) {
                kernel[radius + i] = kernel[radius - i] = (radius - i) * (radius - i);

                for (Int j = 0; j < 256; j++) {
                    lookupTable[radius + i, j] = lookupTable[radius - i, j] = j * kernel[radius - i];
                }
            }
            kernel[radius] = radius * radius;
            for (Int j = 0; j < 256; ++j) {
                lookupTable[radius, j] = j * kernel[radius];
            }

        }
        public static GaussianBlurUsingLookupTable Create(Count radius) {

            return new GaussianBlurUsingLookupTable(radius);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel source) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.Assert(lookupTable != null);

            ArgbChannel target = ArgbChannel.Create(source.Width, source.Height);

            // 가로로 적용
            ApplyCol(source, target);

            // 세로로 적용
            ApplyRow(target, source);
        }

        private void ApplyCol(ArgbChannel source, ArgbChannel target) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.AssertThrow(target != null, eErrorCode.NullArgument);
            Debug.AssertThrow(lookupTable != null, eErrorCode.NullArgument);

            Count width = source.Width;
            Count height = source.Height;

            Index targetPixelPos = 0;
            Index pos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index pixelPos = 0;

            Int total = 0;
            Int aTotal = 0;
            Int rTotal = 0;
            Int gTotal = 0;
            Int bTotal = 0;
            Count kernelCount = kernel.Length;
            Count halfKernelCount = kernelCount / 2;
            Index startPos = 0;

            for (Index y = 0; y < height; ++y) {
                startPos = y * width;
                for (Index x = 0; x < width; ++x) {
                    total = 0;
                    aTotal = 0;
                    rTotal = 0;
                    gTotal = 0;
                    bTotal = 0;

                    targetPixelPos = startPos + x;

                    for (Index k = 0; k < kernelCount; ++k) {
                        pos = x + k - halfKernelCount; // 적용할 픽셀의 가로 위치

                        if (0 <= pos && pos < width) {
                            pixelPos = startPos + pos;

                            total = total + kernel[k];

                            aTotal += lookupTable[k, source.A[pixelPos]];
                            rTotal += lookupTable[k, source.R[pixelPos]];
                            gTotal += lookupTable[k, source.G[pixelPos]];
                            bTotal += lookupTable[k, source.B[pixelPos]];
                        }
                    }

                    aTotal /= total;
                    rTotal /= total;
                    gTotal /= total;
                    bTotal /= total;

                    //aTotal = (aTotal < 0) ? 0 : ((255 < aTotal) ? 255 : aTotal);
                    //rTotal = (rTotal < 0) ? 0 : ((255 < rTotal) ? 255 : rTotal);
                    //gTotal = (gTotal < 0) ? 0 : ((255 < gTotal) ? 255 : gTotal);
                    //bTotal = (bTotal < 0) ? 0 : ((255 < bTotal) ? 255 : bTotal);


                    target.A[targetPixelPos] = (Byte)aTotal;
                    target.R[targetPixelPos] = (Byte)rTotal;
                    target.G[targetPixelPos] = (Byte)gTotal;
                    target.B[targetPixelPos] = (Byte)bTotal;
                }
            }
        }
        private void ApplyRow(ArgbChannel source, ArgbChannel target) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.AssertThrow(target != null, eErrorCode.NullArgument);
            Debug.AssertThrow(lookupTable != null, eErrorCode.NullArgument);


            Count width = source.Width;
            Count height = source.Height;

            Index targetPixelPos = 0;
            Index pos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index pixelPos = 0;

            Int total = 0;
            Int aTotal = 0;
            Int rTotal = 0;
            Int gTotal = 0;
            Int bTotal = 0;
            Count kernelCount = kernel.Length;
            Count halfKernelCount = kernelCount / 2;
            Index startPos = 0;

            for (Index x = 0; x < width; ++x) {
                for (Index y = 0; y < height; ++y) {
                    total = 0;
                    aTotal = 0;
                    rTotal = 0;
                    gTotal = 0;
                    bTotal = 0;
                    startPos = y * width;
                    targetPixelPos = startPos + x;

                    for (Index k = 0; k < kernelCount; ++k) {
                        pos = y + k - halfKernelCount; // 적용할 픽셀의 세로 위치

                        if (0 <= pos && pos < height) {
                            pixelPos = pos * width + x;

                            total = total + kernel[k];

                            aTotal += lookupTable[k, source.A[pixelPos]];
                            rTotal += lookupTable[k, source.R[pixelPos]];
                            gTotal += lookupTable[k, source.G[pixelPos]];
                            bTotal += lookupTable[k, source.B[pixelPos]];
                        }
                    }

                    aTotal /= total;
                    rTotal /= total;
                    gTotal /= total;
                    bTotal /= total;

                    //aTotal = (aTotal < 0) ? 0 : ((255 < aTotal) ? 255 : aTotal);
                    //rTotal = (rTotal < 0) ? 0 : ((255 < rTotal) ? 255 : rTotal);
                    //gTotal = (gTotal < 0) ? 0 : ((255 < gTotal) ? 255 : gTotal);
                    //bTotal = (bTotal < 0) ? 0 : ((255 < bTotal) ? 255 : bTotal);


                    target.A[targetPixelPos] = (Byte)aTotal;
                    target.R[targetPixelPos] = (Byte)rTotal;
                    target.G[targetPixelPos] = (Byte)gTotal;
                    target.B[targetPixelPos] = (Byte)bTotal;

                }
            }
        }
    }
}
