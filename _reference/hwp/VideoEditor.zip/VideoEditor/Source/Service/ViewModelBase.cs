﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Service {
	using String = System.String;
	using System.ComponentModel;
	using System.Collections.ObjectModel;
	using System.Collections.Specialized;

	public class ViewModelBase : INotifyPropertyChanged {
		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyCahnged(String propertyName) {
			var handler = PropertyChanged;

			if (handler != null) {
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}