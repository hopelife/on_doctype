﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;

namespace Hnc.Control {

    public class VirtualizingWrapPanel : VirtualizingPanel, IScrollInfo {

        #region -> Fields

        private Thread measuringThread;
        private Thread arrangingThread;
        private Thread cleaningThread;

        private ItemsControl itemsControl;
        private IItemContainerGenerator generator;

        #endregion

        #region -> Properties

        private Size ChildSlotSize {
            get {
                return new Size(ItemWidth + ItemMargin.Left + ItemMargin.Right, ItemHeight + ItemMargin.Top + ItemMargin.Bottom);
            }
        }

        #endregion

        #region -> Dependency Properties

        public double ItemWidth {
            get {
                return (double)base.GetValue(ItemWidthProperty);
            }
            set {
                base.SetValue(ItemWidthProperty, value);
            }
        }

        public double ItemHeight {
            get {
                return (double)base.GetValue(ItemHeightProperty);
            }
            set {
                base.SetValue(ItemHeightProperty, value);
            }
        }

        /// <summary>
        /// InternalChild의 Margin 입니다.        
        /// ※ InternalChild의 Arrange 과정에서 정확한 좌표를 계산하기 위해 필요합니다.
        /// </summary>
        public Thickness ItemMargin {
            get {
                return (Thickness)base.GetValue(ItemMarginProperty);
            }
            set {
                base.SetValue(ItemMarginProperty, value);
            }
        }

        public Orientation Orientation {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }

        public static readonly DependencyProperty ItemWidthProperty =
            DependencyProperty.Register("ItemWidth", typeof(double), typeof(VirtualizingWrapPanel), new PropertyMetadata(190d));

        public static readonly DependencyProperty ItemHeightProperty =
            DependencyProperty.Register("ItemHeight", typeof(double), typeof(VirtualizingWrapPanel), new PropertyMetadata(130d));

        public static readonly DependencyProperty ItemMarginProperty =
            DependencyProperty.Register("ItemMargin", typeof(Thickness), typeof(VirtualizingWrapPanel), new PropertyMetadata(new Thickness(0, 5, 10, 5)));

        public static readonly DependencyProperty OrientationProperty =
            StackPanel.OrientationProperty.AddOwner(typeof(VirtualizingWrapPanel), new PropertyMetadata(Orientation.Vertical));

        #endregion

        #region -> Methods

        private void viewport_SizeChanged(object sender, SizeChangedEventArgs e) {

            if (Orientation == Orientation.Vertical && !e.WidthChanged)
                return;
            else if (Orientation == Orientation.Horizontal && !e.HeightChanged)
                return;

            // 너비나 폭이 0보다 작거나 같은 경우와 Code에 의해 너비가 변경되는 경우를 제외
            //if (e.PreviousSize.Width > 0 && e.PreviousSize.Height > 0 && e.NewSize.Width > 0 && e.NewSize.Height > 0)
            InvalidateMeasure();
        }

        private void scrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e) {

            if (Orientation == Orientation.Vertical && e.HorizontalChange != 0d)
                SetHorizontalOffset(e.HorizontalOffset);
            else
                SetVerticalOffset(e.VerticalOffset);
        }

        private void MeasureChildren(object args) {

            Debug.Assert(args != null);

            int[] indexes = args as int[];
            Debug.Assert(indexes != null);
            Debug.Assert(indexes.Length == 2);

            int startItemIndex = indexes[0];
            int endItemIndex = indexes[1];

            this.Dispatcher.BeginInvoke(new Action(delegate() {

                GeneratorPosition startPos = generator.GeneratorPositionFromIndex(startItemIndex);
                int childIndex = (startPos.Offset == 0) ? startPos.Index : startPos.Index + 1;

                using (generator.StartAt(startPos, GeneratorDirection.Forward, true)) {

                    // viewport 범위에 들어갈 아이템 갯수만큼 생성
                    for (int itemIndex = startItemIndex; itemIndex <= endItemIndex; itemIndex++, childIndex++) {

                        bool isNewlyRealized;

                        UIElement child = generator.GenerateNext(out isNewlyRealized) as UIElement;

                        if (child == null)
                            break;

                        if (isNewlyRealized) {

                            if (childIndex >= InternalChildren.Count)
                                AddInternalChild(child);
                            else
                                InsertInternalChild(childIndex, child);

                            generator.PrepareItemContainer(child);

                            child.Measure(ChildSlotSize);
                        } else
                            Debug.Assert(InternalChildren.Contains(child));
                    }
                }

            }), DispatcherPriority.ApplicationIdle);
        }

        private void ArrangeChildren() {

            this.Dispatcher.BeginInvoke(new Action(delegate() {

                for (int i = 0; i < InternalChildren.Count; i++) {
                    int itemIndex = generator.IndexFromGeneratorPosition(new GeneratorPosition(i, 0));
                    InternalChildren[i].Arrange(GetChildRect(itemIndex));
                }

            }), DispatcherPriority.ApplicationIdle);
        }

        /// <summary>
        /// viewport(startItemIndex ~ endItemIndex) 범위 이외의 아이템을 가상화합니다.
        /// </summary>        
        private void CleanUpChildren(object args) {

            Debug.Assert(args != null);

            int[] indexes = args as int[];
            Debug.Assert(indexes != null);
            Debug.Assert(indexes.Length == 2);

            int startItemIndex = indexes[0];
            int endItemIndex = indexes[1];

            this.Dispatcher.BeginInvoke(new Action(delegate() {

                for (int i = InternalChildren.Count - 1; i >= 0; i--) {

                    GeneratorPosition childGeneratorPos = new GeneratorPosition(i, 0);

                    int itemIndex = generator.IndexFromGeneratorPosition(childGeneratorPos);

                    if (itemIndex < startItemIndex || itemIndex > endItemIndex) {

                        generator.Remove(childGeneratorPos, 1);
                        RemoveInternalChildRange(i, 1);
                    }
                }

            }), DispatcherPriority.ApplicationIdle);
        }

        private void UpdateScrollInfo() {

            if (itemsControl == null)
                return;

            // extent 셋팅
            int itemCount = itemsControl.HasItems ? itemsControl.Items.Count : 0;

            Size calculatedExtent = new Size();

            if (Orientation == Orientation.Vertical) {
                calculatedExtent.Width = Math.Ceiling(itemCount / (double)CalculateChildrenPerColumn(viewport)) * this.ChildSlotSize.Width;
                calculatedExtent.Height = this.ActualHeight;
            } else {
                calculatedExtent.Width = this.ActualWidth;
                calculatedExtent.Height = Math.Ceiling(itemCount / (double)CalculateChildrenPerRow(viewport)) * this.ChildSlotSize.Height;
            }

            if (extent != calculatedExtent) {
                extent = calculatedExtent;
            }

            if (Orientation == Orientation.Vertical)
                this.Width = extent.Width;
            else
                this.Height = extent.Height;

            // viewport 셋팅
            viewport.Width = itemsControl.ActualWidth;
            viewport.Height = itemsControl.ActualHeight;

            // offset이 extent를 넘어가면 초기화
            if (offset.X > extent.Width)
                SetHorizontalOffset(0);

            if (offset.Y > extent.Height)
                SetVerticalOffset(0);

            // 갱신 정보 반영
            if (ScrollOwner != null)
                ScrollOwner.InvalidateScrollInfo();
        }

        private Rect GetChildRect(int itemIndex) {

            Rect rect = new Rect();
            int childrenPerColumn = CalculateChildrenPerColumn(viewport);
            int childrenPerRow = CalculateChildrenPerRow(viewport);

            if (Orientation == Orientation.Vertical) {

                int row = itemIndex % childrenPerColumn;
                int column = itemIndex / childrenPerColumn;

                rect.X = column * this.ChildSlotSize.Width;
                rect.Y = row * this.ChildSlotSize.Height;
                rect.Width = this.ChildSlotSize.Width;
                rect.Height = this.ChildSlotSize.Height;

            } else {

                int row = itemIndex / childrenPerRow;
                int column = itemIndex % childrenPerRow;

                rect.X = column * this.ChildSlotSize.Width;
                rect.Y = row * this.ChildSlotSize.Height;
                rect.Width = this.ChildSlotSize.Width;
                rect.Height = this.ChildSlotSize.Height;
            }

            return rect;
        }

        private int CalculateChildrenPerRow(Size availableSize) {

            int childrenPerRow = 0;

            if (availableSize.Width == Double.PositiveInfinity)
                childrenPerRow = this.Children.Count;
            else
                childrenPerRow = Math.Max(1, (int)Math.Floor(availableSize.Width / this.ChildSlotSize.Width));

            return childrenPerRow;
        }

        private int CalculateChildrenPerColumn(Size availableSize) {

            int childrenPerColumn = 0;

            if (availableSize.Height == Double.PositiveInfinity)
                childrenPerColumn = this.Children.Count;
            else
                childrenPerColumn = Math.Max(1, (int)Math.Floor(availableSize.Height / this.ChildSlotSize.Height));

            return childrenPerColumn;
        }

        private void GetVisibleRange(out int firstVisibleItemIndex, out int lastVisibleItemIndex, int preLoadCount) {

            if (Orientation == Orientation.Vertical) {

                int childrenPerColumn = CalculateChildrenPerColumn(viewport);

                firstVisibleItemIndex = (int)Math.Ceiling(offset.X / this.ChildSlotSize.Width) * childrenPerColumn;
                lastVisibleItemIndex = (int)Math.Floor((offset.X + viewport.Width) / this.ChildSlotSize.Width) * childrenPerColumn - 1;

                // 보이지는 않지만 미리 로드해두는 여유 범위
                firstVisibleItemIndex -= preLoadCount;
                lastVisibleItemIndex += preLoadCount;

                int itemCount = itemsControl.HasItems ? itemsControl.Items.Count : 0;

                // 바운더리를 넘어가는 인덱스는 보정
                firstVisibleItemIndex = firstVisibleItemIndex < 0 ? 0 : firstVisibleItemIndex;
                lastVisibleItemIndex = lastVisibleItemIndex > itemCount ? itemCount - 1 : lastVisibleItemIndex;

            } else {

                int childrenPerRow = CalculateChildrenPerRow(viewport);

                firstVisibleItemIndex = (int)Math.Ceiling(offset.Y / this.ChildSlotSize.Height) * childrenPerRow;
                lastVisibleItemIndex = (int)Math.Floor((offset.Y + viewport.Height) / this.ChildSlotSize.Height) * childrenPerRow - 1;

                // 보이지는 않지만 미리 로드해두는 여유 범위
                firstVisibleItemIndex -= preLoadCount;
                lastVisibleItemIndex += preLoadCount;

                int itemCount = itemsControl.HasItems ? itemsControl.Items.Count : 0;

                // 바운더리를 넘어가는 인덱스는 보정
                firstVisibleItemIndex = firstVisibleItemIndex < 0 ? 0 : firstVisibleItemIndex;
                lastVisibleItemIndex = lastVisibleItemIndex > itemCount ? itemCount - 1 : lastVisibleItemIndex;
            }
        }

        #endregion

        #region -> Override

        protected override void OnInitialized(EventArgs e) {

            base.OnInitialized(e);

            itemsControl = ItemsControl.GetItemsOwner(this);
            Debug.Assert(itemsControl != null);

            // Panel은 ScrollViewer 안에 있다고 가정
            ItemsPresenter presenter = this.VisualParent as ItemsPresenter;
            Debug.Assert(presenter != null);
            ScrollViewer scrollViewer = presenter.Parent as ScrollViewer;
            Debug.Assert(scrollViewer != null);

            this.ScrollOwner = scrollViewer;

            scrollViewer.ScrollChanged += new ScrollChangedEventHandler(scrollViewer_ScrollChanged);
            scrollViewer.Loaded += new RoutedEventHandler(scrollViewer_Loaded);
            itemsControl.SizeChanged += new SizeChangedEventHandler(viewport_SizeChanged);
            itemsControl.Items.CurrentChanged += new EventHandler(Items_CurrentChanged);

            // Children에 한번 접근해야 ItemContainerGenerator이 초기화되는 버그가 있음
            var necessaryChildrenTouch = this.Children;
            generator = this.ItemContainerGenerator;
            Debug.Assert(generator != null);
        }

        private void scrollViewer_Loaded(object sender, RoutedEventArgs e) {
            UpdateScrollInfo();
        }

        private void Items_CurrentChanged(object sender, EventArgs e) {
            InvalidateMeasure();
        }

        protected override void OnItemsChanged(object sender, ItemsChangedEventArgs args) {

            switch (args.Action) {
                case NotifyCollectionChangedAction.Add:
                    InvalidateMeasure();
                    break;
                case NotifyCollectionChangedAction.Reset:
                    InvalidateMeasure();
                    break;
                case NotifyCollectionChangedAction.Remove:
                case NotifyCollectionChangedAction.Replace:
                    RemoveInternalChildRange(args.Position.Index, args.ItemUICount);
                    UpdateScrollInfo();
                    break;
                case NotifyCollectionChangedAction.Move:
                    RemoveInternalChildRange(args.OldPosition.Index, args.ItemUICount);
                    UpdateScrollInfo();
                    break;
            }
        }

        protected override Size MeasureOverride(Size availableSize) {

            if (itemsControl == null || itemsControl.Items.Count == 0)
                return availableSize;

            // ScrollViewer 정보 (extent, viewport, Width) 업데이트
            UpdateScrollInfo();

            // viewport 범위의 아이템 인덱스를 계산
            int startItemIndex = 0, endItemIndex = 0;
            GetVisibleRange(out startItemIndex, out endItemIndex, 5); // 앞뒤 여유로 5개를 더 로드

            // 생성해야 할 아이템이 없다면 패스
            if ((endItemIndex + 1) - startItemIndex <= 0)
                return availableSize;

            // viewport 영역의 아이템 생성 및 레이아웃 측정
            {
                if (measuringThread != null) {
                    measuringThread.Abort();
                    measuringThread = null;
                }

                measuringThread = new Thread(new ParameterizedThreadStart(MeasureChildren));
                measuringThread.IsBackground = true;
                measuringThread.Start(new int[] { startItemIndex, endItemIndex });
            }

            // 보이지 않는 아이템들을 ReVirtualize하면 메모리 점유율이 지속적으로 높아지고, 그대로 두면 메모리 점유율이 유지됨
            // 아직 원인을 알 수 없음;
            {
                if (cleaningThread != null) {
                    cleaningThread.Abort();
                    cleaningThread = null;
                }

                cleaningThread = new Thread(new ParameterizedThreadStart(CleanUpChildren));
                cleaningThread.IsBackground = true;
                cleaningThread.Start(new int[] { startItemIndex, endItemIndex });
            }

            return availableSize;
        }

        protected override Size ArrangeOverride(Size finalSize) {

            if (arrangingThread != null) {
                arrangingThread.Abort();
                arrangingThread = null;
            }

            arrangingThread = new Thread(new ThreadStart(ArrangeChildren));
            arrangingThread.IsBackground = true;
            arrangingThread.Start();

            return finalSize;
        }

        #endregion

        #region -> IScrollInfo Members

        private Point offset = new Point(0, 0);
        private Size viewport = new Size(0, 0);
        private Size extent = new Size(0, 0);

        public ScrollViewer ScrollOwner {
            get;
            set;
        }

        public bool CanHorizontallyScroll {
            get;
            set;
        }

        public bool CanVerticallyScroll {
            get;
            set;
        }

        public double HorizontalOffset {
            get { return offset.X; }
        }

        public double VerticalOffset {
            get { return offset.Y; }
        }

        public double ViewportHeight {
            get { return viewport.Height; }
        }

        public double ViewportWidth {
            get { return viewport.Width; }
        }

        public double ExtentHeight {
            get { return extent.Height; }
        }

        public double ExtentWidth {
            get { return extent.Width; }
        }

        public void LineDown() {
            if (Orientation == Orientation.Vertical)
                SetVerticalOffset(VerticalOffset + 20);
            else
                SetVerticalOffset(VerticalOffset + 1);
        }

        public void LineLeft() {
            if (Orientation == Orientation.Horizontal)
                SetHorizontalOffset(HorizontalOffset - 20);
            else
                SetHorizontalOffset(HorizontalOffset - 1);
        }

        public void LineRight() {
            if (Orientation == Orientation.Horizontal)
                SetHorizontalOffset(HorizontalOffset + 20);
            else
                SetHorizontalOffset(HorizontalOffset + 1);
        }

        public void LineUp() {
            if (Orientation == Orientation.Vertical)
                SetVerticalOffset(VerticalOffset - 20);
            else
                SetVerticalOffset(VerticalOffset - 1);
        }

        public Rect MakeVisible(Visual visual, Rect rectangle) {

            // ???
            return new Rect();
        }

        public void MouseWheelDown() {
            PageDown();
        }

        public void MouseWheelUp() {
            PageUp();
        }

        public void MouseWheelLeft() {
            PageLeft();
        }

        public void MouseWheelRight() {
            PageRight();
        }

        public void PageDown() {
            SetVerticalOffset(VerticalOffset + viewport.Height * 0.8);
        }

        public void PageUp() {
            SetVerticalOffset(VerticalOffset - viewport.Height * 0.8);
        }

        public void PageLeft() {
            SetHorizontalOffset(HorizontalOffset - viewport.Width * 0.8);
        }

        public void PageRight() {
            SetHorizontalOffset(HorizontalOffset + viewport.Width * 0.8);
        }

        public void SetHorizontalOffset(double offset) {

            if (Double.IsNaN(offset) || offset < 0 || viewport.Width >= extent.Width) {
                offset = 0;
            } else {
                if (offset + viewport.Width >= extent.Width) {
                    offset = extent.Width - viewport.Width;
                }
            }

            this.offset.X = offset;

            if (ScrollOwner != null)
                ScrollOwner.InvalidateScrollInfo();

            // 출력할 영역이 있을 경우에만 갱신
            if (viewport.Width != 0 && viewport.Height != 0 && extent.Width != 0 && extent.Height != 0)
                InvalidateMeasure();
        }

        public void SetVerticalOffset(double offset) {

            if (Double.IsNaN(offset) || offset < 0 || viewport.Height >= extent.Height) {
                offset = 0;
            } else {
                if (offset + viewport.Height >= extent.Height)
                    offset = extent.Height - viewport.Height;
            }

            this.offset.Y = offset;

            if (ScrollOwner != null)
                ScrollOwner.InvalidateScrollInfo();

            // 출력할 영역이 있을 경우에만 갱신
            if (viewport.Width != 0 && viewport.Height != 0 && extent.Width != 0 && extent.Height != 0)
                InvalidateMeasure();
        }

        #endregion
    }
}
