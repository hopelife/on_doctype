﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Frame = System.Double;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Engine;
using System.Xml;
using System.Text;
using System.IO;
using System.Collections.ObjectModel;
using System;
using Hnc.Type;

namespace Hnc.VideoEditor.Filter {
	public class XMLParser : IParser {
		private Bool WriteInfo(XmlTextWriter writer, Collection<TimelineInfo> infoCollection) {

			Collection<TimelineInfo> videoInfoList = DocumentUtil.FindVideoInfo(infoCollection);
			Collection<TimelineInfo> soundInfoList = DocumentUtil.FindSoundInfo(infoCollection);
			Collection<TimelineInfo> subtitleInfoList = DocumentUtil.FindSubtitleInfo(infoCollection);

			if (videoInfoList.Count > 0) {
				foreach (VideoInfo info in videoInfoList) {
					WriteVideoInfo(writer, info);
				}
			}

			if (soundInfoList.Count > 0) {
				foreach (SoundInfo info in soundInfoList) {
					WriteSoundInfo(writer, info);
				}
			}

			if (subtitleInfoList.Count > 0) {
				foreach (SubtitleInfo info in subtitleInfoList) {
					WriteSubtitleInfo(writer, info);
				}
			}
			return true;
		}

		private Bool WriteVideoInfo(XmlTextWriter writer, VideoInfo info) {
			writer.WriteStartElement("VideoInfo");

			writer.WriteStartElement("ID");
			writer.WriteString(info.ID.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("FilePath");
			writer.WriteString(info.FilePath);
			writer.WriteEndElement();

			writer.WriteStartElement("VideoScope");
			writer.WriteStartElement("Start");
			writer.WriteString(info.VideoScope.START.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("End");
			writer.WriteString(info.VideoScope.END.ToString());
			writer.WriteEndElement();
			writer.WriteEndElement();

			writer.WriteStartElement("TimelineScope");
			writer.WriteStartElement("Start");
			writer.WriteString(info.TimelineScope.START.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("End");
			writer.WriteString(info.TimelineScope.END.ToString());
			writer.WriteEndElement();
			writer.WriteEndElement();
			writer.WriteEndElement();
			return true;
		}

		private Bool WriteSoundInfo(XmlTextWriter writer, SoundInfo info) {
			writer.WriteStartElement("SoundInfo");

			writer.WriteStartElement("FilePath");
			writer.WriteString(info.FilePath);
			writer.WriteEndElement();

			writer.WriteStartElement("SoundScope");
			writer.WriteStartElement("Start");
			writer.WriteString(info.SoundScope.START.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("End");
			writer.WriteString(info.SoundScope.END.ToString());
			writer.WriteEndElement();
			writer.WriteEndElement();

			writer.WriteStartElement("TimelineScope");
			writer.WriteStartElement("Start");
			writer.WriteString(info.TimelineScope.START.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("End");
			writer.WriteString(info.TimelineScope.END.ToString());
			writer.WriteEndElement();
			writer.WriteEndElement();

			writer.WriteEndElement();
			return true;
		}

		private Bool WriteSubtitleInfo(XmlTextWriter writer, SubtitleInfo info) {
			writer.WriteStartElement("SubtitleInfo");

			writer.WriteStartElement("Sentence");
			writer.WriteString(info.Sentence);
			writer.WriteEndElement();

			writer.WriteStartElement("TimelineScope");
			writer.WriteStartElement("Start");
			writer.WriteString(info.TimelineScope.START.ToString());
			writer.WriteEndElement();

			writer.WriteStartElement("End");
			writer.WriteString(info.TimelineScope.END.ToString());
			writer.WriteEndElement();
			writer.WriteEndElement();

			writer.WriteEndElement();
			return true;
		}

		private FrameScope ReadScope(XmlNode node) {


			Frame start = Frame.Parse(node["Start"].InnerText);
			Frame end = Frame.Parse(node["End"].InnerText);

			FrameScope scope = FrameScope.Create(start, end);

			return scope;
		}

		private Bool ReadVideoInfo(XmlNode node) {
			try {
				int id = int.Parse(node["ID"].InnerText);

				String filePath = node["FilePath"].InnerText;

				XmlNode videoNode = node["VideoScope"];
				FrameScope videoScope = ReadScope(videoNode);


				XmlNode timelineNode = node["TimelineScope"];
				FrameScope timelineScope = ReadScope(timelineNode);

				Hnc.Instrument.VideoContentInfo contentInfo = Hnc.Instrument.VideoUtil.GetVideoContentInfo(filePath);
				VideoInfo info = VideoInfo.Create(id, timelineScope, contentInfo.TotalFrame, filePath, videoScope);

				MarkerUtil.GetMarker().AddInfo(info);
			} catch (NullReferenceException) {
				Debug.Assert(false, "null 참조로 인해 xml 파일 로딩 실패");
				return false;
			} catch {
				return false;
			}

			return true;
		}

		private Bool ReadSoundInfo(XmlNode node) {
			int id = int.Parse(node["ID"].InnerText);

			String filePath = node["FilePath"].InnerText;

			XmlNode soundNode = node["SoundScope"];
			FrameScope soundScope = ReadScope(soundNode);


			XmlNode timelineNode = node["TimelineScope"];
			FrameScope timelineScope = ReadScope(timelineNode);

			SoundInfo info = SoundInfo.Create(id, timelineScope, 0.0, filePath, soundScope);

			MarkerUtil.GetMarker().AddInfo(info);

			return true;
		}

		private Bool ReadSubtitleInfo(XmlNode node) {
			int id = int.Parse(node["ID"].InnerText);

			String sentence = node["Sentence"].InnerText;

			XmlNode timelineNode = node["TimelineScope"];
			FrameScope timelineScope = ReadScope(timelineNode);

			SubtitleInfo info = SubtitleInfo.Create(id, timelineScope, 0.0, sentence);

			MarkerUtil.GetMarker().AddInfo(info);

			return true;
		}

		public Bool Save(String filePath, Collection<TimelineInfo> infoCollection) {

			XmlTextWriter writer = new XmlTextWriter(filePath, Encoding.UTF8);

			// 들여쓰기 설정
			writer.Formatting = Formatting.Indented;

			writer.WriteStartDocument();

			writer.WriteStartElement("document");

			WriteInfo(writer, infoCollection);

			writer.WriteEndElement();

			writer.WriteEndDocument();
			writer.Close();

			return true;
		}

		public Bool Load(String filePath) {
			try {
				if (File.Exists(filePath) == false) {
					return false;
				}

				XmlDocument xmlDoc = new XmlDocument();
				xmlDoc.Load(filePath);

				XmlElement root = xmlDoc.DocumentElement;
				XmlNodeList nodes = root.ChildNodes;

				if (nodes.Count == 0) {
					return false;
				}

				foreach (XmlNode node in nodes) {
					switch (node.Name) {
						case "VideoInfo":
							ReadVideoInfo(node);
							break;
						case "SoundInfo":
							ReadSoundInfo(node);
							break;
						case "SubtitleInfo":
							ReadSubtitleInfo(node);
							break;
						default:
							Debug.Assert(false, "이상한 이름이 있어서 xml 파일 로딩 실패");
							return false;
					}
				}

				MarkerUtil.GetMarker().SetNewID();


			} catch (FileNotFoundException) {
				Debug.Assert(false, "파일을 찾지 못해 xml 파일 로딩 실패");
				return false;
			} catch (FileLoadException) {
				Debug.Assert(false, "파일을 불러오지 못해 xml 파일 로딩 실패");
				return false;
			} catch (NullReferenceException) {
				Debug.Assert(false, "null 참조로 인해 xml 파일 로딩 실패");
				return false;
			}

			return true;
		}
	}
}