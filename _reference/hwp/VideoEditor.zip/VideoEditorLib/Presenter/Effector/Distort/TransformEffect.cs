﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Index = System.Int32;
using Pixel = System.UInt32;
using Bool = System.Boolean;
using Byte = System.Byte;


namespace Hnc.Presenter.ImageEffect {

    public abstract class TransformEffect {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        protected TransformEffect() {
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected abstract void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY);

        public void Apply(Pixels pixels) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;

            Int width1 = width - 1;
            Int height1 = height - 1;

            Pixel[] target = new Pixel[width * height];

            Float sourceX = 0; // target위치에 대응되는 source 위치
            Float sourceY = 0;
            Int srcX;
            Int srcY;

            Pixel nw; // 보간을 수행하기 위한 인근 픽셀들
            Pixel ne;
            Pixel sw;
            Pixel se;

            Index targetPixelPos = 0;
            Index i;
            for (Index y = 0; y < height; ++y) {
                for (Index x = 0; x < width; ++x) {
                    TransformInverse(x, y, ref sourceX, ref sourceY);
                    srcX = MathUtil.Floor(sourceX);
                    srcY = MathUtil.Floor(sourceY);

                    // biLinear 방식으로 보간
                    if (0 <= srcX && srcX < width1 && 0 <= srcY && srcY < height1) {
                        i = width * srcY + srcX;
                        nw = pixels.Data[i];
                        ne = pixels.Data[i + 1];
                        sw = pixels.Data[i + width];
                        se = pixels.Data[i + width + 1];
                    }
                    else {
                        nw = GetPixel(pixels.Data, srcX, srcY, width, height);
                        ne = GetPixel(pixels.Data, srcX + 1, srcY, width, height);
                        sw = GetPixel(pixels.Data, srcX, srcY + 1, width, height);
                        se = GetPixel(pixels.Data, srcX + 1, srcY + 1, width, height);
                    }

                    target[targetPixelPos] = BilinearInterpolate(sourceX - srcX, sourceY - srcY, nw, ne, sw, se);

                    ++targetPixelPos;
                }
            }

            pixels.Data = target;
        }

        // 주어진 픽셀 좌표를 리턴. 다만 영역을 벗어난 위치는 보정한다.
        public static Pixel GetPixel(Pixel[] pixels, Int x, Int y, Int width, Int height) {
            if (x < 0 || width <= x || y < 0 || height <= y) {

                return pixels[(MathUtil.Clamp(y, 0, height - 1) * width) + MathUtil.Clamp(x, 0, width - 1)];
            }
            return pixels[y * width + x];
        }

        // x, y 위치의 픽셀값을 주변 픽셀을 보고 구함. Bilinear 방식
        // nw - 북서
        // ne - 북동
        // sw - 남서
        // se - 남동
        public static Pixel BilinearInterpolate(Float x, Float y, Pixel nw, Pixel ne, Pixel sw, Pixel se) {
            Debug.Assert(0 <= x && x <= 1);
            Debug.Assert(0 <= y && y <= 1);

            Float m0, m1;
            Byte a0 = (Byte)((nw >> 24) & 0xff);
            Byte r0 = (Byte)((nw >> 16) & 0xff);
            Byte g0 = (Byte)((nw >> 8) & 0xff);
            Byte b0 = (Byte)(nw & 0xff);

            Byte a1 = (Byte)((ne >> 24) & 0xff);
            Byte r1 = (Byte)((ne >> 16) & 0xff);
            Byte g1 = (Byte)((ne >> 8) & 0xff);
            Byte b1 = (Byte)(ne & 0xff);

            Byte a2 = (Byte)((sw >> 24) & 0xff);
            Byte r2 = (Byte)((sw >> 16) & 0xff);
            Byte g2 = (Byte)((sw >> 8) & 0xff);
            Byte b2 = (Byte)(sw & 0xff);

            Byte a3 = (Byte)((se >> 24) & 0xff);
            Byte r3 = (Byte)((se >> 16) & 0xff);
            Byte g3 = (Byte)((se >> 8) & 0xff);
            Byte b3 = (Byte)(se & 0xff);

            Float cx = 1.0f - x;
            Float cy = 1.0f - y;

            m0 = cx * a0 + x * a1;
            m1 = cx * a2 + x * a3;
            Int a = (Int)(cy * m0 + y * m1);

            m0 = cx * r0 + x * r1;
            m1 = cx * r2 + x * r3;
            Int r = (Int)(cy * m0 + y * m1);

            m0 = cx * g0 + x * g1;
            m1 = cx * g2 + x * g3;
            Int g = (Int)(cy * m0 + y * m1);

            m0 = cx * b0 + x * b1;
            m1 = cx * b2 + x * b3;
            Int b = (Int)(cy * m0 + y * m1);

            return (Pixel)((a << 24) | (r << 16) | (g << 8) | b);
        }



    }
}
