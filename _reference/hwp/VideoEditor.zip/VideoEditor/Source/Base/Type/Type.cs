﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Type {
	using Int = System.Int32;
	using Index = System.Int32;
	using Frame = System.Double;
	using String = System.String;
	using Bool = System.Boolean;

	using Hnc.VideoEditor.Base.Enum;
	using System.Windows.Controls;
	using System.Collections.Generic;
	using System.Threading;

	public struct TimeInfo {
		public Int hour;
		public Int minute;
		public Int second;
	};

	public class VideoFileInfo {

		#region 속성
		private String _filePath;
		private String _fileName;
		private String _videoCodec;
		private Int _width;
		private Int _height;
		private Int _frameRate;
		private TimeInfo _runningTime;
		private List<Image> _images;
		#endregion

		#region 프로퍼티
		public String FilePath {
			get {
				return _filePath;
			}
			set {
				_filePath = value;
			}
		}

		public String FileName {
			get {
				return _fileName;
			}
			set {
				_fileName = value;
			}
		}

		public String VideoCodec {
			get {
				return _videoCodec;
			}
			set {
				_videoCodec = value;
			}
		}

		public Int Width {
			get {
				return _width;
			}
			set {
				_width = value;
			}
		}

		public Int Height {
			get {
				return _height;
			}
			set {
				_height = value;
			}
		}

		public Int FrameRate {
			get {
				return _frameRate;
			}
			set {
				_frameRate = value;
			}
		}

		public TimeInfo RunningTime {
			get {
				return _runningTime;
			}
			set {
				_runningTime = value;
			}
		}

		public List<Image> Images {
			get {
				return _images;
			}
			set {
				_images = value;
			}
		}
		#endregion

		#region 생성자
		private VideoFileInfo() {
		}

		private VideoFileInfo(String filePath) {
			_filePath = (String)filePath.Clone();
		}
		#endregion // 생성자

		#region Create
		public static VideoFileInfo Create(String filePath) {
			return new VideoFileInfo(filePath);
		}
		#endregion // Create

		#region 오버라이드 함수
		public override Int GetHashCode() {
			return this.GetHashCode();
		}
		#endregion // 오버라이드 함수
	};

	public class FrameScope {

		#region 속성
		private Frame start;
		private Frame end;
		private Frame length;
		#endregion // 속성

		#region 프로퍼티
		public Frame START {
			get {
				return start;
			}
			set {
				start = value;
				length = end - start;
			}
		}

		public Frame END {
			get {
				return end;
			}
			set {
				end = value;
				length = end - start;
			}
		}

		public Frame LENGTH {
			get {
				return length;
			}
			private set {
				length = value;
			}
		}
		#endregion // 프로퍼티

		#region 생성자
		private FrameScope() {
		}

		private FrameScope(Frame start, Frame end) {
			START = start;
			END = end;
			LENGTH = end - start;
		}

		private FrameScope(FrameScope other) {
			START = other.START;
			END = other.END;
			LENGTH = other.END - other.START;
		}
		#endregion // 생성자

		#region Create
		public static FrameScope Create() {
			return new FrameScope(0.0, 0.0);
		}

		public static FrameScope Create(Frame start, Frame end) {
			if (CheckFrame(start, end) == false) {
				return null;
			}

			return new FrameScope(start, end);
		}

		public static FrameScope Create(FrameScope other) {
			if (CheckFrame(other.START, other.END) == false) {
				return null;
			}

			return new FrameScope(other.START, other.END);
		}
		#endregion // Create

		#region override
		public override Bool Equals(System.Object obj) {
			FrameScope other = obj as FrameScope;
			if (other == null) {
				return false;
			}
			return (START == other.START) && (END == other.END);
		}

		public static Bool operator ==(FrameScope left, FrameScope right) {
			if (System.Object.ReferenceEquals(left, right)) { // left == right == null
				return true;
			}

			if ((left as object) == null) {
				return false;
			}

			return left.Equals(right);
		}
		public static Bool operator !=(FrameScope left, FrameScope right) {
			return !(left == right);
		}

		public override Int GetHashCode() {
			return this.GetHashCode();
		}

		public FrameScope Clone() {
			return new FrameScope(this.START, this.END);
		}
		#endregion // override

		#region 멤버함수
		public Bool CheckFrame() {
			if (START < 0.0) {
				return false;
			}

			if (END < 0.0) {
				return false;
			}

			if (START >= END) {
				return false;
			}

			return true;
		}

		public static Bool CheckFrame(Frame start, Frame end) {
			if (start < 0.0) {
				return false;
			}

			if (end < 0.0) {
				return false;
			}

			if (start >= end) {
				return false;
			}

			return true;
		}
		#endregion // 멤버함수
	}
}