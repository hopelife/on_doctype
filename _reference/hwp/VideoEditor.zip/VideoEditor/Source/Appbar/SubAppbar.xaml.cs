﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Grid = System.Windows.Controls.Grid;
using RoutedEventArgs = System.Windows.RoutedEventArgs;
using Visibility = System.Windows.Visibility;
using Hnc.Control;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Base.Enum;

namespace Hnc.VideoEditor.Appbar {

    public partial class SubAppbar : Grid {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        #region 속성
        private VideoAppbar video = new VideoAppbar();
        private SubtitleAppbar subtitle = new SubtitleAppbar();
        private SoundAppbar sound = new SoundAppbar();
        private ExportAppbar export = new ExportAppbar();
        private InfoAppBar info = new InfoAppBar();
        SUBAPPBAR_STATE panelID = SUBAPPBAR_STATE.Closed;
        #endregion

        // ----------------------------------------------
        // 프로퍼티
        // ----------------------------------------------
        #region 프로퍼티
        public SUBAPPBAR_STATE PanelID {
            get { return panelID; }
            set { panelID = value; }
        }
        #endregion

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        #region 생성자
        public SubAppbar() {
            InitializeComponent();

            panel.Children.Add(video);
            panel.Children.Add(subtitle);
            panel.Children.Add(sound);
            panel.Children.Add(export);
            panel.Children.Add(info);
        }
        #endregion

        // ----------------------------------------------
        // 메소드
        // ----------------------------------------------
        #region 메소드
        public bool ShowPanel(SUBAPPBAR_STATE id, string filePath, TimelineInfo selectedInfo) {

            if (panelID != id) {
                panelID = id;
                video.Visibility = Visibility.Hidden;
                sound.Visibility = Visibility.Hidden;
                subtitle.Visibility = Visibility.Hidden;
                export.Visibility = Visibility.Hidden;
                info.Visibility = Visibility.Hidden;

                if (panelID == SUBAPPBAR_STATE.Video) {                    
                    video.Visibility = Visibility.Visible;
                    video.SelectedInfo = selectedInfo;
                } else if (panelID == SUBAPPBAR_STATE.Sound) {                    
                    sound.Visibility = Visibility.Visible;
                    sound.SelectedInfo = selectedInfo;
                } else if (panelID == SUBAPPBAR_STATE.Subtitle) {                
                    subtitle.Visibility = Visibility.Visible;
                    subtitle.SelectedInfo = selectedInfo;
                } else if (panelID == SUBAPPBAR_STATE.Export) {                    
                    export.Visibility = Visibility.Visible;
                    export.SelectedInfo = selectedInfo;
                } else if (panelID == SUBAPPBAR_STATE.Info) {
                    
                    info.Visibility = Visibility.Visible;
                    info.SelectedFilePath = filePath;
                    /*
                    video.Visibility = Visibility.Visible;
                    video.SelectedInfo = selectedInfo;
                     */
                }

            } else {
                panelID = SUBAPPBAR_STATE.Closed;
                return false;
            }
            return true;
        }

        private void HidePanel(object sender, RoutedEventArgs e) {
			/*
            AppBarSubPanel parent = this.Parent as AppBarSubPanel;
            MainMenu parent2 = parent.Parent as MainMenu;

            if (parent2 != null) {
                parent2.HideSubAppbar();
                // parent.IsOpen = false;
                // panelID = SUBAPPBAR_STATE.Closed;
            }
			*/

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				//Hnc.VEFrame.VEFrameManager.Instance.MainPage.MainMenu.HideSubAppbar();
			}
        }

        public void ChangeSelectFile(string filePath) {
            info.LoadInfo(filePath);
        }
        #endregion
    }
}
