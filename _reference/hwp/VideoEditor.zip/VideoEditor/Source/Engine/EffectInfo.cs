﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;

namespace Hnc.VideoEditor.Engine {
	//////////////////////////////////////////////////////////////////////////////////////////
	// 추후 Video의 이미지필터를 추가하기 위해 만들어놓은 인터페이스
	// 이 클래스는 TimelineInfo 등이 Type로 이동하면서 Type로 이동 될 수도
	// 있는 인터페이스
	//////////////////////////////////////////////////////////////////////////////////////////
	public interface IEffect {
		Bool Apply();
	}
}