﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Byte = System.Byte;
using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Pixel = System.UInt32;

namespace Hnc.Util {



    public class ColorUtil {

        // sat : 채도. 범위 0 : 흑백 1: 컬러
        // intensity : 밝기. 범위 0 : 검은색, 1 : 흰색
        public static void RgbToHsi(Byte red, Byte green, Byte blue, ref Float hue, ref Float sat, ref Float intensity) {

            // rgb 값을 0 ~ 1의 비율로 바꾼다.
            Ratio r = (Ratio)red / 255;
            Ratio g = (Ratio)green / 255;
            Ratio b = (Ratio)blue / 255;


            intensity = (r + g + b) / 3;

            if (r == 0 && g == 0 && b == 0) {
                sat = 0;
            }
            else {
                sat = 1 - (3 / (r + g + b)) * MathUtil.Min(r, MathUtil.Min(g, b));
            }

            if (r == g && g == b) {
                hue = 0;
            }
            else {
                Float temp = (r - 0.5F * g - 0.5F * b) / MathUtil.Sqrt(MathUtil.Pow(r - g, 2) + (r - b) * (g - b));
                temp = MathUtil.Clamp(temp, -1, 1); // Acos가 계산될 수 있도록 데이터 범위 조정
                hue = MathUtil.ToDegree(MathUtil.Acos(temp));
                
               
                if (intensity != 0 && (g / intensity) < (b / intensity)) {
                    hue = 360 - hue;
                }
            }
        }
        public static Pixel HsiToRgb(Float hue, Float sat, Float intensity) {
            Debug.AssertThrow(0 <= hue && hue <= 360, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= sat && sat <= 1, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= intensity && intensity <= 1, eErrorCode.OutOfBoundary);
            
            if (intensity == 0) {
                return 0xFF000000; // 검정색
            }
            else if (intensity == 1) {
                return 0xFFFFFFFF; // 흰색
            }
            if (sat == 0) {
                return Pixels.ToPixel(255, (Byte)(intensity * 255), (Byte)(intensity * 255), (Byte)(intensity * 255));
            }

            Ratio r = 0;
            Ratio g = 0;
            Ratio b = 0;

            Float scale = 3 * intensity;
            Float angle1 = 0;
            Float angle2 = 0;

            if (hue <= 120) {
                angle1 = MathUtil.ToRadian(hue);
                angle2 = MathUtil.ToRadian(60 - hue);
                Debug.Assert(MathUtil.Cos(angle2) != 0);

                b = (1 - sat) / 3;
                r = (1 + (sat * MathUtil.Cos(angle1) / MathUtil.Cos(angle2))) / 3;
                g = 1 - r - b;

                r = r * scale;
                g = g * scale;
                b = b * scale;
            }
            else if (120 < hue && hue <= 240) {
                hue = hue - 120;
                angle1 = MathUtil.ToRadian(hue);
                angle2 = MathUtil.ToRadian(60 - hue);
                Debug.Assert(MathUtil.Cos(angle2) != 0);

                r = (1 - sat) / 3;
                g = (1 + (sat * MathUtil.Cos(angle1) / MathUtil.Cos(angle2))) / 3;
                b = 1 - r - g;

                r = r * scale;
                g = g * scale;
                b = b * scale;
            }
            else {
                hue = hue - 240;
                angle1 = MathUtil.ToRadian(hue);
                angle2 = MathUtil.ToRadian(60 - hue);
                Debug.Assert(MathUtil.Cos(angle2) != 0);

                g = (1 - sat) / 3;
                b = (1 + (sat * MathUtil.Cos(angle1) / MathUtil.Cos(angle2))) / 3;
                r = 1 - g - b;

                r = r * scale;
                g = g * scale;
                b = b * scale;
            }

            if (r < 0) r = 0;
            else if (1 < r) r = 1;
            if (g < 0) g = 0;
            else if (1 < g) g = 1;
            if (b < 0) b = 0;
            else if (1 < b) b = 1;

            return Pixels.ToPixel(255, (Byte)(r * 255), (Byte)(g * 255), (Byte)(b * 255));
   
        }


        // hue 는 0 ~360으로 정규화되지 않았을 수 있다.
        public static void RgbToHsl(Byte red, Byte green, Byte blue, ref Float hue, ref Float sat, ref Float lum) {


            // rgb 값을 0 ~ 1의 비율로 바꾼다.
            Ratio r = (Ratio)red / 255;
            Ratio g = (Ratio)green / 255;
            Ratio b = (Ratio)blue / 255;


            Ratio minVal = MathUtil.Min(r, MathUtil.Min(g, b));
            Ratio maxVal = MathUtil.Max(r, MathUtil.Max(g, b));
            Ratio delta = maxVal - minVal;

            // luminance
            lum = (minVal + maxVal) / 2;

            // saturation
            sat = 0;
            if (0 < lum && lum < 1) {
                sat = delta / (lum < 0.5F ? (2 * lum) : (2 - 2 * lum));
            }

            // hue 
            if (delta > 0) {
                if (maxVal == r && maxVal != g) {
                    hue = (g - b) / delta;
                }
                if (maxVal == g && maxVal != b) {
                    hue = (2 + (b - r) / delta);
                }
                if (maxVal == b && maxVal != r) {
                    hue = (4 + (r - g) / delta);
                }
                hue = hue * 60;
            }
        }

        public static void HslToRgb(Float hue, Float sat, Float lum, ref Byte redVal, ref Byte greenVal, ref Byte blueVal) {
            Debug.AssertThrow(0 <= hue && hue <= 360, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= sat && sat <= 1, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= lum && lum <= 1, eErrorCode.OutOfBoundary);

            Ratio r = 0;
            Ratio g = 0;
            Ratio b = 0;

            if (hue < 120) {
                r = (120 - hue) / 60;
                g = hue / 60;
                b = 0;
            }
            else if (hue < 240) {
                r = 0;
                g = (240 - hue) / 60;
                b = (hue - 120) / 60;
            }
            else {
                r = (hue - 240) / 60;
                g = 0;
                b = (360 - hue) / 60;
            }

            // 속도 때문에 if 문 사용
            //r = MathUtil.Min(r, 1);
            //g = MathUtil.Min(g, 1);
            //b = MathUtil.Min(b, 1);

            if (1 < r) r = 1;
            if (1 < g) g = 1;
            if (1 < b) b = 1;

            Ratio red = 2 * sat * r + (1 - sat);
            Ratio green = 2 * sat * g + (1 - sat);
            Ratio blue = 2 * sat * b + (1 - sat);

            if (lum < 0.5) {
                r = lum * red;
                g = lum * green;
                b = lum * blue;
            }
            else {
                r = (1 - lum) * red + 2 * lum - 1;
                g = (1 - lum) * green + 2 * lum - 1;
                b = (1 - lum) * blue + 2 * lum - 1;
            }

            // 속도 때문에 if 문 사용
            //r = MathUtil.Clamp(r, 0, 1);
            //g = MathUtil.Clamp(g, 0, 1);
            //b = MathUtil.Clamp(b, 0, 1);
            if (r < 0) r = 0;
            else if (1 < r) r = 1;
            if (g < 0) g = 0;
            else if (1 < g) g = 1;
            if (b < 0) b = 0;
            else if (1 < b) b = 1;

            redVal = (Byte)(r * 255);
            greenVal = (Byte)(g * 255);
            blueVal = (Byte)(b * 255);

        }
        
        public static Pixel HslToRgb(Float hue, Float sat, Float lum) {
            Byte r = 0;
            Byte g = 0;
            Byte b = 0;
            HslToRgb(hue, sat, lum, ref r, ref g, ref b);
            return (Pixel)((0xFF000000) | (Pixel)(r << 16) | (Pixel)(g << 8) | (Pixel)(b));
 
        }


        // YUV : TV 방송규격에서 사용하는 컬러 표현 방식.
        // y : 0 ~ 255 임
        // u : 0 ~128
        // v : 0 ~ 128
        public static void RgbToYuv(Byte red, Byte green, Byte blue, ref Float y, ref Float u, ref Float v) {

            y = 0.299F * red + 0.587F * green + 0.114F * blue;
            u = -0.169F * red - 0.332F * green + 0.5F * blue + 128;
            v = 0.5F * red - 0.419F * green - 0.0813F * blue + 128;
        }

        public static void YuvToRgb(Float y, Float u, Float v, ref Byte r, ref Byte g, ref Byte b) {

            r = (Byte)(y + (1.4075F * (v - 128)));
            g = (Byte)(y - 0.3455 * (u - 128) - (0.7169F * (v - 128)));
            b = (Byte)(y + (1.779F * (u - 128)));
        }



        // 1000~20000K 까지 지원
        public static Pixel ColorTemperatureToRgb(Float kelvin) {

            Pixel[] colors = new Pixel[] {
                0xffff3800, // 1000K
                0xffff5300, // 1200K
                0xffff6500, // 1400K
                0xffff7300, // 1600K
                0xffff7e00, // 1800K
                0xffff8912, // 2000K
                0xffff932c, // 2200K
                0xffff9d3f, // 2400K
                0xffffa54f, // 2600K
                0xffffad5e, // 2800K
                0xffffb46b, // 3000K
                0xffffbb78, // 3200K
                0xffffc184, // 3400K
                0xffffc78f, // 3600K
                0xffffcc99, // 3800K
                0xffffd1a3, // 4000K
                0xffffd5ad, // 4200K
                0xffffd9b6, // 4400K
                0xffffddbe, // 4600K
                0xffffe1c6, // 4800K
                0xffffe4ce, // 5000K
                0xffffe8d5, // 5200K
                0xffffebdc, // 5400K
                0xffffeee3, // 5600K
                0xfffff0e9, // 5800K
                0xfffff3ef, // 6000K
                0xfffff5f5, // 6200K
                0xfffff8fb, // 6400K
                //6500은 걍 흰색으로 하여 아무변화가 없게 한다.
                0xfffef9ff, // 6600K
                0xfff9f6ff, // 6800K
                0xfff5f3ff, // 7000K
                0xfff0f1ff, // 7200K
                0xffedefff, // 7400K
                0xffe9edff, // 7600K
                0xffe6ebff, // 7800K
                0xffe3e9ff, // 8000K        
                0xffe0e7ff, // 8200K    
                0xffdde6ff, // 8400K    
                0xffdae4ff, // 8600K    
                0xffd8e3ff, // 8800K    
                0xffd6e1ff, // 9000K        
                0xffd3e0ff, // 9200K    
                0xffd1dfff, // 9400K    
                0xffcfddff, // 9600K    
                0xffcedcff, // 9800K    
                0xffccdbff, // 10000K   
                0xffcadaff, // 10200K   
                0xffc9d9ff, // 10400K   
                0xffc7d8ff, // 10600K   
                0xffc6d8ff, // 10800K   
                0xffc4d7dd, // 11000K   
                0xffc3d6ff, // 11200K   
                0xffc2d5ff, // 11400K   
                0xffc1d4ff, // 11600K   
                0xffc0d4ff, // 11800K   
                0xffbfd3ff, // 12000K   
                0xffbed2ff, // 12200K   
                0xffbdd2ff, // 12400K   
                0xffbcd1ff, // 12600K   
                0xffbbd1ff, // 12800K   
                0xffbad0ff, // 13000K   
                0xffb9d0ff, // 13200K   
                0xffb8cfff, // 13400K   
                0xffb7cfff, // 13600K   
                0xffb7ceff, // 13800K   
                0xffb6ceff, // 14000K   
                0xffb5cdff, // 14200K   
                0xffb5cdff, // 14400K   
                0xffb4ccff, // 14600K   
                0xffb3ccff, // 14800K   
                0xffb3ccff, // 15000K   
                0xffb2cbff, // 15200K   
                0xffb2cbff, // 15400K   
                0xffb1caff, // 15600K   
                0xffb1caff, // 15800K   
                0xffb0caff, // 16000K   
                0xffafc9ff, // 16200K   
                0xffafc9ff, // 16400K   
                0xffafc9ff, // 16600K   
                0xffaec9ff, // 16800K   
                0xffaec8ff, // 17000K   
                0xffadc8ff, // 17200K   
                0xffadc8ff, // 17400K   
                0xffacc7ff, // 17600K   
                0xffacc7ff, // 17800K   
                0xffacc7ff, // 18000K   
                0xffabc7ff, // 18200K   
                0xffabc6ff, // 18400K   
                0xffaac6ff, // 18600K   
                0xffaac6ff, // 18800K   
                0xffaac6ff, // 19000K   
                0xffa9c6ff, // 19200K   
                0xffa9c5ff, // 19400K   
                0xffa9c5ff, // 19600K   
                0xffa9c5ff, // 19800K   
                0xffa8c5ff // 20000K   


            };

            kelvin = MathUtil.Clamp(kelvin, 1000, 20000);
            kelvin = (kelvin - 1000) / 100; // 0, 2, 4, 6... 190의 수열로 바꿈

            if (MathUtil.Round(kelvin) == 55) {
                return 0xffffff; // 6500K에서는 아무변화가 없게 한다.
            }

            return colors[MathUtil.Round(MathUtil.Round(kelvin / 2))];

        }

        // 두 색상을 혼합하여 a1, r1, g1, b1에 저장
        // mix = 1이면 a2, r2, g2, b2가 됨
        public static void MixColors(
            Float mix,
            ref Byte a1, ref Byte r1, ref Byte g1, ref Byte b1,
            Byte a2, Byte r2, Byte g2, Byte b2
        ) {
            Debug.Assert(0 <= mix && mix <= 1);

            a1 = (Byte)(a1 + mix * (a2 - a1));
            r1 = (Byte)(r1 + mix * (r2 - r1));
            g1 = (Byte)(g1 + mix * (g2 - g1));
            b1 = (Byte)(b1 + mix * (b2 - b1));
        }


    }
}
