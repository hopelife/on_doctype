﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Int = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Index = System.Int32;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {
    // 
    public class Gamma {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private LookupTable RTable = LookupTable.Create();
        private LookupTable GTable = LookupTable.Create();
        private LookupTable BTable = LookupTable.Create();

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // gamma : 0 ~ 3. 1이면 원본
        private Gamma(Ratio rGamma, Ratio gGamma, Ratio bGamma) {

            rGamma = MathUtil.Clamp(rGamma, 0, 3);
            gGamma = MathUtil.Clamp(rGamma, 0, 3);
            bGamma = MathUtil.Clamp(rGamma, 0, 3);

            Int temp;
            for (Index i = 0; i < 256; ++i) {

                temp = (Int)((255F * MathUtil.Pow(i / 255F, 1F / rGamma)) + 0.5F);
                RTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);

                temp = (Int)((255F * MathUtil.Pow(i / 255F, 1F / gGamma)) + 0.5F);
                GTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);

                temp = (Int)((255F * MathUtil.Pow(i / 255F, 1F / bGamma)) + 0.5F);
                BTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);

            }

        }

        public static Gamma Create(Ratio rGamma, Ratio gGamma, Ratio bGamma) {
            return new Gamma(rGamma, gGamma, bGamma);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.R.Length; ++i) {
               
                pixels.R[i] = RTable.Data[pixels.R[i]];
                pixels.G[i] = GTable.Data[pixels.G[i]];
                pixels.B[i] = BTable.Data[pixels.B[i]];
            }
        }
    }
}