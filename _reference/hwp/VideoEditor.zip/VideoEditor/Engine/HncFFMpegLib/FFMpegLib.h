#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include "Difine.h"
using namespace std;



// FFMpeg ��� ���� ����
extern "C" {
	#include "./FFMpeg/libavutil/opt.h"
	#include "./FFMpeg/libavcodec/avcodec.h"
	#include "./FFMpeg/libavutil/audioconvert.h"
	#include "./FFMpeg/libavutil/common.h"
	#include "./FFMpeg/libavutil/imgutils.h"
	#include "./FFMpeg/libavutil/mathematics.h"
	#include "./FFMpeg/libswscale/swscale.h"
	#include "./FFMpeg/libavformat/avformat.h"
	#include "./FFMpeg/libavutil/samplefmt.h"
}


class OutputFileInfo {
public:
	char* filePath;
	char* extName;
	double frameRate;
	AVFormatContext* outputFormatContext;
	AVCodecContext* outputCodecContext;
	AVCodec* encoderCodec;
	
public:
	OutputFileInfo() {
		filePath = NULL;
		
		frameRate = 30.0;
		outputFormatContext = NULL;
		outputCodecContext = NULL;
		encoderCodec = NULL;
	}

	OutputFileInfo(const char* path, double frameRate) {
		filePath = new char[strlen(path)];
		strcpy_s(filePath, strlen(filePath), path);
		
		frameRate = frameRate;
		outputFormatContext = NULL;
		outputCodecContext = NULL;
		encoderCodec = NULL;
	}

	~OutputFileInfo() {
		if (outputCodecContext != NULL) {
			avcodec_close(outputCodecContext);
			avio_close(outputFormatContext->pb);
			outputFormatContext->pb = NULL;
		}
		
		if (outputFormatContext != NULL) {
//			avformat_free_context(&outputFormatContext);
		}
	}
};









class TimelineInfo {
public:
	char* filePath;
	int64_t startFrame;
	int64_t endFrame;
	int64_t lengthFrame;
	int videoStreamIndex;
	AVFormatContext* inputFormatContext;
	AVCodecContext* inputCodecContext;
	AVCodec* decoderCodec;

	TimelineInfo(const char* path, int64_t start, int64_t end) {
		filePath = new char[strlen(path)];
		strcpy_s(filePath, strlen(filePath), path);
		startFrame = start;
		endFrame = end;
		lengthFrame = endFrame - startFrame;

		videoStreamIndex = -1;
		inputFormatContext = NULL;
		inputCodecContext = NULL;
		decoderCodec = NULL;
	}

	~TimelineInfo() {
		if (inputFormatContext != NULL) {
			avcodec_close(inputCodecContext);
			avio_close(inputFormatContext->pb);
			inputFormatContext->pb = NULL;
		}
		
		if (inputFormatContext != NULL) {
			avformat_close_input(&inputFormatContext);
		}
	}
};

//-------------------------------------------------------------------------------------------------
// FFMpeg ���� Ŭ����
class FFMpegLib
{
	vector<TimelineInfo*> timelineInfoList;
	OutputFileInfo* outputFileInfo;

public:
	// ������ & �Ҹ���
	FFMpegLib(void);
	~FFMpegLib(void);

	// ��� �Լ�
	void NewTimeline();
	int AddTimelineInfo(TimelineInfo* info);

	// ����
	int CreateOutputfileInfo();
	// outputFilePath ����
	int SetOuputFilePath(const char* outputFilePath);
	// Ȯ���� ����
	int SetExtName(const char* extName);
	// encoder �ڵ� ����
	int SetVideoEncoderInfo(AVCodecID);
	int SetAudioEncoderInfo(AVCodecID);
	// ������ �ӵ� ����
	int SetFrameRate(AVCodecContext* outputCodecContext, int frameRate);
	// ���� ���� ����
	int OpenOutputFile();

	int SetOuputFileInfo(const char* outputFilePath);

	int Export(const char* outputFilePath);
	int SDLPlay(const char* filePath);
	int GetFrame(const char* inputFilePath, int frameIndex, Frame* output, int width=-1, int height=-1);
	int GetFrame(const char* inputFilePath, int count, int* frameIndex, Frame** output, int width=-1, int height=-1);
	int GetVideoInfo(const char* inputFilePath, VideoInfo* info);
	int Export(const char* inputFilePath, const char* outputFilePath);
	
	int VideoEncoder(const char* filename, enum AVCodecID codec_id = AV_CODEC_ID_H264);
	bool SaveFrame(AVFrame* frame, enum PixelFormat fmt, int width, int height, int index);
private:
//	bool GetVideoFrame(AVFormatContext *pFormatCtx, AVCodecContext *pCodecCtx, int videoStream, AVFrame *pFrame);
	bool GetVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* outputFrame);
	bool GetDecodeVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* outputFrame);
	bool GetEncodeVideoFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet);
	bool SetVideoFrame(int64_t dts, AVFormatContext* formatContext, AVStream* stream, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* inputFrame);
	int AVFrameToImage(AVFrame* frame, int width, int height, Frame* output);

	
	int64_t SeekMS(AVStream* videoStream, int ms);

	int sws_flags; // = SWS_BICUBIC;
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// audio output

	float t;
	float tincr;
	float tincr2;
	int16_t* samples;
//	uint8_t* audio_outbuf;
//	int audio_outbuf_size;
	int audio_input_frame_size;

	AVStream* AddAudioStream(AVFormatContext* oc, AVCodec** codec, enum AVCodecID codec_id);
	int OpenAudio(AVFormatContext* oc, AVCodec* codec, AVStream* st);
	int GetAudioFrame(int16_t *samples, int frame_size, int nb_channels);
	int CloseAudio(AVFormatContext *oc, AVStream *st);
	int WriteAudioFrame(AVFormatContext* oc, AVStream* st);

	/////////////////////////////////////////////////////////////////////////////////////
	// video output
	AVFrame* picture;
	AVFrame* tmp_picture;
	uint8_t* video_outbuf;
	int frame_count;
	int video_outbuf_size;

	AVStream* AddVideoStream(AVFormatContext* oc, AVCodec** codec, enum AVCodecID codec_id);
	AVFrame* AllocPicture(enum PixelFormat pix_fmt, int width, int height);
	int OpenVideo(AVFormatContext* oc, AVCodec* codec, AVStream* st);
	int FillYuvImage(AVFrame* pict, int frame_index, int width, int height);
	int CloseVideo(AVFormatContext* oc, AVStream* st);
	int WriteVideoFrame(AVFormatContext* oc, AVStream* st);

	
};
