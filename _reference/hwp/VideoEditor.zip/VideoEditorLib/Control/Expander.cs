﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Hnc.Control
{
	// ListBox 아이템의 Grouping Style
	public enum GroupingStyle
	{
		// 그룹의 접기/펴기가 가능한 형태
		Foldable = 0,
		// 그룹의 접기/펴기가 불가능한 형태
		Foldless = 1,
		// 그룹을 표시하지 않는 형태
		Hidden = 2,
	}
   
    // ListBox의 Group에 사용되는 Expander 클래스
    public class Expander : System.Windows.Controls.Expander {

        private Border expandBorder = null;

        static Expander() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Expander), new FrameworkPropertyMetadata(typeof(Expander)));
        }

        private void InitExpandBorder(DependencyObject obj) {
            if (obj == null)
                return;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); ++i) {
                DependencyObject child = VisualTreeHelper.GetChild(obj, i);

                if (child != null) {
                    if (child is Border) {
                        if ((child as Border).Name == "Expander_ContentBorder") {
                            expandBorder = child as Border;
                        } else {
                            InitExpandBorder(child);
                        }
                    } else {
                        InitExpandBorder(child);
                    }
                }
            }
        }

        protected override void OnCollapsed() {
            base.OnCollapsed();

            if (expandBorder == null) {
                InitExpandBorder(this);
            }

            expandBorder.Height = expandBorder.ActualHeight;
            DoubleAnimation collapseAnimation =
                new DoubleAnimation(0, (Duration)TimeSpan.FromMilliseconds(200));
            expandBorder.BeginAnimation(Border.HeightProperty, collapseAnimation);
        }

        protected override void OnExpanded() {
            base.OnExpanded();

            if (expandBorder == null)
                return;

            DoubleAnimation expandAnimation =
                new DoubleAnimation(
                    (double)expandBorder.GetAnimationBaseValue(Border.HeightProperty),
                    (Duration)TimeSpan.FromMilliseconds(200)
                );
            expandAnimation.Completed += new EventHandler(expandAnimation_Completed);
            expandBorder.BeginAnimation(Border.HeightProperty, expandAnimation);
        }

        // Expander가 완전히 펼쳐지면 애니메이션 속성 및 속성값 제거
        private void expandAnimation_Completed(object sender, EventArgs e) {
            expandBorder.BeginAnimation(Border.HeightProperty, null);
            expandBorder.Height = double.NaN;
        }        
    }	
}
