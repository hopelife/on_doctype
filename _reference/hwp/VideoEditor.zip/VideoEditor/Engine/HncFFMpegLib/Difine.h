#pragma once

//-------------------------------------------------------------------------------------------------
// dll ����
#define DLLEXPORT

#ifdef DLLEXPORT
#define DLLTYPE __declspec(dllexport)
#define DLLTYPE_TEMPLATE
#else
#define DLLTYPE __declspec(dllimport)
#define DLLTYPE_TEMPLATE extern
#endif

//-------------------------------------------------------------------------------------------------
// �������� Ȯ�� define
#define FAILED 0
#define SUCCESSED 1

//-------------------------------------------------------------------------------------------------
// FFMpeg ���̺귯������ �ʿ�� �ϴ� define
#ifndef INT64_C
#define INT64_C(c) (c ## LL)
#define UINT64_C(c) (c ## ULL)
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define STREAM_DURATION   5.0
#define STREAM_FRAME_RATE 25 // 25 images/s
#define STREAM_NB_FRAMES  ((int)(STREAM_DURATION * STREAM_FRAME_RATE))
#define STREAM_PIX_FMT PIX_FMT_YUV420P // default pix_fmt

//-------------------------------------------------------------------------------------------------
// ���� frame ���忡 ���� ������ ó���ϱ� ���� ����ü
struct Frame {
	unsigned char** pixel;
	int width;
	int height;
};

struct TimeInfo {
	int hour;
	int minute;
	int second;
};

struct VideoInfo {
	int width;
	int height;
	int FrameRate;
	TimeInfo runningTime;
	int ModifyDate;
	const char* videoCodec;
	char filePath[255];
	char fileName[100];
};