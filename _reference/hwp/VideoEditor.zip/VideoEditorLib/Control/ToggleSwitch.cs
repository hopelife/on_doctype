﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Media.Animation;
using Hnc.Type;

namespace Hnc.Control {

    /// <summary>
    /// 스위치 모양의 토글 버튼입니다.
    /// </summary>
    public class ToggleSwitch : Hnc.Control.Slider {
        
        static ToggleSwitch() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ToggleSwitch), new FrameworkPropertyMetadata(typeof(ToggleSwitch)));
        }

        #region -> Properties

        /// <summary>
        /// On/Off 여부를 가져오거나 설정합니다. (True: On, False: Off)
        /// </summary>
        public bool IsChecked {

            get {
                Debug.Assert(this.Value == 0d || this.Value == 1d);

                if (this.Value == 0d)
                    return false;
                else
                    return true;
            }
            set {
                if (value)
                    this.Value = 1d;
                else
                    this.Value = 0d;

                OnToggled();
            }
        }

        #endregion

        #region -> Events

        /// <summary>
        /// 토글 스위치의 상태가 변경될 때 발생합니다.
        /// </summary>
        public event RoutedEventHandler Toggled;

        #endregion

        #region -> Private Methods

        private void OnToggled() {
            if (Toggled != null)
                Toggled(this, null);
        }

        #endregion

        #region -> Overrided Methods

        /// <summary>
        /// 토글 버튼(Thumb)을 임의의 위치로 드래그했을 때 가까운 상태(On 또는 Off)로 강제 이동시킵니다.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnThumbDragCompleted(System.Windows.Controls.Primitives.DragCompletedEventArgs e) {            

            if (this.Value > (Maximum - Minimum) / 2d)                
                this.Value = Maximum;
            else
                this.Value = Minimum;
            
            base.OnThumbDragCompleted(e);
        }

        #endregion
    }
}
