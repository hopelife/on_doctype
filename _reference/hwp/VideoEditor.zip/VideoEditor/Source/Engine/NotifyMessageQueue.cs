﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;

namespace Hnc.VideoEditor.Engine {
	class NotifyMessage {

	}

	public static class NotifyMessageQueue {
		/*
		private static readonly Object thisLock = new Object();

		static NotifyMessageQueue instance;
		public static NotifyMessageQueue Instance {
			get {
				lock (thisLock) {
					if (instance == null) {
						instance = new NotifyMessageQueue();
					}
				}
				return instance;
			}
		}
		*/
		private static Queue<String> notifyQueue = new Queue<String>();

		public static void EnQueueMessage(String message) {
			notifyQueue.Enqueue(message);
		}

		public static String DeQueueMessage() {
			return notifyQueue.Dequeue();
		}
	}
}