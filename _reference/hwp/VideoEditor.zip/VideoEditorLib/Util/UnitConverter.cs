﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Logical = System.Int32;
using Inch = System.Single;
using Int = System.Int32;
using Float = System.Single;
using Double = System.Double;
using Ratio = System.Single;
using Hnc.Util;



namespace Hnc.Util {



    // Doc에서 사용하는 단위계 정보
    public class Unit {
        private readonly Int dpi;
        public Int Dpi { get { return dpi; } }

        private Unit(Int dpi) {
            this.dpi = dpi;

        }
        public static Unit Create(Int dpi) {
            return new Unit(dpi);
        }
    }

    // 단위 변환
    public static class UnitConverter {
        public static Logical InchToLogical(Inch inch, Int dpi) {
            return MathUtil.Round(inch * dpi);
        }
        public static Int LogicalToEmu(Logical val, Int dpi) {
            Debug.AssertThrow(dpi != 0, eErrorCode.InvalidArgument);
            return MathUtil.Round((Float)val / dpi * Emu.Length);
        }
        public static Logical EmuToLogical(Int val, Int dpi) {
            Debug.AssertThrow(Emu.Length != 0, eErrorCode.DevideZero);
            return MathUtil.Round((Float)val * dpi / Emu.Length);
        }

        public static Logical PxToLogical(Int val, Int dpi) {
            return MathUtil.Round((Float)val / 96 * dpi); 
        }
        public static Int LogicalToPx(Logical val, Int dpi) {
            Debug.AssertThrow(0 < dpi, eErrorCode.DevideZero);
            return MathUtil.Round((Float)val / dpi * 96);
        }

        public static Logical DegreeToEmu(Float angle) { 
            return MathUtil.Round(angle * 60000);
        }
        public static Int RatioToEmu(Ratio val) {
            return MathUtil.Round(val * 100 * 1000);
        }
        public static Logical PxToLogical(Double px, Int dpi) {
            return MathUtil.Round((Float)(px / 96 * dpi));
        }
    }

    // EMU 단위
    public static class Emu { 
        public static Int Length {
            get { return 914400; }
        }
    }
}
