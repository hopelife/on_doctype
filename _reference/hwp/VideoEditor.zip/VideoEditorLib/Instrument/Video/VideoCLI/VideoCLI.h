/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

using namespace System;
class VideoLib;

namespace Hnc {
	namespace Instrument {
		public ref class VideoCLI {
		protected:
			VideoLib* videoLib;
			VideoInfoStruct* info;

		public:
			VideoCLI();
			virtual ~VideoCLI();	

			int GetVideoInfo(System::String^ filePath);
			System::String^ GetVideoInfoFilePath();
			System::String^ GetVideoInfoFileName();
			int GetVideoInfoWidth();
			int GetVideoInfoHeight();
			double GetVideoInfoFrameRate();
			double GetVideoInfoTotalFrame();
			System::String^ GetVideoInfoRunningTime();
			System::String^ GetVideoInfoModifyDate();
			System::String^ GetVideoInfoVideoCodec();
			System::String^ GetVideoInfoAudioCodec();
			void DeleteVideoInfo();

			Drawing::Bitmap^ GetThumbnail(System::String^ filePath, int width, int height);
			Drawing::Bitmap^ GetThumbnail(System::String^ filePath, int frameIndex);
			Drawing::Bitmap^ GetThumbnail(System::String^ filePath, int frameIndex, int width, int height);
			double GetEstimateTime(System::String^ filePath, int width, int height);

			int DeleteOutputfileInfo();
			int Export();
			int ExportEx();
			int CreateOutputfileInfo(System::String^ outputFilePath, int width, int height, int frameRate, int videoCodecID, int audioCodecID);
			int AddTimelineInfo(System::String^ filePath, int effect, int startFrame, int endFrame);
			void NewTimeline();

			int GetExportState();
			void SetExportState(int state);
			int GetExportProgress();
			bool GetExportIsCancel();
			void SetExportIsCancel(bool isCancel);
		};

	}
}
