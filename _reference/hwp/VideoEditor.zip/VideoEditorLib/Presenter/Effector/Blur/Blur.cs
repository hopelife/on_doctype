﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;

using Float = System.Single;


namespace Hnc.Presenter.ImageEffect {

    // Convolution을 사용하는 기본 Blur
    public class Blur : ConvolutionEffect {
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Blur() : base(true) {
            Float[] m = new Float[9] {
                 1.0F / 9.0F,       1.0F / 9.0F,      1.0F / 9.0F,
                 1.0F / 9.0F,       1.0F / 9.0F,      1.0F / 9.0F,
                 1.0F / 9.0F,       1.0F / 9.0F,      1.0F / 9.0F,
            };

            // simple
            //Float[] m = new Float[9] {
            //     1.0F / 14.0F,       2.0F / 14.0F,      1.0F / 14.0F,
            //     2.0F / 14.0F,       2.0F / 14.0F,      2.0F / 14.0F,
            //     1.0F / 14.0F,       2.0F / 14.0F,      1.0F / 14.0F,
            //};

            Kernel = Kernel.Create(3, 3, m);

        }
        public static Blur Create() {

            return new Blur();
        }
    }
}
