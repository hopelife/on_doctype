﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Int = System.Int32;
using Index = System.Int32;
using Pixel = System.UInt32;
using Float = System.Single;
using Byte = System.Byte;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {

    public abstract class ConvolutionEffect {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        protected Kernel Kernel { get; set; } // 가로 세로로 적용
        protected Bool IsApplyAlpha { get; set; } // 알파채널도 적용하는지의 여부

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        protected ConvolutionEffect(Bool isApplyAlpha) {
            IsApplyAlpha = isApplyAlpha;
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            Debug.AssertThrow(Kernel != null, eErrorCode.CreateFail);

            ArgbChannel target = ArgbChannel.Create(pixels.Width, pixels.Height);

            Apply(pixels, target, Kernel, IsApplyAlpha);

            if (IsApplyAlpha) {
                pixels.A = target.A;
            }
            pixels.R = target.R;
            pixels.G = target.G;
            pixels.B = target.B;
        }

        private static void Apply(ArgbChannel source, ArgbChannel target, Kernel kernel, Bool isApplyAlpha) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.AssertThrow(target != null, eErrorCode.NullArgument);
            Debug.AssertThrow(kernel != null, eErrorCode.NullArgument);


            Count width = source.Width;
            Count height = source.Height;

            Count kernelRowCount = kernel.RowCount;
            Count kernelColCount = kernel.ColCount;
            Count kernelCount = kernelRowCount * kernelColCount;

            Count kernelHalfRowCount = kernelRowCount / 2;
            Count kernelHalfColCount = kernelColCount / 2;

            Count xOffsetTemp = kernelColCount * kernelHalfRowCount + kernelHalfColCount; // xOffset 계산을 위한 상수

            Index xPos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index yPos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index xOffset = 0;
            Index yOffset = 0;
            Index targetPixelPos = 0;
            Index colorPos = 0;


            // 연산속도 향상을 위해 
            // 커널항목에 따라 0~255 의 곱셈 값을 미리 계산해 둔다.
            // 2차 배열보다는 1차 배열이 속도가 빠름
            Int[] lookupTable = new Int[kernelCount * 256];
            Index lookupPos = 0;
            for (Index i = 0; i < kernelCount; ++i) {
                for (Index j = 0; j < 256; ++j) { 
                    lookupTable[lookupPos] = (Int)(kernel.M[i] * j);
                    ++lookupPos;
                }
            }

            Int a = 0;
            Int r = 0;
            Int g = 0;
            Int b = 0;

            for (Index y = 0; y < height; ++y) {
                for (Index x = 0; x < width; ++x) {

                    if (isApplyAlpha) {
                        a = 0;
                    }
                    r = 0;
                    g = 0;
                    b = 0;

                    
                    for (Index row = -kernelHalfRowCount; row <= kernelHalfRowCount; ++row) {
                        yPos = y + row;
                        if (0 <= yPos && yPos < height) {
                            yOffset = yPos * width;
                        }
                        // 이미지의 경계부분은 Kernel을 적용할 수 없으므로, 걍 경계점에 있는 것을 사용하여 convolution을 적용
                        else {
                            yOffset = y * width;
                        }

                        // 속도 향상을 위해 상수값 추출
                        // xOffset = kernelColCount * (row + kernelHalfRowCount) + kernelHalfColCount;
                        xOffset = kernelColCount * row + xOffsetTemp;

                        for (Index col = -kernelHalfColCount; col <= kernelHalfColCount; ++col) {
                            if (xOffset != 0) {
                                xPos = x + col;
                                if (!(0 <= xPos && xPos < width)) {
                                    xPos = x;
                                }
                            }

                            lookupPos = (xOffset + col) * 256; // kernel에 따라 256개의 색상을 미리 저장하고 있음
                            colorPos = yOffset + xPos;

                            if (isApplyAlpha) {
                                a += lookupTable[lookupPos + source.A[colorPos]];
                            }

                            r += lookupTable[lookupPos + source.R[colorPos]];
                            g += lookupTable[lookupPos + source.G[colorPos]];
                            b += lookupTable[lookupPos + source.B[colorPos]];
                        }

                    }



                    if (isApplyAlpha) {
                        a = (a < 0) ? 0 : ((255 < a) ? 255 : a);
                        target.A[targetPixelPos] = (Byte)a;
                    }

                    r = (r < 0) ? 0 : ((255 < r) ? 255 : r);
                    g = (g < 0) ? 0 : ((255 < g) ? 255 : g);
                    b = (b < 0) ? 0 : ((255 < b) ? 255 : b);

                    target.R[targetPixelPos] = (Byte)r;
                    target.G[targetPixelPos] = (Byte)g;
                    target.B[targetPixelPos] = (Byte)b;


                    ++targetPixelPos;

                }

            }

        }
    }

}