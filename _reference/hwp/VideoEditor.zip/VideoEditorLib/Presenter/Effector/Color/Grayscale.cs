﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Pixel = System.UInt32;
using Byte = System.Byte;
using Bool = System.Boolean;
using Int = System.Int32;
using Index = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // 회색조
    public class Grayscale {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        private GrayscaleTable GrayscaleTable = GrayscaleTable.Instance;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Grayscale() {
        }

        public static Grayscale Create() {
            return new Grayscale();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels.R != null, eErrorCode.NullArgument);

            Byte temp;
            for (Index i = 0; i < pixels.R.Length; ++i) {
                temp = GrayscaleTable.GetAt(pixels.R[i], pixels.G[i], pixels.B[i]);

                pixels.R[i] = temp;
                pixels.G[i] = temp;
                pixels.B[i] = temp;
            }
        }
    }


}