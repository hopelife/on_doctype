/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include <stdio.h>
#include <windows.h>
#include <fstream>
#include <ios>
#include "Debug.h"

using namespace std;

clock_t Debug::start = 0L;
clock_t Debug::end = 0L;
Char* Debug::subject = "NoSubject";
Char* Debug::lastDebugMessage = "NoMassage";
Char* Debug::outputFilePath = "c:\\videoeditor.txt";

Debug::Debug(void) {
}

Debug::Debug(const Char* subject) {
	this->subject = (Char*) subject;
}

Debug::~Debug(void) {
}

void Debug::Start() {
	start = clock();
}

void Debug::End() {
	end = clock();

	Char debugString[100];
	sprintf_s(debugString, 100, "%s : %d\n", subject, end - start);
	OutputDebugString((const Char*)debugString);
}

clock_t Debug::Result() {
	Double duration = 0;
	if (CLOCKS_PER_SEC != 0) {
		duration = (Double) (end - start) / (Double) CLOCKS_PER_SEC;
	}

	Char debugString[100];
	sprintf_s(debugString, 100, "%2.1f seconds\n", duration);
	OutputDebugString((const Char*)debugString);
	return end - start;
}

double Debug::ResultPerSEC() {
	Double duration = 0;
	if (CLOCKS_PER_SEC != 0) {
		duration = (Double) (end - start) / (Double) CLOCKS_PER_SEC;
	}
	return duration;
}

const Char* Debug::GetLastdebugMessage() {
	return lastDebugMessage;
}

void Debug::StartPrintTextFile() {
#ifdef _DEBUG
	fstream fs;
	fs.open(outputFilePath, ios_base::out);

	if (fs.is_open() == true) {
		fs.close();
	}
#endif
}

void Debug::PrintTextFile(const Char* string) {
#ifdef _DEBUG
	fstream fs;
	fs.open(outputFilePath, ios_base::out | ios_base::app);

	if (fs.is_open() == true) {
		fs <<string;
		fs.close();
	}
#endif
}

void Debug::Trace(Char* string) {
#ifdef _DEBUG
	lastDebugMessage = string;
	OutputDebugString("Debug::");
	OutputDebugString(lastDebugMessage);
	OutputDebugString("\n");
#endif
}
