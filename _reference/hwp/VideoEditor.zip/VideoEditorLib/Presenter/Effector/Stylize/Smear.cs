﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {

    // 이미지를 직선, 십자가, 사각형등으로 방향성 있게 mix 하여 표시한다.
    public class Smear {
        public enum eType { 
            Cross,
            CrossHatch,
            Line,
            Circle,
            Rect
        }
        
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private eType Type = eType.Cross;

        private Ratio Density = 0.75F; // 출력 밀도 0 ~ 1
        private Count Distance = 30; // 변형시킬 픽셀거리 1 ~
        private Ratio Mix = 0.5F; // 색 혼합 정도 0 ~ 1
        private Degree Angle = Degree.Create(0); // 선형일때의 회전각 
        private Bool IsWhiteBackground = false;


        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Smear(eType type, Ratio density, Count distance, Ratio mix, Degree angle, Bool isWhiteBackground) {
            Debug.AssertThrow(angle != null, eErrorCode.NullArgument);

            Type = type;
            Density = MathUtil.Clamp(density, 0, 1);
            Distance = distance < 1 ? 1 : distance;
            Mix = MathUtil.Clamp(mix, 0, 1);
            Angle = angle;
            IsWhiteBackground = isWhiteBackground;

        }
        public static Smear Create(eType type, Ratio density, Count distance, Ratio mix, Degree angle, Bool isWhiteBackground) {

            return new Smear(type, density, distance, mix, angle, isWhiteBackground);
        }
        
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            System.Random Random = new System.Random();


            Count width = pixels.Width;
            Count height = pixels.Height;
            Index targetPos;
            Index sourcePos;
            
            ArgbChannel background = null;
            
            if (IsWhiteBackground) {

                background = ArgbChannel.Create(width, height);
                for (Index i = 0; i < pixels.R.Length; ++i) {
                    background.A[i] = 255;
                    background.R[i] = 255;
                    background.G[i] = 255;
                    background.B[i] = 255;
                }
            }
            else {
                background = pixels.Clone();
            }


            switch (Type) {

                case eType.Cross:
                    {
                        Count count = (Count)(2 * Density * width * height / (Distance + 1));

                        for (Index i = 0; i < count; ++i) {
                            Index sx = Random.Next() % width;
                            Index sy = Random.Next() % height;
                            Count length = Random.Next() % Distance + 1;

                            for (Index x = sx - length; x < sx + length + 1; ++x) {
                                if (0 <= x  && x < width) {
                                    targetPos = sy * width + x;
                                    sourcePos = sy * width + sx;
                                    ColorUtil.MixColors(
                                        Mix,
                                        ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                        pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                    );
                                }
                            }
                            for (Index y = sy - length; y < sy + length + 1; ++y) {
                                if (0 <= y && y < height) {
                                    targetPos = y * width + sx;
                                    sourcePos = sy * width + sx;

                                    ColorUtil.MixColors(
                                        Mix,
                                        ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                        pixels.A[sourcePos], pixels.R[sourcePos],pixels.G[sourcePos], pixels.B[sourcePos]
                                    );
                                }
                            }
                        }
                    }
                    break;
                case eType.CrossHatch: {
                        Count count = (Count)(2 * Density * width * height / (Distance + 1));

                        for (Index i = 0; i < count; ++i) {
                            Index sx = Random.Next() % width;
                            Index sy = Random.Next() % height;
                            Count length = Random.Next() % Distance + 1;

                            for (Index delta = - length; delta < length + 1; ++delta) {
                                if (0 <= (sx + delta) && (sx + delta) < width && 0 <= (sy + delta) && (sy + delta) < height &&
                                    0 <= (sx - delta) && (sx - delta) < width) {
                                    targetPos = (sy + delta) * width + (sx + delta);
                                    sourcePos = sy * width + sx;
                                    ColorUtil.MixColors(
                                        Mix,
                                        ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                        pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                    );

                                    targetPos = (sy + delta) * width + (sx - delta);
                                    ColorUtil.MixColors(
                                        Mix,
                                        ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                        pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                    );

                                }
                            }
                        }
                    }
                    break;

                case eType.Line:
                    {
                        Count count = (Count)(4 * Density * width * height / (Distance + 1));
                        Float sinAngle = (Float)MathUtil.Sin(MathUtil.ToRadian(Angle.Value));
                        Float cosAngle = (Float)MathUtil.Cos(MathUtil.ToRadian(Angle.Value));


                        for (Index i = 0; i < count; ++i) {
                            Index sx = Random.Next() % width;
                            Index sy = Random.Next() % height;
                            Count length = Random.Next() % Distance;
                            Count dx = (Count)(length * cosAngle);
                            Count dy = (Count)(length * sinAngle);

                            Index x0 = sx - dx;
                            Index y0 = sy - dy;
                            Index x1 = sx + dx;
                            Index y1 = sy + dy;
                            Index x, y, d, incrE, incrNE, ddx, ddy;

                            if (x1 < x0) {
                                ddx = -1;
                            }
                            else {
                                ddx = 1;
                            }
                            if (y1 < y0) {
                                ddy = -1;
                            }
                            else {
                                ddy = 1;
                            }

                            dx = MathUtil.Abs(x1 - x0);
                            dy = MathUtil.Abs(y1 - y0);
                            x = x0;
                            y = y0;

                            if (0 <= x && x < width && 0 <= y && y < height) {

                                targetPos = y * width + x;
                                sourcePos = sy * width + sx;
                                ColorUtil.MixColors(
                                    Mix,
                                    ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                    pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                );

                            }
                            // 가로가 더 긴경우
                            if (dy < dx) {
                                d = 2 * dy - dx;
                                incrE = 2 * dy;
                                incrNE = 2 * (dy - dx);

                                while (x != x1) {
                                    if (d <= 0)
                                        d += incrE;
                                    else {
                                        d += incrNE;
                                        y += ddy;
                                    }
                                    x += ddx;
                                    if (0 <= x && x < width && 0 <= y && y < height) {
                                        targetPos = y * width + x;
                                        sourcePos = sy * width + sx;
                                        ColorUtil.MixColors(
                                            Mix,
                                            ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                            pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                        );
                                    }
                                }
                            }

                            else {
                                d = 2 * dx - dy;
                                incrE = 2 * dx;
                                incrNE = 2 * (dx - dy);

                                while (y != y1) {
                                    if (d <= 0) {
                                        d += incrE;
                                    }
                                    else { 
                                        d += incrNE;
                                        x += ddx;
                                    }
                                    y += ddy;
                                    if (0 <= x && x < width && 0 <= y && y < height) {
                                        targetPos = y * width + x;
                                        sourcePos = sy * width + sx;
                                        ColorUtil.MixColors(
                                            Mix,
                                            ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                            pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                        );

                                    }
                                }
                            }
                        }

                    }
                    break;
                case eType.Circle:
                case eType.Rect:
                    {
                        Count radius = Distance + 1;
                        Count radius2 = radius * radius;
                        Count count = (Count)(2 * Density * width * height / radius2);

                        for (Index i = 0; i < count; ++i) {
                            Index sx = Random.Next() % width;
                            Index sy = Random.Next() % height;
                            Count length = Random.Next() % Distance + 1;

                            for (Index x = sx - radius; x < sx + radius + 1; ++x) {
                                for (Index y = sy - radius; y < sy + radius + 1; ++y) {
                                    int f;

                                    if (Type == eType.Circle) {
                                        f = (x - sx) * (x - sx) + (y - sy) * (y - sy);
                                    }
                                    else {
                                        f = 0;
                                    }
                                    if (0 <= x && x < width && 0 <= y && y < height && f <= radius2) {
                                        targetPos = y * width + x;
                                        sourcePos = sy * width + sx;

                                        ColorUtil.MixColors(
                                             Mix,
                                             ref background.A[targetPos], ref background.R[targetPos], ref background.G[targetPos], ref background.B[targetPos],
                                             pixels.A[sourcePos], pixels.R[sourcePos], pixels.G[sourcePos], pixels.B[sourcePos]
                                         );
                                    }
                                }
                            }
                        }
                    }
                    break;
            }

            pixels.A = background.A;
            pixels.R = background.R;
            pixels.G = background.G;
            pixels.B = background.B;

        }



    }
}