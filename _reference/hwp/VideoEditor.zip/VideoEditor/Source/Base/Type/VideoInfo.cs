﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Type {
	using Int = System.Int32;
	using Index = System.Int32;
	using Frame = System.Double;
	using String = System.String;
	using Bool = System.Boolean;
	using System.Collections.Generic;
	using System.Windows.Controls;

	public class VideoInfo : TimelineInfo {

		#region 멤버변수
		private String _filePath;
		private FrameScope _videoScope;
		private List<Int> _effectList = new List<Int>();
		private Image _thumbnailImage = null;
		#endregion // 멤버변수

		#region Property
		public FrameScope VideoScope {
			get {
				return _videoScope;
			}
			set {
				_videoScope = value.Clone();
			}
		}

		public String FilePath {
			get {
				return _filePath;
			}
			set {
				_filePath = (String)value.Clone();
			}
		}

		public List<Int> EffectList {
			get {
				return _effectList;
			}
			set {
				_effectList = value;
			}
		}

		public Image ThumbnailImage {
			get {
				return _thumbnailImage;
			}
			set {
				_thumbnailImage = value;
			}
		}
		#endregion // Property

		#region 생성자
		private VideoInfo() {
			_id = -1;
			_timelineScope = FrameScope.Create();
			_totalFrame = 0;
			_filePath = "";
			_videoScope = FrameScope.Create();
			_thumbnailImage = null;
		}

		private VideoInfo(Index id, FrameScope timelineScope, Frame totalFrame, String path, FrameScope videoScope) {
			_id = id;
			_timelineScope = timelineScope.Clone();
			_totalFrame = totalFrame;
			_filePath = path;
			_videoScope = videoScope.Clone();
			_thumbnailImage = null;
		}

		private VideoInfo(VideoInfo other) {
			_id = other._id;
			_timelineScope = other._timelineScope.Clone();
			_totalFrame = other._totalFrame;
			_filePath = (String)other._filePath.Clone();
			_videoScope = other._videoScope.Clone();
			_thumbnailImage = other.ThumbnailImage;
		}
		#endregion // 생성자

		#region Create
		public new static VideoInfo Create() {
			return new VideoInfo();
		}

		public static VideoInfo Create(Index id, FrameScope timelineScope, Frame totalFrame, String path, FrameScope videoScope) {
			return new VideoInfo(id, timelineScope, totalFrame, path, videoScope);
		}

		public static VideoInfo Create(VideoInfo other) {
			return new VideoInfo(other);
		}
		#endregion // Create

		#region override
		public override TimelineInfo Clone() {
			return new VideoInfo(this);
		}

		public override void Copy(TimelineInfo other) {
			VideoInfo videoOther = other as VideoInfo;

			_id = videoOther._id;
			_timelineScope = videoOther._timelineScope.Clone();
			_totalFrame = videoOther._totalFrame;
			_filePath = (String)videoOther._filePath.Clone();
			_videoScope = videoOther._videoScope.Clone();

			OnPropertyCahnged(ID.ToString());
		}

		public override Bool Equals(System.Object obj) {
			VideoInfo other = obj as VideoInfo;

			if (base.Equals(obj) == false) {
				return false;
			}

			if (_filePath.Equals(other._filePath) == false) {
				return false;
			}

			if (_videoScope != other._videoScope) {
				return false;
			}

			return true;
		}

		public override Int GetHashCode() {
			return this.GetHashCode();
		}
		#endregion // override
	}
}