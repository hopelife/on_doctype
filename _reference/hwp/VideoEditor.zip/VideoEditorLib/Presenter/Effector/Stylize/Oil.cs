﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {
    // Oil로 렌더링한듯한 효과
    // 픽셀주변영역 Radius * 2 + 1만큼 히스토그램을 구한후 최대 히스토그램인 색상을 찾아 그 평균색으로 채운다.
    // 속도 향상을 위한 개선
    // 1. 히스토그램은 각 픽셀단위로 이루어져 있으므로 x 증가시마다 불필요한 히스토그램은 감소시키고 필요한 값을 증가시킨다.
    // 2. 주변 픽셀의 각 칼럼단위로 히스토그램 최대값의 Index를 colMaxIndex에 저장해두어
    //    최대값 탐색시 historam 갯수와 Radius * 2 + 1 중 크기를 비교하여 둘중 1가지 방식으로 검색하게 한다.
    // 
    public class Oil {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Count Levels = 32; // 2 ~ 256
        private Count Radius = 4; // 오일 효과를 주기위해 처리할 경계 반경. Radius * 2 + 1 크기에서 히스토그램 최대값 사용

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Oil(Count level, Count radius) {
            Levels = MathUtil.Clamp(level, 2, 256);
            Radius = MathUtil.Clamp(radius, 1, 20); 

        }
        public static Oil Create(Count level, Count radius) {

            return new Oil(level, radius);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        public void Apply(Ycbcr255Channel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);


            if (Levels < Radius * 2 + 1) {
                ApplyFindMaxUsingLevel(pixels);
            }
            else {
                ApplyFindMaxUsingIndex(pixels);
            }
        }

        // ApplyFindMaxUsingIndex 와 동일하나 histogram 최대값 탐색시 직접검색한다.
        // 엄청난 코드 중복이나 하나의 함수를 합칠경우 중첩된 for문내에 if문이 필요하게 되어
        // 0.00000001초라도 줄이고자 별도의 함수로 구현.
        public void ApplyFindMaxUsingLevel(Ycbcr255Channel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;
            Count width1 = width - 1;
            Count height1 = height - 1;
            Count radius2 = Radius + Radius;

            Count[] histogram = new Count[Levels];
            Int[] total = new Int[Levels];
            Byte[] target = new Byte[width * height];

            Index targetPixelPos = 0;
            Index startPos;

            Int Y;
            Int iY;
            Int yPos = 0;
            Int xPos = 0;

            Int yPos1 = 0;
            Int yPos2 = 0;

            Int removePos = 0;
            Int insertPos = 0;
            Index maxIndex = 0;
            Count maxHistogram;
            Bool needMaxCalc = false; // 최대값 탐색이 필요한지의 여부
            Index x, y, i, row, col;


            for (y = 0; y < height; ++y) {
                // 히스토그램 초기화
                for (i = 0; i < Levels; ++i) {
                    histogram[i] = total[i] = 0;
                }
                maxIndex = 0;
                maxHistogram = 0;

                // x = 0에서 range 영역에서의 histogram을 구함
                for (row = -Radius; row <= Radius; ++row) {
                    yPos = y + row;
                    // 그림 외부
                    if (yPos < 0) {
                        yPos = 0;
                    }
                    if (height <= yPos) {
                        yPos = height1;
                    }
                    startPos = yPos * width;

                    for (col = -Radius; col <= Radius; ++col) {

                        xPos = col;
                        if (xPos < 0) {
                            xPos = 0;
                        }
                        if (width <= xPos) {
                            xPos = width1;
                        }

                        Y = pixels.Y[startPos + xPos];

                        iY = Y * Levels / 256;

                        total[iY] += Y;

                        ++histogram[iY];

                        // 히스토그램 최대값 위치를 기억해둠
                        if (maxHistogram < histogram[iY]) {
                            maxHistogram = histogram[iY];
                            maxIndex = iY;
                        }
                    }

                }

                // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
                target[targetPixelPos] = (Byte)MathUtil.Round(total[maxIndex] / (Float)histogram[maxIndex]);
                ++targetPixelPos;

                yPos1 = y - Radius;
                yPos2 = y + Radius;


                // 1에서 부터 나머지를 계산
                for (x = 1; x < width; ++x) {

                    removePos = x - Radius - 1;
                    if (removePos < 0) {
                        removePos = 0;
                    }

                    insertPos = x + Radius;
                    if (width <= insertPos) {
                        insertPos = width1;
                    }

                    needMaxCalc = false;

                    // 가장 왼쪽것은 더이상 사용하지 않으므로 빼고 오른쪽 것은 추가한다.
                    for (row = yPos1; row <= yPos2; ++row) {
                        yPos = row;
                        if (yPos < 0) {
                            yPos = 0;
                        }
                        else if (height <= yPos) {
                            yPos = height1;
                        }
                        startPos = yPos * width;

                        // 왼쪽 것은 뺌
                        {
                            Y = pixels.Y[startPos + removePos];

                            iY = Y * Levels / 256;

                            total[iY] -= Y;

                            --histogram[iY];

                            // 기존에 최대값이던 것이 줄어들었으므로 최대값 연산이 필요함
                            if (maxIndex == iY) {
                                needMaxCalc = true;
                            }

                        }
                        // 오른쪽 것은 추가
                        {
                            Y = pixels.Y[startPos + insertPos];

                            iY = Y * Levels / 256;

                            total[iY] += Y;

                            ++histogram[iY];


                            if (maxHistogram < histogram[iY]) {
                                maxHistogram = histogram[iY];
                                maxIndex = iY;
                                needMaxCalc = true;
                            }
                        }
                    }


                    // Histogram의 최대값 위치를 찾음
                    if (needMaxCalc == true) {

                        // Histogram의 최대값 위치를 찾음
                        maxIndex = 0;
                        for (i = 1; i < Levels; ++i) {
                            if (histogram[maxIndex] < histogram[i]) {
                                maxIndex = i;
                            }

                        }
                    }


                    // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
                    target[targetPixelPos] = (Byte)MathUtil.Round(total[maxIndex] / (Float)histogram[maxIndex]);

                    ++targetPixelPos;
                }
            }

            pixels.Y = target;
        }

        // histogram의 Level이 많으면 최대값 탐색에 시간이 많이 걸리므로
        // histogram의 최대값을 찾기위해 각 Radius 칼럼별로 최대값의 인덱스를 저장해두고 찾는다.
        public void ApplyFindMaxUsingIndex(Ycbcr255Channel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;
            Count width1 = width - 1;
            Count height1 = height - 1;
            Count radius2 = Radius + Radius;

            Count[] histogram = new Count[Levels];
            Int[] total = new Int[Levels];
            Byte[] target = new Byte[width * height];

            // 각 픽셀마다 radius * 2 + 1 영역의 주변 픽셀 histogram의 최대값을 구해야 하므로
            // 반복횟수가 많아 속도가 오래 걸린다.
            // 이에 따라 각 Column 마다의 최대값 위치를 기억해 두고 칼럼간 비교를 하여 연산속도를 향상시킨다.
            Index[] colMaxIndex = new Index[width + Radius * 2 + 1];

            Index targetPixelPos = 0;
            Index startPos;
            Index temp;

            Int Y;
            Int iY;
            Int yPos = 0;
            Int xPos = 0;

            Int yPos1 = 0;
            Int yPos2 = 0;

            Int removePos = 0;
            Int insertPos = 0;
            Index maxIndex = 0;
            Count maxHistogram;
            Bool needMaxCalc = false; // 최대값 탐색이 필요한지의 여부
            Index x, y, i, row, col;
            

            for (y = 0; y < height; ++y) {
                // 히스토그램 초기화
                for (i = 0; i < Levels; ++i) {
                    histogram[i] = total[i] = 0;
                }
                maxIndex = 0;
                maxHistogram = 0;

                // x = 0에서 range 영역에서의 histogram을 구함
                for (row = -Radius; row <= Radius; ++row) {
                    yPos = y + row;
                    // 그림 외부
                    if (yPos < 0) {
                        yPos = 0;
                    }
                    if (height <= yPos) {
                        yPos = height1;
                    }
                    startPos = yPos * width;

                    for (col = -Radius; col <= Radius; ++col) {

                        xPos = col;
                        if (xPos < 0) {
                            xPos = 0;
                        }
                        if (width <= xPos) {
                            xPos = width1;
                        }

                        Y = pixels.Y[startPos + xPos];

                        iY = Y * Levels / 256;

                        total[iY] += Y;

                        ++histogram[iY];



                        // 히스토그램 최대값 위치를 기억해둠
                        if (maxHistogram < histogram[iY]) {
                            maxHistogram = histogram[iY];
                            maxIndex = iY;
                        }

#region ApplyFindMaxUsingLevel 과 다른 부분
                        // 현 칼럼에서의 최대값위치를 기억해둠
                        temp = col + Radius;
                        if (row == -Radius) {
                            colMaxIndex[temp] = iY;
                        } 
                        else if (histogram[colMaxIndex[temp]] < histogram[iY]) {
                            colMaxIndex[temp] = iY;
                        }
#endregion
                    }

                }

                // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
                target[targetPixelPos] = (Byte)MathUtil.Round(total[maxIndex] / (Float)histogram[maxIndex]);
                ++targetPixelPos;

                yPos1 = y - Radius;
                yPos2 = y + Radius;

                
                // 1에서 부터 나머지를 계산
                for (x = 1; x < width; ++x) {

                    removePos = x - Radius - 1;
                    if (removePos < 0) {
                        removePos = 0;
                    }

                    insertPos = x + Radius;
                    if (width <= insertPos) {
                        insertPos = width1;
                    }

                    needMaxCalc = false;

                    // 가장 왼쪽것은 더이상 사용하지 않으므로 빼고 오른쪽 것은 추가한다.
                    for (row = yPos1; row <= yPos2; ++row) {
                        yPos = row;
                        if (yPos < 0) {
                            yPos = 0;
                        }
                        else if (height <= yPos) {
                            yPos = height1;
                        }
                        startPos = yPos * width;

                        // 왼쪽 것은 뺌
                        {
                            Y = pixels.Y[startPos + removePos];

                            iY = Y * Levels / 256;

                            total[iY] -= Y;

                            --histogram[iY];

                            // 기존에 최대값이던 것이 줄어들었으므로 최대값 연산이 필요함
                            if (maxIndex == iY) {
                                needMaxCalc = true;
                            }

                        }
                        // 오른쪽 것은 추가
                        {
                            Y = pixels.Y[startPos + insertPos];

                            iY = Y * Levels / 256;

                            total[iY] += Y;

                            ++histogram[iY];


                            if (maxHistogram < histogram[iY]) {
                                maxHistogram = histogram[iY]; 
                                maxIndex = iY;
                                needMaxCalc = true;
                            }
#region ApplyFindMaxUsingLevel 과 다른 부분
                            // 현 칼럼에서의 최대값위치를 기억해둠
                            temp = x + radius2;
                            if (row == yPos1) {
                                colMaxIndex[temp] = iY;
                            }
                            else if (histogram[colMaxIndex[temp]] < histogram[iY]) {
                                colMaxIndex[temp] = iY;
                            }
#endregion
                        }
                    }


                    // Histogram의 최대값 위치를 찾음
                    if (needMaxCalc == true) {
#region ApplyFindMaxUsingLevel 과 다른 부분
                        maxIndex = x;
                        for (i = x + 1; i <= x + radius2; ++i) {
                            if (histogram[colMaxIndex[maxIndex]] < histogram[colMaxIndex[i]]) {
                                maxIndex = i;
                            }
                        }
                        maxIndex = colMaxIndex[maxIndex];
#endregion
                    }


                    // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
                    target[targetPixelPos] = (Byte)MathUtil.Round(total[maxIndex] / (Float)histogram[maxIndex]);

                    ++targetPixelPos;
                }
            }

            pixels.Y = target;
        }



        //public void Apply(Ycbcr255Channel pixels) {
        //    Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
        //    Count width = pixels.Width;
        //    Count height = pixels.Height;

        //    Index index = 0;
        //    Int[] histogram = new Int[Levels];
        //    Int[] total = new Int[Levels];
        //    Byte[] target = new Byte[width * height];


        //    int Y = 0;
        //    for (Index y = 0; y < height; ++y) {
        //        for (Index x = 0; x < width; ++x) {

        //            // 히스토그램 초기화
        //            for (Index i = 0; i < Levels; ++i) {
        //                histogram[i] = total[i] = 0;
        //            }


        //            // range 영역에서의 histogram을 구함
        //            for (int row = -Radius; row <= Radius; ++row) {
        //                int iy = y + row;
        //                int ioffset;
        //                if (0 <= iy && iy < height) {
        //                    ioffset = iy * width;
        //                    for (Index col = -Radius; col <= Radius; ++col) {
        //                        int ix = x + col;
        //                        if (0 <= ix && ix < width) {

        //                            Y = pixels.Y[ioffset + ix];

        //                            int Yi = Y * Levels / 256;

        //                            total[Yi] += Y;

        //                            histogram[Yi]++;

        //                        }
        //                    }
        //                }
        //            }

        //            Y = 0;

        //            // Histogram의 최대값 위치를 찾음
        //            for (int i = 1; i < Levels; i++) {
        //                if (histogram[Y] < histogram[i])
        //                    Y = i;

        //            }

        //            // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
        //            target[index] = (Byte)MathUtil.Round(total[Y] / (Float)histogram[Y]);


        //            index++;
        //        }
        //    }
        //    pixels.Y = target;
        //}



        //public void Apply(ArgbChannel pixels) {

        //    Count width = pixels.Width;
        //    Count height = pixels.Height;

        //    Index index = 0;
        //    Int[] rHistogram = new Int[Levels];
        //    Int[] gHistogram = new Int[Levels];
        //    Int[] bHistogram = new Int[Levels];
        //    Int[] rTotal = new Int[Levels];
        //    Int[] gTotal = new Int[Levels];
        //    Int[] bTotal = new Int[Levels];
        //    Int[] outPixels = new Int[width * height];

        //    Byte[] targetR = new Byte[width * height];
        //    Byte[] targetG = new Byte[width * height];
        //    Byte[] targetB = new Byte[width * height];

        //    int r = 0, g = 0, b = 0;
        //    for (Index y = 0; y < height; ++y) {
        //        for (Index x = 0; x < width; ++x) {

        //            // 히스토그램 초기화
        //            for (Index i = 0; i < Levels; ++i) {
        //                rHistogram[i] = gHistogram[i] = bHistogram[i] = rTotal[i] = gTotal[i] = bTotal[i] = 0;
        //            }


        //            // range 영역에서의 histogram을 구함
        //            for (int row = -Range; row <= Range; ++row) {
        //                int iy = y + row;
        //                int ioffset;
        //                if (0 <= iy && iy < height) {
        //                    ioffset = iy * width;
        //                    for (Index col = -Range; col <= Range; ++col) {
        //                        int ix = x + col;
        //                        if (0 <= ix && ix < width) {

        //                            r = pixels.R[ioffset + ix];
        //                            g = pixels.G[ioffset + ix];
        //                            b = pixels.B[ioffset + ix];

        //                            int ri = r * Levels / 256;
        //                            int gi = g * Levels / 256;
        //                            int bi = b * Levels / 256;
        //                            rTotal[ri] += r;
        //                            gTotal[gi] += g;
        //                            bTotal[bi] += b;
        //                            rHistogram[ri]++;
        //                            gHistogram[gi]++;
        //                            bHistogram[bi]++;
        //                        }
        //                    }
        //                }
        //            }

        //            r = 0;
        //            g = 0;
        //            b = 0;

        //            // Histogram의 최대값 위치를 찾음
        //            for (int i = 1; i < Levels; i++) {
        //                if (rHistogram[r] < rHistogram[i])
        //                    r = i;
        //                if (gHistogram[g] < gHistogram[i])
        //                    g = i;
        //                if (bHistogram[b] < bHistogram[i])
        //                    b = i;
        //            }

        //            // 빈도수가 제일 높은 값의 평균값을 색상으로 사용
        //            r = rTotal[r] / rHistogram[r];
        //            g = gTotal[g] / gHistogram[g];
        //            b = bTotal[b] / bHistogram[b];

        //            targetR[index] = (Byte)r;
        //            targetG[index] = (Byte)g;
        //            targetB[index] = (Byte)b;


        //            index++;
        //        }
        //    }
        //    pixels.R = targetR;
        //    pixels.G = targetG;
        //    pixels.B = targetB;
        //}
    }
}