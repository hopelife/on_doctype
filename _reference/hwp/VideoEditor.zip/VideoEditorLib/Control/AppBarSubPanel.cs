﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Hnc.Control
{
    public class AppBarSubPanel : ContentControl
    {
        
        #region -> Enumeration

        public enum DirectionType {
            /// <summary>
            /// 부모 컨트롤의 위로 움직이며 보여지는 타입
            /// </summary>
            Up,
            /// <summary>
            /// 부모 컨트롤의 아래로 움직이며 보여지는 타입
            /// </summary>
            Down
        }

        #endregion

        #region -> Fields

        private TranslateTransform slideTransform = new TranslateTransform();
        private DoubleAnimation slideAnimation = new DoubleAnimation();
        private DoubleAnimation transparentAnimation = new DoubleAnimation();
        private bool initialized = false;

        #endregion

        #region -> Constructor

        static AppBarSubPanel() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AppBarSubPanel), new FrameworkPropertyMetadata(typeof(AppBarSubPanel)));
        }

        #endregion

        #region -> Events

        /// <summary>
        /// AppBarSubPanel이 열릴 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Opened;

        /// <summary>
        /// AppBarSubPanel이 닫힐 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Closed;

        #endregion

        #region -> Properties

        /// <summary>
        /// AppBarSubPanel이 어느 방향으로 보여질지 설정합니다.
        /// </summary>
        public DirectionType Direction {
            get { return (DirectionType)GetValue(DirectionProperty); }
            set { SetValue(DirectionProperty, value); }
        }

        public static readonly DependencyProperty DirectionProperty =
            DependencyProperty.Register("Direction", typeof(DirectionType), typeof(AppBarSubPanel), new PropertyMetadata(DirectionType.Up));

        /// <summary>
        /// AppBarSubPanel의 표시 상태를 설정하거나 가져옵니다.
        /// </summary>
        public bool IsOpen {
            get { return (bool)GetValue(IsOpenProperty); }
            set {
                if (IsOpen == value)
                    return;

                SetValue(IsOpenProperty, value);

                if (initialized == false)
                    return ;

                if (value) {
                    // 부모의 높이가 AppBarSubPanel의 높이보다 작은 경우 잘려나오지 않도록 클립영역 재설정
                    if (VisualClip != null && VisualClip.Bounds.Height < this.ActualHeight) {
                        this.VisualClip = new RectangleGeometry(new Rect(0, 0, this.ActualWidth, this.Height));
                    }

                    PlayOpenAnimation();
                    OnOpened();
                }
                else {
                    PlayCloseAnimation();
                    OnClosed();
                }
            }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(AppBarSubPanel), new PropertyMetadata(false));

        #endregion

        #region -> Private Methods

        private void OnOpened() {
            if (Opened != null)
                Opened(this, null);
        }

        private void OnClosed() {
            if (Closed != null)
                Closed(this, null);
        }

        private void PlayOpenAnimation() {

            this.Visibility = Visibility.Visible;

            if (Direction == DirectionType.Up)
                slideAnimation.To = -this.Height;
            else if (Direction == DirectionType.Down)
                slideAnimation.To = this.Height;

            transparentAnimation.To = 1.0;

            slideAnimation.BeginTime = TimeSpan.FromSeconds(0);
            transparentAnimation.BeginTime = TimeSpan.FromSeconds(0.1);
                   
            slideTransform.BeginAnimation(TranslateTransform.YProperty, slideAnimation);
            this.BeginAnimation(OpacityProperty, transparentAnimation);
        }

        private void PlayCloseAnimation() {

            slideAnimation.To = 0;
            transparentAnimation.To = 0.0;

            //transparentAnimation.BeginTime = TimeSpan.FromSeconds(0.02);
            slideAnimation.BeginTime = TimeSpan.FromSeconds(0.08);

            slideTransform.BeginAnimation(TranslateTransform.YProperty, slideAnimation);
            this.BeginAnimation(OpacityProperty, transparentAnimation);        
        }

        private void transparentAnimation_Completed(object sender, EventArgs e) {

            // 열림, 닫힘 상태에 따라 다른 컨트롤을 가리지 않도록 상태 설정
            if (IsOpen)
                this.Visibility = Visibility.Visible;
            else
                this.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region -> Overrided Methods

        protected override void OnInitialized(EventArgs e) {
            base.OnInitialized(e);

            // 같은 레벨의 다른 컨트롤들을 가리지 않도록 설정
            Panel.SetZIndex(this, -1);

            // 부모 컨트롤 내의 AppBarSubPanel 위치 지정
            if (this.Direction == DirectionType.Up)
                this.VerticalAlignment = VerticalAlignment.Top;
            else if (this.Direction == DirectionType.Down)
                this.VerticalAlignment = VerticalAlignment.Bottom;

            // 열림/닫힘 상태에 따른 초기 위치 이동
            this.Opacity = 255.0;
            if (IsOpen && Direction == DirectionType.Up) {
                slideTransform.Y = -this.Height;
            }
            else if (IsOpen && Direction == DirectionType.Down) {
                slideTransform.Y = this.Height;
            }
            else {
                slideTransform.Y = 0;
                this.Opacity = 0.0;
            }

            this.RenderTransform = slideTransform;

            slideAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.2));
            slideAnimation.AccelerationRatio = 0.3;
            slideAnimation.DecelerationRatio = 0.1;

            transparentAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.1));
            transparentAnimation.AccelerationRatio = 0.5;
            transparentAnimation.AccelerationRatio = 0.1;
            transparentAnimation.Completed += new EventHandler(transparentAnimation_Completed);

            initialized = true;
        }

        protected override void OnRender(DrawingContext drawingContext) {
            base.OnRender(drawingContext);

            // 부모의 높이가 AppBarSubPanel의 높이보다 작은 경우 잘려나오지 않도록 클립영역 재설정
            if (VisualClip != null && VisualClip.Bounds.Height < this.ActualHeight) {
                this.VisualClip = new RectangleGeometry(new Rect(0, 0, this.ActualWidth, this.Height));
            }
        }

        protected override Size MeasureOverride(Size constraint) {

            // OnRender에서 변경한 VisualClip이 반영되도록 화면 무효화
            this.InvalidateVisual();

            return base.MeasureOverride(constraint);
        }        
     
        #endregion
    }
}
