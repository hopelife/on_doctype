﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Float = System.Single;


namespace Hnc.Presenter.ImageEffect {
    // 인근 픽셀과 Convolution 하여 현 픽셀을 강조한다.
    // 사픈의 효과는 있으나 여러번 사용하면 지저분해짐
    public class Sharpen :ConvolutionEffect {
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Sharpen() : base(false) {
            Float[] m = new Float[9] {
                 0,      -0.2F,      0,
                -0.2F,   1.8F,     -0.2F,
                 0,     -0.2F,      0,
            };

            Kernel = Kernel.Create(3, 3, m);

        }
        public static Sharpen Create() {

            return new Sharpen();
        }
    }
}
