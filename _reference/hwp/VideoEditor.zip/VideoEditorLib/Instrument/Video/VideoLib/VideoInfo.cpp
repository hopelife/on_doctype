/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "VideoInfo.h"
#include "Debug.h"

VideoInfo::VideoInfo(const Char* fullFilePath) : FileInfo(fullFilePath) {
	isVideoFile = false;

	if (IsOpened() == true) {	
		width = -1;
		height = -1;
		frameRate = -1.0;
		totalFrame = 0;
		
		memset(&runningTime, 0x00, sizeof(TimeInfo));
		memset(this->videoCodecName, 0x00, sizeof(this->videoCodecName));
		memset(this->audioCodecName, 0x00, sizeof(this->audioCodecName));
	
		GetVideoInfo();
	}
}

VideoInfo::~VideoInfo() {
}

Bool VideoInfo::GetVideoInfo(VideoInfoStruct* info) {
	if (isVideoFile != true) {
		return false;
	}

	strcpy_s(info->fileName, MAX_FILENAME, GetFileName());
	strcpy_s(info->filePath, MAX_FILEPATH, GetFullFilePath());
	info->frameRate = frameRate;
	info->totalFrame = totalFrame;
	info->width = width;
	info->height = height;
	
	info->runningTime = runningTime;

	strcpy_s(info->modifyDate, MAX_DATE, GetFileModifyDate());

	strcpy_s(info->videoCodecName, MAX_CODEC_NAME, videoCodecName);
	strcpy_s(info->audioCodecName, MAX_CODEC_NAME, audioCodecName);

	return true;
}

Bool VideoInfo::GetVideoInfo() {
	try {
		AVFormatContext* formatContext = NULL;
		AVCodecContext* codecContext = NULL;
	
		// ���� ���� ����
		if (avformat_open_input(&formatContext, GetFullFilePath(), NULL, NULL) < 0) {
			Debug::Trace("VideoLib::GetVideoInfo ���� ������ ���� ���Ͽ����ϴ�.");
			return false;
		}

		// ��Ʈ�� ���� ã��
		if (avformat_find_stream_info(formatContext, NULL) < 0) {
			Debug::Trace("VideoLib::GetVideoInfo ��Ʈ�� ������ ã�� ���Ͽ����ϴ�.");
			return false;
		}
		
		
		AVCodec* audioCodec = NULL;
		// ��Ʈ�� �� ����� Ÿ���� �ε��� ã��
		Int stream_audioIdx = av_find_best_stream(formatContext, AVMEDIA_TYPE_AUDIO, -1, -1, &audioCodec, 0);
		if (stream_audioIdx < 0) {
			Debug::Trace("VideoLib::GetVideoInfo ��Ʈ�� ���� �� ����� ��Ʈ���� �������� �ʽ��ϴ�.");
		} else {
			AVStream* audioStream = formatContext->streams[stream_audioIdx];

			strcpy_s(audioCodecName, sizeof(audioCodecName), audioCodec->name);
		}

		AVCodec* codec = NULL;
		// ��Ʈ�� �� ���� Ÿ���� �ε��� ã��
		Int stream_idx = av_find_best_stream(formatContext, AVMEDIA_TYPE_VIDEO, -1, -1, &codec, 0);
		if (stream_idx < 0) {
			Debug::Trace("VideoLib::GetVideoInfo ��Ʈ�� ���� �� ���� ��Ʈ���� �������� �ʽ��ϴ�.");
			return false;
		}

		AVStream* videoStream = formatContext->streams[stream_idx];
		codecContext = videoStream->codec;

		if (codec == NULL) {
			return false;
		}

		// ���� ��������
		width = codecContext->width;
		height = codecContext->height;

		strcpy_s(videoCodecName, sizeof(videoCodecName), codec->name);

		if (videoStream->r_frame_rate.den != 0) {
			Double frameRate = av_q2d(videoStream->r_frame_rate);
			Double runningTime = (Double) videoStream->duration * av_q2d(videoStream->time_base);

			if (runningTime < 0) {
				Double formatContextDuration = (Double) formatContext->duration * 1000 / AV_TIME_BASE;
				runningTime = (Double) formatContextDuration * av_q2d(videoStream->time_base);
			}

			Double duration = (Double) formatContext->duration / AV_TIME_BASE;

			if (duration <= 0) {
				Double tmpDuration = 0.0;

				if (videoStream->codec->bit_rate > 0 && formatContext->packet_size > 0) {
					if(videoStream->codec->bit_rate >= 8) {
						if (videoStream->codec->bit_rate / 8 != 0) {
							tmpDuration = 0.9 * formatContext->packet_size / (videoStream->codec->bit_rate / 8);
						} else {
							tmpDuration = 0.0;
						}
					}

					if (tmpDuration > 0) {
						duration = tmpDuration;
					}
				}
			}

			this->frameRate = frameRate;
			this->totalFrame = Round(runningTime * frameRate);
			//this->totalFrame = videoStream->duration / frameRate;
			Int time = Round(runningTime);
			this->runningTime.hour = time / 3600;
			this->runningTime.minute = (time % 3600) / 60;
			this->runningTime.second = (time % 3600) % 60;
		} else {
			this->frameRate = 0.0;
			this->runningTime.hour = 0;
			this->runningTime.minute = 0;
			this->runningTime.second = 0;
		}

		if (formatContext != NULL) {
			avcodec_close(codecContext);
			avformat_close_input(&formatContext);
		}
	} catch(...) {
		Debug::Trace("VideoLib::GetVideoInfo ���ܹ߻�!!!");
	}

	isVideoFile = true;

	return true;
}

Bool VideoInfo::IsVideoFile() {
	return isVideoFile;
}

Int VideoInfo::GetWidth() {
	return width;
}

Int VideoInfo::GetHeight() {
	return height;
}

Double VideoInfo::GetFrameRate() {
	return frameRate;
}

Int64_t VideoInfo::GetTotalFrame() {
	return totalFrame;
}

TimeInfo VideoInfo::GetRunningTime() {
	return runningTime;
}

const Char* VideoInfo::GetVideoCodec() {
	return videoCodecName;
}

const Char* VideoInfo::GetAudioCodec() {
	return audioCodecName;
}
