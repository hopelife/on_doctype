﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Int = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    
    // 히스토그램 strectch하여 level을 재구성한다.
    public class AutoLevel {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private AutoLevel() {

        }

        public static AutoLevel Create() {
            return new AutoLevel();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(Ycbcr255Channel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            Histogram.Item histogram = Histogram.Item.Create(pixels.Y);

            LookupTable table = histogram.Stretch(histogram.Left(0.005F), histogram.Right(0.005F));
            for (Index i = 0; i < pixels.Y.Length; ++i) {
                pixels.Y[i] = table.Data[pixels.Y[i]];
            }

        }

        //public void Apply(ArgbChannel pixels) {
        //    Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

        //    Histogram histogram = Histogram.Create(pixels);

        //    LookupTable rTable = histogram.Red.Stretch(histogram.Red.Low, histogram.Red.High);
        //    LookupTable gTable = histogram.Green.Stretch(histogram.Green.Low, histogram.Green.High);
        //    LookupTable bTable = histogram.Blue.Stretch(histogram.Blue.Low, histogram.Blue.High);

        //    for (Index i = 0; i < pixels.R.Length; ++i) {

        //        pixels.R[i] = rTable.Data[pixels.R[i]];
        //        pixels.G[i] = gTable.Data[pixels.G[i]];
        //        pixels.B[i] = bTable.Data[pixels.B[i]];


        //        //r = Pixels.GetR(pixels.Data[i]);
        //        //g = Pixels.GetG(pixels.Data[i]);
        //        //b = Pixels.GetB(pixels.Data[i]);

        //        //pixels.Data[i] = Pixels.ToPixel(
        //        //    Pixels.GetA(pixels.Data[i]),
        //        //    red.Data[r],
        //        //    green.Data[g],
        //        //    blue.Data[b]
        //        //);

        //    }

        //    // Hsl 채널을 이용하는 방법도 있으나 색감이 탁해서 사용안함.

        //    //HslChannel hslChannel = HslChannel.Create(pixels);

        //    //// lum을 이용하여 히스토그램 생성
        //    //Histogram.Item histogram = Histogram.Item.Create(hslChannel.L);

        //    //// 사용이 적은 좌우 5%에 해당하는 픽셀은 제거한 Histogram을 사용한다.
        //    //LookupTable lookupTable = histogram.Stretch(histogram.Low, histogram.High);
           
          

        //    //// lookupTable에 맞게 명도 조정
        //    //for (Index i = 0; i < hslChannel.L.Length; ++i) {
        //    //    hslChannel.L[i] = lookupTable.Data[MathUtil.Round(hslChannel.L[i] * 255)] / 255.0F;
        //    //}

        //    //// 픽셀 데이터 반영
        //    //for (Index i = 0; i < pixels.Data.Length; ++i) {
        //    //    pixels.Data[i] = (pixels.Data[i] & 0xff000000) | ColorUtil.HslToRgb(
        //    //        hslChannel.H[i], hslChannel.S[i], hslChannel.L[i]
        //    //    );
        //    //}
        //}

 
    }
}