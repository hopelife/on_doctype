﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Grid = System.Windows.Controls.Grid;

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Collections.ObjectModel;
using Hnc.Control;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Controls;
using Hnc.VideoEditor.Service;
using Hnc.Instrument;
using Hnc.VideoEditor.Base.Enum;
using System.IO;
using Hnc.Util;
using System.Timers;
using System.Windows.Threading;
using Hnc.VideoEditor.Util;
using System.Diagnostics;

namespace Hnc.VideoEditor.Pages {
    public delegate bool DelegateDeleteLoadBarItem(String filePath);
    public partial class MainPage : Grid {
		public DelegateDeleteLoadBarItem DelegateDeleteLoadBarItemInstance = null;

		private VideoPlayer player;
		private LoadStatusBar LoadBar;
		private ViewUtil viewUtil = null;
		private WaitDialog waitDlg = null;
		private static readonly int OPEN_COUNT_MAX = 100;

		String loadFilePath = null;
		private Timer openTimer;
		private int openCount = 0;

		private bool IsPlayState = false;
		private bool IsPlayBtnEnable = false;

		public MainPage() {
			DelegateDeleteLoadBarItemInstance = new DelegateDeleteLoadBarItem(this.DeleteLoadBarItem);
			InitializeComponent();

			player = new VideoPlayer();
			PlayerView.Children.Add(player);

			LoadBar = new LoadStatusBar(this);

			//manager.TopToolBar.Children.Add(LoadBar);
			//TopAppbar.Children.Add(LoadBar);
			//TopAppbar.Content = LoadBar;
			LoadStatusBarGrid.Children.Add(LoadBar);

			//MainMenu.Page = this;

			soundTimeline.Visibility = Visibility.Hidden;
			subtitleTimeline.Visibility = Visibility.Hidden;

			EditorControl.MouseMove += Event_InfosMouseMove;
			//videoTimeline.MouseUp += Event_VideoInfosMouseUp;
			soundTimeline.MouseUp += Event_SoundInfosMouseUp;
			subtitleTimeline.MouseUp += Event_SubtitleInfosMouseUp;

			viewUtil = new ViewUtil(videoTimeline, soundTimeline, subtitleTimeline);

			TimelineSlider.SetValue(Canvas.LeftProperty, 0.0);

		}

		private void OnLoaded(object sender, RoutedEventArgs e) {
			AutoZoom();
		}

		public void AddSourceFile() {
			LoadBar.AddSourceFile();
		}

		public void AddSourceFile(List<String> addSourcePaths) {
			LoadBar.AddSourceFile(addSourcePaths);
		}

		public void AddSourceFile(List<String> addSourcePaths, bool load) {
			LoadBar.AddSourceFile(addSourcePaths, load);
		}

		public string LoadBarSelectedItemFilePath() {
			PhotoListBoxItem item = LoadBar.LoadPhotoListBox.SelectedItem as PhotoListBoxItem;
			return item.Path;
		}

		private void AddTimelineInfo(object sender, RoutedEventArgs e) {
			PhotoListBoxItem item = LoadBar.LoadPhotoListBox.SelectedItem as PhotoListBoxItem;

			if (item == null) {
				return;
			}

			if (item.Path == null) {
				return;
			}

			double start = player.GetVideoSlider.StartSecondsValue * 30;
			double end = player.GetVideoSlider.EndSecondsValue * 30;

			if (start < 0.0 || end < 0.0) {
				return;
			}

			if (start >= end) {
				return;
			}

			Hnc.Instrument.VideoContentInfo info = Hnc.Instrument.VideoUtil.GetVideoContentInfo(item.Path);

			if (info == null) {
				return;
			}

			FrameScope videoScope = FrameScope.Create(start, end);

			if (videoScope == null) {
				return;
			}

			ActionAddVideoInfo action = new ActionAddVideoInfo(item.Path, info.TotalFrame, videoScope);

			if (action == null) {
				return;
			}

			if (ActionManager.Instance.Excute(action) == true) {
				//MainMenu.UpdateMenuState();
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.UpdateToolbarState();
				}
				
				//scrollViewer.ScrollToHorizontalOffset(scrollViewer.HorizontalOffset + videoScope.LENGTH);
			}
		}

		public void ScrollViewerPosition(double position) {
			double x = scrollViewer.HorizontalOffset;
			double width = scrollViewer.ViewportWidth;
			double viewWidth = scrollViewer.ActualWidth;

			if (x + width < position) {
				scrollViewer.ScrollToHorizontalOffset(position);
			}

			if (x > position) {
				scrollViewer.ScrollToHorizontalOffset(position);
			}
		}

		private void Event_InfosMouseMove(object sender, MouseEventArgs e) {
		//	Point p = e.GetPosition(EditorControl);
		//	SetTimelineSlider(p.X);
		}

		public void SetTimelineSlider(double seconds) {
			double position = hRuler.GetPositon(seconds);
			TimelineSlider.SetValue(Canvas.LeftProperty, position);
		}

		public void AutoZoom() {
			// viewPort의 길이 구하기
			double viewPortLength = scrollViewer.ViewportWidth;

			if (viewPortLength == 0.0) {
				return;
			}

			// 현재 viewPort가 허용 가능한 현재 줌상태에서의 최대 프레임 카운트 구하기
			double maxFrameCount = hRuler.GetMaxFrameCount(viewPortLength);

			// 현재 타임라인에 추가된 정보들의 총 프레임 카운터 구하기
			double timelineFrameCount = videoTimeline.GetTimelineFrameCount();

			// 2에서 구한것과 3에서 구한 것 비교
			if (maxFrameCount < timelineFrameCount) {
				// autozoom
				// 얼마만큼의 줌을 줄여야 현재 프레임 카운터가 현재 viewport 길이 안에서 나타날 수 있는지 확인
				ZoomInForFrame(timelineFrameCount, viewPortLength);
			}
		}

		public void VideoInfosMouseUp() {
			List<TimelineInfo> infoList = new List<TimelineInfo>();

			foreach (TimelineInfoView infoView in videoTimeline.infoCanvas.Children) {
				if (infoView.STATE != TimelineInfoChangedState.NoChanged) {
					infoList.Add(infoView.Value);
				}
			}

			if (infoList.Count != 0) {
				ActionPropertyChangedInfo action = new ActionPropertyChangedInfo(infoList);

				if (ActionManager.Instance.Excute(action) == true) {
					MediaEditOpen();
					SetMediaEditSlider();
				}
			}
		}

		private void Event_VideoInfosMouseUp(object sender, MouseEventArgs e) {
			VideoInfosMouseUp();
		}

		private void Event_SoundInfosMouseUp(object sender, MouseEventArgs e) {
			List<TimelineInfo> infoList = new List<TimelineInfo>();

			foreach (TimelineInfoView infoView in soundTimeline.infoCanvas.Children) {
				if (infoView.STATE != TimelineInfoChangedState.NoChanged) {
					infoList.Add(infoView.Value);
				}
			}

			if (infoList.Count != 0) {
				ActionPropertyChangedInfo action = new ActionPropertyChangedInfo(infoList);

				if (ActionManager.Instance.Excute(action) == true) {
				}
			}
		}

		private void Event_SubtitleInfosMouseUp(object sender, MouseEventArgs e) {
			List<TimelineInfo> infoList = new List<TimelineInfo>();

			foreach (TimelineInfoView infoView in subtitleTimeline.infoCanvas.Children) {
				if (infoView.STATE != TimelineInfoChangedState.NoChanged) {
					infoList.Add(infoView.Value);
				}
			}

			if (infoList.Count != 0) {
				ActionPropertyChangedInfo action = new ActionPropertyChangedInfo(infoList);

				if (ActionManager.Instance.Excute(action) == true) {
				}
			}
		}

		private void ZoomInForFrame(double frameCount, double length) {

			int numberUnit = hRuler.GetAutoNumberUnit(frameCount, length);

			ZoomIn(1.0, numberUnit);

		}

		private void ZoomIn(double zoom, int numberUnit) {

			double zoomValue = zoom;

			if (zoomValue > 1.4) {
				zoomValue = 1.4;
			} else if (zoomValue < 0.7) {
				zoomValue = 0.7;
			}

			if (numberUnit == 0) {
				numberUnit = 1;
			}

			if (numberUnit % 10 != 0) {
				numberUnit -= numberUnit % 10;
			}

			hRuler.numberUnit = numberUnit;
			hRuler.Zoom = zoom;

			videoTimeline.NumberUnit = hRuler.numberUnit;
			videoTimeline.Zoom = hRuler.Zoom;

			if (hRuler.Zoom > 1.4) {
				if (hRuler.numberUnit == 1) {
					ZoomInBtn.IsEnabled = false;
				}
			}
		}

		private void ZoomIn() {
			double zoomValue = hRuler.Zoom + 0.1;

            if (ZoomOutBtn.IsEnabled == false) {
                ZoomOutBtn.IsEnabled = true;
            }

			if (hRuler.Zoom > 1.4) {
				if (hRuler.numberUnit != 1) {
					hRuler.numberUnit -= 10;

					if (hRuler.numberUnit == 0) {
						hRuler.numberUnit = 1;
					}

					hRuler.Zoom = 1.0;
					videoTimeline.NumberUnit = hRuler.numberUnit;
					//               soundTimeline.NumberUnit = hRuler.numberUnit;
					//              subtitleTimeline.NumberUnit = hRuler.numberUnit;
					videoTimeline.Zoom = hRuler.Zoom;
					//              soundTimeline.Zoom = hRuler.Zoom;
					//              subtitleTimeline.Zoom = hRuler.Zoom;
				}
			} else {
				videoTimeline.Zoom = zoomValue;
				//            soundTimeline.Zoom = zoomValue;
				//            subtitleTimeline.Zoom = zoomValue;
				hRuler.Zoom = zoomValue;

				if (hRuler.Zoom > 1.4) {
					if (hRuler.numberUnit == 1) {
						ZoomInBtn.IsEnabled = false;
					}
				}
			}
		}

		private void ZoomOut() {
			double zoomValue = hRuler.Zoom - 0.1;

			if (ZoomInBtn.IsEnabled == false) {
				ZoomInBtn.IsEnabled = true;
			}

			if (hRuler.Zoom < 0.7) {
				if (hRuler.numberUnit == 1) {
					hRuler.numberUnit += 9;
				} else {
					hRuler.numberUnit += 10;
				}

				hRuler.Zoom = 1.0;
				videoTimeline.NumberUnit = hRuler.numberUnit;
				//soundTimeline.NumberUnit = hRuler.numberUnit;
				//subtitleTimeline.NumberUnit = hRuler.numberUnit;
				videoTimeline.Zoom = hRuler.Zoom;
				//soundTimeline.Zoom = hRuler.Zoom;
				//subtitleTimeline.Zoom = hRuler.Zoom;
			} else {
				videoTimeline.Zoom = zoomValue;
				//soundTimeline.Zoom = zoomValue;
				//subtitleTimeline.Zoom = zoomValue;
				hRuler.Zoom = zoomValue;

                if (hRuler.Zoom < 1.0) {
                    ZoomOutBtn.IsEnabled = false;
                }
			}
		}

		private void ClickZoomIn(object sender, RoutedEventArgs e) {
			ZoomIn();
		}

		private void ClickZoomOut(object sender, RoutedEventArgs e) {
			ZoomOut();
		}

		private void PlayMovie(object sender, RoutedEventArgs e) {
			if (IsPlayState == false) {
				player.MediaPlay();
				PlayBtn.IsChecked = true;
				IsPlayState = true;
			} else {
				player.MediaPause();
				PlayBtn.IsChecked = false;
				IsPlayState = false;
			}

			PlayButtonEnable();

		}

		public void PlayButtonEnable() {
			if (IsPlayBtnEnable == false) {
				PlayerPlayBtn.Visibility = Visibility.Hidden;
			} else {
				if (IsPlayState == true) {
					PlayerPlayBtn.Visibility = Visibility.Hidden;
				} else {
					PlayerPlayBtn.Visibility = Visibility.Visible;
				}
			}
		}

		public void PlayMovie(bool play) {
			if (play == true) {
				PlayBtn.IsChecked = true;
				IsPlayState = true;
				player.MediaPlay();
			} else {
				PlayBtn.IsChecked = false;
				IsPlayState = false;
				player.MediaPause();
			}

			PlayButtonEnable();
		}

		public bool IsLoadBarSelectedItem() {
			return LoadBar.IsSelectedItem();
		}

		public void ChangePlayState(bool state) {
			if (player.GetCloseOption() == false) {
				PlayBtn.IsChecked = state;

				if (state == true) {
					player.MediaPlay();
					IsPlayState = true;
				} else {
					player.MediaPause();
					IsPlayState = false;
				}
			} else {
				PlayBtn.IsChecked = false;
				IsPlayState = false;
			}

			PlayButtonEnable();
		}

		public void ClosePlayer() {
			if (player.PlayerMode == PlayerMode.PlayClose) {
				return;
			}

			IsPlayBtnEnable = false;
			PlayBtn.IsEnabled = false;
			AddBtn.IsEnabled = false;

			PlayButtonEnable();

			player.ChangeMode(PlayerMode.PlayClose);
		}

		public void CheckTimelineInfoCount() {
			if (videoTimeline.infoCanvas.Children.Count == 0) {
				player.SetCloseOption(true);
				ClosePlayer();
			}
		}

		public void MediaEditOpen() {
			
			player.ChangeMode(PlayerMode.PlayEditor);
			int selectIndex = 0;

			for (int i = 0; i < videoTimeline.infoCanvas.Children.Count; ++i) {
				TimelineInfoView infoView = videoTimeline.infoCanvas.Children[i] as TimelineInfoView;

				if (infoView.Select == true) {
					selectIndex = i;
				}
			}

			player.OpenEdit(selectIndex);

			LoadBar.LoadPhotoListBox.SelectedItem = null;
			AddBtn.IsEnabled = false;
			ChangeSelectFile(null);

			IsPlayBtnEnable = true;
			PlayBtn.IsEnabled = true;
			AddBtn.IsEnabled = false;

			PlayButtonEnable();
		}

		public void ChangePlayerMode(PlayerMode mode) {
			player.ChangeMode(mode);
		}

		public void SetMediaEditSlider() {
			player.NewVideoList();

			int selectIndex = 0;

			// 정렬된 새로운 아이 만들기
			// 새로운 아이로 밑에 내용 실행
			List<TimelineInfoView> viewInfoList = new List<TimelineInfoView>();

			for (int i = 0; i < videoTimeline.infoCanvas.Children.Count; ++i) {
				TimelineInfoView infoView = videoTimeline.infoCanvas.Children[i] as TimelineInfoView;
				viewInfoList.Add(infoView);
			}

			for (int i = 0; i < viewInfoList.Count-1; ++i) {
				TimelineInfoView info = viewInfoList[i];

				for (int j = i + 1; j < viewInfoList.Count; ++j) {
					TimelineInfoView nextInfo = viewInfoList[j];

					if (info.TimelineScope.START > nextInfo.TimelineScope.START) {
						TimelineInfoView tempInfo = viewInfoList[i];
						viewInfoList[i] = viewInfoList[j];
						viewInfoList[j] = tempInfo;
					}
				}
			}

			for (int i = 0; i < viewInfoList.Count; ++i) {
				TimelineInfoView infoView = viewInfoList[i];
				EditVideoInfo info = new EditVideoInfo(infoView.Value);

				player.AddVideoInfo(info);

				if (infoView.Select == true) {
					selectIndex = i;
				}
			}

			// playerMode == PlayerMode.PlayEditor
			double totalSeconds = player.SetSliderBar();
			player.SetCurrentBar(selectIndex);

            int min = (int) totalSeconds / 60;
            int sec = (int) totalSeconds % 60;

            SetStatusbar(min, sec);
            
			/*
			if (videoTimeline.infoCanvas.Children.Count <= 0) {
				return;
			}

			player.NewVideoList();

			int selectIndex = 0;

			for (int i = 0; i < videoTimeline.infoCanvas.Children.Count; ++i) {
				TimelineInfoView infoView = videoTimeline.infoCanvas.Children[i] as TimelineInfoView;
				EditVideoInfo info = new EditVideoInfo(infoView.Value);

				player.AddVideoInfo(info);

				if (infoView.Select == true) {
					selectIndex = i;
				}
			}

			player.OpenEdit(selectIndex);

			LoadBar.LoadPhotoListBox.SelectedItem = null;
			AddBtn.IsEnabled = false;
			ChangeSelectFile(null);

			PlayBtn.IsEnabled = true;
			AddBtn.IsEnabled = false;

		//	player.MediaPlay();
		//	player.MediaPause();
			*/
		}

		public void IsEnabledAddVideoBtn(bool isEnabled) {
			AddBtn.IsEnabled = isEnabled;
		}

        public void MediaEditPlay() {
            if (videoTimeline.infoCanvas.Children.Count <= 0) {
                return;
            }

            /*
            if (player.PlayerMode == PlayerMode.PlayEditor) {
                return;
            }
            */

            player.NewVideoList();

            int selectIndex = 0;

            for (int i = 0; i < videoTimeline.infoCanvas.Children.Count; ++i) {
                TimelineInfoView infoView = videoTimeline.infoCanvas.Children[i] as TimelineInfoView;
                EditVideoInfo info = new EditVideoInfo(infoView.Value);

                player.AddVideoInfo(info);

                if (infoView.Select == true) {
                    selectIndex = i;
                }
            }

            player.OpenEdit(selectIndex);

            LoadBar.LoadPhotoListBox.SelectedItem = null;
            AddBtn.IsEnabled = false;
            ChangeSelectFile(null);

			IsPlayBtnEnable = true;
            PlayBtn.IsEnabled = true;
            AddBtn.IsEnabled = false;

			PlayButtonEnable();

            player.MediaPlay();
        //    player.MediaPause();     
        }        

        //public void UpdateStatusFrame() {
        //    double videoTotalFrame = videoTimeline.GetTotalFrame();
        //    double soundTotalFrame = soundTimeline.GetTotalFrame();
        //    double subtitleTotalFrame = subtitleTimeline.GetTotalFrame();

        //    double totalFrame = videoTotalFrame;

        //    if (totalFrame < soundTotalFrame) {
        //        totalFrame = soundTotalFrame;
        //    }

        //    if (totalFrame < subtitleTotalFrame) {
        //        totalFrame = subtitleTotalFrame;
        //    }

        //    int total = (int) totalFrame / 30;

        //    int min = total / 60;
        //    int sec = total % 60;

        //    MinuteLabel.Content = string.Format("{0:00}", min);
        //    SecondLabel.Content = string.Format("{0:00}", sec);
        //} 

        #region -> Public Methods

		private void VideoLoadFail(string msg) {
			AppDialog appDlg = null;

			string pathMessage = StringUtil.GetAudoLengthMessage(loadFilePath);


            CustomDialog dialog = new CustomDialog();


            string message = "";

			if (msg == "System.Windows.Media.InvalidWmpVersionException") {
                message = Application.Current.Resources["IDS_Message_12"] as String + "\n" +
                             Application.Current.Resources["IDS_Message_16"] as String;


			} else {
                message = Application.Current.Resources["IDS_Message_12"] as String + "\n" +
                             Application.Current.Resources["IDS_Message_14"] as String;
			}

            dialog.ChangeMessageBoxType("", message, 400.0, Application.Current.Resources["IDS_Confirm"] as String);
            dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

			if (appDlg != null) {
				try {
					appDlg.ShowDialog();
				} catch (Exception ex) {
					Hnc.Type.Debug.Assert(false, ex.Message);
				}
			}

			PhotoListBoxItem item = FindLoadBarItem(loadFilePath);
			if (item != null) {
				WaitDeleteLoadBarItem(item);
			}

			loadFilePath = null;
		}

		public void CloseWaitDlg(bool isOpened, string msg) {
			if (waitDlg == null) {
				return;
			}

			if (waitDlg != null) {
				waitDlg.Close();
				waitDlg = null;
			}

			if (isOpened == false) {
				VideoLoadFail(msg);
			} else {
				string videoCodecName = Hnc.Instrument.VideoUtil.IsPossibleVideoCodec(loadFilePath);
                double framerate = Hnc.Instrument.VideoUtil.GetFrameRate(loadFilePath);

                if (framerate < 28.0 || framerate > 31.0) {
                    CustomDialog dialog = new CustomDialog();
                    string message = Application.Current.Resources["IDS_Message_13"] as String + "\n" +
                                     Application.Current.Resources["IDS_Message_31"] as String;

                    dialog.ChangeMessageBoxType("", message, 350.0, Application.Current.Resources["IDS_Confirm"] as String);
                    dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

                    IsPlayBtnEnable = true;
                    PlayBtn.IsEnabled = true;
                    AddBtn.IsEnabled = false;

                    PlayButtonEnable();

                    player.videoSlider.StartPosition.Visibility = Visibility.Hidden;
                    player.videoSlider.EndPosition.Visibility = Visibility.Hidden;
                    player.videoSlider.MiddleLineUp.Visibility = Visibility.Hidden;
                    player.videoSlider.MiddleLineDown.Visibility = Visibility.Hidden;
                } else if (videoCodecName != null) {
                    CustomDialog dialog = new CustomDialog();
                    string message = Application.Current.Resources["IDS_Message_13"] as String + "\n" +
                                     Application.Current.Resources["IDS_Message_25"] as String;

                    dialog.ChangeMessageBoxType("", message, 350.0, Application.Current.Resources["IDS_Confirm"] as String);
                    dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

					IsPlayBtnEnable = true;
					PlayBtn.IsEnabled = true;
					AddBtn.IsEnabled = false;

					PlayButtonEnable();

					player.videoSlider.StartPosition.Visibility = Visibility.Hidden;
					player.videoSlider.EndPosition.Visibility = Visibility.Hidden;
                    player.videoSlider.MiddleLineUp.Visibility = Visibility.Hidden;
                    player.videoSlider.MiddleLineDown.Visibility = Visibility.Hidden;
                    
				} else {
					string audioCodecName = Hnc.Instrument.VideoUtil.IsPossibleAudioCodec(loadFilePath);

					if (audioCodecName != null) {
                        CustomDialog dialog = new CustomDialog();
                        string message = Application.Current.Resources["IDS_Message_27"] as String;

                        dialog.ChangeMessageBoxType("", message, 350.0, Application.Current.Resources["IDS_Confirm"] as String);
                        dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);
					}

					FileChangedManager.AddFile(loadFilePath);
				}
			}
		}

		public void TimelineClearSelect() {
			videoTimeline.ClearSelect();
			videoTimeline.AllUpdate();
		}

		public void ChangeSelectFile(string filePath) {
			//MainMenu.ChangeSelectFile(filePath);
		}

		private void StartOpenTimer() {
			openCount = 0;
			openTimer = new Timer(100);
			openTimer.Elapsed += new ElapsedEventHandler(OpenTimerElapsed);
			
			openTimer.Start();
		}

		public void EndOpenTimer() {
			openCount = 0;
			if (openTimer != null) {
				openTimer.Stop();
				openTimer.Close();
				openTimer = null;
			}
		}

		private void OpenTimerElapsed(object sender, ElapsedEventArgs e) {
			this.Dispatcher.Invoke(new Action(delegate() {
				++openCount;
#if DEBUG
				waitDlg.Percentage = openCount.ToString();
#endif
				if (openCount == OPEN_COUNT_MAX) {
					if (waitDlg != null) {
						waitDlg.Close();
						waitDlg = null;
					}

					EndOpenTimer();

					VideoLoadFail(null);
					LoadFirstVideo();
				}

			}), DispatcherPriority.Render);
		}

		public void OpenVideoFile(string path) {
			if (player != null && path != null) {
				loadFilePath = path;
				player.OpenFile(path);
				player.UpdateLayout();

				StartOpenTimer();


				//waitDlg.BGGrid.ActualHeight = PlayerView.ActualHeight;
				//waitDlg.BGGrid.ActualWidth = PlayerView.ActualWidth;

				waitDlg = new WaitDialog();
				waitDlg.Show();
				waitDlg.Message = Application.Current.Resources["IDS_Message_10"] as String;
				waitDlg.Percentage = "";

				IsPlayBtnEnable = true;
				PlayBtn.IsEnabled = true;
				AddBtn.IsEnabled = true;

				PlayButtonEnable();
			}
		}

		public void StopVideoFile() {
			if (player != null) {
				player.StopVideoFile();
			}
		}

		public void SetSelectedItems(IList<string> paths) {
			LoadBar.SetSelectedItems(paths);
		}

		public void SetSelectedItems2(IList<string> paths) {
			foreach (String path in paths) {
				PhotoListBoxItem newItem = new PhotoListBoxItem(path, ControlUtil.CreateImageControl(VideoUtil.GetVideoAutoThumbnail(path, 96, 72)));

				newItem.ItemName = System.IO.Path.GetFileName(path);
				newItem.Path = path;

				VideoContentInfo info = VideoUtil.GetVideoContentInfo(path);

				String information = "";
				FileInfo fileInfo = new FileInfo(path);
                information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                information += Application.Current.Resources["IDS_Size"] as String + ": " + Math.Round(fileInfo.Length / 1024.0, 2) + "KB" + Environment.NewLine;
                information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
				newItem.Information = information;


				FileManager.Instance.AddWatcherFile(newItem.Path);
				LoadBar.LoadPhotoListBox.Items.Add(newItem);
			}

			if (LoadBar.LoadPhotoListBox.Items.Count > 0) {
				PhotoListBoxItem item = LoadBar.LoadPhotoListBox.Items[0] as PhotoListBoxItem;
				if (item != null) {
					LoadBar.LoadPhotoListBox.SelectedItem = item;
				}
			}
		}

		public int RenameLoadBarItem(String oldFilePath, String newFilePath) {
			int count = 0;
			foreach (PhotoListBoxItem item in LoadBar.LoadPhotoListBox.Items) {
				if (item.Path == oldFilePath) {
					item.Path = newFilePath;
					item.ItemName = System.IO.Path.GetFileName(newFilePath);
					item.Path = newFilePath;

					VideoContentInfo info = VideoUtil.GetVideoContentInfo(newFilePath);
					String information = "";
					FileInfo fileInfo = new FileInfo(newFilePath);
                    information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                    information += Application.Current.Resources["IDS_Size"] as String + ": " + Math.Round(fileInfo.Length / 1024.0, 2) + "KB" + Environment.NewLine;
                    information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                    information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                    information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
					item.Information = information;

					++count;
				}
			}
			return count;
		}

		public bool DeleteLoadBarItem(String filePath) {
			try {
				Collection<PhotoListBoxItem> itemList = new Collection<PhotoListBoxItem>();

				foreach (PhotoListBoxItem item in LoadBar.LoadPhotoListBox.Items) {
					if (item.Path == filePath) {
						itemList.Add(item);
					}
				}

				if (itemList.Count > 0) {
					foreach (PhotoListBoxItem item in itemList) {
						DeleteLoadBarItem(item);
					}
					itemList.Clear();
				}
			} catch (Exception e) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem 예외발생\n" + e.Message);
				return false;
			}
			return true;
		}

		public PhotoListBoxItem FindLoadBarItem(String path) {
			PhotoListBoxItem item = null;

			foreach (PhotoListBoxItem findItem in LoadBar.LoadPhotoListBox.Items) {
				if (findItem.Path == path) {
					item = findItem;
				}
			}

			return item;
		}

		public bool DeleteLoadBarItem(PhotoListBoxItem item) {
			if (item == null) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem item이 null 입니다.\n");
				return false;
			}

			try {
				if (LoadBar.LoadPhotoListBox.SelectedItem == item) {
					LoadBar.LoadPhotoListBox.Items.Remove(item);

					LoadFirstVideo();
				} else {
					LoadBar.LoadPhotoListBox.Items.Remove(item);
				}

				FileChangedManager.RemoveFile(item.Path);
			} catch (Exception e) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem 예외발생\n" + e.Message);
				return false;
			}

			return true;
		}

		public bool InfoLoadBarItem(PhotoListBoxItem item) {
			if (item == null) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem item이 null 입니다.\n");
				return false;
			}

			try {
				//MessageBox.Show(item.Path, "file Path", MessageBoxButton.OK, MessageBoxImage.Information);

				CustomDialog dialog = new CustomDialog();
				dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.Info, item.Path, null);

			} catch (Exception e) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem 예외발생\n" + e.Message);
				return false;
			}

			return true;
		}

		public bool ExportTimeline() {
			int timelineInfoCount = GetTimelineInfoCount();

			if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {
				try {
					CustomDialog dialog = new CustomDialog();
					dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.Export, null, null);

				} catch (Exception e) {
					Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem 예외발생\n" + e.Message);
					return false;
				}
			} else {
				return false;
			}

			return true;
		}

		private static readonly String[] HvwExtension = { ".hvw", ".xml" };

		public int ProjectSave(int option) {
			int timelineInfoCount = GetTimelineInfoCount();

			if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo != true || timelineInfoCount <= 0) {
				return -1;
			}

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
			}

			System.Windows.Forms.SaveFileDialog dlg = new System.Windows.Forms.SaveFileDialog();
            string mediaFiles = Application.Current.Resources["IDS_ProjectFiles"] as String;
            mediaFiles += "|*.xml;*.hvw";
            dlg.Filter = mediaFiles;
            dlg.Title = Application.Current.Resources["IDS_XMLSave"] as String;

			if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
				String saveFileName = dlg.FileName;

				ActionSave action = ActionSave.Create(saveFileName);
				AppDialog appDlg = null;

				if (ActionManager.Instance.Excute(action) != true) {
					appDlg = new AppDialog(Application.Current.Resources["IDS_XMLSave"] as String,
					Application.Current.Resources["IDS_XMLSaveResultSucess"] as String,
					Application.Current.Resources["IDS_Confirm"] as String);
				}

				if (appDlg != null && option == 1) {
					try {
						appDlg.ShowDialog();
					} catch (Exception ex) {
						Debug.Assert(false, ex.Message);
					}
				}
				return 1;
			} else {
				return 0;
			}
		}

		public void ProjectLoad() {
			// 창이 뜨면 재생 정지
			ChangePlayState(false);
			// bool undoCount = 0;
			int timelineInfoCount = GetTimelineInfoCount();

			// 불러오기 전에 이미 작업중이던 timeline 내용이 있을 경우
			if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {

				// 저장하고 불러올지 그냥 불러올지 확인
                CustomDialog dialog = new CustomDialog();
                string message = Application.Current.Resources["IDS_Message_29"] as String + "\n" +
                                 Application.Current.Resources["IDS_Message_30"] as String;

                dialog.ChangeMessageBoxType("", message, 315.0,
                    Application.Current.Resources["IDS_Save"] as String,
                Application.Current.Resources["IDS_NoSave"] as String,
                Application.Current.Resources["IDS_Cancel"] as String);
                dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

                if (dialog.Result != Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                    if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.CANCEL) {
                        return;
                    }
                }

				// 작업 중이던 내용 저장하기
				if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
					System.Windows.Forms.SaveFileDialog dlg = new System.Windows.Forms.SaveFileDialog();

                    string ProjectFiles = Application.Current.Resources["IDS_ProjectFiles"] as String;
                    ProjectFiles += "|*.xml;*.hvw";
                    dlg.Filter = ProjectFiles;
                    dlg.Title = Application.Current.Resources["IDS_XMLSave"] as String;

					if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
						String saveFileName = dlg.FileName;
						ActionSave saveAction = ActionSave.Create(saveFileName);
						ActionManager.Instance.Excute(saveAction);
					} else {
						return;
					}
				}
			}

			// project 파일 불러오기
			System.Windows.Forms.OpenFileDialog dlgOpen = new System.Windows.Forms.OpenFileDialog();
            string projectFiles = Application.Current.Resources["IDS_ProjectFiles"] as String;
            projectFiles += "|*.xml;*.hvw;|AllFile(*.*)|*.*";

            dlgOpen.Filter = projectFiles;
            dlgOpen.Title = Application.Current.Resources["IDS_Load"] as String;
			dlgOpen.Multiselect = false;

			// 파일 다이얼로그에서 확인을 눌렀을 경우
			if (dlgOpen.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
				ActionLoad action = ActionLoad.Create(dlgOpen.FileName);

				if (ActionManager.Instance.Excute(action) == true) {
					// 불러오기 성공
					if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
						ClearSourceFileList();
						GetSourceFileList();

						if (videoTimeline.SelectFirstTimeline() > 0) {
							MediaEditOpen();
							SetMediaEditSlider();
							ChangePlayState(false);
						}
					}
				} else {
					// 불러오기 실패
					AppDialog appDlg = null;

					appDlg = new AppDialog(Application.Current.Resources["IDS_LoadFail"] as String,
										Application.Current.Resources["IDS_Message_22"] as String,
										Application.Current.Resources["IDS_Confirm"] as String);

					if (appDlg != null) {
						try {
							appDlg.ShowDialog();
						} catch (Exception ex) {
							Hnc.Type.Debug.Assert(false, ex.Message);
						}
					}
				}

				// 툴바 업데이트
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.UpdateToolbarState();
				}
			}
		}

		public bool WaitDeleteLoadBarItem(PhotoListBoxItem item) {
			if (item == null) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem item이 null 입니다.\n");
				return false;
			}

			try {
				if (LoadBar.LoadPhotoListBox.SelectedItem == item) {
					LoadBar.LoadPhotoListBox.Items.Remove(item);
				} else {
					LoadBar.LoadPhotoListBox.Items.Remove(item);
				}
			} catch (Exception e) {
				Hnc.Type.Debug.Assert(false, "DeleteLoadBarItem 예외발생\n" + e.Message);
				return false;
			}

			return true;
		}

		public void LoadFirstVideo() {
			if (LoadBar.LoadPhotoListBox.Items.Count > 0) {
				PhotoListBoxItem firstItem = LoadBar.LoadPhotoListBox.Items[0] as PhotoListBoxItem;

				if (firstItem != null) {
					LoadBar.LoadPhotoListBox.SelectedItem = firstItem;
					loadFilePath = firstItem.Path;
					ChangeSelectFile(firstItem.Path);
				}
			} else {
				player.SetCloseOption(true);
				ClosePlayer();
				ChangeSelectFile(null);
				//                    ChangeSelectFile(null);
				//                    StopVideoFile();
			}
		}

		public void AddVideoTimelineInfo(TimelineInfo value) {
			videoTimeline.AddTimelineInfo(value);
		}

		public void AddSoundTimelineInfo(TimelineInfo value) {
			// videoTimeline.AddTimelineInfo(id, path, scope, totalFrame);
		}

		public void AddSubtitleTimelineInfo(TimelineInfo value) {
			// videoTimeline.AddTimelineInfo(id, path, scope, totalFrame);
		}

		public bool LoadFile(string path) {
			ActionLoad action = ActionLoad.Create(path);

			if (ActionManager.Instance.Excute(action) == true) {
				ClearSourceFileList();
				GetSourceFileList();

				videoTimeline.SelectFirstTimeline();

				MediaEditOpen();
				SetMediaEditSlider();
				ChangePlayState(false);

				return true;
			} else {
				AppDialog appDlg = null;

				appDlg = new AppDialog(Application.Current.Resources["IDS_LoadFail"] as String,
									Application.Current.Resources["IDS_Message_22"] as String,
									Application.Current.Resources["IDS_Confirm"] as String);

				if (appDlg != null) {
					try {
						appDlg.ShowDialog();
					} catch (Exception ex) {
						Hnc.Type.Debug.Assert(false, ex.Message);
					}
				}
			}

			return false;
		}

		public void ClearSourceFileList() {
			LoadBar.ClearSourceFileList();
		}

		public void GetSourceFileList() {
			List<String> addSourceFileList = new List<string>();
			if (addSourceFileList == null) {
				return;
			}

			videoTimeline.GetSourceFileList(addSourceFileList);

			if (addSourceFileList.Count == 0) {
				return;
			}

			AddSourceFile(addSourceFileList, false);
		}

		public bool IsExistOpenedAppBar() {
			//if (BottomAppbar.IsOpen) {
			//	return true;
			//}
			return false;
		}

		public void SwitchAppBarState(bool isOpen) {
			// AppBar를 닫을 경우 AppBarSubPanel도 모두 닫기
			if (isOpen == true) {
				//MainMenu.UpdateMenuState();
			} else {
				//MainMenu.SwitchAppBarSubPanelState(false);
			}

			//BottomAppbar.IsOpen = isOpen;
		}

		public void SetStatusbar(int width, int height, int frameRate) {
			StatusWidth.Content = width.ToString();
			StatusHeight.Content = height.ToString();
			StatusFrameRate.Content = frameRate.ToString();

			DipHelper.FrameCount = frameRate;
			hRuler.InvalidateVisual();
			videoTimeline.FrameCount = frameRate;
		}

		public void SetStatusbar(int min, int sec) {
			StatusMin.Content = min.ToString();
			StatusSec.Content = sec.ToString();
		}

		public void ChangeMeinMenuState() {
			//MainMenu.UpdateMenuState();
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.UpdateToolbarState();
			}
		}

		public int GetTimelineInfoCount() {
			return videoTimeline.infoCanvas.Children.Count;
		}

		public string GetTimelineInfoPath() {
			if (GetTimelineInfoCount() > 0) {
				TimelineInfoView info = videoTimeline.infoCanvas.Children[0] as TimelineInfoView;

				VideoInfo videoInfo = info.Value as VideoInfo;
				return videoInfo.FilePath;
			}

			return null;
		}

		public double GetTimelineFrameCount() {
			return videoTimeline.GetTimelineFrameCount();
		}

		#endregion

		private void MainPageClicked(object sender, MouseButtonEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.Instance.IsExistOpenedAppBar()) {
				Hnc.VEFrame.VEFrameManager.Instance.SwitchAppBarState(false);
			} else {
				Hnc.VEFrame.VEFrameManager.Instance.SwitchAppBarState(true);
			}
		}

		private void Grid_MouseUp(object sender, MouseButtonEventArgs e) {
			e.Handled = true;
		}

		private void ShortCutKey(object sender, KeyEventArgs e) {
			// 컨트롤키 확인
			if (Keyboard.Modifiers == ModifierKeys.Control) {

				// Ctrl + L - 프로젝트 불러오기
				if (e.Key == Key.L) {
					ProjectLoad();
				}

				// Ctrl + S - 프로젝트 저장하기
				else if (e.Key == Key.S) {
					ProjectSave(1);
				}

				// Ctrl + Z - Undo
				else if (e.Key == Key.Z) {
					if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
						Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.Undo();
					}
				}

				// Ctrl + Y - Redo
				else if (e.Key == Key.Y) {
					if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
						Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.Redo();
					}
				}

				// Ctrl + I - 소스 동영상 추가
				else if (e.Key == Key.I) {
					ChangePlayState(false);
					AddSourceFile();
				}

				// Ctrl + E - 내보내기
				else if (e.Key == Key.E) {
					ExportTimeline();
				}

				// Shift키 확인
				if (Keyboard.Modifiers == ModifierKeys.Shift) {

					// Ctrl + Shift + Z - Redo
					if (e.Key == Key.Z) {
						if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
							Hnc.VEFrame.VEFrameManager.Instance.TitleBarGrid.Redo();
						}
					}
				}
			}
		}

		
	}
}
