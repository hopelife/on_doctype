﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {


    static class Blend {
        public static Byte ColorDodgeForSketch(Byte back, Byte fore) {
            return back == 255 ? fore : (Byte)(MathUtil.Min(255, (fore << 8) / (255 - back)));
        }
        public static Byte ColorDodge(Byte back, Byte fore) {
            return back == 255 ? back : (Byte)(MathUtil.Min(255, (fore << 8) / (255 - back)));
        }
        // backA에 mask를 적용
        public static Byte Mask(Byte backA, Byte maskA, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            Float fMaskARatio = maskA * opacity / 255;

            return (Byte)(backA * fMaskARatio);
        }

        public static void Normal(ref Byte backA, ref Byte backR, ref Byte backG, ref Byte backB, Byte foreA, Byte foreR, Byte foreG, Byte foreB, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            foreA = (Byte)(foreA * opacity);
            Int resultA = 65025 - (255 - backA) * (255 - foreA);
            Int foreAlphaFactor = 255 * foreA;
            Int backAlphaFactor = (255 - foreA) * backA;

			if (resultA == 0) {
				return;
			}

            backA = (Byte)(resultA / 255);
            backR = (Byte)((foreR * foreAlphaFactor + backR * backAlphaFactor) / resultA);
            backG = (Byte)((foreG * foreAlphaFactor + backG * backAlphaFactor) / resultA);
            backB = (Byte)((foreB * foreAlphaFactor + backB * backAlphaFactor) / resultA);
        }

        public static void Overlay(ref Byte backA, ref Byte backR, ref Byte backG, ref Byte backB, Byte foreA, Byte foreR, Byte foreG, Byte foreB, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            foreR = (((foreR < 128) ? (Byte)(2 * backR * foreR / 255) : (Byte)(255 - 2 * (255 - backR) * (255 - foreR) / 255)));
            foreG = (((foreG < 128) ? (Byte)(2 * backG * foreG / 255) : (Byte)(255 - 2 * (255 - backG) * (255 - foreG) / 255)));
            foreB = (((foreB < 128) ? (Byte)(2 * backB * foreB / 255) : (Byte)(255 - 2 * (255 - backB) * (255 - foreB) / 255)));

            Normal(
                ref backA, ref backR, ref backG, ref backB,
                foreA, foreR, foreG, foreB,
                opacity
            );
        }

        public static void Add(ref Byte backA, ref Byte backR, ref Byte backG, ref Byte backB, Byte foreA, Byte foreR, Byte foreG, Byte foreB, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            foreR = (Byte)MathUtil.Min(255, backR + foreR);
            foreG = (Byte)MathUtil.Min(255, backG + foreG);
            foreB = (Byte)MathUtil.Min(255, backB + foreB);

            Normal(
                ref backA, ref backR, ref backG, ref backB,
                foreA, foreR, foreG, foreB,
                opacity
            );
        }
        public static void Screen(ref Byte backA, ref Byte backR, ref Byte backG, ref Byte backB, Byte foreA, Byte foreR, Byte foreG, Byte foreB, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            foreR = (Byte)(255 - (((255 - backR) * (255 - foreR)) >> 8));
            foreG = (Byte)(255 - (((255 - backG) * (255 - foreG)) >> 8));
            foreB = (Byte)(255 - (((255 - backB) * (255 - foreB)) >> 8));

            Normal(
                ref backA, ref backR, ref backG, ref backB,
                foreA, foreR, foreG, foreB,
                opacity
            );
        }
        public static void SoftLighten(ref Byte backA, ref Byte backR, ref Byte backG, ref Byte backB, Byte foreA, Byte foreR, Byte foreG, Byte foreB, Ratio opacity) {
            Debug.Assert(0 <= opacity && opacity <= 1);

            foreR = (Byte)((foreR < 128) ? MathUtil.Min(255, (2 * ((backR >> 1) + 64)) * (foreR / 255F)) : MathUtil.Min(255, (255 - (2 * (255 - ((backR >> 1) + 64)) * (255 - foreR) / 255F))));
            foreG = (Byte)((foreG < 128) ? MathUtil.Min(255, (2 * ((backG >> 1) + 64)) * (foreG / 255F)) : MathUtil.Min(255, (255 - (2 * (255 - ((backG >> 1) + 64)) * (255 - foreG) / 255F))));
            foreB = (Byte)((foreB < 128) ? MathUtil.Min(255, (2 * ((backB >> 1) + 64)) * (foreB / 255F)) : MathUtil.Min(255, (255 - (2 * (255 - ((backB >> 1) + 64)) * (255 - foreB) / 255F))));

            Normal(
                ref backA, ref backR, ref backG, ref backB,
                foreA, foreR, foreG, foreB,
                opacity
            );
        }

    }
}
