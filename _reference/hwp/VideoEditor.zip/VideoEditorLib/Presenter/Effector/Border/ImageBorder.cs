﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {

    // 그림으로 테두리를 그린다.
    public class ImageBorder {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Pixels Border; 
        private Pixels Mask;
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private ImageBorder(Pixels border, Pixels mask) {
            Border = border;
            Mask = mask;

        }
        public static ImageBorder Create(Pixels border, Pixels mask) {

            return new ImageBorder(border, mask);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(Pixels pixels) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);

            if (Mask != null) {
                if (Pixels.GetR(Mask.Data[0]) == 255) {
                    Tile(pixels, Mask, true);
                }              
            }


            if (Border != null) {
                if (Pixels.GetR(Border.Data[0]) == 255) {
                    Tile(pixels, Border, false);
                }  
            }

        }

        private void Tile(Pixels pixels, Pixels border, Bool mask) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(border.Data != null, eErrorCode.NullArgument);


            Count borderWidth = border.Width;
            Count borderHeight = border.Height;

            // border에서 left, top, right, bottom 영역을 추출
            Index xStart = 0;
            Index xLast = 0;

            Pixel red = 0xFFFF0000;

            for (Index i = 1; i < borderWidth; ++i) {
                if (border.Data[i] == red) {
                    xStart = i;
                    break;
                }
            }

            for (Index i = borderWidth; 0 < i; --i) {
                if (border.Data[i - 1] == red) {
                    xLast = i - 1;
                    break;
                }           
            }
            Debug.Assert(xStart < xLast);

            Index yStart = 0;
            Index yLast = 0;

            for (Index i = 1; i < borderHeight; ++i) {
                if (border.Data[i * borderWidth] == red) {
                    yStart = i;
                    break;
                }
            }

            for (Index i = borderHeight; 0 < i; --i) {
                if (border.Data[(i - 1) * borderWidth] == red) {
                    yLast = i - 1;
                    break;
                }
            }

            Debug.Assert(yStart < yLast);

            Count leftEdgeWidth = xStart - 1;
            Count topEdgeHeight = yStart - 1;
            Count rightEdgeWidth = borderWidth - xLast - 2; // 가장 오른편에 잉여 예약 픽셀 1이 있으므로 -1을 추가로 해주어 -2가 됨
            Count bottomEdgeHeight = borderHeight - yLast - 2;
            Count horizWidth = xLast - xStart + 1;
            Count vertHeight = yLast - yStart + 1;

            Pixel[] leftTop     = Extract(border, 1,         1,          leftEdgeWidth, topEdgeHeight);
            Pixel[] rightTop    = Extract(border, xLast + 1, 1, rightEdgeWidth, topEdgeHeight);
            Pixel[] leftBottom  = Extract(border, 1, yLast + 1, leftEdgeWidth, bottomEdgeHeight);
            Pixel[] rightBottom = Extract(border, xLast + 1, yLast + 1, rightEdgeWidth, bottomEdgeHeight);

            Pixel[] left    = Extract(border, 1, yStart, leftEdgeWidth, vertHeight);
            Pixel[] right   = Extract(border, xLast + 1, yStart, rightEdgeWidth, vertHeight);
            Pixel[] top     = Extract(border, xStart, 1, horizWidth, topEdgeHeight);
            Pixel[] bottom  = Extract(border, xStart, yLast + 1, horizWidth, bottomEdgeHeight);


            Draw(pixels, leftTop, 0, 0, leftEdgeWidth, topEdgeHeight, mask);
            Draw(pixels, rightTop, pixels.Width - rightEdgeWidth, 0, rightEdgeWidth, topEdgeHeight, mask);
            Draw(pixels, leftBottom, 0, pixels.Height - bottomEdgeHeight, leftEdgeWidth, bottomEdgeHeight, mask);
            Draw(pixels, rightBottom, pixels.Width - rightEdgeWidth, pixels.Height - bottomEdgeHeight, rightEdgeWidth, bottomEdgeHeight, mask);


            DrawHorizTile(pixels, top, 
                leftEdgeWidth, 0, 
                pixels.Width - leftEdgeWidth - rightEdgeWidth, 
                horizWidth, topEdgeHeight, mask);
            DrawHorizTile(pixels, bottom, 
                leftEdgeWidth, pixels.Height - bottomEdgeHeight, 
                pixels.Width - leftEdgeWidth - rightEdgeWidth, 
                horizWidth, bottomEdgeHeight, mask);

            DrawVertTile(pixels, left, 
                0, topEdgeHeight,
                pixels.Height - topEdgeHeight - bottomEdgeHeight, 
                leftEdgeWidth, vertHeight, mask);
            DrawVertTile(pixels, right,
                pixels.Width - rightEdgeWidth, topEdgeHeight,
                pixels.Height - topEdgeHeight - bottomEdgeHeight,
                rightEdgeWidth, vertHeight, mask);
        }

        private Pixel[] Extract(Pixels pixels, Index sx, Index sy, Count width, Count height) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);


            Count pixelsWidth = pixels.Width;

            Pixel[] result = new Pixel[width * height];
            Index targetPixelPos = 0;

            for (Index y = 0; y < height; ++y) {
                for (Index x = 0; x < width; ++x) {
                    if (sy + y < pixels.Height && sx + x < pixels.Width) {
                        result[targetPixelPos] = pixels.Data[(sy + y) * pixelsWidth + (sx + x)];
                        ++targetPixelPos;
                    }
                }
            }
            return result;
        }

        // pixels의 sx, sy 위치에 width, height 크기로 image를 그린다. 이때 image의 크기는 imageWidth, imageHeight이다
        private void Draw(Pixels pixels, Pixel[] image, Index sx, Index sy, Count imageWidth, Count imageHeight, Bool mask) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(image != null, eErrorCode.NullArgument);

            Count pixelsWidth = pixels.Width;
            Count pixelsHeight = pixels.Height;

            Byte a1;
            Byte r1;
            Byte g1;
            Byte b1;
            Byte a2;
            Byte r2;
            Byte g2;
            Byte b2;

            Index targetPixelPos;
            Index imagePixelPos = 0;

            for (Index y = 0; y < imageHeight; ++y) {
                for (Index x = 0; x < imageWidth; ++x) {

                    if (0 <= (sy + y) && (sy + y) < pixelsHeight &&
                        (0 <= (sx + x) && (sx + x) < pixelsWidth)) {

                        targetPixelPos = (sy + y) * pixelsWidth + (sx + x);

                        // mask인 경우 image의 red 성분을 alpha 값을 취한다.
                        if (mask) {
                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetR(image[imagePixelPos]);
                            a1 = Blend.Mask(a1, a2, 1);

                        }
                        else {
                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetA(image[imagePixelPos]);
                            r2 = Pixels.GetR(image[imagePixelPos]);
                            g2 = Pixels.GetG(image[imagePixelPos]);
                            b2 = Pixels.GetB(image[imagePixelPos]);

                            Blend.Normal(ref a1, ref r1, ref g1, ref b1, a2, r2, g2, b2, 1);

                        }

                        pixels.Data[targetPixelPos] = Pixels.ToPixel(a1, r1, g1, b1);
                    }

                    ++imagePixelPos;
                }
            }
        }

        // pixels의 sx, sy 좌표에 width 크기로 image를 채운다. 이때 image의 크기는 imageWidth, imageHeight이다
        // 이때 image는 적당하게 tile 된다. 
        private void DrawHorizTile(Pixels pixels, Pixel[] image, Index sx, Index sy, Count width, Count imageWidth, Count imageHeight, Bool mask) {


            // 원본 크기 그대로 출력한다.
            if (width == imageWidth) {
                Draw(pixels, image, sx, sy, imageWidth, imageHeight, mask);
                return;
            }

            if (width <= 0) {
                return;
            }

            Debug.Assert(imageWidth != 0);

            Count count = width / imageWidth;
            if (count == 0) count = 1;
            // 남은 영역이 절반보다 작다면 이미지를 조금 확대하고, 그렇지 않다면 이미지를 조금 축소해서 tile할 수 있도록 갯수를 증가시킨다.
            count = (width % imageWidth) < (imageWidth / 2) ? count : count + 1;
           
            // tile되는 이미지의 확대/축소 비율
            Ratio ratio = (Float)(width) / (imageWidth * count);
            Debug.Assert(ratio != 0);
            Debug.Assert(imageWidth * count != 0);

            Float sourceX = 0; // target 위치에 대응되는 source 위치
            Float sourceY = 0;
            Index srcX;
            Index srcY;

            Count imageWidth1 = imageWidth - 1;
            Count imageHeight1 = imageHeight - 1;
            Pixel nw; // 보간을 수행하기 위한 인근 픽셀들
            Pixel ne;
            Pixel sw;
            Pixel se;


            Byte a1;
            Byte r1;
            Byte g1;
            Byte b1;
                        Byte a2;
            Byte r2;
            Byte g2;
            Byte b2;

            Pixel pixel;
            Index targetPixelPos;
            Index pixelPos;

            for (Index y = 0; y < imageHeight; ++y) {
                Count minusWidth = 0;
                for (Index x = 0; x < width; ++x) {

                    sourceX = x / ratio - minusWidth; // 원본에서의 실수좌표
                    if (imageWidth - 1 < sourceX) {
                        minusWidth += imageWidth;
                        sourceX -= minusWidth;
                    }
                    sourceY = y;
                    srcX = MathUtil.Floor(sourceX); // 원본에서의 좌표
                    srcY = MathUtil.Floor(sourceY);

                    // biLinear 방식으로 보간
                    if (0 <= srcX && srcX < imageWidth1 && 0 <= srcY && srcY < imageHeight1) {
                        pixelPos = imageWidth * srcY + srcX;
                        nw = image[pixelPos];
                        ne = image[pixelPos + 1];
                        sw = image[pixelPos + imageWidth];
                        se = image[pixelPos + imageWidth + 1];
                    }
                    else {

                        nw = TransformEffect.GetPixel(image, srcX, srcY, imageWidth, imageHeight);
                        ne = TransformEffect.GetPixel(image, srcX + 1, srcY, imageWidth, imageHeight);
                        sw = TransformEffect.GetPixel(image, srcX, srcY + 1, imageWidth, imageHeight);
                        se = TransformEffect.GetPixel(image, srcX + 1, srcY + 1, imageWidth, imageHeight);
                    }
                    

                    pixel = TransformEffect.BilinearInterpolate(sourceX - srcX, sourceY - srcY, nw, ne, sw, se);


                    // target이 영역을 벗어나지 않는다면 출력한다.
                    if ((sy + y) < pixels.Height && (sx + x) < pixels.Width) {

                        targetPixelPos = (sy + y) * pixels.Width + (sx + x);

                        if (mask) {
                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetR(pixel);
                            a1 = Blend.Mask(a1, a2, 1);
                        }
                        else {

                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetA(pixel);
                            r2 = Pixels.GetR(pixel);
                            g2 = Pixels.GetG(pixel);
                            b2 = Pixels.GetB(pixel);

                            Blend.Normal(ref a1, ref r1, ref g1, ref b1, a2, r2, g2, b2, 1);
                        }

                        pixels.Data[targetPixelPos] = Pixels.ToPixel(a1, r1, g1, b1);
                    }
                }
            }
        }
        // pixels의 sx, sy 좌표에 height 크기로 image를 채운다. 이때 image의 크기는 imageWidth, imageHeight이다
        // 이때 image는 적당하게 tile 된다. 
        private void DrawVertTile(Pixels pixels, Pixel[] image, Index sx, Index sy, Count height, Count imageWidth, Count imageHeight, Bool mask) {


            // 원본 크기 그대로 출력한다.
            if (height == imageHeight) {
                Draw(pixels, image, sx, sy, imageWidth, imageHeight, mask);
                return;
            }

            if (height <= 0) {
                return;
            }

            Debug.Assert(imageHeight != 0);


            Count count = height / imageHeight;
            if (count == 0) count = 1;
            // 남은 영역이 절반보다 작다면 이미지를 조금 확대하고, 그렇지 않다면 이미지를 조금 축소해서 tile할 수 있도록 갯수를 증가시킨다.
            count = (height % imageHeight) < (imageHeight / 2) ? count : count + 1;

            // tile되는 이미지의 확대/축소 비율
            Ratio ratio = (Float)(height) / (imageHeight * count);
            Debug.Assert(ratio != 0);
            Debug.Assert(imageHeight * count != 0);

            Float sourceX = 0; // target 위치에 대응되는 source 위치
            Float sourceY = 0;
            Index srcX;
            Index srcY;

            Count imageWidth1 = imageWidth - 1;
            Count imageHeight1 = imageHeight - 1;
            Pixel nw; // 보간을 수행하기 위한 인근 픽셀들
            Pixel ne;
            Pixel sw;
            Pixel se;


            Byte a1;
            Byte r1;
            Byte g1;
            Byte b1;
            Byte a2;
            Byte r2;
            Byte g2;
            Byte b2;

            Pixel pixel;
            Index targetPixelPos;
            Index pixelPos;


            for (Index x = 0; x < imageWidth; ++x) {
                
                Count minusHeight = 0;
                for (Index y = 0; y < height; ++y) {

                    sourceY = y / ratio - minusHeight;
                    if (imageHeight - 1 < sourceY) {
                        minusHeight += imageHeight;
                        sourceY -= minusHeight;
                    }
                    sourceX = x;
                    srcX = MathUtil.Floor(sourceX);
                    srcY = MathUtil.Floor(sourceY);

                    // biLinear 방식으로 보간
                    if (0 <= srcX && srcX < imageWidth1 && 0 <= srcY && srcY < imageHeight1) {
                        pixelPos = imageWidth * srcY + srcX;
                        nw = image[pixelPos];
                        ne = image[pixelPos + 1];
                        sw = image[pixelPos + imageWidth];
                        se = image[pixelPos + imageWidth + 1];
                    }
                    else {
                        nw = TransformEffect.GetPixel(image, srcX, srcY, imageWidth, imageHeight);
                        ne = TransformEffect.GetPixel(image, srcX + 1, srcY, imageWidth, imageHeight);
                        sw = TransformEffect.GetPixel(image, srcX, srcY + 1, imageWidth, imageHeight);
                        se = TransformEffect.GetPixel(image, srcX + 1, srcY + 1, imageWidth, imageHeight);
                    }


                    pixel = TransformEffect.BilinearInterpolate(sourceX - srcX, sourceY - srcY, nw, ne, sw, se);


                    // target이 영역을 벗어나지 않는다면 출력한다.
                    if ((sy + y) < pixels.Height && (sx + x) < pixels.Width) {

                        targetPixelPos = (sy + y) * pixels.Width + (sx + x);
                        if (mask) {
                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetR(pixel);
                            a1 = Blend.Mask(a1, a2, 1);
                        }
                        else {
                            a1 = Pixels.GetA(pixels.Data[targetPixelPos]);
                            r1 = Pixels.GetR(pixels.Data[targetPixelPos]);
                            g1 = Pixels.GetG(pixels.Data[targetPixelPos]);
                            b1 = Pixels.GetB(pixels.Data[targetPixelPos]);

                            a2 = Pixels.GetA(pixel);
                            r2 = Pixels.GetR(pixel);
                            g2 = Pixels.GetG(pixel);
                            b2 = Pixels.GetB(pixel);

                            Blend.Normal(ref a1, ref r1, ref g1, ref b1, a2, r2, g2, b2, 1);
                        }

                        pixels.Data[targetPixelPos] = Pixels.ToPixel(a1, r1, g1, b1);
                    }
                }
            }
        }
    }
}