﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hnc.VideoEditor.Appbar;
using Hnc.VideoEditor.Base.Enum;
using Hnc.VideoEditor.Base.Type;
using System.Windows.Media.Animation;

namespace Hnc.VideoEditor.Controls {
	/// <summary>
	/// CustomDialog.xaml에 대한 상호 작용 논리
	/// </summary>
	public partial class CustomDialog : Window {
		public enum SUBDIALOG_STATE {
			Closed = -1,
			Export = 0,
			Info = 1,
            MessageBox = 2
		};

        public enum RESULT_STATE {
            Save = 1,
            NoSave = 2,
            Cancel = 3
        };

		// ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private ExportAppbar export = new ExportAppbar();
		private InfoAppBar info = new InfoAppBar();
        private MessageBoxAppbar messageBox = new MessageBoxAppbar();

        private RESULT_STATE messageBoxResult = RESULT_STATE.Cancel;
        public RESULT_STATE _MessageBoxResult {
            get {
                return messageBoxResult;
            }
            set {
                messageBoxResult = value;
            }
        }

		SUBDIALOG_STATE dialogID = SUBDIALOG_STATE.Closed;

		public enum ResultType {
			OK,
			NO,
			CANCEL
		}

		public ResultType Result {
			get;
			set;
		}

		public SUBDIALOG_STATE DialogID {
			get {
				return dialogID;
			}
			set {
				dialogID = value;
			}
		}
		#endregion

		// ----------------------------------------------
		// 생성자
		// ----------------------------------------------
		#region 생성자
		public CustomDialog() {
			InitWindow();
			InitializeComponent();

			panel.Children.Add(export);
			panel.Children.Add(info);
            panel.Children.Add(messageBox);
		}
		#endregion

		private void InitWindow() {
			this.Owner = Application.Current.MainWindow;

            this.PreviewKeyDown += CustomDialog_PreviewKeyDown;
		}

		private void Window_Loaded(object sender, RoutedEventArgs e) {
			DoubleAnimation ani = new DoubleAnimation(1d, new Duration(TimeSpan.FromSeconds(0.2d)));
			ani.AccelerationRatio = 0.33;
			ani.DecelerationRatio = 0.33;
			panel.BeginAnimation(Grid.OpacityProperty, ani);
		}

		private void ClickCloseBtn(object sender, System.Windows.RoutedEventArgs e) {
			this.DialogResult = true;
			this.Result = ResultType.CANCEL;
			this.Close();
		}

        void CustomDialog_PreviewKeyDown(object sender, KeyEventArgs e) {
            if (e.Key == Key.Escape) {
                this.DialogResult = true;
                this.Result = ResultType.CANCEL;
                this.Close();
            }
        }

		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		public bool ShowDialog(SUBDIALOG_STATE id, string filePath, TimelineInfo selectedInfo) {
			if (dialogID != id) {
				dialogID = id;
				export.Visibility = Visibility.Hidden;
				info.Visibility = Visibility.Hidden;
                messageBox.Visibility = Visibility.Hidden;

				if (dialogID == SUBDIALOG_STATE.Export) {
                    DialogTitle.Content = Application.Current.Resources["IDS_Export"] as String;
					export.Visibility = Visibility.Visible;
					export.SelectedInfo = selectedInfo;
					export._CustomDialog = this;
					this.Height = 150;
					this.Width = 700;
				} else if (dialogID == SUBDIALOG_STATE.Info) {
                    DialogTitle.Content = Application.Current.Resources["IDS_VideoInformation"] as String;
					info.Visibility = Visibility.Visible;
					info.SelectedFilePath = filePath;
					this.Height = 280;
					this.Width = 400;
                } else if (dialogID == SUBDIALOG_STATE.MessageBox) {
                    DialogTitle.Content = Application.Current.Resources["IDS_VideoEditor"] as String;
                    messageBox.Visibility = Visibility.Visible;
                    messageBox._CustomDialog = this;
                    this.Height = 163;
                }
			} else {
				dialogID = SUBDIALOG_STATE.Closed;
				return false;
			}

			ShowDialog();

			return true;
		}

        public void ChangeMessageBoxType(string subject, string message, double width=315, string button1 ="확인", string button2 ="", string button3="") {
            messageBox.ChangeMeesageBoxType(message, button1, button2, button3);
            messageBox.Width = width;
            this.Width = width;
        }

		public void ChangeSelectFile(string filePath) {
			info.LoadInfo(filePath);
		}

		private void Grid_MouseMove(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
		}
	}
}