﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.IO;
using System.Windows;
using System.Windows.Resources;
using System.Xml;
using Hnc.Type;

using Bool = System.Boolean;
using String = System.String;
using Hnc.Control;

namespace Hnc.VideoEditor.Util {
    
    /// <summary>
    /// 애플리케이션의 설정 정보를 관리합니다.
    /// </summary>
    sealed class SetupManager {
     
        #region -> Singleton Impl.

        private static SetupManager instance;

        public static SetupManager Instance {
            get {
                if (instance == null)
                    instance = new SetupManager();

                return instance;
            }
        }

        private SetupManager() {
            Load();            
        }

        #endregion

        #region -> Properties       

        private String lastOpenedDirectory = string.Empty;
        /// <summary>
        /// 파일 탐색 창에서 마지막으로 이동했던 경로입니다.
        /// </summary>
        public String LastOpendDirectory {
            set {
                lastOpenedDirectory = value;
                Save();
            }
            get {

				if (Hnc.Util.StringUtil.IsNullOrEmpty(lastOpenedDirectory))
                    return SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO);

                return lastOpenedDirectory;
            }
        }

        private System.Windows.Point lastWindowPosition = new System.Windows.Point(0, 0);
        /// <summary>
        /// 애플리케이션 종료 시점의 메인 윈도우 위치입니다.
        /// </summary>
        public System.Windows.Point LastWindowPosition {
            set {
                lastWindowPosition = value;
                Save();
            }
            get {
                return lastWindowPosition;
            }
        }

        private System.Windows.Size lastWindowSize = new System.Windows.Size(800, 600);
        /// <summary>
        /// 애플리케이션 종료 시점의 메인 윈도우 사이즈입니다.
        /// </summary>
        public System.Windows.Size LastWindowSize {
            set {
                lastWindowSize = value;
                Save();
            }
            get {
                return lastWindowSize;
            }
        }

        private bool isMaximized = false;
        /// <summary>
        /// 애플리케이션 종료 시점의 메인 윈도우 상태입니다.
        /// </summary>
        public bool IsMaximized {
            set {
                isMaximized = value;
                Save();
            }
            get {
                return isMaximized;
            }
        }

        private Bool isCheckedRequiredOSMessage = false;
        /// <summary>
        /// 요구 사양(OS) 메세지를 확인했는지 여부를 셋팅합니다.
        /// </summary>
        public Bool IsCheckedRequiredOSMessage {
            set {
                isCheckedRequiredOSMessage = value;
                Save();
            }
            get {
                return isCheckedRequiredOSMessage;
            }
        }

        #endregion     

        #region -> Private Methods

        private void Create() {

            Debug.AssertThrow(!File.Exists(DocumentInfo.SetupPath), eErrorCode.ExistsFile);

            using (StreamWriter writer = new StreamWriter(DocumentInfo.SetupPath)) {

                StreamResourceInfo resourceInfo =
                    Application.GetResourceStream(new Uri("/VideoEditor;Component/Resources/Setup.xml", UriKind.Relative));

                using (StreamReader reader = new StreamReader(resourceInfo.Stream)) {

                    writer.Write(reader.ReadToEnd());
                    writer.Close();
                    reader.Close();
                }
            }
        }

        private void Load() {            

            // Setup파일이 존재하지 않는다면 기본 파일 생성
            if (!File.Exists(DocumentInfo.SetupPath))
                Create();

            XmlDocument doc = new XmlDocument();
            doc.Load(DocumentInfo.SetupPath);
         
            // Setup/LastOpenedDirectory
            XmlNode node = doc.SelectSingleNode("Setup/LastOpenedDirectory");
            Debug.Assert(node != null);            

            if (node != null) {
                Debug.Assert(node.Attributes["Path"] != null);

                if (node.Attributes["Path"] != null)
                    lastOpenedDirectory = node.Attributes["Path"].Value;
            }

            // Setup/LastWindowPosition
            node = doc.SelectSingleNode("Setup/LastWindowPosition");
            Debug.Assert(node != null);                       

            if (node != null) {
                Debug.Assert(node.Attributes["Left"] != null);
                Debug.Assert(node.Attributes["Top"] != null);

                if (node.Attributes["Left"] != null)
                    lastWindowPosition.X = Double.Parse(node.Attributes["Left"].Value);
                if (node.Attributes["Top"] != null)
                    lastWindowPosition.Y = Double.Parse(node.Attributes["Top"].Value);
            }

            // Setup/LastWindowPosition
            node = doc.SelectSingleNode("Setup/LastWindowSize");
            Debug.Assert(node != null);            

            if (node != null) {
                Debug.Assert(node.Attributes["Width"] != null);
                Debug.Assert(node.Attributes["Height"] != null);

                if (node.Attributes["Width"] != null)
                    lastWindowSize.Width = Double.Parse(node.Attributes["Width"].Value);
                if (node.Attributes["Height"] != null)
                    lastWindowSize.Height = Double.Parse(node.Attributes["Height"].Value);
            }

            // Setup/LastWindowState
            node = doc.SelectSingleNode("Setup/LastWindowState");
            Debug.Assert(node != null);

            if (node != null) {
                Debug.Assert(node.Attributes["IsMaximized"] != null);

                if (node.Attributes["IsMaximized"] != null)
                    isMaximized = Bool.Parse(node.Attributes["IsMaximized"].Value);
            }

            // Setup/RequiredOSMessage
            node = doc.SelectSingleNode("Setup/RequiredOSMessage");
            Debug.Assert(node != null);

            if (node != null) {
                Debug.Assert(node.Attributes["IsChecked"] != null);

                if (node.Attributes["IsChecked"] != null)
                    isCheckedRequiredOSMessage = Bool.Parse(node.Attributes["IsChecked"].Value);
            }
        }

        private void Save() {

            using (XmlWriter writer = XmlWriter.Create(DocumentInfo.SetupPath, DocumentInfo.WriterSettings)) {
                writer.WriteStartDocument();

                // Setup
                writer.WriteStartElement("Setup");
                {
                    // Setup/LastOpenedDirectory
                    writer.WriteStartElement("LastOpenedDirectory");
                    {
                        writer.WriteAttributeString("Path", this.lastOpenedDirectory);                     
                    }
                    writer.WriteEndElement();

                    // Setup/LastWindowPosition
                    writer.WriteStartElement("LastWindowPosition");
                    {
                        writer.WriteAttributeString("Left", this.lastWindowPosition.X.ToString());
                        writer.WriteAttributeString("Top", this.lastWindowPosition.Y.ToString());
                    }
                    writer.WriteEndElement();

                    // Setup/LastWindowSize
                    writer.WriteStartElement("LastWindowSize");
                    {
                        writer.WriteAttributeString("Width", this.lastWindowSize.Width.ToString());
                        writer.WriteAttributeString("Height", this.lastWindowSize.Height.ToString());
                    }
                    writer.WriteEndElement();

                    // Setup/LastWindowState
                    writer.WriteStartElement("LastWindowState");
                    {
                        writer.WriteAttributeString("IsMaximized", this.isMaximized.ToString());
                    }
                    writer.WriteEndElement();

                    // Setup/RequiredOSMessage
                    writer.WriteStartElement("RequiredOSMessage");
                    {
                        writer.WriteAttributeString("IsChecked", this.isCheckedRequiredOSMessage.ToString());
                    }
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();

                writer.WriteEndDocument();
            }
        }

        #endregion
    }
}
