﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Index = System.Int32;
using Bool = System.Boolean;


namespace Hnc.Presenter.ImageEffect {

    // 픽셀을 분산시켜 흩부린듯한 효과를 준다.
    public class Sphere : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        Float XCenter; // 중심위치 픽셀 좌표
        Float YCenter;

        Float WidthRadius; // 구체의 반경
        Float HeightRadius;
        
        Float WidthRadius2;
        Float HeightRadius2;

        // 굴절 정도. 1.5가 적절 1 ~ 3
        private Ratio RefractionIndex = 1.5F;

        Bool IsBall = true; // 전체를 공모양으로 왜곡한다. false 이면 주어진 WidthRadius, HeightRadius 영역만 변경한다.
        

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // 
        private Sphere(Float xCenter, Float yCenter, Float widthRadius, Float heightRadius, Ratio refractionIndex, Bool isBall)
            : base() {

            XCenter = xCenter;
            YCenter = yCenter;
            WidthRadius = widthRadius;
            HeightRadius = heightRadius;
            RefractionIndex = MathUtil.Clamp(refractionIndex, 1, 3);
            IsBall = isBall;


            WidthRadius2 = WidthRadius * WidthRadius;
            HeightRadius2 = HeightRadius * HeightRadius;
  
            Debug.AssertThrow(WidthRadius2 != 0, eErrorCode.DevideZero);
            Debug.AssertThrow(HeightRadius2 != 0, eErrorCode.DevideZero);
        }
        public static Sphere Create(Float xCenter, Float yCenter, Float widthRadius, Float heightRadius, Ratio refractionIndex, Bool isBall) {
            return new Sphere(xCenter, yCenter, widthRadius, heightRadius, refractionIndex, isBall);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {
            Debug.Assert(RefractionIndex != 0);


            if (IsBall) {
                Float dx = targetX - XCenter;
                Float dy = targetY - YCenter;

                Float theta = MathUtil.Atan(dy / dx); // atan(INF) 가 계산시 문제 없으므로 그냥 놔둠.
                Float radius = MathUtil.Sqrt(dx * dx + dy * dy);
                radius = radius * radius / MathUtil.Max(YCenter, XCenter);

                if (dx < 0) {
                    originX = XCenter - (Int)(radius * MathUtil.Cos(theta));
                    originY = YCenter - (Int)(radius * MathUtil.Sin(theta));
                }
                else {
                    originX = XCenter + (Int)(radius * MathUtil.Cos(theta));
                    originY = YCenter + (Int)(radius * MathUtil.Sin(theta));
                }
            }
            else {


                Float dx = targetX - XCenter;
                Float dy = targetY - YCenter;
                Float x2 = dx * dx;
                Float y2 = dy * dy;

                // 영역 바깥
                if ((HeightRadius2 - (HeightRadius2 * x2) / WidthRadius2) <= y2) {
                    originX = targetX;
                    originY = targetY;
                }
                // 영역내부
                else {
                    Float rRefraction = 1F / RefractionIndex;

                    Float z = MathUtil.Sqrt((1F - x2 / WidthRadius2 - y2 / HeightRadius2) * (WidthRadius * HeightRadius));
                    Float z2 = z * z;

                    Float xAngle = MathUtil.Acos(dx / MathUtil.Sqrt(x2 + z2));
                    Float angle1 = MathUtil.HALF_PI - xAngle;
                    Float angle2 = MathUtil.Asin(MathUtil.Sin(angle1) * rRefraction);
                    angle2 = MathUtil.HALF_PI - xAngle - angle2;
                    originX = targetX - MathUtil.Tan(angle2) * z;

                    Float yAngle = MathUtil.Acos(dy / MathUtil.Sqrt(y2 + z2));
                    angle1 = MathUtil.HALF_PI - yAngle;
                    angle2 = MathUtil.Asin(MathUtil.Sin(angle1) * rRefraction);
                    angle2 = MathUtil.HALF_PI - yAngle - angle2;
                    originY = targetY - MathUtil.Tan(angle2) * z;
                }
            }
        }
        #endregion

    }
}
