﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using System.Windows.Controls;

namespace Hnc.VideoEditor.Controls {
    // ----------------------------------------------
    // SpinControl 3개를 합쳐 시, 분, 초를 나타낼 수 있도록 만든 컨트롤
    // ---------------------------------------------- 
    public partial class TimePicker : UserControl {
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        #region 생성자
        public TimePicker() {
            InitializeComponent();
        }
        #endregion

        // ----------------------------------------------
        // 메소드
        // ----------------------------------------------
        #region 메소드
        public Int ToSecond() {
            return (Hour.Value * 60 * 60) + (Minute.Value * 60) + Second.Value;
        }

        public void FromSecond(int second) {
            Second.Value = second % 60;
            Minute.Value = second / 60;
            Hour.Value = second / (60 * 60);
        }

        public void InitTime() {
            Hour.Value = 0;
            Minute.Value = 0;
            Second.Value = 0;
        }

        public Int GetHour() {
            return Hour.Value;
        }

        public Int GetMinute() {
            return Minute.Value;
        }

        public Int GetSecond() {
            return Second.Value;
        }
        #endregion
    }
}
