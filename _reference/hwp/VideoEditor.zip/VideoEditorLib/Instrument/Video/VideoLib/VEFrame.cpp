/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "VEFrame.h"

#include "Effect.h"

VEFrame::VEFrame() {
	numBytes = 0;
	buffer = NULL;
	originalFrame = NULL;
	changeFrame = NULL;

	effect = NULL;
	enumEffect = enumOriginal;
	originalWidth = DEFAULT_SIZE;
	originalHeight = DEFAULT_SIZE;
	changeWidth = DEFAULT_SIZE;
	changeHeight = DEFAULT_SIZE;
	frameCount = FADE_NONE;
	frameLengh = FADE_NONE;

	change = false;

	frameFmt = PIX_FMT_YUV420P;
}

VEFrame::VEFrame(AVFrame* frame, enum PixelFormat fmt) {
	originalFrame = frame;
	frameFmt = fmt;

	numBytes = 0;
	buffer = NULL;
	changeFrame = NULL;

	effect = NULL;
	enumEffect = enumOriginal;

	originalWidth = originalFrame->width;
	originalHeight = originalFrame->height;
	changeWidth = originalWidth;
	changeHeight = originalHeight;
	frameCount = FADE_NONE;
	frameLengh = FADE_NONE;

	change = false;
}

VEFrame::~VEFrame() {
	numBytes = 0;

	if (buffer != NULL) {
		delete [] buffer;
	}

	if (changeFrame != NULL) {
		av_free(changeFrame);
	}

	if (originalFrame != NULL) {
	//	av_free(originalFrame);
	}

	if (effect != NULL) {
		delete effect;
	}
}

AVFrame* VEFrame::GetFrame() {
	if (changeFrame != NULL) {
		return changeFrame;
	}

	return originalFrame;
}

AVFrame* VEFrame::GetOriginalFrame() {
	return originalFrame;
}

AVFrame* VEFrame::GetChangeFrame() {
	return changeFrame;
}

void VEFrame::SetSize(Int width, Int height) {

	if (changeWidth != width) {
		changeWidth = width;
		change = true;
	}

	if (changeHeight != height) {
		changeHeight = height;
		change = true;
	}
}

void VEFrame::SetFadeInFadeOut(Int64_t frameCount, Int64_t frameLengh) {
	// ���̵������̵�ƿ�����
	this->frameCount = frameCount;
	this->frameLengh = frameLengh;
}

void VEFrame::SetEffect(Effect enumEffect) {
//	if (this->enumEffect != enumEffect) {
		this->enumEffect = enumEffect;
		
		if (effect != NULL) {
			delete effect;
			effect = NULL;
		}

		if (enumEffect == enumGray) {
			effect = new Gray();
		} else if (enumEffect == enumRed) {
			effect = new Red();
		} else if (enumEffect == enumGreen) {
			effect = new Green();
		} else if (enumEffect == enumBlue) {
			effect = new Blue();
		} else if (enumEffect == enumYellow) {
			effect = new Yellow();
		} else if (enumEffect == enumOrange) {
			effect	= new Orange();
		} else {
			effect = new None();
		}

		change = true;
//	}
}

Bool VEFrame::ApplyFrame() {
	if (change == true) {
		EffectFrame();

		/*
		if (enumEffect != enumOriginal) {
			EffectFrame();
		} else {
			ResizeFrame(PIX_FMT_YUV420P, PIX_FMT_YUV420P);
		}
		*/

		change = false;
	}

	return true;
}

Bool VEFrame::EffectFrame() {
	if (originalFrame == NULL) {
		return false;
	}

	Int tempWidth = changeWidth;
	Int tempHeight = changeHeight;
	AVFrame* tempFrame = NULL;
	tempFrame = avcodec_alloc_frame();

	if (tempFrame == NULL) {
		return false;
	}

	Int tempNumBytes = avpicture_get_size(PIX_FMT_RGB24, tempWidth, tempHeight);
	UInt8_t* tempBuffer = new UInt8_t[tempNumBytes];
	avpicture_fill((AVPicture*) tempFrame, tempBuffer, PIX_FMT_RGB24, tempWidth, tempHeight);

	struct SwsContext* toTempContext = sws_getContext(originalWidth, originalHeight, frameFmt,
																				tempWidth, tempHeight, PIX_FMT_RGB24,
																				SWS_BICUBIC, NULL, NULL, NULL);

	if (toTempContext != NULL) {
		sws_scale(toTempContext, originalFrame->data, originalFrame->linesize, 0, originalHeight, tempFrame->data, tempFrame->linesize);
		tempFrame->width = tempWidth;
		tempFrame->height = tempHeight;
		tempFrame->format = PIX_FMT_RGB24;
		sws_freeContext(toTempContext);
	}

	// ȿ�� ����
	if (effect != NULL) {
		effect->Apply(tempFrame, frameCount, frameLengh);
	}

	if (tempFrame == NULL) {
		return false;
	}

	if (changeFrame != NULL) {
		delete [] buffer;
		av_free(changeFrame);
		changeFrame = NULL;
	}

	changeFrame = avcodec_alloc_frame();

	if (changeFrame == NULL) {
		return false;
	}

	numBytes = avpicture_get_size(PIX_FMT_YUV420P, changeWidth, changeHeight);
	buffer = new UInt8_t[numBytes];
	avpicture_fill((AVPicture*) changeFrame, buffer, PIX_FMT_YUV420P, changeWidth, changeHeight);

	struct SwsContext* toContext = sws_getContext(tempWidth, tempHeight, PIX_FMT_RGB24,
													changeWidth, changeHeight, PIX_FMT_YUV420P,
													SWS_BICUBIC, NULL, NULL, NULL);

	if (toContext != NULL) {
		sws_scale(toContext, tempFrame->data, tempFrame->linesize, 0, tempHeight, changeFrame->data, changeFrame->linesize);
		changeFrame->width = changeWidth;
		changeFrame->height = changeHeight;
		changeFrame->format = PIX_FMT_YUV420P;

		sws_freeContext(toContext);
	}

	if (tempBuffer != NULL) {
		delete [] tempBuffer;
	}

	if (tempFrame != NULL) {
		av_free(tempFrame);
	}

	changeFrame->pts = originalFrame->pts;

	return true;
}

Bool VEFrame::ResizeFrame(enum PixelFormat dstFmt, enum PixelFormat srcFmt) {
	if (originalFrame != NULL) {
		if (changeFrame != NULL) {
			delete [] buffer;
			av_free(changeFrame);
			changeFrame = NULL;
		}

		changeFrame = avcodec_alloc_frame();

		if (changeFrame == NULL) {
			return false;
		}

		numBytes = avpicture_get_size(dstFmt, changeWidth, changeHeight);
		buffer = new UInt8_t[numBytes];
		avpicture_fill((AVPicture*) changeFrame, buffer, dstFmt, changeWidth, changeHeight);

		struct SwsContext* toContext = sws_getContext(originalWidth, originalHeight, srcFmt,
														changeWidth, changeHeight, dstFmt,
														SWS_BICUBIC, NULL, NULL, NULL);

		if (toContext != NULL) {
			sws_scale(toContext, originalFrame->data, originalFrame->linesize, 0, originalHeight, changeFrame->data, changeFrame->linesize);
			changeFrame->width = changeWidth;
			changeFrame->height = changeHeight;
			changeFrame->format = dstFmt;
		}
			
		sws_freeContext(toContext);
	}

	return true;
}