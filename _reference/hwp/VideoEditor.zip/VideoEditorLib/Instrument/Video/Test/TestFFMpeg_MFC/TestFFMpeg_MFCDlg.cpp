
// TestFFMpeg_MFCDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "TestFFMpeg_MFC.h"
#include "TestFFMpeg_MFCDlg.h"



//#include "../../VideoLib/FileInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTestFFMpeg_MFCDlg ��ȭ ����
CTestFFMpeg_MFCDlg::CTestFFMpeg_MFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestFFMpeg_MFCDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestFFMpeg_MFCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTestFFMpeg_MFCDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_FILEOPEN, &CTestFFMpeg_MFCDlg::OnBnClickedButtonFileopen)
	ON_BN_CLICKED(IDC_BUTTON_GETFRAME, &CTestFFMpeg_MFCDlg::OnBnClickedButtonGetframe)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, &CTestFFMpeg_MFCDlg::OnBnClickedButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CTestFFMpeg_MFCDlg::OnBnClickedButtonStop)
END_MESSAGE_MAP()


// CTestFFMpeg_MFCDlg �޽��� ó����

BOOL CTestFFMpeg_MFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	/*
	HMODULE module = ::LoadLibrary(_T("HncFFMpegLib.dll"));

	if (module == NULL) {
		int aaa = 10;
		aaa = 20;
	}
	*/

	image.pixel = NULL;
	image.height = 240;
	image.width = 320;

	isPlay = FALSE;

	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸�����
//  �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
//  �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CTestFFMpeg_MFCDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this);
		// CDC* dc = GetDC();

		static int isCreate = 0;
		if (isCreate == 0) {
			memDC.CreateCompatibleDC(&dc);
			bmp.CreateCompatibleBitmap(&dc, image.width, image.height);
			pOldBmp = memDC.SelectObject(&bmp);
			++isCreate;
		}

		if (image.pixel != NULL) {
			for (int y=0; y<image.height; ++y) {
				int xxxx = 0;
				for (int x=0; x<image.width*3; x+=3) {
					unsigned char R = image.pixel[y][x];
					unsigned char G = image.pixel[y][x+1];
					unsigned char B = image.pixel[y][x+2];
					memDC.SetPixel(xxxx, y, RGB(R,G,B));
					xxxx++;
				}
			}

			
			SetTextColor(memDC, RGB(255, 255, 255));
			SetBkMode(memDC, TRANSPARENT);
			/*
			RECT rect;
			rect.left = 100;
			rect.top = 30;
			rect.right = 250;
			rect.bottom = 130;

			memDC.DrawText(_T("�ڸ���� �׽�Ʈ1"), &rect, DT_SINGLELINE);

			RECT rect2;
			rect2.left = 100;
			rect2.top = 160;
			rect2.right = 250;
			rect2.bottom = 260;

			SetTextColor(memDC, RGB(0, 255, 0));
			SetBkMode(memDC, OPAQUE);

			memDC.DrawText(_T("�ڸ���� �׽�Ʈ2"), &rect2, DT_SINGLELINE);
			*/
		}

		dc.BitBlt(0, 0, image.width, image.height, &memDC, 0, 0, SRCCOPY);
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�.
HCURSOR CTestFFMpeg_MFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CTestFFMpeg_MFCDlg::OnBnClickedButtonFileopen()
{

}

void CTestFFMpeg_MFCDlg::OnBnClickedButtonGetframe()
{
		// HncFFMpegLib lib;
//		VideoLib videoLib;
//		videoLib.Export("c:\\play3.wmv", "c:\\export123.avi");
		int retval;
		//videoLib.Get GetAu Frame("c:\\1.avi", count, frameIndex, images, 320, 240);

		/*
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\1.avi", &info);
		*/

		/*
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		*/

		/*
		retval = videoLib.GetVideoInfo("c:\\���Ƹ�\\2.avi", &info);
		retval = videoLib.GetVideoInfo("c:\\3.ts", &info);
		retval = videoLib.GetVideoInfo("c:\\play.wmv", &info);
		retval = videoLib.GetVideoInfo("c:\\wildlife.wmv", &info);
		*/

		videoLib.ClearImage(&image);

		retval = videoLib.GetFrame("c:\\01.wmv", &image, 320, 240);

		// retval = videoLib.GetFrame("c:\\���Ƹ�\\1.avi", 2100, &image);

		if (retval != 0) {
			Invalidate();
		}
}
/*
void CTestFFMpeg_MFCDlg::ChangeImage() {
	
		if (image.pixel != NULL) {
			for (int y=0; y<image.height; ++y) {
				int xxxx = 0;
				for (int x=0; x<image.width*3; x+=3) {
					unsigned char R = image.pixel[y][x];
					unsigned char G = 0;//image.pixel[y][x+1];
					unsigned char B = 0;//image.pixel[y][x+2];
					memDC.SetPixel(xxxx, y, RGB(R,G,B));
					xxxx++;
				}
			}
		}

}
*/

void CTestFFMpeg_MFCDlg::OnBnClickedButtonPlay()
{
	
	videoLib.NewTimeline();

	// videoLib.AddTimelineInfo("c:\\���Ƹ�\\1.avi", enumOriginal, 200, 500);
	// videoLib.AddTimelineInfo("c:\\���Ƹ�\\1.avi", enumOriginal, 1508, 2562);
/*
	videoLib.AddTimelineInfo("c:\\Wildlife_60.avi", enumOriginal, 0, 200);
	videoLib.AddTimelineInfo("c:\\60.avi", enumOriginal, 0, 200);
	videoLib.AddTimelineInfo("c:\\new_60.avi", enumOriginal, 0, 200);
	videoLib.AddTimelineInfo("c:\\other_60.avi", enumOriginal, 0, 200);
*/
//	videoLib.AddTimelineInfo("c:\\Wildlife_5.avi", enumOriginal, 0, 200);

	//videoLib.GetVideoInfo("c:\\Movie8.avi", &info);
	//videoLib.GetVideoInfo("c:\\1111.avi", &info);
	//videoLib.GetVideoInfo("c:\\test2.avi", &info);

	//videoLib.AddTimelineInfo("c:\\Wildlife.wmv", enumOriginal, 300, 450);
	videoLib.AddTimelineInfo("c:\\Wildlife - ���纻.wmv", enumOriginal, 0, 400);

	//videoLib.AddTimelineInfo("c:\\Wildlife.wmv", enumOriginal, 775, 1000);
	/*
	videoLib.AddTimelineInfo("c:\\Wildlife.wmv", enumOriginal, 800, 1200);
	videoLib.AddTimelineInfo("c:\\Wildlife.wmv", enumOriginal, 1200, 1600);
	*/

	/*
	videoLib.AddTimelineInfo("c:\\Wildlife_30.avi", enumOriginal, 0, 200);
	videoLib.AddTimelineInfo("c:\\Wildlife_5.avi", enumOriginal, 0, 200);
	videoLib.AddTimelineInfo("c:\\Wildlife_5.avi", enumOriginal, 0, 200);
*/
	
//	videoLib.AddTimelineInfo(NULL, enumOriginal, 0, 200);
//	videoLib.AddTimelineInfo("c:\\���Ƹ�\\1.avi", enumOriginal, 0, 200);
//	videoLib.AddTimelineInfo("c:\\2.avi", 1000, 1100);

//	int ret = videoLib.Export("c:\\output\\output14.avi");

	int ret = videoLib.CreateOutputfileInfo("c:\\output\\g1.avi", 320, 240, 30, AV_CODEC_ID_MPEG4, AV_CODEC_ID_MP3);


	// AV_CODEC_ID_MPEG4
	// AV_CODEC_ID_MSMPEG4V3
	// AV_CODEC_ID_WMV2
	// AV_CODEC_ID_H264

	/*
	static int aaa = 0;

	int ret;

	if (aaa == 0) {
		 ret = videoLib.CreateOutputfileInfo("d:\\test\\1.avi", 320, 240, 60, AV_CODEC_ID_MPEG4, AV_CODEC_ID_NONE);
	} else {
		ret = videoLib.CreateOutputfileInfo("c:\\VideoTest\\031801.avi", 1280, 720, 30, AV_CODEC_ID_MPEG4, AV_CODEC_ID_NONE);
	}
	*/
	
	if (ret == SUCCESS) {
		//ret = videoLib.Export();
		ret = videoLib.ExportEx();

		if (ret != SUCCESS) {
			int a = 10;
			a = 20;
		}

		ret = videoLib.DeleteOutputfileInfo();

		if (ret != SUCCESS) {
			int a = 10;
			a = 20;
		}
	} else {
		int a = 10;
		a = 20;
	}

	videoLib.DeleteTimeline();
	//videoLib.Export("c:\\1.avi", "c:\\output\\output9.avi") ;

}

void CTestFFMpeg_MFCDlg::OnBnClickedButtonStop()
{
	StartThread();
}

void CTestFFMpeg_MFCDlg::StartThread() {
	pThreadExport = AfxBeginThread(ThreadExport, (LPVOID)this);
	pThreadState = AfxBeginThread(ThreadState, (LPVOID)this);
}

void CTestFFMpeg_MFCDlg::StartExport() {
	videoLib.NewTimeline();

	// videoLib.AddTimelineInfo("c:\\1.avi", enumBlue, 100, 500);
	// videoLib.AddTimelineInfo("c:\\2.avi", enumGreen, 300, 800);

	videoLib.AddTimelineInfo("c:\\���Ƹ�\\1.avi", (Effect) 0, 100, 90000);
//	videoLib.AddTimelineInfo("c:\\2.avi", (Effect) 0, 300, 1400);
//	videoLib.AddTimelineInfo("c:\\2.avi", 1000, 1100);

//	int ret = videoLib.Export("c:\\output\\output14.avi");

	int ret = videoLib.CreateOutputfileInfo("c:\\output\\test26.avi", 800, 600, 30, (AVCodecID) 13, (AVCodecID) 0);
	
	if (ret == SUCCESS) {
		if (videoLib.Export() == SUCCESS) {
			AfxMessageBox(_T("����"));
		}

		videoLib.DeleteOutputfileInfo();
	}
}

UINT ThreadExport(LPVOID param) {
	CTestFFMpeg_MFCDlg* dlg = (CTestFFMpeg_MFCDlg*) param;
	dlg->StartExport();

	return 0;
}

UINT ThreadState(LPVOID param) {
	CTestFFMpeg_MFCDlg* dlg = (CTestFFMpeg_MFCDlg*) param;
	
	while(true) {
		ExportInfo info = dlg->videoLib.GetExportInfo();

		int per = 0;

		if (info.state == ExportNone) {
			per = 0;
		} else {
			if (info.totalFrameCount <= 0 || info.encodingFrameCount <= 0) {
				per = 0;
			} else {
				per = (int) (((double)info.encodingFrameCount / (double)info.totalFrameCount) * 100);
			}
		}

		TCHAR buf[20];

		_stprintf_s(buf, _countof(buf), _T("%.2d%%"), per);

		dlg->GetDlgItem(IDC_EDIT_FILEPATH)->SetWindowText(buf);

		Sleep(100);
	}

	return 0;
}