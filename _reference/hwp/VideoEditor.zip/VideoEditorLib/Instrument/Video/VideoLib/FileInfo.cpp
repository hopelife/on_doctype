/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include <sys/stat.h>
#include <time.h>
#include "FileInfo.h"




FileInfo::FileInfo(const Char* fullFilePath)	:	pcImage(NULL),
													isExcutable(FALSE),
													fileSize(0),
													isOpened(FALSE) {
	memset(this->fileName, 0x00, sizeof(this->fileName));
	memset(this->fullFilePath, 0x00, sizeof(this->fullFilePath));
	memset(this->fileExtension, 0x00, sizeof(this->fileExtension));
	memset(this->fileModifyDate, 0x00, sizeof(this->fileModifyDate));
	memset(this->fileCreateDate, 0x00, sizeof(this->fileCreateDate));

	strcpy_s(this->fullFilePath, MAX_FILEPATH, fullFilePath);

	hFile = INVALID_HANDLE_VALUE;
	hMapping = NULL;
	pcImage = NULL;	
	
	InfoAll();
}

FileInfo::~FileInfo() {
	CloseFile();
}

Int FileInfo::OpenFile() {
	if (hFile != INVALID_HANDLE_VALUE) {
        CloseFile();
    }
	
    hFile = CreateFile(fullFilePath, GENERIC_READ , FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        return FA_ERR_FILEOPEN;
    }
	
    hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, "PE");
    if (hMapping == NULL) {
        return FA_ERR_MAPPING;
    }
	
    pcImage = (Char*) MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, 0);
	
    return FA_OPEN_SUCCESS;
}

void FileInfo::CloseFile() {
    if (hFile != INVALID_HANDLE_VALUE) {
        CloseHandle(hFile);
    }
    
    if (hMapping != NULL) {
        CloseHandle(hMapping);
    }
	
    if(pcImage != NULL) {
        UnmapViewOfFile(pcImage);
    }
	
    hFile = INVALID_HANDLE_VALUE;
    hMapping = NULL;
    pcImage = NULL;
}

Bool FileInfo::InfoExcutableFile() {
	if(pcImage == NULL) {
        return FALSE;
    }

    pstImageDosHeader = (PIMAGE_DOS_HEADER) pcImage;

	if(pstImageDosHeader == NULL) {
        return FALSE;
    }

	if (pstImageDosHeader->e_magic != IMAGE_DOS_SIGNATURE) {
        return FALSE;
	}

    pstImageNtHeader = (PIMAGE_NT_HEADERS) (pcImage + pstImageDosHeader->e_lfanew);

	if(pstImageNtHeader == NULL) {
        return FALSE;
    }

	if (pstImageNtHeader->Signature != IMAGE_NT_SIGNATURE) {
        return FALSE;
	}

    return TRUE;
}

Bool FileInfo::InfoFileAttribute() {


	FILE* stream = fopen(fullFilePath, "r");
	if(stream != NULL) {
		struct stat statbuf;

		fstat(fileno(stream), &statbuf);
		fclose(stream);

		fileSize = (ULong) statbuf.st_size;

		Int nameLen = strlen(fullFilePath);
		Int i;
		for (i = nameLen-1; i>0; i--) {
			if (fullFilePath[i]=='.') {
				break;
			}
		}

		strcpy_s(fileExtension, MAX_EXTENSION, &fullFilePath[i]);
		for (i = nameLen-1; i>0; i--) {
			if (fullFilePath[i]=='\\') {
				break;
			}
		}

		strcpy_s(fileName, MAX_FILEPATH, &fullFilePath[i+1]);

		CTime tempMTime = statbuf.st_mtime;
		CTime tempCTime = statbuf.st_ctime;
		sprintf_s(fileModifyDate, MAX_DATE, "%04d-%02d-%02d %02d:%02d:%02d", 
														tempMTime.GetYear(), tempMTime.GetMonth(), tempMTime.GetDay(), 
														tempMTime.GetHour(), tempMTime.GetMinute(), tempMTime.GetSecond());

		sprintf_s(fileCreateDate, MAX_DATE, "%04d-%02d-%02d %02d:%02d:%02d", 
														tempCTime.GetYear(), tempCTime.GetMonth(), tempCTime.GetDay(), 
														tempCTime.GetHour(), tempCTime.GetMinute(), tempCTime.GetSecond());

		return TRUE;
	}

/*
	CFileStatus tempStatus;

	if (CFile::GetStatus(fullFilePath, tempStatus)) {
		fileSize = (ULong) tempStatus.m_size;
		
		Int nameLen = strlen(fullFilePath);
		Int i;
		for (i = nameLen-1; i>0; i--) {
			if (fullFilePath[i]=='.') {
				break;
			}
		}

		strcpy_s(fileExtension, MAX_EXTENSION, &fullFilePath[i]);
		for (i = nameLen-1; i>0; i--) {
			if (fullFilePath[i]=='\\') {
				break;
			}
		}

		strcpy_s(fileName, MAX_FILEPATH, &fullFilePath[i+1]);
		CTime tempMTime = tempStatus.m_mtime;
		CTime tempCTime = tempStatus.m_ctime;
		sprintf_s(fileModifyDate, MAX_DATE, "%04d-%02d-%02d %02d:%02d:%02d", 
														tempMTime.GetYear(), tempMTime.GetMonth(), tempMTime.GetDay(), 
														tempMTime.GetHour(), tempMTime.GetMinute(), tempMTime.GetSecond());

		sprintf_s(fileCreateDate, MAX_DATE, "%04d-%02d-%02d %02d:%02d:%02d", 
														tempCTime.GetYear(), tempCTime.GetMonth(), tempCTime.GetDay(), 
														tempCTime.GetHour(), tempCTime.GetMinute(), tempCTime.GetSecond());
		return TRUE;
	}
	*/

	return FALSE;
}

Int FileInfo::InfoAll() {
	Int res;

	if (!InfoFileAttribute()) {
		return FA_ERR_FILEOPEN;
	}

	res = OpenFile();
	if (res!=FA_OPEN_SUCCESS) {
		CloseFile();
		return res;
	}
	
	if (InfoExcutableFile()) {
		isExcutable = TRUE;
	}
	
	CloseFile();

	isOpened = TRUE;
	return FA_ALL_SUCCESS;
}

Char* FileInfo::GetFileName() {
	return fileName;
}

Char* FileInfo::GetFullFilePath() {
	return fullFilePath;
}

Char* FileInfo::GetFileExtension() {
	return fileExtension;
}

ULong FileInfo::GetFileSize() {
	return fileSize;
}

Char* FileInfo::GetFileModifyDate() {
	return fileModifyDate;
}

Char* FileInfo::GetFileCreateDate() {
	return fileCreateDate;
}

Bool FileInfo::GetFileExcutablity() {
	return isExcutable;
}

Bool FileInfo::IsOpened() {
	return isOpened;
}