﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Controls {
	using System;
	using System.Windows.Controls;
	
	public partial class PositionBar : Grid {

		#region 멤버변수
		private double _positionGap = 7.5;
		private double _sliderGap = 0.0;
		private bool _isStartBar = true;
		private double _sliderWidth = 0.0;
		private double _totalSeconds = 0.0;
		private double _positionValue = 0.0;
		private double _secondsValue = 0.0;
		#endregion // 멤버변수

		#region Property
		public double PositionGap {
			get {
				return _positionGap;
			}
			set {
				if (_positionGap != value) {
					_positionGap = value;
				}
			}
		}

		public double SliderGap {
			get {
				return _sliderGap;
			}
			set {
				if (_sliderGap != value) {
					_sliderGap = value;
				}
			}
		}

		public bool IsStartBar {
			get {
				return _isStartBar;
			}
			set {
				if (_isStartBar != value) {
					_isStartBar = value;
				}
			}
		}

		public double SliderWidth {
			get {
				return _sliderWidth;
			}
			set {
				if (_sliderWidth != value) {
					_sliderWidth = value;

					_positionValue = SecondsValueToSliderValue(_secondsValue);
					this.SetValue(Canvas.LeftProperty, _positionValue);
				}
			}
		}

		public double TotalSeconds {
			get {
				return _totalSeconds;
			}
			set {
				if (_totalSeconds != value) {
					_totalSeconds = value;
				}
			}
		}

		public double PositionValue {
			get {
				return _positionValue;
			}
			set {
				if (value < 0.0) {
					value = 0.0;
				}
				
				if (_positionValue != value) {
					_positionValue = value;
					_secondsValue = SliderValueToSecondsValue(_positionValue);
					this.SetValue(Canvas.LeftProperty, _positionValue);
				}
			}
		}

		public double SecondsValue {
			get {
				return _secondsValue;
			}
			set {
				if (value < 0.0) {
					value = 0.0;
				}

				if (_secondsValue != value) {
					_secondsValue = value;
					_positionValue = SecondsValueToSliderValue(_secondsValue);
					this.SetValue(Canvas.LeftProperty, _positionValue);
				}
			}
		}
		#endregion // Property

		#region 생성자
		public PositionBar() {
			InitializeComponent();
		}
		#endregion // 생성자

		#region 멤버함수
		double SecondsValueToSliderValue(double value) {
			if ((_sliderWidth * value) == 0.0) {
				return 0.0;
			} else if (_totalSeconds == 0.0) {
				return 0.0;
			}

			double result = 0.0;
			try {
				result = (_sliderWidth * value) / _totalSeconds;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "SecondsValueToSliderValue 0으로 나누려고 했습니다.");
				result = 0.0;
			} catch {
				Hnc.Type.Debug.Assert(false, "SecondsValueToSliderValue에서 except가 발생했습니다.");
				result = 0.0;
			}

			return result;
		}

		double SliderValueToSecondsValue(double value) {
			if ((_totalSeconds * value) == 0.0) {
				return 0.0;
			} else if (_sliderWidth == 0.0) {
				return 0.0;
			}

			double result = 0.0;
			try {
				result = (_totalSeconds * value) / _sliderWidth;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "SliderValueToSecondsValue 0으로 나누려고 했습니다.");
				result = 0.0;
			} catch {
				Hnc.Type.Debug.Assert(false, "SliderValueToSecondsValue에서 except가 발생했습니다.");
				result = 0.0;
			}

			return result;
		}
		#endregion // 멤버함수
	}
}