﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Int = System.Int32;
using Byte = System.Byte;
using Pixel = System.UInt32;
using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    // byte 값을 갖는 테이블
    public class LookupTable {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Byte[] Data = new Byte[256]; // 참조속도 향상을 위해 직접 액세스


        public Count Count {
            get {
                return Data.Length;
            }
        }

        // ----------------------------------------------
        // 생성자 연산자
        // ----------------------------------------------
        private LookupTable() {
        }
        public static LookupTable Create() {
            return new LookupTable();
        }
    }


    // pixel 값을 갖는 테이블
    class PixelTable {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Pixel[] Data = new Pixel[256]; // 참조속성 향상을 위해 직접 액세스

        // ----------------------------------------------
        // 생성자 연산자
        // ----------------------------------------------
        private PixelTable() { 
        
        }
        public static PixelTable Create() {
            return new PixelTable();
        }
    }

    // singleton
    sealed class GrayscaleTable {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Int[] r = new Int[256]; // 2의 10승으로 저장한다.
        private Int[] g = new Int[256];
        private Int[] b = new Int[256];

        private static readonly GrayscaleTable instance;
        public static GrayscaleTable Instance {
            get {
                Debug.Assert(instance != null);
                return instance;
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        static GrayscaleTable() {
            instance = new GrayscaleTable();
        }
        private GrayscaleTable() {

            // 또다른 Grayscale 공식들 
            // NTSC 공식 : 0.299*R + 0.587*G + 0.114*B -> 대비가 약하게 표시된다.
            // SQRT(R^2 + G^2 + B^2) / SQRT(3) -> 조금 밝게 처리된다.
            for (Int i = 0; i < 256; ++i) {
                // LookupTable Y709=0.2126R+0.7152G + 0.0712B
                r[i] = i * 218; // 218 = 0.2126*1024
                g[i] = i * 732; // 732 = 0.7152*1024
                b[i] = i * 73;  //  73 = 0.0712*1024
            }
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public Byte GetAt(Byte r, Byte g, Byte b) {
            return (Byte)((this.r[r] + this.g[g] + this.b[b]) >> 10); // 2의10승으로 스케일한 값이기 때문에 2의10승(1024) 으로 나눠준다.
        }

    }
}
