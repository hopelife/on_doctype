﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Count = System.Int32;
using Index = System.Int32;
using Float = System.Single;
using Byte = System.Byte;
using Ratio = System.Single;
using Int = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {

    // 블럭영역의 평균값을 사용하여 모자이크 효과를 만든다.
    public class Mosaic {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Ratio WidthScale { get; set; }
        private Ratio HeightScale { get; set; }
        private Bool AspectRatio { get; set; }

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // widthScale : 블럭 크기(그림대비) . 0.001 ~ 1
        // aspectRatio : 블럭을 가로세로 고정크기로 할지의 여부
        private Mosaic(Ratio widthScale, Ratio heightScale, Bool aspectRatio) {

            WidthScale = MathUtil.Clamp(widthScale, 0.001F, 1.0F);
            HeightScale = MathUtil.Clamp(heightScale, 0.001F, 1.0F);
            AspectRatio = aspectRatio;

        }
        public static Mosaic Create(Ratio widthScale, Ratio heightScale, Bool aspectRatio) {
            return new Mosaic(widthScale, heightScale, aspectRatio);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;
            Count widthBlockSize = MathUtil.Round(width * WidthScale);
            Count heightBlockSize = MathUtil.Round(height * HeightScale);

            if (AspectRatio) {
                widthBlockSize = MathUtil.Min(widthBlockSize, heightBlockSize);
                heightBlockSize = widthBlockSize;
            }
            if (widthBlockSize == 0 || heightBlockSize == 0) {
                return;
            }

            Int a = 0;
            Int r = 0;
            Int g = 0;
            Int b = 0;
            Count w = 0;
            Count h = 0;
            Count blockCount = 0;
            Index targetStartPos = 0;
            Index targetPixelPos = 0;


            for (Index y = 0; y < height; y += heightBlockSize) {
                targetStartPos = y * width;
                for (Index x = 0; x < width; x += widthBlockSize) {
                    w = MathUtil.Min(widthBlockSize, width - x);
                    h = MathUtil.Min(heightBlockSize, height - y);
                    blockCount = w * h;

                    a = 0;
                    r = 0;
                    g = 0;
                    b = 0;

                    
                    // block 영역의 평균값을 구함
                    for (Index by = 0; by < h; ++by) {
                        targetPixelPos = targetStartPos + by * width;
                        for (Index bx = 0; bx < w; ++bx) {

                            a += pixels.A[targetPixelPos];
                            r += pixels.R[targetPixelPos];
                            g += pixels.G[targetPixelPos];
                            b += pixels.B[targetPixelPos];
                            ++targetPixelPos;
                        }
                    }

                    a = (Int)((Float)a / blockCount);
                    r = (Int)((Float)r / blockCount);
                    g = (Int)((Float)g / blockCount);
                    b = (Int)((Float)b / blockCount);

                    targetPixelPos = targetStartPos + x;
                    // block 영역에 동일값 세팅
                    for (Index by = 0; by < h; ++by) {
                        targetPixelPos = targetStartPos + by * width;
                        for (Index bx = 0; bx < w; ++bx) {
                            

                            pixels.A[targetPixelPos] = (Byte)a;
                            pixels.R[targetPixelPos] = (Byte)r;
                            pixels.G[targetPixelPos] = (Byte)g;
                            pixels.B[targetPixelPos] = (Byte)b;
                            ++targetPixelPos;
                        }
                    }

                    targetStartPos += widthBlockSize;
                }

            }
        }
    }

}
