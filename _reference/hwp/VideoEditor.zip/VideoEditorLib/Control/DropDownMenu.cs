﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Hnc.Control {
    public class DropDownMenu : ContentControl {
        #region -> Fields

        private Popup popup;
        private Grid contentGrid;
        private Image checkImage;
        private TextBlock text;

        /// <summary>
        /// text나 checkImage를 클릭하면 팝업 메뉴가 오픈되고 이 메뉴는 StaysOpen 속성을 가지기 때문에 
        /// 메뉴 이외의 영역을 클릭하면 팝업이 닫힘
        /// text나 checkImage 영역을 클릭할 경우 팝업이 닫히자 마자 다시 열리는 어색한 동작이 발생하지 않도록 플래그를 셋팅
        /// </summary>
        private bool isClickedLabel = true;
        private bool isEnabledPopup = true;

        #endregion

        #region -> Constructor

        static DropDownMenu() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DropDownMenu), new FrameworkPropertyMetadata(typeof(DropDownMenu)));
        }

        #endregion

        #region -> Properties

        /// <summary>
        /// DropDownMenu에 표시할 캡션입니다.
        /// </summary>
        public string Caption {
            get { return (string)GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }

        /// <summary>
        /// DropDownMenu의 캡션 색상을 체크된 상태로 표시할지 선택합니다.
        /// </summary>
        public bool IsChecked {
            get { return (bool)GetValue(IsCheckedProperty); }
            set { SetValue(IsCheckedProperty, value); }
        }

        public bool StaysOpen {
            get { return (bool)GetValue(StaysOpenProperty); }
            set { SetValue(StaysOpenProperty, value); }
        }

        /// <summary>
        /// DropDownMenu를 열거나 닫습니다.
        /// </summary>
        public bool IsOpen {
            get {
                if (popup != null)
                    return popup.IsOpen;
                else
                    return false;
            }
            set {
                if (popup != null) {

                    if (isEnabledPopup) {

                        popup.IsOpen = value;

                        if (value) {
                            popup.HorizontalOffset = 0;
                            popup.VerticalOffset = 10;
                        }
                    }
                    isEnabledPopup = true;
                }
            }
        }

        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption", typeof(string), typeof(DropDownMenu), new PropertyMetadata(string.Empty));

        public static readonly DependencyProperty IsCheckedProperty =
            DependencyProperty.Register("IsChecked", typeof(bool), typeof(DropDownMenu), new PropertyMetadata(false));

        public static readonly DependencyProperty StaysOpenProperty =
            DependencyProperty.Register("StaysOpen", typeof(bool), typeof(DropDownMenu), new PropertyMetadata(true));

        #endregion

        #region -> Overrided Methods

        public override void OnApplyTemplate() {

            popup = GetTemplateChild("MenuPopup") as Popup;
            Debug.Assert(popup != null);
            popup.MouseUp += new System.Windows.Input.MouseButtonEventHandler(popup_MouseUp);
            popup.Closed += new System.EventHandler(popup_Closed);

            contentGrid = GetTemplateChild("contentGrid") as Grid;
            Debug.Assert(contentGrid != null);

            var thumb = new Thumb {
                Width = 0,
                Height = 0,
            };
            contentGrid.Children.Add(thumb);
            popup.MouseDown += (sender, e) => {
                if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                    thumb.RaiseEvent(e);
            };
            thumb.DragDelta += (sender, e) => {
                popup.HorizontalOffset += e.HorizontalChange;
                popup.VerticalOffset += e.VerticalChange;
            };

            checkImage = GetTemplateChild("CheckImage") as Image;
            Debug.Assert(checkImage != null);
            checkImage.MouseDown += new System.Windows.Input.MouseButtonEventHandler(checkImage_MouseDown);
            checkImage.MouseUp += new System.Windows.Input.MouseButtonEventHandler(checkImage_MouseUp);

            text = GetTemplateChild("Text") as TextBlock;
            Debug.Assert(text != null);
            text.MouseDown += new System.Windows.Input.MouseButtonEventHandler(text_MouseDown);
            text.MouseUp += new System.Windows.Input.MouseButtonEventHandler(text_MouseUp);

            base.OnApplyTemplate();
        }

        private void text_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            isClickedLabel = true;
        }

        private void checkImage_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            isClickedLabel = true;
        }

        private void popup_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            e.Handled = true;
        }

        private void popup_Closed(object sender, System.EventArgs e) {
            if (isClickedLabel)
                isEnabledPopup = false;
        }

        private void text_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            IsOpen = !IsOpen;

            e.Handled = true;

            isClickedLabel = false;
        }

        void checkImage_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            IsOpen = !IsOpen;

            e.Handled = true;

            isClickedLabel = false;
        }

        #endregion
    }
}
