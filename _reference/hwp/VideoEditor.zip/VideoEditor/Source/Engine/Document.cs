﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Frame = System.Double;
using Hnc.Type;
using Hnc.VideoEditor.Base.Type;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Hnc.VideoEditor.Engine {

	//////////////////////////////////////////////////////////////////////////////////////////
	// Model 정보등 기억 해야 하는 정보들을 모아둔 클래스
	// MVVM 패턴에서 따지고 보면 이 클래스가 VM과 비슷한
	// 역할을 하고 있다.
	// Transaction, Maker, Document, Timeline, Action 클래스들이 VM을 
	// 이전 MVC에서 컨트롤에 해당하는 역할 들을 한다.
	// Document는 Maker와 통신을 한다. 따라서 마커의 함수들과
	// 비슷한 형태를 띄고 있다.
	//////////////////////////////////////////////////////////////////////////////////////////
	public class Document {
		// ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private Bool isSave;
		private String fileName;
		private Timeline timeline;
		#endregion

		// ----------------------------------------------
		// 프로퍼티
		// ----------------------------------------------
		#region 프로퍼티
		public Bool IsSave {
			get {
				return isSave;
			}
			set {
				isSave = value;
			}
		}

		public String FileName {
			get {
				return fileName;
			}

			set {
				fileName = value;
			}
		}

		public Timeline Timeline {
			get {
				return timeline;
			}
			set {
				timeline = value;
			}
		}
		#endregion

		// ----------------------------------------------
		// 생성자 / 연산자
		// ----------------------------------------------
		#region 생성자 및 생성 관련 함수
		// 기본 생성자를 private으로 막고 생성을 Create 함수를 이용해서 생성하도록 작성
		public static Document Create() {
			return new Document();
		}

		// 기본생성자 - private
		private Document() {
			isSave = false;
			fileName = null;
			timeline = new Timeline();
#if DEBUG
			Debug.Assert(timeline != null, "Timeline를 생성하지 못하였습니다.");
#endif
		}
		#endregion

		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		#region 메소드
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Timeline 수정 관련 메소드

		// 문서 초기화
		public Bool NewDocument() {
			Collection<int> idList = new Collection<int>();

			foreach (TimelineInfo info in timeline.InfoList) {
				idList.Add(info.ID);
			}

			foreach (int id in idList) {
				RemoveInfo(id);
			}

			idList.Clear();

			if (timeline.InfoList.Count != 0) {
				return false;
			}

			return true;
		}

		// TimelineInfo List 반환
		public Collection<TimelineInfo> GetTimelineInfoCollection() {
			return timeline.InfoList;
		}

		// 새로운 비디오정보가 추가 될 위치 반환
		private FrameScope GetNewVideoInfoFrameScope(Frame frameLength) {
			Frame startTimelineFrame = Timeline.GetNewVideoInfoStartFrame();
			FrameScope scope = FrameScope.Create(startTimelineFrame, startTimelineFrame + frameLength);

			return scope;
		}

		// 새로운 사운드정보가 추가 될 위치 반환
		private FrameScope GetNewSoundInfoFrameScope(Frame frameLength) {
			Frame startTimelineFrame = Timeline.GetNewSoundInfoStartFrame();
			FrameScope scope = FrameScope.Create(startTimelineFrame, startTimelineFrame + frameLength);

			return scope;
		}

		// 새로운 자막정보가 추가 될 위치 반환
		private FrameScope GetNewSubtitleInfoFrameScope(Frame frameLength) {
			Frame startTimelineFrame = Timeline.GetNewSubtitleInfoStartFrame();
			FrameScope scope = FrameScope.Create(startTimelineFrame, startTimelineFrame + frameLength);

			return scope;
		}

		public int ChangingFilePathInfo(String oldFilePath, String newFilePath) {
			int count = 0;
			foreach (TimelineInfo info in Timeline.InfoList) {
				if (info.GetType() == typeof(VideoInfo)) {
					VideoInfo videoInfo = info as VideoInfo;

					if (videoInfo.FilePath == oldFilePath) {
						VideoInfo newInfo = videoInfo.Clone() as VideoInfo;

						newInfo.FilePath = newFilePath;
						videoInfo.Copy(newInfo);

						++count;
					}
				}
			}

			return count;
		}

		public int FindInfo(String filePath, System.Collections.Generic.List<TimelineInfo> infoList) {
			foreach (TimelineInfo info in Timeline.InfoList) {
				if (info.GetType() == typeof(VideoInfo)) {
					VideoInfo videoInfo = info as VideoInfo;

					if (videoInfo.FilePath == filePath) {
						infoList.Add(videoInfo);
					}
				}
			}

			return infoList.Count;
		}

		// 인자로 들어온 id 값으로 TimelineInfo 검색
		public TimelineInfo FindInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif
			foreach (TimelineInfo info in Timeline.InfoList) {
				if (id == info.ID) {
					return info;
				}
			}

			return null;
		}

		public void SetNewID() {
			Timeline.SetNewID();
		}

		// TimelineInfo 추가
		public int AddInfo(TimelineInfo info) {
			if (Timeline.AddInfo(info) == false) {
				return -1;
			}

			return info.ID;
		}

		// VideoInfo 추가
		public TimelineInfo AddVideoInfo(String filePath, Frame totalFrame, FrameScope videoScope) {
			int id = Timeline.GetNewInfoID();

			FrameScope timelineScope = GetNewVideoInfoFrameScope(videoScope.LENGTH);
			VideoInfo info = VideoInfo.Create(id, timelineScope, totalFrame, filePath, videoScope);

#if DEBUG
			Debug.Assert(info != null, "VideoInfo를 생성하지 못하였습니다.");
#endif
			if (info == null) {
				return null;
			}

			Timeline.AddInfo(info);
			return info;
		}

		// SoundInfo 추가
		public TimelineInfo AddSoundInfo(String filePath, FrameScope soundScope) {
			int id = Timeline.GetNewInfoID();

			FrameScope timelineScope = GetNewVideoInfoFrameScope(soundScope.LENGTH);
			SoundInfo info = SoundInfo.Create(id, timelineScope, 0.0, filePath, soundScope);

#if DEBUG
			Debug.Assert(info != null, "VideoInfo를 생성하지 못하였습니다.");
#endif
			if (info == null) {
				return null;
			}

			Timeline.AddInfo(info);
			return info;
		}

		// SubtitleInfo 추가
		public TimelineInfo AddSubtitleInfo(String sentence, Frame frameLength) {
			int id = Timeline.GetNewInfoID();

			FrameScope timelineScope = GetNewSubtitleInfoFrameScope(frameLength);
			SubtitleInfo info = SubtitleInfo.Create(id, timelineScope, 0.0, sentence);

#if DEBUG
			Debug.Assert(info != null, "VideoInfo를 생성하지 못하였습니다.");
#endif
			if (info == null) {
				return null;
			}

			Timeline.AddInfo(info);
			return info;
		}

		// VideoInfo 삭제
		public Bool RemoveVideoInfo(String filePath, FrameScope videoScope, FrameScope timelineScope) {
			return Timeline.RemoveVideoInfo(filePath, videoScope, timelineScope);
		}

		// VideoInfo 삭제
		public Bool RemoveVideoInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif
			return Timeline.RemoveVideoInfo(id);
		}

		// TimelineInfo 삭제
		public Bool RemoveInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif
			return Timeline.RemoveInfo(id);
		}

		public System.Collections.Generic.List<TimelineInfo> SortInfo() {
			return Timeline.SortInfo();
		}

		#endregion

		public Bool CompareFilePath(String filePath) {
			if (Timeline.InfoList.Count <= 0) {
				return false;
			}

			foreach (TimelineInfo info in Timeline.InfoList) {
				if (info.GetType() == typeof(VideoInfo)) {
					VideoInfo videoInfo = info as VideoInfo;

					if (filePath.CompareTo(videoInfo.FilePath) == 0) {
						return true;
					}
				}
			}

			return false;
		}

		public int ExportCancel() {
			return Hnc.Instrument.VideoUtil.ExportCancel();
		}

		public int Export(String filePath, int width, int height, int frameRate, int videoCodec, int audioCodec) {

			try {

				if (Timeline.InfoList.Count <= 0) {
					return 0;
				}

				Hnc.Instrument.VideoUtil.NewTimeline();

				VideoInfo preInfo = null;

				int ret = 1;


				System.Collections.Generic.List<TimelineInfo> infoList = new System.Collections.Generic.List<TimelineInfo>();

				for (int i = 0; i < Timeline.InfoList.Count; ++i) {
					TimelineInfo info = Timeline.InfoList[i] as TimelineInfo;
					infoList.Add(info);
				}

				for (int i = 0; i < infoList.Count - 1; ++i) {
					TimelineInfo info = infoList[i];

					for (int j = i + 1; j < infoList.Count; ++j) {
						TimelineInfo nextInfo = infoList[j];

						if (info.TimelineScope.START > nextInfo.TimelineScope.START) {
							TimelineInfo tempInfo = infoList[i];
							infoList[i] = infoList[j];
							infoList[j] = tempInfo;
						}
					}
				}

				foreach (TimelineInfo info in infoList) {
					if (info.GetType() == typeof(VideoInfo)) {
						VideoInfo videoInfo = info as VideoInfo;

						int effect = -1;

						if (videoInfo.EffectList.Count > 0) {
							effect = videoInfo.EffectList[0];
						}

						/*
						if (preInfo != null) {
							if (preInfo.TimelineScope.END != videoInfo.TimelineScope.START) {
								double gap = videoInfo.TimelineScope.START - preInfo.TimelineScope.END;
								ret = Hnc.Instrument.VideoUtil.AddTimelineInfo(null, -1, 0, (int)gap);
								if (ret < 0) {
									break;
								}
								continue;
							}
						}
						*/

						ret = Hnc.Instrument.VideoUtil.AddTimelineInfo(videoInfo.FilePath, effect, (int)videoInfo.VideoScope.START, (int)videoInfo.VideoScope.
	END);
						if (ret < 0) {
							break;
						}

						preInfo = videoInfo;
					}
				}

				if (ret < 0) {
					Hnc.Instrument.VideoUtil.NewTimeline();
					return ret;
				}

				ret = Hnc.Instrument.VideoUtil.CreateOutputfileInfo(filePath, width, height, frameRate, videoCodec, audioCodec);
				if (ret < 0) {
					Hnc.Instrument.VideoUtil.NewTimeline();
					return ret;
				}

				ret = Hnc.Instrument.VideoUtil.ExportEx();
				if (ret < 0 || ret == 5) {
					Hnc.Instrument.VideoUtil.NewTimeline();
					Hnc.Instrument.VideoUtil.DeleteOutputfileInfo();
					return ret;
				}

				ret = Hnc.Instrument.VideoUtil.DeleteOutputfileInfo();
				if (ret < 0) {
					Hnc.Instrument.VideoUtil.NewTimeline();
					return ret;
				}

				Hnc.Instrument.VideoUtil.NewTimeline();
			} catch (System.Exception e) {
				Hnc.Control.AppDialog appDlg = null;

				appDlg = new Hnc.Control.AppDialog("내보내기 실패",
									"내보내기에 실패하였습니다.\n" + e.GetType().ToString(),
									"확인");

				if (appDlg != null) {
					try {
						appDlg.ShowDialog();
					} catch (System.Exception ex) {
						Debug.Assert(false, ex.Message);
					}
				}
			}

			return 1;
		}
	}
}