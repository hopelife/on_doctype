/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "stdafx.h"
#include "VideoCLI.h"

using namespace System;
using namespace System::Runtime::InteropServices;

namespace Hnc {
	namespace Instrument {
		VideoCLI::VideoCLI() : videoLib(new VideoLib) {
			info = NULL;
		}

		VideoCLI::~VideoCLI() {
			DeleteVideoInfo();

			if (videoLib != NULL) {
				delete videoLib;
				videoLib = NULL;
			}
		}

		int VideoCLI::GetVideoInfo(System::String^ filePath) {
			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
			char* pFilePath = (char*) (void*) ptr;

			DeleteVideoInfo();
			info = new VideoInfoStruct();

			if (pFilePath == NULL) {
				return -1;
			}

			if (info == NULL) {
				return -1;
			}

			if (videoLib == NULL) {
				return -1;
			}

			int ret = videoLib->GetVideoInfo(pFilePath, info);

			Marshal::FreeHGlobal(ptr);

			return ret;
		}

		System::String^ VideoCLI::GetVideoInfoFilePath() {
			return gcnew System::String(info->filePath);
		}

		System::String^ VideoCLI::GetVideoInfoFileName() {
			return gcnew System::String(info->fileName);
		}

		int VideoCLI::GetVideoInfoWidth() {
			return info->width;
		}

		int VideoCLI::GetVideoInfoHeight() {
			return info->height;
		}

		double VideoCLI::GetVideoInfoFrameRate() {
			return info->frameRate;
		}

		double VideoCLI::GetVideoInfoTotalFrame() {
			return (double) info->totalFrame;
		}

		System::String^ VideoCLI::GetVideoInfoRunningTime() {
			char tempTime[100];
			sprintf_s(tempTime, 100, "%02d:%02d:%02d", info->runningTime.hour, info->runningTime.minute, info->runningTime.second);

			return gcnew System::String(tempTime);
		}

		System::String^ VideoCLI::GetVideoInfoModifyDate() {
			return gcnew System::String(info->modifyDate);
		}

		System::String^ VideoCLI::GetVideoInfoVideoCodec() {
			return gcnew System::String(info->videoCodecName);
		}

		System::String^ VideoCLI::GetVideoInfoAudioCodec() {
			return gcnew System::String(info->audioCodecName);
		}

		void VideoCLI::DeleteVideoInfo() {
			if (info != NULL) {
				delete info;
				info = NULL;
			}
		}

		Drawing::Bitmap^ VideoCLI::GetThumbnail(System::String^ filePath, int width, int height) {
			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
			char* pFilePath = (char*) (void*) ptr;

			Frame output;
			output.pixel = 0;
			output.height = 0;
			output.width = 0;

			if (videoLib->GetFrame(pFilePath, &output, width, height) < 0) {
				Marshal::FreeHGlobal(ptr);
				videoLib->ClearImage(&output);
				return nullptr;
			}

			if (output.pixel == 0 || output.height <= 0 || output.width <= 0 || output.width > 1920 || output.height > 1080) {
				Marshal::FreeHGlobal(ptr);
				videoLib->ClearImage(&output);
				return nullptr;
			}

			Drawing::Bitmap^ bitmap = gcnew Drawing::Bitmap(output.width, output.height);
			for (int y=0; y<output.height; ++y) {
				int x = 0;	
				for (int xPixel=0; xPixel<output.width*3; xPixel+=3) {
					Drawing::Color color = Drawing::Color().FromArgb(output.pixel[y][xPixel], output.pixel[y][xPixel+1], output.pixel[y][xPixel+2]);
					bitmap->SetPixel(x, y, color);
					++x;
				}
			}
			Marshal::FreeHGlobal(ptr);

			videoLib->ClearImage(&output);

			return bitmap;
		}

		Drawing::Bitmap^ VideoCLI::GetThumbnail(System::String^ filePath, int frameIndex) {
			return GetThumbnail(filePath, frameIndex, -1, -1);
		}

		Drawing::Bitmap^ VideoCLI::GetThumbnail(System::String^ filePath, int frameIndex, int width, int height) {

			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);

			char* pFilePath = (char*) (void*) ptr;

			Frame output;
			output.pixel = 0;
			output.height = 0;
			output.width = 0;
			
			if (videoLib->GetFrame(pFilePath, frameIndex, &output, width, height) == 0) {
				Marshal::FreeHGlobal(ptr);
				videoLib->ClearImage(&output);
				return nullptr;
			}

			if (output.pixel == 0 || output.height <= 0 || output.width <= 0 || output.width > 1920 || output.height > 1080) {
				Marshal::FreeHGlobal(ptr);
				videoLib->ClearImage(&output);
				return nullptr;
			}

			Drawing::Bitmap^ bitmap = gcnew Drawing::Bitmap(output.width, output.height);

			for (int y=0; y<output.height; ++y) {

				int x = 0;
				
				for (int xPixel=0; xPixel<output.width*3; xPixel+=3) {
					Drawing::Color color = Drawing::Color().FromArgb(output.pixel[y][xPixel], output.pixel[y][xPixel+1], output.pixel[y][xPixel+2]);

					bitmap->SetPixel(x, y, color);

					++x;
				}
			}

			Marshal::FreeHGlobal(ptr);

			videoLib->ClearImage(&output);

			return bitmap;
		}

		void VideoCLI::NewTimeline() {
			videoLib->NewTimeline();
		}

		double VideoCLI::GetEstimateTime(System::String^ filePath, int width, int height) {
			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
			char* pFilePath = (char*) (void*) ptr;

			double sec = videoLib->GetEstimateTime(pFilePath, width, height);

			Marshal::FreeHGlobal(ptr);

			return sec;
		}

		int VideoCLI::AddTimelineInfo(System::String^ filePath, int effect, int startFrame, int endFrame) {
			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
			char* pFilePath = (char*) (void*) ptr;

			int ret = videoLib->AddTimelineInfo(pFilePath, (Effect) effect, startFrame, endFrame);
			Marshal::FreeHGlobal(ptr);

			return ret;
		}

		int VideoCLI::CreateOutputfileInfo(System::String^ outputFilePath, int width, int height, int frameRate, int videoCodecID, int audioCodecID) {
			System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(outputFilePath);
			char* pOutputFilePath = (char*) (void*) ptr;

			int ret = videoLib->CreateOutputfileInfo(pOutputFilePath, width, height, frameRate, (AVCodecID) videoCodecID, (AVCodecID) audioCodecID);

			Marshal::FreeHGlobal(ptr);

			return ret;
		}

		int VideoCLI::Export() {
			return videoLib->Export();
		}

		int VideoCLI::ExportEx() {
			return videoLib->ExportEx();
		}

		int VideoCLI::DeleteOutputfileInfo() {
			return videoLib->DeleteOutputfileInfo();
		}

		bool VideoCLI::GetExportIsCancel() {
			return videoLib->GetExportIsCancel();
		}

		void VideoCLI::SetExportIsCancel(bool isCancel) {
			return videoLib->SetExportIsCancel(isCancel);
		}

		int VideoCLI::GetExportState() {
			return videoLib->GetExportState();
		}

		void VideoCLI::SetExportState(int state) {
			videoLib->SetExportState(state);
		}

		int VideoCLI::GetExportProgress() {
			return videoLib->GetExportProgress();
		}
	}
}