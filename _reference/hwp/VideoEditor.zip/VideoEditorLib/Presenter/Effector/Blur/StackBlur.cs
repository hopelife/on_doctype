﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

//
// http://www.hancom.co.kr
//
// Copyright (c) 2012. Hancom. Allright reserved.(http://www.hancom.co.kr)
// License : Hancom.
//
// Date: 2012.07.02.
// version: 1.0

// 
// Stack Blur v1.0
//
// Author: Mario Klingemann <mario@quasimondo.com>
// http://incubator.quasimondo.com
// created Feburary 29, 2004


// This is a compromise between Gaussian Blur and Box blur
// It creates much better looking blurs than Box Blur, but is
// 7x faster than my Gaussian Blur implementation.
//
// I called it Stack Blur because this describes best how this
// filter works internally: it creates a kind of moving stack
// of colors whilst scanning through the image. Thereby it
// just has to add one new block of color to the right side
// of the stack and remove the leftmost color. The remaining
// colors on the topmost layer of the stack are either added on
// or reduced by one, depending on if they are on the right or
// on the left side of the stack. 
//
// If you are using this algorithm in your code please add
// the following line:
// 
// Stack Blur Algorithm by Mario Klingemann <mario@quasimondo.com>
//
//
// GaussianBlur 보다 빠르고 품질은 유사함.
// Gaussian 공식에 의해 Kernel을 만들지 않고 삼각형 형태로 Kernel을 만들어 속도를 향상시킴
//
// 2012.10.24. 변수 컨벤션 수정


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {


    // 삼각형 형태로 정수형의 Kernel 데이터를 1씩 증가하는 정수값으로 만들어 처리.
    // x, y 좌표 변경에 따른 가중치 변화량이 1씩이므로 기존에 계산된 값으로 부터 다음 연산을 가감 연산으로 구할 수 있기 때문에 속도가 빠름
    public class StackBlur {
        struct Argb { // 복사기반으로 만들기 위해 class 대신 struct 사용
            public Byte A;
            public Byte R;
            public Byte G;
            public Byte B;
        }

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        Count Radius;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private StackBlur(Count radius) {

            Radius = (radius < 1) ? 1 : radius;

        }
        public static StackBlur Create(Count radius) {

            return new StackBlur(radius);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            if (Radius < 1) {
                return;
            }

            Count radiusPlusOne = Radius + 1;
            Count width = pixels.Width;
            Count height = pixels.Height;
            Index xMax = width - 1;
            Index yMax = height - 1;

            Count kernelCount = Radius * 2 + 1; // 항상 홀수임
            Int kernelItem; // 커널의 가중치 상수

    
            Index[] nextFirst = new Index[MathUtil.Max(width, height)]; // 다음 픽셀 평균값을 구할때 사용할 픽셀 위치
            Byte[] a = new Byte[width * height];
            Byte[] r = new Byte[width * height];
            Byte[] g = new Byte[width * height];
            Byte[] b = new Byte[width * height];
            Argb[] stack = new Argb[kernelCount];

            Index pos;
            Index targetPixelPos;
            Index startPos;
            Index stackPos;
            Index stackIndex;
            Index stackStart;
            
            Index nextIndex;
           
            Int aTotal;
            Int rTotal;
            Int gTotal;
            Int bTotal;

            Int aInTotal; // 기존 연산값으로 부터 가중치 1만큼 가감연산하기 위해 사용. 삼각형의 오른쪽 부분
            Int rInTotal;
            Int gInTotal;
            Int bInTotal;

            Int aOutTotal; // 기존 연산값으로 부터 가중치 1만큼 가감연산하기 위해 사용. 삼각형의 왼쪽 부분
            Int rOutTotal;
            Int gOutTotal;
            Int bOutTotal;

            // Radius가 2인 경우 1-2-3-2-1 과 같이 삼각형 형태로 커널의 가중치 계산된다.
            // 따라서 최대 픽셀값은 256 * (Radius + 1) 이며, 합계가 될 것이므로 256 * (Radius + 1) 로 계산할 수 있다.
            Count total = (radiusPlusOne) * (radiusPlusOne);
            Byte[] average = new Byte[256 * total];
            for (Index i = 0; i < 256 * total; i++) {
                average[i] = (Byte)(i / total);
            }


            // 가로방향
            startPos = 0; // x = 0인 픽셀 위치
            targetPixelPos = 0;
            for (Index y = 0; y < height; ++y) {
                aTotal = 0;
                rTotal = 0;
                gTotal = 0;
                bTotal = 0;

                aInTotal = 0;
                rInTotal = 0;
                gInTotal = 0;
                bInTotal = 0;

                aOutTotal = 0;
                rOutTotal = 0;
                gOutTotal = 0;
                bOutTotal = 0;

                // kernelCount 만큼의 합계를 미리 계산해 둔다.
                // 추후 이값을 바탕으로 앞의 항목은 빼고 뒤의 항목을 더해서 
                // 빨리 계산할 수 있다.
                for (Index k = -Radius; k <= Radius; ++k) {
                    pos = startPos + MathUtil.Min(xMax, MathUtil.Max(k, 0)); // startPos == y * width
                    stackIndex = k + Radius;

                    stack[stackIndex].A = pixels.A[pos];
                    stack[stackIndex].R = pixels.R[pos];
                    stack[stackIndex].G = pixels.G[pos];
                    stack[stackIndex].B = pixels.B[pos];

                    kernelItem = radiusPlusOne - MathUtil.Abs(k); // Radius가 2인 경우 1-2-3-2-1 과 같이 삼각형 형태로 가중치가 계산되게 한다.

                    aTotal += stack[stackIndex].A * kernelItem;
                    rTotal += stack[stackIndex].R * kernelItem;
                    gTotal += stack[stackIndex].G * kernelItem;
                    bTotal += stack[stackIndex].B * kernelItem;

                    if (0 < k){
                        aInTotal += stack[stackIndex].A;
                        rInTotal += stack[stackIndex].R;
                        gInTotal += stack[stackIndex].G;
                        bInTotal += stack[stackIndex].B;
                    } 
                    else {
                        aOutTotal += stack[stackIndex].A;
                        rOutTotal += stack[stackIndex].R;
                        gOutTotal += stack[stackIndex].G;
                        bOutTotal += stack[stackIndex].B;
                    }
                }

                stackPos = Radius;

                for (Index x = 0; x < width; ++x) {

                    a[targetPixelPos] = average[aTotal];
                    r[targetPixelPos] = average[rTotal];
                    g[targetPixelPos] = average[gTotal];
                    b[targetPixelPos] = average[bTotal];

                    aTotal -= aOutTotal; // 가중치 1만큼 감소 시킴(삼각형의 왼편)
                    rTotal -= rOutTotal; 
                    gTotal -= gOutTotal;
                    bTotal -= bOutTotal;

                    stackStart = stackPos + radiusPlusOne; // 다음번 stack의 위치
                    stackIndex = stackStart % kernelCount;

                    aOutTotal -= stack[stackIndex].A; // 가감 연산 합계에서 가장 처음것은 뺀다.
                    rOutTotal -= stack[stackIndex].R; 
                    gOutTotal -= stack[stackIndex].G;
                    bOutTotal -= stack[stackIndex].B;

                    // x값만 계산하면 되므로 y = 0 일때 한번만 계산
                    if (y == 0) {
                        nextFirst[x] = MathUtil.Min(x + radiusPlusOne, xMax);
                    }
                    nextIndex = startPos + nextFirst[x];

                    stack[stackIndex].A = pixels.A[nextIndex];
                    stack[stackIndex].R = pixels.R[nextIndex];
                    stack[stackIndex].G = pixels.G[nextIndex];
                    stack[stackIndex].B = pixels.B[nextIndex];

                    // 새롭게 연산에 추가되는 픽셀을 추가
                    aInTotal += stack[stackIndex].A;
                    rInTotal += stack[stackIndex].R;
                    gInTotal += stack[stackIndex].G;
                    bInTotal += stack[stackIndex].B;

                    aTotal += aInTotal;
                    rTotal += rInTotal;
                    gTotal += gInTotal;
                    bTotal += bInTotal;

                    // 다음번 가감연산을 위해 중심의 것을 Out으로 옮김
                    stackPos = (stackPos + 1) % kernelCount;
                    stackIndex = stackPos % kernelCount;

                    aOutTotal += stack[stackIndex].A;
                    rOutTotal += stack[stackIndex].R;
                    gOutTotal += stack[stackIndex].G;
                    bOutTotal += stack[stackIndex].B;

                    aInTotal -= stack[stackIndex].A;
                    rInTotal -= stack[stackIndex].R;
                    gInTotal -= stack[stackIndex].G;
                    bInTotal -= stack[stackIndex].B;

                    ++targetPixelPos;
                }
                startPos += width;
            }


            // 세로 방향
            for (Index x = 0; x < width; ++x) {

                aTotal = 0;
                rTotal = 0;
                gTotal = 0;
                bTotal = 0;

                aInTotal = 0;
                rInTotal = 0;
                gInTotal = 0;
                bInTotal = 0;

                aOutTotal = 0;
                rOutTotal = 0;
                gOutTotal = 0;
                bOutTotal = 0;

                startPos = -Radius * width;
                for (Index k = -Radius; k <= Radius; ++k) {
                    pos = MathUtil.Max(0, startPos) + x;
                    stackIndex = k + Radius;

                    stack[stackIndex].A = a[pos];
                    stack[stackIndex].R = r[pos];
                    stack[stackIndex].G = g[pos];
                    stack[stackIndex].B = b[pos];

                    kernelItem = radiusPlusOne - MathUtil.Abs(k);

                    aTotal += a[pos] * kernelItem;
                    rTotal += r[pos] * kernelItem;
                    gTotal += g[pos] * kernelItem;
                    bTotal += b[pos] * kernelItem;

                    if (0 < k) {
                        aInTotal += stack[stackIndex].A;
                        rInTotal += stack[stackIndex].R;
                        gInTotal += stack[stackIndex].G;
                        bInTotal += stack[stackIndex].B;
                    }
                    else {
                        aOutTotal += stack[stackIndex].A;
                        rOutTotal += stack[stackIndex].R;
                        gOutTotal += stack[stackIndex].G;
                        bOutTotal += stack[stackIndex].B;
                    }

                    if (k < yMax) {
                        startPos += width;
                    }
                }
                targetPixelPos = x;
                stackPos = Radius;
                for (Index y = 0; y < height; ++y) {

                    pixels.A[targetPixelPos] = average[aTotal];
                    pixels.R[targetPixelPos] = average[rTotal];
                    pixels.G[targetPixelPos] = average[gTotal];
                    pixels.B[targetPixelPos] = average[bTotal];

                    aTotal -= aOutTotal; // 가중치 1만큼 감소 시킴(삼각형의 왼편)
                    rTotal -= rOutTotal; 
                    gTotal -= gOutTotal;
                    bTotal -= bOutTotal;

                    stackStart = stackPos + radiusPlusOne; // 다음번 stack의 위치
                    stackIndex = stackStart % kernelCount;

                    aOutTotal -= stack[stackIndex].A; // 가감 연산 합계에서 가장 처음것은 뺀다.
                    rOutTotal -= stack[stackIndex].R; 
                    gOutTotal -= stack[stackIndex].G;
                    bOutTotal -= stack[stackIndex].B;

                    // y값만 계산하면 되므로 x = 0 일때 한번만 계산
                    if (x == 0) {
                        nextFirst[y] = MathUtil.Min(y + radiusPlusOne, yMax) * width;
                    }
                    nextIndex = x + nextFirst[y];

                    stack[stackIndex].A = a[nextIndex];
                    stack[stackIndex].R = r[nextIndex];
                    stack[stackIndex].G = g[nextIndex];
                    stack[stackIndex].B = b[nextIndex];

                    // 새롭게 연산에 추가되는 픽셀을 추가
                    aInTotal += stack[stackIndex].A;
                    rInTotal += stack[stackIndex].R;
                    gInTotal += stack[stackIndex].G;
                    bInTotal += stack[stackIndex].B;

                    aTotal += aInTotal;
                    rTotal += rInTotal;
                    gTotal += gInTotal;
                    bTotal += bInTotal;

                    // 다음번 가감연산을 위해 중심의 것을 Out으로 옮김
                    stackPos = (stackPos + 1) % kernelCount;

                    aOutTotal += stack[stackPos].A;
                    rOutTotal += stack[stackPos].R;
                    gOutTotal += stack[stackPos].G;
                    bOutTotal += stack[stackPos].B;

                    aInTotal -= stack[stackPos].A;
                    rInTotal -= stack[stackPos].R;
                    gInTotal -= stack[stackPos].G;
                    bInTotal -= stack[stackPos].B;

                    targetPixelPos += width;
                }
            }
        }
 
    }
}