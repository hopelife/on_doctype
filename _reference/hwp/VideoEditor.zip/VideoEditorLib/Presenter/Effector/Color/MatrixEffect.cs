﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Int = System.Int32;
using Index = System.Int32;
using Pixel = System.UInt32;
using Float = System.Single;
using Byte = System.Byte;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {


    // 메트릭스를 만들어 메트릭스를 적용한 색상 반영
    public class MatrixEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Matrix3 M { get; set; }


        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            Debug.AssertThrow(M != null, eErrorCode.CreateFail);

            Float r = 0;
            Float g = 0;
            Float b = 0;

            for (Index i = 0; i < pixels.R.Length; ++i) {

                M.Mutiply(
                    ref r, ref g, ref b, pixels.R[i], pixels.G[i], pixels.B[i]
                );

                r = (255 < r) ? 255 : r;
                g = (255 < g) ? 255 : g;
                b = (255 < b) ? 255 : b;

                pixels.R[i] = (Byte)r;
                pixels.G[i] = (Byte)g;
                pixels.B[i] = (Byte)b;
            }
        }

    }

}