﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Float = System.Single;
using Ratio = System.Single;
using Byte = System.Byte;
using Index = System.Int32;
using Int = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {

    // 노이즈 발생
    public class NoiseEffect {
        public enum eType { 
            Mono,
            Color,
        }

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private eType Type = eType.Color;
        private Bool IsGaussian = true;  // 가우시안분포인지, Uniform 분포인지의 여부
        private Float Amount = 50F; // 0 ~ 100
        private Ratio Density = 0.2F; // 0 ~ 1


        private System.Random Random = new System.Random();
 
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private NoiseEffect(eType type, Bool isGaussian, Float amount, Ratio density) {
            Type = type;
            IsGaussian = isGaussian;
            Amount = MathUtil.Clamp(amount, 0, 100); // 0 100
            Density = MathUtil.Clamp(density, 0, 1);
        }

        public static NoiseEffect Create(eType type, Bool isGaussian, Float amount, Ratio density) {
            return new NoiseEffect(type, isGaussian, amount, density);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Int temp;

            switch (Type) {
                case eType.Mono:

                    for (Index i = 0; i < pixels.R.Length; ++i) {

                        if (Random.NextDouble() <= Density) {

                            temp = (Int)(((IsGaussian) ? Gaussian() : Uniform()) * Amount);

                            pixels.R[i] = (Byte)MathUtil.Clamp(pixels.R[i] + temp, 0, 255);
                            pixels.G[i] = (Byte)MathUtil.Clamp(pixels.G[i] + temp, 0, 255);
                            pixels.B[i] = (Byte)MathUtil.Clamp(pixels.B[i] + temp, 0, 255);
                        }
                    }

                    break;
                case eType.Color:

                    for (Index i = 0; i < pixels.R.Length; ++i) {

                        if (Random.NextDouble() <= Density) {


                            temp = (Int)(((IsGaussian) ? Gaussian() : Uniform()) * Amount);
                            pixels.R[i] = (Byte)MathUtil.Clamp(pixels.R[i] + temp, 0, 255);

                            temp = (Int)(((IsGaussian) ? Gaussian() : Uniform()) * Amount);
                            pixels.G[i] = (Byte)MathUtil.Clamp(pixels.G[i] + temp, 0, 255);

                            temp = (Int)(((IsGaussian) ? Gaussian() : Uniform()) * Amount);
                            pixels.B[i] = (Byte)MathUtil.Clamp(pixels.B[i] + temp, 0, 255);
                        }
                    }
                   break;

            }
        }

        private Float Gaussian() {
            Float u = (Float)(2 * Random.NextDouble() - 1);
            Float v = (Float)(2 * Random.NextDouble() - 1);
            Float r = u * u + v * v;
            if (r == 0 || 1 < r) {
                return Gaussian();
            }
            Float c = MathUtil.Sqrt(-2 * MathUtil.Log(r) / r);
            return u * c;
        }
        private Float Uniform() {
            return (Float)(2 * Random.NextDouble() - 1);
        }

    }

}