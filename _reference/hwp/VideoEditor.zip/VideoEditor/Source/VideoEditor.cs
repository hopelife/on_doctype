﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor {
	using System;
	using Hnc.VEFrame;
	using System.Windows;
	using Hnc.VideoEditor.Controls;
	using System.Reflection;
	using System.Globalization;
	using Hnc.Type;
	using System.Windows.Input;
	using Hnc.Control;
	using Hnc.VideoEditor.Util;
	using System.Windows.Threading;
	using System.IO;
	using System.Text;
    using System.Runtime.InteropServices;
    using System.ComponentModel;	
	using Hnc.Manager;

	public sealed class VideoEditor : System.Windows.Application {

		public static readonly String HanShowClassName9 = "HslFrame_9";
		public static readonly String HanShowClassName9_6 = "HslFrame_9.6";

        #region -> Interop

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr FindWindow(string strClassName, string strWindowName);

        #endregion

        /// <summary>
        /// 동영상을 내보낼 한쇼가 실행 중인지 여부입니다.
        /// </summary>
        private static bool isHShowRunning = false;
        private static BackgroundWorker HShowMonitor = new BackgroundWorker();

		private static readonly double BORDER_TERM = 5.0;		        
        private static bool _isTap = false;

		private static System.Windows.Point ButtonDownPos {
			get;
			set;
		}

		private static System.Windows.Point WindowDefaultPos {
			get;
			set;
		}		

		public static bool IsHanShowMode {
			get;
			private set;
		}

		public static String HanShowClassName {
			get;
			private set;
		}

		public static String HanShowWindowName {
			get;
			private set;
		}

		public static String LinkFilePath {
			get;
			private set;
		}

		[System.STAThread]
		public static void Main(String[] args) {
			//SplashScreen splashScreen = new SplashScreen("Resources/Images/splash.png");
			if (args.Length != 0 && args.Length != 2 && args.Length != 3) {
				MessageBox.Show("Invalid arguments. Application will be closed.", "Executable arguments exception", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

            // 이미 실행 중인지 체크            
            System.Diagnostics.Process[] procs = System.Diagnostics.Process.GetProcessesByName("VideoEditor");
            System.Diagnostics.Process executedProc = null;
            if (procs != null && procs.Length != 0) {

                System.Diagnostics.Process currentProc = System.Diagnostics.Process.GetCurrentProcess();

                for (int i = 0; i < procs.Length; i++) {
                    if (procs[i].Id != currentProc.Id) {
                        executedProc = procs[i];
                    }
                }
            }

            if (executedProc != null) {
                SetForegroundWindow(executedProc.MainWindowHandle);
                return;
            }

			// 일반모드, 한쇼 연동모드 선택
			if (args.Length != 0 && args[0].Equals("/hshow")) {
				IsHanShowMode = true;
				LinkFilePath = args[1];

                // 실행된 한쇼 찾기
				if (args.Length >= 2) {
					int hWnd = (int)FindWindow(VideoEditor.HanShowClassName9, null);

					if (hWnd != 0) {
						HanShowClassName = VideoEditor.HanShowClassName9;
					} else {
						HanShowClassName = VideoEditor.HanShowClassName9_6;
					}

                    if (hWnd == 0) {
                        System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcessesByName("HShow");
                        if (processes.Length != 0) {
                            IntPtr hWnd2 = processes[0].MainWindowHandle;
                            hWnd = hWnd2.ToInt32();
                            
                            HanShowClassName = null;
                            HanShowWindowName = processes[0].MainWindowTitle;
                        } else {
                            HanShowWindowName = null;
                        }
                    }
				} 
                
                //  다국어 설정
                if (args.Length >= 3) {
                    // HanShowClassName = null;
                    // HanShowWindowName = args[2];
                    if (args[2].Equals("ko-KR")) {
                        CultureManager.SetCurrentCulture("ko-KR");
                    } else {
                        CultureManager.SetCurrentCulture("en-US");
                    }
                }
                
                // 인자가 잘 못들어온 경우 종료
                if (args.Length == 1 || args.Length > 3) {
					MessageBox.Show("Invalid arguments. Application will be closed.", "Executable arguments exception", MessageBoxButton.OK, MessageBoxImage.Error);
					return;
				}
			} else {
				// 연동 모드가 아닐 경우에만 스플래쉬 스크린 보이기                
				//splashScreen.Show(false);
			}

			VideoEditor app = new VideoEditor();
			app.ShutdownMode = ShutdownMode.OnMainWindowClose;

			// 국가에 맞는 리소스 로딩
			String currentCultureName = CultureManager.CurrentCultureName;
            if (File.Exists(Environment.CurrentDirectory + @"\lang.txt")) {
                String[] lines = File.ReadAllLines(Environment.CurrentDirectory + @"\lang.txt");

                if (lines != null && lines.Length != 0)
                    currentCultureName = lines[0].Trim();
            }

            app.Resources.Source = new Uri("Resources/" + currentCultureName + "/VideoEditor.xaml", UriKind.Relative);
			// 컨트롤 리소스 병합
			LoadControlResources();

			Window mainWindow = VEFrameManager.Instance.RootWindow;
			Debug.AssertThrow(mainWindow != null, eErrorCode.CreateFail);

			// 윈도우의 사이즈 설정 (모니터 해상도를 초과하지 않도록 설정)
			if (SystemParameters.PrimaryScreenWidth > SetupManager.Instance.LastWindowSize.Width) {
				mainWindow.Width = SetupManager.Instance.LastWindowSize.Width;
			} else {
				mainWindow.Width = SystemParameters.PrimaryScreenWidth - 50;
			}

			if (SystemParameters.PrimaryScreenHeight > SetupManager.Instance.LastWindowSize.Height) {
				mainWindow.Height = SetupManager.Instance.LastWindowSize.Height;
			} else {
				mainWindow.Height = SystemParameters.PrimaryScreenHeight - 50;
			}

			mainWindow.Title = StringManager.GetString("IDS_ApplicationName");
			mainWindow.MinWidth = 1024;
			mainWindow.MinHeight = 768;

			// 연동모드가 아닐 경우의 설정
			if (!IsHanShowMode) {
				// 윈도우는 마지막으로 사용했던 위치에 배치
				mainWindow.WindowStartupLocation = WindowStartupLocation.Manual;
				mainWindow.Left = SetupManager.Instance.LastWindowPosition.X;
				mainWindow.Top = SetupManager.Instance.LastWindowPosition.Y;
			}
			// 연동모드일 경우의 설정
			else {
                // 한쇼 프로세스 감시 시작    
                HShowMonitor.DoWork += new DoWorkEventHandler(HShowMonitor_DoWork);
                HShowMonitor.RunWorkerAsync();

				// 윈도우는 부모창의 가운데 배치
				mainWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}

			mainWindow.Loaded += new RoutedEventHandler(mainWindow_Loaded);
			mainWindow.Closing += new System.ComponentModel.CancelEventHandler(mainWindow_Closing);

			// AppBar 관련 이벤트 등록
			mainWindow.MouseDown += new System.Windows.Input.MouseButtonEventHandler(mainWindow_MouseDown);
			//mainWindow.MouseMove += new System.Windows.Input.MouseEventHandler(mainWindow_MouseMove);
			mainWindow.MouseUp += new System.Windows.Input.MouseButtonEventHandler(mainWindow_MouseUp);

			// 핸들링 되지 않은 예외들을 받는 곳
			// Dispatcher.CurrentDispatcher.UnhandledException += new DispatcherUnhandledExceptionEventHandler(CurrentDispatcher_UnhandledException);
#if DEBUG
			Dispatcher.CurrentDispatcher.UnhandledException += new DispatcherUnhandledExceptionEventHandler(Dispatcher_UnhandledException);
			Dispatcher.CurrentDispatcher.UnhandledExceptionFilter += new DispatcherUnhandledExceptionFilterEventHandler(Dispatcher_UnhandledExceptionFilter);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
#endif
			// 타이틀바 생성
			TitleBar titleBar = new TitleBar();
			Debug.AssertThrow(titleBar != null, eErrorCode.CreateFail);

			// 프로그램 첫 화면 설정
			//VEFrameManager.Instance.GoStartPage();
			VEFrameManager.Instance.GoMainPage();
			VEFrameManager.Instance.SetTitleBar(titleBar);
			VEFrameManager.Instance.ShowTitleBar();
			VEFrameManager.Instance.HideStatusBar();
			VEFrameManager.Instance.HideTopToolBar();
			VEFrameManager.Instance.HideBottomToolBar();

			// 동영상 소스 삭제 커맨드 바인딩
			mainWindow.CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Delete, RemoveSourceItem, null));

			mainWindow.CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Properties, InfoSourceItem, null));

            //if (!IsHanShowMode) {
            //    splashScreen.Close(TimeSpan.FromSeconds(0.3));
            //}
			app.Run(mainWindow);
		}        

		static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e) {
			string reportFile;

			reportFile = AppDomain.CurrentDomain.BaseDirectory;
			reportFile += "CurrentDomain_UnhandledException.txt";

			StreamWriter writer = new StreamWriter(reportFile, true, Encoding.UTF8);
			writer.WriteLine("[Sender]");
			writer.WriteLine(sender.GetType().ToString());
			writer.WriteLine("");
			writer.WriteLine("[UnhandledExceptionEventArgs.ExceptionObject]");
			writer.WriteLine(e.ExceptionObject.ToString());
			writer.Close();
		}

		static void ExceptinWrite(ref StreamWriter writer, Exception e) {
			writer.WriteLine("[e.Message]");
			writer.WriteLine(e.Message);
			writer.WriteLine("");

			writer.WriteLine("[e.Source]");
			writer.WriteLine(e.Source);
			writer.WriteLine("");

			writer.WriteLine("[e.StackTrace]");
			writer.WriteLine(e.StackTrace);
			writer.WriteLine("");

			writer.WriteLine("[e.HelpLink]");
			writer.WriteLine(e.HelpLink);
			writer.WriteLine("");

			writer.WriteLine("[e.Data]");
			writer.WriteLine(e.Data.ToString());
			writer.WriteLine("");
			writer.WriteLine("");

			if (e.InnerException != null) {
				writer.WriteLine("<< Inner exception >>");
				ExceptinWrite(ref writer, e.InnerException);
			}
		}

		static void Dispatcher_UnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e) {
			string reportFile;

			reportFile = AppDomain.CurrentDomain.BaseDirectory;
			reportFile += "Dispatcher_UnhandledException.txt";

			StreamWriter writer = new StreamWriter(reportFile, true, Encoding.UTF8);
			ExceptinWrite(ref writer, e.Exception);
			writer.Close();
		}

		static void Dispatcher_UnhandledExceptionFilter(object sender, DispatcherUnhandledExceptionFilterEventArgs e) {
			string reportFile;

			reportFile = AppDomain.CurrentDomain.BaseDirectory;
			reportFile += "Dispatcher_UnhandledExceptionFilter.txt";

			StreamWriter writer = new StreamWriter(reportFile, true, Encoding.UTF8);
			ExceptinWrite(ref writer, e.Exception);
			writer.Close();
		}

		private static void mainWindow_Loaded(object sender, RoutedEventArgs e) {
			if (SetupManager.Instance.IsMaximized) {
				Application.Current.MainWindow.WindowState = WindowState.Maximized;
			}
		}

		private static void mainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
			SetupManager.Instance.LastWindowPosition =
				new System.Windows.Point(Application.Current.MainWindow.RestoreBounds.Left, Application.Current.MainWindow.RestoreBounds.Top);

			SetupManager.Instance.LastWindowSize =
					new System.Windows.Size(Application.Current.MainWindow.RestoreBounds.Width, Application.Current.MainWindow.RestoreBounds.Height);

			if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
				SetupManager.Instance.IsMaximized = true;
			} else {
				SetupManager.Instance.IsMaximized = false;
			}
		}

		private static void mainWindow_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e) {
			_isTap = true;
			ButtonDownPos = e.GetPosition(Application.Current.MainWindow);
			WindowDefaultPos = new System.Windows.Point(Application.Current.MainWindow.Left, Application.Current.MainWindow.Top);

			double width = Application.Current.MainWindow.Width;
			if (ButtonDownPos.X <= BORDER_TERM || ButtonDownPos.X >= width - BORDER_TERM ||
				ButtonDownPos.Y <= BORDER_TERM) {
				_isTap = false;
				return;
			}
		}

		private static void mainWindow_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) {
			/*
            if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed ||
                e.RightButton == System.Windows.Input.MouseButtonState.Pressed) {

                System.Windows.Point curPos = e.GetPosition(Application.Current.MainWindow);

                SizeF delta = SizeF.Create(
                   (Float)(curPos.X - ButtonDownPos.X),
                   (Float)(curPos.Y - ButtonDownPos.Y)
                );

                // tracking 영역보다 많이 움직였으면 flicking이다.
                if (!((MathUtil.Abs(delta.CX) < SystemParameters.MinimumHorizontalDragDistance) &&
                    (MathUtil.Abs(delta.CY) < SystemParameters.MinimumVerticalDragDistance))) {
                    isTap = false;
                }
            }
			*/
		}

		private static void mainWindow_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
			// 아래 조건 충족 시 AppBar 전환 동작
			// - Tap 동작
			// - 윈도우가 이동되지 않음
			// - MainPage를 클릭
			if (_isTap &&
				Application.Current.MainWindow.Left == WindowDefaultPos.X &&
				Application.Current.MainWindow.Top == WindowDefaultPos.Y &&
				e.OriginalSource is Hnc.VEFrame.Controls.Layout.MainWindowDockPanel) {
			}

			_isTap = false;
		}

		private static void RemoveSourceItem(object sender, ExecutedRoutedEventArgs e) {
			// 썸네일 목록에서 동영상을 삭제할 때 처리
			PhotoListBoxItem deleteItem = e.Parameter as PhotoListBoxItem;

			if (deleteItem == null) {
				return;
			}

			VEFrameManager.Instance.MainPage.DeleteLoadBarItem(deleteItem);
		}

		private static void InfoSourceItem(object sender, ExecutedRoutedEventArgs e) {
			// 썸네일 목록 동영상의 정보 출력
			PhotoListBoxItem item = e.Parameter as PhotoListBoxItem;

			if (item == null) {
				return;
			}

			VEFrameManager.Instance.MainPage.InfoLoadBarItem(item);
		}

		private static void LoadControlResources() {
			Assembly assembly = Assembly.LoadFrom("VideoEditorLib.dll");

			String currentCultureName = CultureManager.CurrentCultureName;
            if (File.Exists(Environment.CurrentDirectory + @"\lang.txt")) {
                String[] lines = File.ReadAllLines(Environment.CurrentDirectory + @"\lang.txt");

                if (lines != null && lines.Length != 0)
                    currentCultureName = lines[0].Trim();
            }

            string packUri = @"/VideoEditorLib;Component/Control/Skin_" + currentCultureName + ".xaml";
			Application.Current.Resources.MergedDictionaries.Clear();
			ResourceDictionary rd = Application.LoadComponent(new Uri(packUri, UriKind.Relative)) as ResourceDictionary;

			if (rd != null) {
				Application.Current.Resources.MergedDictionaries.Add(rd);
			}
		}

        #region -> 한쇼 실행 여부 감시

        public static bool IsRunningProcess(String className, String windowName) {

			int hWnd = (int)FindWindow(className, windowName);

            if (hWnd == 0)
                return false;
            else
                return true;
        }

        private static void HShowMonitor_DoWork(object sender, DoWorkEventArgs e) {

            isHShowRunning = IsRunningProcess(HanShowClassName, HanShowWindowName);

            // 한쇼가 꺼질때 마다 경고 메세지 출력
            while (true) {

                if (isHShowRunning) {

					if (!IsRunningProcess(HanShowClassName, HanShowWindowName)) {

                        VEFrameManager.Instance.MainWindow.Dispatcher.Invoke(new Action(delegate() {
                            CustomDialog dialog = new CustomDialog();
                            string message = Application.Current.Resources["IDS_Message_24"] as String;

                            dialog.ChangeMessageBoxType("", message, 350.0, Application.Current.Resources["IDS_Confirm"] as String);
                            dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

                        }), DispatcherPriority.DataBind);

                        isHShowRunning = false;
                    }

                } else {
					if (IsRunningProcess(HanShowClassName, HanShowWindowName)) {
                        isHShowRunning = true;
                    }
                }

                System.Threading.Thread.Sleep(300);
            }
        }

        #endregion
	}
}