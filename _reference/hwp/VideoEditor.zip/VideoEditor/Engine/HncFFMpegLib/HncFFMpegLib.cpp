
#include <stdio.h>
#include <string.h>
#include "HncFFMpegLib.h"
#include "FFMpegLib.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// ������ & �Ҹ���
HncFFMpegLib::HncFFMpegLib(void) {
	lib = new FFMpegLib();
	filePath = NULL;
	videoInfo = NULL;
}

HncFFMpegLib::~HncFFMpegLib(void) {
	if (lib != NULL) {
		delete lib;
	}

	if (filePath != NULL) {
		delete [] filePath;
	}

	if (videoInfo != NULL) {
		delete videoInfo;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// ��� ���� set & get �Լ�
void HncFFMpegLib::SetFilePath(const char* inputFilePath) {
	
	if (filePath != NULL) {
		delete [] filePath;
	}

	int length = strlen(inputFilePath) + 1;
	filePath = new char[length]; // (char*) malloc(length);
	strcpy_s(filePath, length, inputFilePath);

	videoInfo = new VideoInfo();
	GetVideoInfo(filePath, videoInfo);
}

const char* HncFFMpegLib::GetFilePath() {
	return filePath;
}

const int HncFFMpegLib::GetWidth() {
	return videoInfo->width;
}

const int HncFFMpegLib::GetHeight() {
	return videoInfo->height;
}

const int HncFFMpegLib::GetFrameRate() {
	return videoInfo->FrameRate;
}

const int HncFFMpegLib::GetPlayTime() {
	TimeInfo info = videoInfo->runningTime;
	int second = info.hour * 3600 + info.minute * 60 + info.second;
	return second;
}

const char* HncFFMpegLib::videoCodec() {
	return videoInfo->videoCodec;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// ��� �Լ�
int HncFFMpegLib::GetFrame(const char* inputFilePath, int count, int* frameIndex, Frame** output, int width, int height) {
	//output = (Frame**) malloc(sizeof(Frame*) * count);
	return lib->GetFrame(inputFilePath, count, frameIndex, output, width, height);
}

int HncFFMpegLib::GetFrame(const char* inputFilePath, int frameIndex, Frame* output, int width, int height) {
	return lib->GetFrame(inputFilePath, frameIndex, output, width, height);
}

int HncFFMpegLib::GetVideoInfo(const char* inputFilePath) {
	return lib->GetVideoInfo(inputFilePath, videoInfo);
}

int HncFFMpegLib::GetVideoInfo(const char* inputFilePath, VideoInfo* info) {
	return lib->GetVideoInfo(inputFilePath, info);
}

int HncFFMpegLib::DeleteFrame(int count, Frame** output) {
	for (int i=0; i<count; ++i) {
		DeleteFrame(output[i]);
	}

	delete [] output;

	return SUCCESSED;
}

int HncFFMpegLib::DeleteFrame(Frame* output) {
	for (int i=0; i<output->height; ++i) {
		free(output->pixel[i]);
	}

	free(output);

	return SUCCESSED;
}

int HncFFMpegLib::SDLPlay() {
	return lib->SDLPlay(filePath);
}

void HncFFMpegLib::NewTimeline() {
	lib->NewTimeline();
}

int HncFFMpegLib::AddTimelineInfo(char* filePath, int startFrame, int endFrame) {
	TimelineInfo* info1 = new TimelineInfo(filePath, startFrame, endFrame);
	return lib->AddTimelineInfo(info1);
}

int HncFFMpegLib::Export(const char* outputFilePath) {
	int retval = lib->Export(outputFilePath);
	lib->NewTimeline();
	return retval;
}

int HncFFMpegLib::Export(const char* inputFilePath, const char* outputFilePath) {
	

//	lib->VideoEncoder("c:\\play3.wmv");

	
	TimelineInfo* info1 = new TimelineInfo("c:\\0\\3.avi", 0, 300);
	TimelineInfo* info2 = new TimelineInfo("c:\\0\\3.avi", 0, 300);
//	TimelineInfo* info3 = new TimelineInfo("c:\\0\\4.avi", 0, 300);

	lib->NewTimeline();
	lib->AddTimelineInfo(info1);
//	lib->AddTimelineInfo(info2);
//	lib->AddTimelineInfo(info3);
	

	lib->Export(outputFilePath);
	lib->NewTimeline();
	

	return 1;
	

	

	// return lib->Export(inputFilePath, outputFilePath);
}