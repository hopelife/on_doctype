﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Pixel = System.UInt32;
using Byte = System.Byte;
using Bool = System.Boolean;
using Int = System.Int32;
using Index = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // 색상 반전
    public class Invert {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Invert() {
        }

        public static Invert Create() {
            return new Invert();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels.R != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.R.Length; ++i) {

                pixels.R[i] = (Byte)(~pixels.R[i]);
                pixels.G[i] = (Byte)(~pixels.G[i]);
                pixels.B[i] = (Byte)(~pixels.B[i]);
            }
        }

        public static void Apply(Byte[] data) {
            Debug.AssertThrow(data != null, eErrorCode.NullArgument);

            for (Index i = 0; i < data.Length; ++i) {

                data[i] = (Byte)(~data[i]);
            }        
        }
    }


}