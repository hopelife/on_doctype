﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.ComponentModel;

namespace Hnc.Control
{
    public class ExtListBoxItem : System.Windows.Controls.ContentControl {

        #region -> Properties

        public string Key {
            get { return (string)GetValue(KeyProperty); }
            set { SetValue(KeyProperty, value); }
        }        

        public string Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static readonly DependencyProperty KeyProperty =
            DependencyProperty.Register("Key", typeof(string), typeof(ExtListBoxItem), new PropertyMetadata(string.Empty));

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(ExtListBoxItem), new PropertyMetadata(string.Empty));

        #endregion

        /// <summary>
        /// ExtListBoxItem의 생성자입니다.
        /// </summary>
        /// <param name="key">각 아이템을 구분할 수 있는 유일한 Id</param>
        /// <param name="text">아이템 캡션으로 사용할 문자열</param>
        public ExtListBoxItem(string key, string text) {
            this.Key = key;
            this.Text = text;
        }
    }

    public class ExtListBox : System.Windows.Controls.ListBox {

        private bool autoSort = false;

        public enum ItemStyles {
            Underline, Toggle, KeyValuePair, Text
        }

        public TextAlignment TextAlignment {
            get { return (TextAlignment)GetValue(TextAlignmentProperty); }
            set { SetValue(TextAlignmentProperty, value); }
        }

        public static readonly DependencyProperty TextAlignmentProperty =
            DependencyProperty.Register("TextAlignment", typeof(TextAlignment), typeof(ExtListBox), new PropertyMetadata(TextAlignment.Center));

        public Orientation Orientation {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }

        public static readonly DependencyProperty OrientationProperty =
            DependencyProperty.Register("Orientation", typeof(Orientation), typeof(ExtListBox), new PropertyMetadata(Orientation.Vertical));

        public ItemStyles ItemStyle {
            get { return (ItemStyles)GetValue(ItemStyleProperty); }
            set { SetValue(ItemStyleProperty, value); }
        }

        public static readonly DependencyProperty ItemStyleProperty =
            DependencyProperty.Register("ItemStyle", typeof(ItemStyles), typeof(ExtListBox), new PropertyMetadata(ItemStyles.Toggle));

        /// <summary>
        /// 선택된 아이템들의 Key를 열거형으로 가져옵니다.
        /// </summary>
        public IEnumerable<string> SelectedKeys {

            get {
                List<string> keys = new List<string>();

                if (SelectionMode == SelectionMode.Multiple || SelectionMode == SelectionMode.Extended) {                    
                    foreach (ExtListBoxItem item in this.SelectedItems) {
                        keys.Add(item.Key);
                    }                    
                } else if (SelectionMode == SelectionMode.Single) {
                    keys.Add((this.SelectedItem as ExtListBoxItem).Key);
                }

                return keys;
            }

        }

        /// <summary>
        /// 아이템의 Text 속성을 기준으로 자동 정렬합니다.
        /// </summary>
        public bool AutoSort {
            get { return autoSort; }
            set {
                autoSort = value;

                if (autoSort) {
                    Items.SortDescriptions.Add(new SortDescription("Text", ListSortDirection.Ascending));
                    Items.Refresh();
                } else
                    Items.SortDescriptions.Clear();
            }
        }

        static ExtListBox() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ExtListBox), new FrameworkPropertyMetadata(typeof(ExtListBox)));            
        }

        protected override DependencyObject GetContainerForItemOverride() {

            // Text 스타일의 Single 선택 모드에서는 선택해제 불가
            if ((ItemStyle == ItemStyles.Text || ItemStyle == ItemStyles.Underline) && SelectionMode == SelectionMode.Single)
                return new Hnc.Control.ListBoxItem(false);
            else
                return new Hnc.Control.ListBoxItem(true);
        }

        protected override void OnItemsChanged(System.Collections.Specialized.NotifyCollectionChangedEventArgs e) {

            if (e.NewItems != null && AutoSort)
                this.Items.Refresh();

            base.OnItemsChanged(e);
        }

        #region -> Public Methods

        /// <summary>
        /// 목록의 마지막 아이템까지 스크롤합니다.
        /// </summary>
        public void ScrollToEnd() {

            if (Items != null && Items.Count != 0)
                ScrollIntoView(Items[Items.Count - 1]);
        }

        #endregion
    }
}
