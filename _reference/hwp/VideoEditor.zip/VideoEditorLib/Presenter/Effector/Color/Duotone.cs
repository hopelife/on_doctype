﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Int = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Index = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // duotone
    public class Duotone {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private GrayscaleTable GrayscaleTable = GrayscaleTable.Instance;
        private PixelTable PixelTable = PixelTable.Create();

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Duotone(Pixel dark, Pixel bright) {

            Byte brightR = Pixels.GetR(bright);
            Byte brightG = Pixels.GetG(bright);
            Byte brightB = Pixels.GetB(bright);

            Byte darkR = Pixels.GetR(dark);
            Byte darkG = Pixels.GetG(dark);
            Byte darkB = Pixels.GetB(dark);

            // bright - dark 색으로 평준화된 색상테이블 작성
            PixelTable.Data[0] = dark;
            PixelTable.Data[255] = bright;
            for (Int i = 1; i < 255; ++i) {
                PixelTable.Data[i] = Pixels.ToPixel(
                    255,
                    (Byte)((brightR * i + darkR * (255 - i) + 128) / 255), // r
                    (Byte)((brightG * i + darkG * (255 - i) + 128) / 255), // g
                    (Byte)((brightB * i + darkB * (255 - i) + 128) / 255) // b
                );
            }
        }

        public static Duotone Create(Pixel dark, Pixel bright) {
            return new Duotone(dark, bright);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
         public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Byte temp;
            for (Index i = 0; i < pixels.R.Length; ++i) {
                temp = GrayscaleTable.GetAt(pixels.R[i], pixels.G[i], pixels.B[i]);

                pixels.R[i] = (Byte)(((PixelTable.Data[temp] >> 16) & 0xFF));
                pixels.G[i] = (Byte)(((PixelTable.Data[temp] >> 8) & 0xFF));
                pixels.B[i] = (Byte)(((PixelTable.Data[temp]) & 0xFF));
            }
        }
     }
}