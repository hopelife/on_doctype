﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {

    // 2가지 색상으로 중심에 원형 그러데이션을 그린다.
    public class CenterRadialGradient {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Pixel Color1 = Pixels.ToPixel(0, 0, 0, 0);
        private Pixel Color2 = Pixels.ToPixel(255, 0, 0, 0);
        private Ratio Center = 0; // 중심영역
        private Ratio LastInset = 0; // 마지막 그러데이션 위치. 0이면 width/height


        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private CenterRadialGradient(Pixel color1, Pixel color2, Ratio center, Ratio lastInset) {
            Color1 = color1;
            Color2 = color2;
            Center = MathUtil.Clamp(center, 0, 1);
            LastInset = MathUtil.Clamp(lastInset, 0, 1);
        }
        public static CenterRadialGradient Create(Pixel color1, Pixel color2, Ratio center, Ratio lastInset) {

            return new CenterRadialGradient(color1, color2, center, lastInset);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;

            Byte a1 = Pixels.GetA(Color1);
            Byte r1 = Pixels.GetR(Color1);
            Byte g1 = Pixels.GetG(Color1);
            Byte b1 = Pixels.GetB(Color1);

            Byte a2 = Pixels.GetA(Color2);
            Byte r2 = Pixels.GetR(Color2);
            Byte g2 = Pixels.GetG(Color2);
            Byte b2 = Pixels.GetB(Color2);


            Byte a, r, g, b;

            Index p1X = width / 2, p1Y = height / 2, p2X = (Count)(width - width * LastInset), p2Y = (Count)(height - height * LastInset);



            for (Index y = 0; y < height; ++y) {
                int off = y * width;
                Float radius = Distance(p2X - p1X, p2Y - p1Y);
                for (Index x = 0; x < width; ++x) {
                    float distance = Distance(x - p1X, y - p1Y);
                    float ratio = distance / radius;

                    // center 영역은 무조건 a1색
                    if (ratio < Center) {
                        pixels.A[off] = a1;
                        pixels.R[off] = r1;
                        pixels.G[off] = g1;
                        pixels.B[off] = b1;
                    }
                    // center영역이 아니면 비례적으로 가중치를 줌
                    else {

                        if (Center == 1) {
                            ratio = 0;
                        }
                        else {
                            ratio = (ratio - Center) / (1 - Center);
                        }


                        if (1 < ratio) {
                            ratio = 1; // a2 계열색 사용
                        }
                        a = a1;
                        r = r1;
                        g = g1;
                        b = b1;

                        ColorUtil.MixColors(ratio, ref a, ref r, ref g, ref b, a2, r2, g2, b2);

                        pixels.A[off] = a;
                        pixels.R[off] = r;
                        pixels.G[off] = g;
                        pixels.B[off] = b;
                    }
                    off++;
                }




            }
        }
        private float Distance(float a, float b) {
            return (float)MathUtil.Sqrt(a * a + b * b);
        }

    }
}
