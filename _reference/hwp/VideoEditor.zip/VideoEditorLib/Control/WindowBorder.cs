﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;

namespace Hnc.Control
{
	public class WindowBorder : Border
	{
		private bool inLeft = false;
		private bool inTop = false;
		private bool inRight = false;
		private bool inBottom = false;

		private Point mouseDownPoint;
		private Rect lastWindowRect;

		private Window parentWindow;
		private Window ParentWindow
		{
			get
			{
				if (parentWindow != null)
					return parentWindow;

				parentWindow = Window.GetWindow(this);
				return parentWindow;
			}
		}

		public WindowBorder()
		{
            this.PreviewMouseDown += new MouseButtonEventHandler(WindowBorder_PreviewMouseDown);
			this.PreviewMouseMove += new MouseEventHandler(WindowBorder_PreviewMouseMove);
            this.PreviewMouseUp += new MouseButtonEventHandler(WindowBorder_PreviewMouseUp);
            
            this.MouseLeave += new MouseEventHandler(WindowBorder_MouseLeave);						
		}

        private void WindowBorder_PreviewMouseDown(object sender, MouseButtonEventArgs e) {
            
            base.OnPreviewMouseDown(e);
            
            // Border의 경계선에 특정 컨트롤 겹쳐서 출력될 경우 해당 컨트롤의 마우스 이벤트까지 뺐어올 수 있기 때문에
            // 경계선에 출력될 수도 있는 컨트롤에 대해 예외처리를 함
            if (e.OriginalSource is TextBlock)
                return;

            if (inLeft || inTop || inRight || inBottom) {
                mouseDownPoint = ParentWindow.PointToScreen(e.GetPosition(this));
                lastWindowRect = new Rect(ParentWindow.Left, ParentWindow.Top, ParentWindow.ActualWidth, ParentWindow.ActualHeight);
                this.CaptureMouse();
            }
        }

        private void WindowBorder_PreviewMouseMove(object sender, MouseEventArgs e) {

            base.OnPreviewMouseMove(e);

            Point mousePoint = ParentWindow.PointToScreen(e.GetPosition(this));
            double term = 5.0;

            if (!this.IsMouseCaptured) {

                Rect controlRect = ControlUtil.GetControlScreenRect(this);

                inTop = controlRect.Top <= mousePoint.Y && controlRect.Top + BorderThickness.Top + term >= mousePoint.Y;
                inLeft = controlRect.Left <= mousePoint.X && controlRect.Left + BorderThickness.Left + term >= mousePoint.X;
                inBottom = controlRect.Bottom >= mousePoint.Y && controlRect.Bottom - BorderThickness.Bottom - term <= mousePoint.Y;
                inRight = controlRect.Right >= mousePoint.X && controlRect.Right - BorderThickness.Right - term <= mousePoint.X;

                if ((inLeft && inTop) || (inBottom && inRight)) {
                    this.Cursor = Cursors.SizeNWSE;
                } else if ((inRight && inTop) || (inBottom && inLeft)) {
                    this.Cursor = Cursors.SizeNESW;
                } else if (inTop || inBottom) {
                    this.Cursor = Cursors.SizeNS;
                } else if (inRight || inLeft) {
                    this.Cursor = Cursors.SizeWE;
                } else {
                    this.Cursor = Cursors.Arrow;
                }

                //base.OnPreviewMouseMove(e);

            } else {
                double deltaW = mouseDownPoint.X - mousePoint.X;
                double deltaH = mouseDownPoint.Y - mousePoint.Y;

                if (inTop) {
                    
                    if (lastWindowRect.Height + deltaH < ParentWindow.MinHeight) {
                        ParentWindow.Top = lastWindowRect.Top + (lastWindowRect.Height - ParentWindow.MinHeight);                        
                    } else {
                        ParentWindow.Top = lastWindowRect.Top - deltaH;
                    }
                    
                    ParentWindow.Height = lastWindowRect.Height + deltaH < 0 ? 0 : lastWindowRect.Height + deltaH;
                }

                if (inLeft) {

                    if (lastWindowRect.Width + deltaW < ParentWindow.MinWidth) {
                        ParentWindow.Left = lastWindowRect.Left + (lastWindowRect.Width - ParentWindow.MinWidth);                        
                    } else {
                        ParentWindow.Left = lastWindowRect.Left - deltaW;
                    }
                    
                    ParentWindow.Width = lastWindowRect.Width + deltaW < 0 ? 0 : lastWindowRect.Width + deltaW;
                }

                if (inBottom) {
                    ParentWindow.Height = lastWindowRect.Height - deltaH < 0 ? 0 : lastWindowRect.Height - deltaH;
                }

                if (inRight) {
                    ParentWindow.Width = lastWindowRect.Width - deltaW < 0 ? 0 : lastWindowRect.Width - deltaW;
                }
            }
        }

		private void WindowBorder_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			base.OnPreviewMouseUp(e);

			this.ReleaseMouseCapture();
		}						

        private void WindowBorder_MouseLeave(object sender, MouseEventArgs e) {
            Cursor = Cursors.Arrow;
        }
	}
}
