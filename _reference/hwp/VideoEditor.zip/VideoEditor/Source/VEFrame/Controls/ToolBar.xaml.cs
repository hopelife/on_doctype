﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hnc.VEFrame.Controls {
    /// <summary>
    /// ToolBar.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ToolBar : Grid {
         // 생성자
        #region Constructor
        // 기본 생성자
        public ToolBar() {
            InitializeComponent();
        }
        #endregion // Constructor
    }
}
