﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Controls.Primitives;

namespace Hnc.Control {
    public class FlickingScrollViewer : ScrollViewer {

        #region -> Fields

        private Point buttonDownPos;
        private int buttonDown = 0;
        private int scrollCount = 0;

        /// <summary>
        /// 여기 설정된 값 이상 마우스를 움직여야 플리킹이 동작합니다.
        /// </summary>
        private double sensitiveValue = 50;

        private Point scrollTarget;
        private Point scrollStartPoint;
        private Point scrollStartOffset;
        private Point previousPoint;
        private Vector velocity;
        private double friction;
        private Timer scrollTimer = new Timer();
        private Timer loadTimer = new Timer();

        private FrameworkElement scrollArea;
        private Track hTrack;
        private Track vTrack;
        private double hTrackValue = 0.0;
        private double vTrackValue = 0.0;

        #endregion

        #region -> Constructors

        static FlickingScrollViewer() {
            FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata();
        }

        public FlickingScrollViewer() {
            friction = 0.96;

            scrollTimer.Interval = 20;
            scrollTimer.Elapsed += new ElapsedEventHandler(scrollTimer_Elapsed);

            loadTimer.Interval = 1500;
            loadTimer.Elapsed += new ElapsedEventHandler(loadTimer_Elapsed);
        }

        #endregion

        #region -> Properties

        /// <summary>
        /// ScrollViewer안의 Content 사이즈가 변할 때 
        /// 가로, 세로 Offset을 자동으로 변경하여 현재 보이는 위치를 유지할 지 설정합니다.
        /// </summary>
        public bool IsFixedViewport {
            get;
            set;
        }

        public double Friction {
            get { return 1.0 - friction; }
            set { friction = Math.Min(Math.Max(1.0 - value, 0), 1.0); }
        }

        #endregion

        #region -> Private Methods

        // DispathcherTimer로는 MouseMove 동안 Timer가 동작하지 않아서
        // System.Timers::Timer를 사용하여 다른 쓰레드에서 동작하도록 수정함
        private void scrollTimer_Elapsed(object sender, ElapsedEventArgs e) {
            if (0 < buttonDown) {
                Point currentPoint = new Point();

                // System.Timers::Timer에서 Dispatcher 쓰레드를 사용하기 위해 Invoke
                this.Dispatcher.Invoke(new Action(delegate() {
                        currentPoint = Mouse.GetPosition(this);
                    }
                ));

                velocity = previousPoint - currentPoint;
                previousPoint = currentPoint;
            } else {
                if (1 < velocity.Length) {
                    // System.Timers::Timer에서 Dispatcher 쓰레드를 사용하기 위해 Invoke
                    this.Dispatcher.Invoke(new Action(delegate() {
                            this.ScrollToHorizontalOffset(scrollTarget.X);
                            this.ScrollToVerticalOffset(scrollTarget.Y);
                        }
                    ));

                    scrollTarget.X += velocity.X;
                    scrollTarget.Y += velocity.Y;
                    velocity *= friction;
                } else {
                    if ((!hTrack.IsMouseOver) && (!vTrack.IsMouseOver)) {
                        this.Dispatcher.Invoke(new Action(delegate() {
                            //scrollArea.Visibility = Visibility.Hidden;                            
                        }
                        ));
                        scrollTimer.Stop();
                    }
                }
            }
        }

        private void loadTimer_Elapsed(object sender, ElapsedEventArgs e) {

            if (hTrack == null || vTrack == null)
                return;

            if ((!hTrack.IsMouseOver) && (!vTrack.IsMouseOver)) {

                this.Dispatcher.Invoke(new Action(delegate() {
                    //scrollArea.Visibility = Visibility.Hidden;
                }
                ));

                loadTimer.Stop();
            }
        }

        private void hScrollBar_Loaded(object sender, RoutedEventArgs e) {
            ScrollBar hScrollBar = e.Source as ScrollBar;
            hTrack = hScrollBar.Track;
            Hnc.Type.Debug.Assert(hTrack != null);

            hTrack.MouseMove += new MouseEventHandler(hTrack_MouseMove);
        }

        private void vScrollBar_Loaded(object sender, RoutedEventArgs e) {
            ScrollBar vScrollBar = e.Source as ScrollBar;
            vTrack = vScrollBar.Track;
            Hnc.Type.Debug.Assert(vTrack != null);

            vTrack.MouseMove += new MouseEventHandler(vTrack_MouseMove);
        }

        private void hTrack_MouseMove(object sender, MouseEventArgs e) {

            if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {

                if (Math.Abs(hTrackValue - hTrack.Value) >= 50) {

                    this.ScrollInfo.SetHorizontalOffset(hTrack.Value);
                    hTrackValue = hTrack.Value;
                }
            }
        }

        private void vTrack_MouseMove(object sender, MouseEventArgs e) {

            if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {

                if (Math.Abs(vTrackValue - vTrack.Value) >= 50) {

                    this.ScrollInfo.SetVerticalOffset(vTrack.Value);
                    vTrackValue = vTrack.Value;
                }
            }
        }

        #endregion

        #region -> Overrided Methods

        public override void OnApplyTemplate() {
            base.OnApplyTemplate();

            scrollArea = Template.FindName("ScrollArea", this) as FrameworkElement;
            Hnc.Type.Debug.Assert(scrollArea != null);

            ScrollBar hScrollBar = Template.FindName("PART_HorizontalScrollBar", this) as ScrollBar;
            Hnc.Type.Debug.Assert(hScrollBar != null);
            ScrollBar vScrollBar = Template.FindName("PART_VerticalScrollBar", this) as ScrollBar;
            Hnc.Type.Debug.Assert(vScrollBar != null);

            hScrollBar.Loaded += new RoutedEventHandler(hScrollBar_Loaded);
            vScrollBar.Loaded += new RoutedEventHandler(vScrollBar_Loaded);
        }

        protected override void OnScrollChanged(ScrollChangedEventArgs e) {

            if (e.ExtentWidthChange != 0d || e.ExtentHeightChange != 0d ||
                e.HorizontalChange != 0d || e.VerticalChange != 0d) {

                loadTimer.Start();
                scrollArea.Visibility = Visibility;

                if (IsFixedViewport && (e.ExtentWidthChange != 0d || e.ExtentHeightChange != 0d)) {

                    double oldHOffset = e.HorizontalOffset - e.HorizontalChange;
                    double oldVOffset = e.VerticalOffset - e.VerticalChange;
                    double oldWExtent = e.ExtentWidth - e.ExtentWidthChange;
                    double oldHExtent = e.ExtentHeight - e.ExtentHeightChange;

                    double newHOffset = (oldHOffset * e.ExtentWidth) / oldWExtent + (e.HorizontalOffset / 2);
                    double newVOffset = (oldVOffset * e.ExtentHeight) / oldHExtent + (e.VerticalOffset / 2);

                    if (newHOffset < 0)
                        newHOffset = 0;

                    if (newHOffset > e.ExtentWidth)
                        newHOffset = e.ExtentWidth;

                    if (newVOffset < 0)
                        newVOffset = 0;

                    if (newVOffset > e.ExtentHeight)
                        newVOffset = e.ExtentHeight;

                    Console.WriteLine("H: " + (int)oldHOffset + "/" + (int)oldWExtent + "->" + (int)newHOffset + "/" + (int)e.ExtentWidth);
                    Console.WriteLine("W: " + (int)oldVOffset + "/" + (int)oldHExtent + "->" + (int)newVOffset + "/" + (int)e.ExtentHeight);

                    if (!double.IsNaN(newHOffset)) {
                        this.ScrollInfo.SetHorizontalOffset(newHOffset);
                    }

                    if (!double.IsNaN(newVOffset)) {
                        this.ScrollInfo.SetVerticalOffset(newVOffset);
                    }
                }
            }

            base.OnScrollChanged(e);
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) {
            // System.Windows.Controls.ScrollViewer에서 재구현하여 e.Handled를 true 바꾸어 이벤트 버블링을 막기 때문에
            // 마우스 이벤트가 mainWindow 로 전달되어 AppBar를 show/hide 할 수 있도록 
            // 동작하지 않게 막아둔다.
            // .Net의 구현코드를 임의로 막았으므로 알수없는 문제의 소지가 있다.
            // base.OnMouseLeftButtonDown(e);
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
            if (this.IsMouseOver) {
                //scrollArea.Visibility = Visibility.Hidden;
                scrollTimer.Stop();

                ++buttonDown;
                scrollCount = 0;

                buttonDownPos = e.GetPosition(this);

                //Keyboard.Focus(this);
            }

            base.OnPreviewMouseDown(e);
        }

        protected override void OnPreviewMouseMove(MouseEventArgs e) {
            if (0 < buttonDown && (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed)) {
                if (scrollCount == 1) {
                    if (Mouse.Captured == null) {
                        ++scrollCount;
                        scrollTimer.Start();
                        scrollArea.Visibility = Visibility.Visible;

                        scrollStartPoint = e.GetPosition(this);
                        scrollStartOffset.X = Double.IsNaN(this.HorizontalOffset) ? 0d : this.HorizontalOffset;
                        scrollStartOffset.Y = Double.IsNaN(this.VerticalOffset) ? 0d : this.VerticalOffset;

                        this.Cursor = (this.ViewportWidth < this.ExtentWidth) || (this.ViewportHeight < this.ExtentHeight) ? Cursors.Hand : Cursors.Arrow;

                        this.CaptureMouse();
                    } else {
                        buttonDown = 0;
                    }
                } else if (1 < scrollCount) {
                    Point currentPoint = e.GetPosition(this);
                    Point delta = new Point(scrollStartPoint.X - currentPoint.X, scrollStartPoint.Y - currentPoint.Y);

                    scrollTarget.X = scrollStartOffset.X + delta.X;
                    scrollTarget.Y = scrollStartOffset.Y + delta.Y;

                    this.ScrollToHorizontalOffset(scrollTarget.X);
                    this.ScrollToVerticalOffset(scrollTarget.Y);
                } else {
                    if ((SystemParameters.MinimumHorizontalDragDistance < Math.Abs(e.GetPosition(Content as IInputElement).X - buttonDownPos.X) + sensitiveValue) ||
                        (SystemParameters.MinimumVerticalDragDistance < Math.Abs(e.GetPosition(Content as IInputElement).Y - buttonDownPos.Y) + sensitiveValue)) {
                        ++scrollCount;
                    }
                }
            }

            base.OnPreviewMouseMove(e);
        }

        protected override void OnPreviewMouseUp(MouseButtonEventArgs e) {
            if (0 < buttonDown) {
                buttonDown = 0;

                this.Cursor = Cursors.Arrow;
                this.ReleaseMouseCapture();
            }

            base.OnPreviewMouseUp(e);
        }

        protected override void OnMouseWheel(MouseWheelEventArgs e) {

            if (this.HorizontalScrollBarVisibility != ScrollBarVisibility.Disabled) {

                double offset = this.HorizontalOffset;

                if (offset < -120)
                    offset = 0;

                if (offset >= this.ScrollableWidth + 120)
                    offset = this.ScrollableWidth;

                // Wheel 스크롤 한번의 기본 delta 값은 120
                if (offset - e.Delta >= -120 && offset - e.Delta <= this.ScrollableWidth + 120) {

                    if (scrollTimer.Enabled)
                        scrollTimer.Stop();

                    offset -= e.Delta;
                    this.ScrollToHorizontalOffset(offset);
                }
            }

            if (this.VerticalScrollBarVisibility != ScrollBarVisibility.Disabled) {

                double offset = this.VerticalOffset;

                if (offset < -120)
                    offset = 0;

                if (offset >= this.ScrollableHeight + 120)
                    offset = this.ScrollableHeight;

                // Wheel 스크롤 한번의 기본 delta 값은 120
                if (offset - e.Delta >= -120 && offset - e.Delta <= this.ScrollableHeight + 120) {

                    if (scrollTimer.Enabled)
                        scrollTimer.Stop();

                    offset -= e.Delta;
                    this.ScrollToVerticalOffset(offset);
                }
            }

            base.OnMouseWheel(e);
        }

        #endregion
    }
}
