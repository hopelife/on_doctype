﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using String = System.String;
using Index = System.Int32;
using System;
using System.Windows;
using System.Windows.Controls;
using Hnc.VideoEditor.Base.Type;
using Hnc.Control;
using Hnc.Instrument;
using System.Windows.Media;

namespace Hnc.VideoEditor.Appbar {
    // ----------------------------------------------
    // 정보 창
    // ----------------------------------------------
    public partial class InfoAppBar : Grid {
        private static readonly Index NonSelectedInfo = -1;

		private Index _selectedInfoID = NonSelectedInfo;
		private String _selectedFilePath = null;
		private TimelineInfo _selectedInfo = null;

        #region -> Properties
        public Index SelectedInfoID {
            get { return _selectedInfoID; }
            set { _selectedInfoID = value; }
        }

        public String SelectedFilePath {
            get { return _selectedFilePath; }
            set {
                if (value != null) {
                    _selectedFilePath = value;
                    LoadInfo(_selectedFilePath);
                } else {
                    _selectedFilePath = null;
                }
            }
        }

        public TimelineInfo SelectedInfo {
            get { return _selectedInfo; }
            set {
                if (value != null) {
                    _selectedInfo = value.Clone();
                } else {
                    _selectedInfo = null;
                }
            }
        }
        #endregion

        #region -> Constructor
        public InfoAppBar() {
            InitializeComponent();
        }
        #endregion

        public void LoadInfo(String filePath) {
			if (filePath != null) {
				Hnc.Instrument.VideoContentInfo info = Hnc.Instrument.VideoUtil.GetVideoContentInfo(filePath);

				infoListBox.Items.Clear();

				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoFileName"] as String, info.FileName));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoWidth"] as String, info.Width.ToString()));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoRunningTime"] as String, info.RunningTime));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoVideoCodec"] as String, info.VideoCodec));

				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoModifyDate"] as String, info.ModifyDate));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoHeight"] as String, info.Height.ToString()));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoFrameRate"] as String, info.FrameRate.ToString("F2")));
				infoListBox.Items.Add(new ExtListBoxItem(Application.Current.Resources["IDS_InfoAudioCodec"] as String, info.AudioCodec));

				//ImageSource thumbnailImageSource = Hnc.Instrument.VideoUtil.GetVideoAutoThumbnail(filePath, 500, 375);
				
				//if (thumbnailImageSource != null) {
				//	ThumbnailImage.Source = thumbnailImageSource;
				//}
			} else {
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					//Hnc.VEFrame.VEFrameManager.Instance.MainPage.MainMenu.HideSubAppbar();
				}
			}
        }
    }
}
