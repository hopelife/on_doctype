﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using Hnc.Util;
using String = System.String;

namespace Hnc.VideoEditor.Util {
    
    /// <summary>
    /// 문자열 리소스를 관리합니다.
    /// </summary>
    sealed class StringManager {
    
        #region -> Public Methods
       
        /// <summary>
        /// 문자열 리소스를 반환합니다.
        /// </summary>
        public static String GetString(String resourceId) {

            String str = Application.Current.Resources[resourceId] as String;

			if (Hnc.Util.StringUtil.IsNullOrEmpty(str)) {
                return String.Empty;
            } else {
                return str.Replace(@"\n", Environment.NewLine);
            }
        }

        public static String TrimResourceString(String str) {

            // 개행 문자 치환
            str = str.Replace(@"\n", Environment.NewLine);

            return str;
        }

        #endregion
    }
}
