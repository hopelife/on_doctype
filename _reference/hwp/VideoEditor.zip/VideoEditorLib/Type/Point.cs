﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using Float = System.Single;
using Bool = System.Boolean;

namespace Hnc.Type {

    // x, y 좌표 관리
    // value Compare
    public sealed class Point {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Int X { get; set; }
        public Int Y { get; set; }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Point(Int x, Int y) {
            X = x;
            Y = y;
        }

        public static Point Create(Int x, Int y) {
            return new Point(x, y);
        }
        public Point Clone() {
            return Point.Create(X, Y);
        }
        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            Point other = obj as Point;
            Debug.Assert(other != null);

            return (X == other.X) && (Y == other.Y);
        }
        public static Bool operator ==(Point left, Point right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Point left, Point right) {
            return !(left == right);
        }
        #endregion

        public static Point operator +(Point left, Point right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return Point.Create(left.X + right.X, left.Y + right.Y);
        }
        public static Point operator -(Point left, Point right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return Point.Create(left.X - right.X, left.Y - right.Y);
        }

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }
    }

    public sealed class PointF {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Float X { get; set; }
        public Float Y { get; set; }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private PointF(Float x, Float y) {
            X = x;
            Y = y;
        }

        public static PointF Create(Float x, Float y) {
            return new PointF(x, y);
        }

        public PointF Clone() {
            return PointF.Create(X, Y);
        }

        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            Point other = obj as Point;
            Debug.Assert(other != null);

            return (X == other.X) && (Y == other.Y);
        }
        public static Bool operator ==(PointF left, PointF right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(PointF left, PointF right) {
            return !(left == right);
        }
        #endregion

        public static PointF operator +(PointF left, PointF right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return PointF.Create(left.X + right.X, left.Y + right.Y);
        }
        public static PointF operator -(PointF left, PointF right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return PointF.Create(left.X - right.X, left.Y - right.Y);
        }

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }
    }

}
