﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using String = System.String;
using Bool = System.Boolean;
using Index = System.Int32;
using Frame = System.Double;

using Hnc.VideoEditor.Base.Type;

using Hnc.VideoEditor.Filter;

using Hnc.VideoEditor.Engine;
using Hnc.DataLogic;

using System;
using System.Windows;
using Hnc.Type;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Hnc.VideoEditor.Engine {
	public class Transaction {
		private static readonly Index NonSelectedInfo = -1;

		private static readonly Object thisLock = new Object();
		private static Transaction instance;

		public static Transaction Instance {
			get {
				lock (thisLock) {
					if (instance == null) {
						instance = new Transaction();
					}
				}
				return instance;
			}
		}

		public void Close() {
			Application.Current.Shutdown();
		}

		public void ChangeWindowStateMin() {
			Application.Current.MainWindow.WindowState = System.Windows.WindowState.Minimized;
		}

		public void ChangeWindowStateMax() {
			Application.Current.MainWindow.WindowState = System.Windows.WindowState.Maximized;
		}

		public void ChangeWindowStateNomal() {
			Application.Current.MainWindow.WindowState = System.Windows.WindowState.Normal;
		}

		public String GetSaveFileName() {
			return MarkerUtil.GetMarker().GetSaveFilePath();
		}

		public void SetSaveFileName(String saveFileName) {
			MarkerUtil.GetMarker().SetSaveFilePath(saveFileName);
		}

		public int ExportCancel() {
			return MarkerUtil.GetMarker().ExportCancel();
		}

		public int Export(String filePath, int width, int height, int frameRate, int videoCodec, int audioCodec) {
			if (filePath == null) {
				return 0;
			}

			if (width <= 0) {
				return 0;
			}

			if (height <= 0) {
				return 0;
			}

			if (frameRate <= 0) {
				return 0;
			}

			return MarkerUtil.GetMarker().Export(filePath, width, height, frameRate, videoCodec, audioCodec);
		}

		public Bool Save() {
			Pipe pipe = new Pipe();

			Collection<TimelineInfo> infoCollection = MarkerUtil.GetMarker().GetTimelineInfoCollection();

			return pipe.Save(MarkerUtil.GetMarker().GetSaveFilePath(), infoCollection);

			// XMLParser parser = new XMLParser();

			// return parser.Save(MarkerUtil.GetMarker().GetSaveFilePath(), MarkerUtil.GetMarker().GetTimeline());
		}

		public Bool Load(String filePath) {
			//XMLParser parser = new XMLParser();
			NewDocument();

			if (filePath == null) {
				// 파일 다이얼로그 띄우기
			}

			Pipe pipe = new Pipe();
			Bool retval = pipe.Load(filePath);
			MarkerUtil.GetMarker().SetSaveFilePath(filePath);
			//parser.Load(MarkerUtil.GetMarker().GetSaveFilePath(), MarkerUtil.GetMarker().GetTimeline());

			return retval;
		}

		public Bool CompareFilePath(String filePath) {
			if (filePath == null) {
				return false;
			}

			return MarkerUtil.GetMarker().CompareFilePath(filePath);
		}

		public Bool NewDocument() {

			if (MarkerUtil.GetMarker().NewDocument() != true) {
				return false;
			}

			MarkerUtil.GetMarker().SetSaveFilePath(null);
			UndoManager.Instance.Clear();

			/*
			marker.Doc = Document.Create();

			if (marker.Doc == null) {
				return false;
			}
			*/

			return true;
		}

		public UndoItem PropertyChangedInfo(TimelineInfo info) {
			TimelineInfo newInfo = info.Clone();
			TimelineInfo oldInfo = MarkerUtil.GetMarker().PropertyChangedInfo(newInfo);
			UndoItem undoItem = UndoPropertyChangedInfo.Create(oldInfo, newInfo);
#if DEBUG
			Debug.Assert(undoItem != null, "UndoItem를 생성하지 못하였습니다.");
#endif
			return undoItem;
		}

		public int ChangingFilePathInfo(String oldFilePath, String newFilePath) {
			return MarkerUtil.GetMarker().ChangingFilePathInfo(oldFilePath, newFilePath);
		}

		public UndoItem AddSubtitleInfo(String sentence, Frame frame) {
			TimelineInfo addInfo = MarkerUtil.GetMarker().AddSubtitleInfo(sentence, frame);

			if (addInfo == null) {
				return null;
			}

			UndoItem undoItem = UndoAddInfo.Create(addInfo);
#if DEBUG
			Debug.Assert(undoItem != null, "UndoItem를 생성하지 못하였습니다.");
#endif
			return undoItem;
		}


		public UndoItem AddVideoInfo(String filePath, Frame totalFrame, FrameScope videoScope) {
			if (filePath == null) {
				Debug.Assert(false, "AddVideoInfo filePath가 null 입니다.");
				return null;
			}

			if (System.IO.File.Exists(filePath) == false) {
				Debug.Assert(false, "AddVideoInfo file이 존재하지 않습니다.");
				return null;
			}

			if (videoScope.CheckFrame() == false) {
				Debug.Assert(false, "AddVideoInfo videoScope가 잘못되었습니다.");
				return null;
			}

			TimelineInfo addInfo = MarkerUtil.GetMarker().AddVideoInfo(filePath, totalFrame, videoScope);

			if (addInfo == null) {
				Debug.Assert(false, "AddVideoInfo addInfo가 실패하였습니다.");
				return null;
			}

			UndoItem undoItem = UndoAddInfo.Create(addInfo);
#if DEBUG
			Debug.Assert(undoItem != null, "UndoItem를 생성하지 못하였습니다.");
#endif
			return undoItem;
		}

		public System.Collections.Generic.List<TimelineInfo> SortInfo() {
			return MarkerUtil.GetMarker().SortInfo();
		}

		public UndoItem RemoveInfo(String filePath) {
			if (filePath == null) {
				return null;
			}
			return null;
		}

		public UndoItem RemoveInfo(Index id) {
			if (id <= NonSelectedInfo) {
				return null;
			}

			TimelineInfo removeInfo = MarkerUtil.GetMarker().RemoveInfo(id);

			UndoItem undoItem = UndoRemoveInfo.Create(removeInfo);
#if DEBUG
			Debug.Assert(undoItem != null, "UndoItem를 생성하지 못하였습니다.");
#endif

			return undoItem;
		}

		public Bool RemoveVideoInfo(String filePath, FrameScope videoScope, FrameScope timelineScope) {
			if (filePath == null) {
				return false;
			}

			if (videoScope.CheckFrame() == false) {
				return false;
			}

			if (timelineScope.CheckFrame() == false) {
				return false;
			}

			return MarkerUtil.GetMarker().RemoveVideoInfo(filePath, videoScope, timelineScope);
		}
	}



	public class TransactionUtil {
		public static Transaction GetTransaction() {
			return Transaction.Instance;
		}
	}

	public class UndoManagerUtil {
		public static UndoManager GetTransaction() {
			return UndoManager.Instance;
		}
	}
}