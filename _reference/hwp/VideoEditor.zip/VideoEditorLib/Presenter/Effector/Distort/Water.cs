﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Index = System.Int32;


namespace Hnc.Presenter.ImageEffect {

    // 픽셀을 분산시켜 물방울 파동을 표시한다.
    public class Water : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        Float XCenter; // X 좌표
        Float YCenter;
        Float Radius; // 반경. 최소 0
        Float Radius2; // 최소 0
        Ratio Amplitude; // 1.5정도가 적절 왜곡을 위한 증폭량, 0 ~ 100
        Float WaveLength; // 웨이브 길이
        Float Phase = 0; // 주기적으로 변하는 파동에서 굴절 표시할 각도. Radian

 
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------

        private Water(
            Float xCenter, Float yCenter,
            Float radius,
            Float amplitude,
            Float waveLength,
            Float phase
            )
            : base() {

            XCenter = xCenter;
            YCenter = yCenter;
            Radius = (radius < 0) ? 0 : radius;

            Amplitude = MathUtil.Clamp(amplitude, 0, 100); // 진폭
            WaveLength = waveLength;
            Phase = phase;

            Radius2 = Radius * Radius;


            Debug.AssertThrow(Radius2 != 0, eErrorCode.DevideZero);

        }
        public static Water Create(
            Float xCenter,
            Float yCenter,
            Float radius,
            Float amplitude,
            Float waveLength,
            Float phase) {
            return new Water(
                xCenter, yCenter,
                radius,
                amplitude,
                waveLength,
                phase);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {

            Float dx = targetX - XCenter;
            Float dy = targetY - YCenter;
		    Float distance2 = dx * dx + dy * dy;
		    if (Radius2 < distance2) {
			    originX = targetX;
			    originY = targetY;
		    } 
            else {
			    Float distance = MathUtil.Sqrt(distance2);
                Float amount = Amplitude * MathUtil.Sin(distance / WaveLength * MathUtil.TWO_PI - Phase);
			    amount *= (Radius - distance) / Radius;
                if (distance != 0) {
                    amount *= WaveLength / distance;
                }
                originX = targetX + dx * amount;
                originY = targetY + dy * amount;
            }
        }
        #endregion

    }
}
