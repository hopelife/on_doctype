﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {

    // 로모느낌이 나도록 비네팅과 색상/Contrast를 조정한다.
    public class Romo {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Ratio Center = 0.3F; // 중심 영역. 0 ~ 1
        private Ratio Opacity = 0.7F; // 불투명도. 0 ~ 1

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Romo(Ratio center, Ratio opacity) {
            Center = MathUtil.Clamp(center, 0, 1);
            Opacity = MathUtil.Clamp(opacity, 0, 1);

        }
        public static Romo Create(Ratio center, Ratio opacity) {

            return new Romo(center, opacity);
        }  
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);


            Rgb.Create(-0.02F, 0.04F, -0.01F).Apply(pixels);
            BrightnessContrast.Create(0, 0.2F).Apply(pixels);
            Vignette.Create(Center, Opacity).Apply(pixels);

        }

    }
}
