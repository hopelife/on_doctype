﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;

namespace Hnc.Type {

    public enum eErrorCode { 

        // 인자 검사
        InvalidPathName, // 유효하지 않은 경로명
        InvalidArgument, // 유효하지 않은 인자
        NullArgument,   // 인자가 널
        OutOfBoundary, // 값의 경계범위 밖의 값
        OutOfRange, // 허용 범위 밖의 값. 주로 컬렉션의 인덱스 범위 이상
        InvalidCount, // 갯수가 유효하지 않음
        DevideZero, // 0 으로 나눔
        CreateFail, // 생성실패

        
        // 폴더, 파일
        ExistsFolder, // 동일한 폴더가 존재함
        ExistsFile, // 동일한 파일이 존재함
        FolderNotFound, // 해당 디렉토리가 없음
        FileNotFound, // 해당 파일이 없음
        FileLoadFail, // 파일로딩 실패


    }

    // 디버그 자가진단
    public static class Debug {

        // 디버그 상태에서 Assert. release에서 아무동작 안함.
        // 개발자에 의한 실수 검출때 사용.
        // 주로 다른 곳에서 가정한 내용이 리팩토링에 의해 변화되었는지 감지하는 용도로 사용
        [System.Diagnostics.Conditional("DEBUG")]
        public static void Assert(Bool condition) {
            System.Diagnostics.Debug.Assert(condition);
        }

        [System.Diagnostics.Conditional("DEBUG")]
        public static void Assert(Bool condition, String message) {
            System.Diagnostics.Debug.Assert(condition, message);
        }

        // 디버그상태에서 Assert. release에서 throw 발생
        // API 사용자에 의한 실수이므로 런타임에도 throw를 발생시킴
        // 주로 함수 인자가정오류시 이를 보정 못하면 발생시킴
        public static void AssertThrow(Bool condition, eErrorCode errorCode) {
            System.Diagnostics.Debug.Assert(condition);
            if (!condition) {
                System.Exception e = new System.Exception();
                e.Data["ErrorCode"] = errorCode;
                throw e;
            }
        }
    }
}
