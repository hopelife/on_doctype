﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;

using Int = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // 3x3 영역의 인접 픽셀과 비교하여
    // 인접 픽셀의 최소값보다 작으면 노이즈로 판단하여 인접픽셀 최소값으로 대체하고,
    // 인접 픽셀의 최소값보다 크면 노이즈로 판단하여 인접픽셀 최대값으로 대체한다.
    // 노이즈가 점 1개일 때만 효과가 있으므로 현실적으로 사용성은 떨어진다.
    public class ReduceNoise {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private ReduceNoise() {
        }

        public static ReduceNoise Create() {
            return new ReduceNoise();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;

            Byte[] r = new Byte[9];
            Byte[] g = new Byte[9];
            Byte[] b = new Byte[9];
            Index targetPixelPos = 0;
            Index matrixIndex;
            Index xPos;
            Index yPos;
            Index pos;
            Index startPos;


            for (Index y = 0; y < height; ++y) {
                for (Index x = 0; x < width; ++x) {

                    // ----------------------------------------------
                    // 3 x 3 영역의 인근 픽셀 추출. 이미지 영역바깥이면 걍 현재 픽셀을 추출한다.
                    // ----------------------------------------------
                    matrixIndex = 0;
                    for (Index row = -1; row <= 1; ++row) {
                        yPos = y + row;

                        // 이미지 내부
                        if (0 <= yPos && yPos < height) {
                            startPos = yPos * width;

                            for (Index col = -1; col <= 1; ++col) {
                                xPos = x + col;

                                // 이미지 내부
                                if (0 <= xPos && xPos < width) {
                                    pos = startPos + xPos;
                                    r[matrixIndex] = pixels.R[pos];
                                    g[matrixIndex] = pixels.G[pos];
                                    b[matrixIndex] = pixels.B[pos];
                                }
                                // 이미지 외부
                                else {
                                    r[matrixIndex] = pixels.R[targetPixelPos];
                                    g[matrixIndex] = pixels.G[targetPixelPos];
                                    b[matrixIndex] = pixels.B[targetPixelPos];
                                }
                                ++matrixIndex;
                            }
                        }
                        // 이미지 외부
                        else {
                            for (Index col = -1; col <= 1; ++col) {
                                r[matrixIndex] = pixels.R[targetPixelPos];
                                g[matrixIndex] = pixels.G[targetPixelPos];
                                b[matrixIndex] = pixels.B[targetPixelPos];

                                ++matrixIndex;
                            }
                        }
                        
                    }
                    // ----------------------------------------------
                    // 추출된 rgb에서 노이즈영역을 판단하여 smooth한 값을 구함
                    // ----------------------------------------------
                    pixels.R[targetPixelPos] = Smooth(r);
                    pixels.G[targetPixelPos] = Smooth(g);
                    pixels.B[targetPixelPos] = Smooth(b);
                    
                    ++targetPixelPos;
                }
            }
        }
        // 추출된 픽셀들에서 중심위치(index == 4)와 주변 픽셀의 차를 보고 
        // 인접 픽셀의 최소값보다 작으면 노이즈로 판단하여 인접픽셀 최소값으로 대체하고,
        // 인접 픽셀의 최소값보다 크면 노이즈로 판단하여 인접픽셀 최대값으로 대체한다.
        private Byte Smooth(Byte[] m) { 
            Debug.Assert(m.Length == 9);
            Index minIndex = 0;
            Index maxIndex = 0;
            Byte min = 255;
            Byte max = 0;


            for (Index i = 0; i < 9; ++i) {
                if (i != 4) {
                    if (m[i] < min) {
                        min = m[i];
                        minIndex = i;
                    }
                    else if (max < m[i]) { 
                        max = m[i];
                        maxIndex = i;
                    }
                }
            }

            if (m[4] < min) {
                return m[minIndex];
            }
            if (max < m[4]) {
                return m[maxIndex];
            }
            return m[4];
        }
    }
}