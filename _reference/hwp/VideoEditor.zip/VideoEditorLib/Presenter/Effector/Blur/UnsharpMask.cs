﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Count = System.Int32;
using Ratio = System.Single;
using Index = System.Int32;
using Byte = System.Byte;
using Pixel = System.UInt32;
using Int = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    // Blur를 수행한 이미지와 원본이미지간의 픽셀차를 보고 
    // Threshold 이상의 차이가 있다면 급격한 색상변화가 있는 경계영역이므로
    // 이 영역을 Amount만큼 색상 더하기를 하여 강조시킨다.
    public class UnsharpMask {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Count Radius = 2; // 반경. 블러링되는 영역. 1~
        private Ratio Amount = 2F; // Sharpen 적용량. 1~
        private Pixel Threshold = 10; // 색상차. 1~

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------

        // radius : 반경
        // Amount : sharpen 적용량. 2가 적절. 1이면 아무변화없음
        // Threshold : 색상차. 10 정도가 적절 이 값보다 커야 sharpen이 적용됨
        private UnsharpMask(Count radius, Ratio amount, Pixel threshold) {
            Radius = (radius < 1) ? 1 : radius;
            Amount = (amount < 1) ? 1 : amount;
            Threshold = (threshold < 1) ? 1 : threshold;
        }
        public static UnsharpMask Create(Count radius, Ratio amount, Pixel threshold) {

            return new UnsharpMask(radius, amount, threshold);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {


            Count radius = Radius;

            ArgbChannel blur = pixels.Clone();
            BoxBlur.Create(radius).Apply(blur);

            Byte r1;
            Byte g1;
            Byte b1;
            
            Byte r2;
            Byte g2;
            Byte b2;

            Int dr; // 1 - 2
            Int dg;
            Int db;

            // 연산속도 향상을 위해 Amount에 따른 값을 미리 저장
            Int[] plusTable = new Int[256];
            for (Index i = 0; i < 256; ++i) {
                plusTable[i] = (Int)(Amount * i);
            }

            Int[] minersTable = new Int[256];
            for (Index i = 0; i < 256; ++i) {
                minersTable[i] = (Int)(Amount * (-i));
            }

            for (Index i = 0; i < pixels.R.Length; ++i) {
               
                r1 = pixels.R[i];
                g1 = pixels.G[i];
                b1 = pixels.B[i];

                r2 = blur.R[i];
                g2 = blur.G[i];
                b2 = blur.B[i];

                dr = r1 - r2;
                dg = g1 - g2;
                db = b1 - b2;

                if (Threshold <= dr) {
                    r1 = (Byte)MathUtil.Clamp((plusTable[dr] + r2), 0, 255);
                }
                else if (Threshold <= -dr) {
                    r1 = (Byte)MathUtil.Clamp((minersTable[-dr] + r2), 0, 255);
                } 
                
                if (Threshold <= dg) {
                    g1 = (Byte)MathUtil.Clamp((plusTable[dg] + g2), 0, 255);
                }
                else if (Threshold <= -dg) {
                    g1 = (Byte)MathUtil.Clamp((minersTable[-dg] + g2), 0, 255);
                }
                
                if (Threshold <= db) {
                    b1 = (Byte)MathUtil.Clamp((plusTable[db] + b2), 0, 255);
                }

                else if (Threshold <= -db) {
                    b1 = (Byte)MathUtil.Clamp((minersTable[-db] + b2), 0, 255);
                }


                pixels.R[i] = (Byte)r1;
                pixels.G[i] = (Byte)g1;
                pixels.B[i] = (Byte)b1;
           }
        
        }
    }
}
