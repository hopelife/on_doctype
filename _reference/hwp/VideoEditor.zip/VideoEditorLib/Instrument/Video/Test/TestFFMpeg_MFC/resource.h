//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestFFMpeg_MFC.rc
//
#define IDD_TESTFFMPEG_MFC_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_FILEOPEN             1000
#define IDC_BUTTON_GETFRAME             1001
#define IDC_BUTTON_PLAY                 1002
#define IDC_BUTTON_STOP                 1003
#define IDC_EDIT_FILEPATH               1004
#define IDC_STATIC_SCREEN               1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
