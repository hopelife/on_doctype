#include "gdevwmf.h"
#include "gdevwmf_.h"

#define CMYK_C	0
#define CMYK_M	1
#define CMYK_Y	2
#define CMYK_K	3

gx_color_index wmf_map_cmyk_color( gx_device *dev, const gx_color_value cv[4] )
{
	gx_color_index color = 0;
	BOOL bICCSuccess = FALSE;
	int r, g, b;
	gx_device_wmf *wdev = (gx_device_wmf*)dev;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_map_cmyk_color\n");

		if (wdev->hTransform) {
			fprintf(wdev->pFile, "wdev->hTransform != NULL\n");
		}
	}
#endif // _DEBUG

	// ICC Profile ���
	if (wdev->hTransform) {
		COLOR InputColor, OutputColor;
		InputColor.cmyk.cyan =		(WORD)( cv[ CMYK_C ] / 32760.0 * 65535.0);
		InputColor.cmyk.magenta =	(WORD)( cv[ CMYK_M ] / 32760.0 * 65535.0);
		InputColor.cmyk.yellow =	(WORD)( cv[ CMYK_Y ] / 32760.0 * 65535.0);
		InputColor.cmyk.black =		(WORD)( cv[ CMYK_K ] / 32760.0 * 65535.0);
		TranslateColors(wdev->hTransform, &InputColor, 1, COLOR_CMYK, &OutputColor, COLOR_RGB);
		r = (int)(OutputColor.rgb.red / 65535.0 * 255.0);
		g = (int)(OutputColor.rgb.green / 65535.0 * 255.0);
		b = (int)(OutputColor.rgb.blue / 65535.0 * 255.0);
		bICCSuccess = TRUE;
	}

	// CMYK -> RGB ��ȯ ���� ���   R = 1 - C * (1 - K) - K
	if (!bICCSuccess) {
		r = (int)((1 - ( cv[ CMYK_C ] / 32760.0 * (1 - cv[ CMYK_K ] / 32760.0)) - cv[ CMYK_K ] / 32760.0) * 255.0);
		g = (int)((1 - ( cv[ CMYK_M ] / 32760.0 * (1 - cv[ CMYK_K ] / 32760.0)) - cv[ CMYK_K ] / 32760.0) * 255.0);
		b = (int)((1 - ( cv[ CMYK_Y ]  / 32760.0 * (1 - cv[ CMYK_K ] / 32760.0)) - cv[ CMYK_K ] / 32760.0) * 255.0);
	}

	// 0 - 255 ������ ������ ����.
	r = (r < 0) ? 0 : r;
	g = (g < 0) ? 0 : g;
	b = (b < 0) ? 0 : b;

	r = (r > 255) ? 255 : r;
	g = (g > 255) ? 255 : g;
	b = (b > 255) ? 255 : b;

	color = r << 16 | g << 8 | b;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "r=%ld,g=%ld,b=%ld\n\n", r, g, b);
	}
#endif // _DEBUG

	return color;
}
