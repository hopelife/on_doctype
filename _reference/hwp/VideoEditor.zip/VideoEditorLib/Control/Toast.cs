﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Diagnostics;

namespace Hnc.Control {
    /// <summary>
    /// Windows Metro UX의 Flyouts와 유사한 컨트롤
    /// </summary>
    public class Toast : ContentControl {
        public enum FloatPosition {
            Top, Bottom, Left, Right, Center, LeftBottom, RightBottom, LeftTop, RightTop
        }

        #region -> Fields

        private Thickness toastMargin = new Thickness();
        private DoubleAnimation transparentAnimation = new DoubleAnimation();
        private ThicknessAnimation borderAnimation = new ThicknessAnimation();

        #endregion

        #region -> Constructor

        static Toast() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Toast), new FrameworkPropertyMetadata(typeof(Toast)));
        }

        #endregion

        #region -> Events

        /// <summary>
        /// Toast가 열릴 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Opened;

        /// <summary>
        /// Toast가 닫힐 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Closed;

        #endregion

        #region -> Properties

        /// <summary>
        /// Toast의 출력 위치를 설정하거나 가져옵니다.
        /// </summary>
        public FloatPosition FloatType {
            get { return (FloatPosition)GetValue(FloatTypeProperty); }
            set { SetValue(FloatTypeProperty, value); }
        }

        public double HorizontalOffset {
            get { return (double)GetValue(HorizontalOffsetProperty); }
            set {

                if (FloatType == FloatPosition.Right || FloatType == FloatPosition.RightBottom || FloatType == FloatPosition.RightTop)
                    toastMargin.Right = -value;
                else
                    toastMargin.Left = value;

                this.Margin = toastMargin;

                SetValue(HorizontalOffsetProperty, value);
            }
        }

        public double VerticalOffset {
            get { return (double)GetValue(VerticalOffsetProperty); }
            set {

                if (FloatType == FloatPosition.Bottom || FloatType == FloatPosition.LeftBottom || FloatType == FloatPosition.RightBottom)
                    toastMargin.Bottom = -value;
                else
                    toastMargin.Top = value;

                this.Margin = toastMargin;

                SetValue(VerticalOffsetProperty, value);
            }
        }

        public static readonly DependencyProperty FloatTypeProperty =
            DependencyProperty.Register("FloatType", typeof(FloatPosition), typeof(Toast), new PropertyMetadata(FloatPosition.Center));

        public static readonly DependencyProperty HorizontalOffsetProperty =
            DependencyProperty.Register("HorizontalOffset", typeof(double), typeof(Toast), new PropertyMetadata(0d));

        public static readonly DependencyProperty VerticalOffsetProperty =
            DependencyProperty.Register("VerticalOffset", typeof(double), typeof(Toast), new PropertyMetadata(0d));

        /// <summary>
        /// Toast의 표시 상태를 설정하거나 가져옵니다.
        /// </summary>
        public bool IsOpen {
            get { return (bool)GetValue(IsOpenProperty); }
            set {
                if (IsOpen == value)
                    return;

                SetValue(IsOpenProperty, value);

                if (value) {
                    PlayOpenAnimation();
                    OnOpened();
                } else {
                    PlayCloseAnimation();
                    OnClosed();
                }
            }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(Toast), new PropertyMetadata(false));

        #endregion

        #region -> Private Methods

        private void OnOpened() {
            if (Opened != null)
                Opened(this, null);
        }

        private void OnClosed() {
            if (Closed != null)
                Closed(this, null);
        }

        private void PlayOpenAnimation() {

            this.Visibility = Visibility.Visible;

            transparentAnimation.To = 1d;

            borderAnimation.To = new Thickness(0d);
            borderAnimation.AutoReverse = true;

            this.BeginAnimation(OpacityProperty, transparentAnimation);
            this.BeginAnimation(BorderThicknessProperty, borderAnimation);
        }

        private void PlayCloseAnimation() {

            transparentAnimation.To = 0d;
            this.BeginAnimation(OpacityProperty, transparentAnimation);
        }

        #endregion

        #region -> Overrided Methods

        protected override void OnInitialized(EventArgs e) {
            base.OnInitialized(e);

            transparentAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.3));
            transparentAnimation.AccelerationRatio = 0.33;
            transparentAnimation.DecelerationRatio = 0.33;
            transparentAnimation.Completed += new EventHandler(transparentAnimation_Completed);

            borderAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.5));
            borderAnimation.AccelerationRatio = 0.33;
            borderAnimation.DecelerationRatio = 0.33;

            if (IsOpen)
                this.Visibility = Visibility.Visible;
            else
                this.Visibility = Visibility.Collapsed;
        }

        private void transparentAnimation_Completed(object sender, EventArgs e) {

            if (!IsOpen)
                this.Visibility = Visibility.Collapsed;
        }

        #endregion
    }
}
