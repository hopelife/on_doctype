﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using String = System.String;
using Hnc.VideoEditor.Base.Type;
using System.Collections.Generic;


namespace Hnc.VideoEditor.Engine {
    //////////////////////////////////////////////////////////////////////////////////////////
    // 추후 Video Info 정보 대신 Image를 출력할 수도 있서 만들어놓은 클래스
    //////////////////////////////////////////////////////////////////////////////////////////
    public class ImageInfo : TimelineInfo {
        public ImageInfo(String filePath, FrameScope timelineScope) {
            this.filePath = filePath;
            TimelineScope = timelineScope;
        }

        private String filePath;
        public String FilePath {
            get {
                return filePath;
            }
            set {
                filePath = value;
            }
        }

        private List<IEffect> effectList = new List<IEffect>();
    }
}
