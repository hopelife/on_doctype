﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Float = System.Single;
using Ratio = System.Single;

namespace Hnc.Util {
    public sealed class Transform2D {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Matrix3 matrix = Matrix3.Create(); // 단위 행렬로 생성
        private Matrix3 M {
            get {
                Debug.Assert(matrix != null);
                return matrix;
            }
            set {
                Debug.AssertThrow(value != null, eErrorCode.NullArgument);
                matrix = value;
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Transform2D() { // 단위행렬로 생성
        }

        public static Transform2D Create() {
            return new Transform2D();
        }
		// Scale - Rotation - Transform의 순서로 매트릭스를 적용하여 생성
		// 단, 회전은 0, 0 좌표를 기준으로 회전하므로, Apply시 이를 고려한 점을 전달해 주어야 한다.
        public static Transform2D Create(Ratio xScale, Ratio yScale, Degree angle, Float dx, Float dy) {
            Transform2D result = Create();
            
            result.Scale(xScale, yScale, 0, 0);
            result.Rotate(angle, 0, 0);
            result.Translate(dx, dy);

            return result;
        }

        // originRect 가 curRect가 되기위한 transform 설정
        // originRect : 원본의 rect
        // curRect : X, Y 는 오프셋, Width, Height는 Scale된 현재 크기
        // angle : 각도
        // center : 회전중심
        public static Transform2D Create(RectF originRect, RectF curRect, Degree angle, PointF center) {
            Debug.AssertThrow(originRect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(curRect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(angle != null, eErrorCode.NullArgument);
            Debug.AssertThrow(center != null, eErrorCode.NullArgument);

            Transform2D result = Create();
            if ((originRect.Width == 0 && originRect.Width != curRect.Width) ||
                (originRect.Height == 0 && originRect.Height != curRect.Height)) {
                return result;// 단위행렬
            }



            PointF originCenter = originRect.Center;
            PointF curCenter = curRect.Center;

		    Ratio xScale = (curRect.Width == originRect.Width)  ? 1 : (curRect.Width  / originRect.Width);
		    Ratio yScale = (curRect.Height == originRect.Height) ? 1 : (curRect.Height / originRect.Height);
    	
		    // 중심을 원점으로 이동
		    result.Translate(-originCenter.X, -originCenter.Y);

		    result.Scale(xScale, yScale, 0, 0);


		    // 회전 중심점 변경
		    PointF rotationCenterOffset = PointF.Create((originCenter.X - center.X) * MathUtil.Abs(xScale), (originCenter.Y - center.Y) * MathUtil.Abs(yScale));
		    result.Translate(rotationCenterOffset.X, rotationCenterOffset.Y);
		    result.Rotate(angle, 0, 0);
		    result.Translate(-rotationCenterOffset.X, -rotationCenterOffset.Y);

		    result.Translate(curCenter.X, curCenter.Y);

            return result;
        }


        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public Point GetTransformPoint(Point point) {
            Debug.AssertThrow(point != null, eErrorCode.NullArgument);

            if (M.Identity) {
                return point;
            }


            Float tempX = point.X * M.A[0, 0] + point.Y * M.A[0, 1] + M.A[0, 2];
            Float tempY = point.X * M.A[1, 0] + point.Y * M.A[1, 1] + M.A[1, 2];

            return Point.Create(
                MathUtil.Round(tempX),
                MathUtil.Round(tempY)
            );
        }
        public PointF GetTransformPoint(PointF point) {
            Debug.AssertThrow(point != null, eErrorCode.NullArgument);

            if (M.Identity) {
                return point;
            }


            Float tempX = point.X * M.A[0, 0] + point.Y * M.A[0, 1] + M.A[0, 2];
            Float tempY = point.X * M.A[1, 0] + point.Y * M.A[1, 1] + M.A[1, 2];

            return PointF.Create(
                tempX,
                tempY
            );
        }


        public void Translate(Float dx, Float dy) {
            Matrix3 m = Matrix3.Create();
            // | 1  0  x  |  
            // | 0  1  y  |
            // | 0  0  1  |
            m.A[0, 2] = dx;
            m.A[1, 2] = dy;

            M.PreMultiply(m);
        }
        public void Scale(Ratio x, Ratio y, Float xCenter, Float yCenter) {

            Matrix3 m = Matrix3.Create();
            m.A[0, 0] = x; m.A[0, 1] = 0; m.A[0, 2] = xCenter * (1 - x);
            m.A[1, 0] = 0; m.A[1, 1] = y; m.A[1, 2] = yCenter * (1 - y);
            m.A[2, 0] = 0; m.A[2, 1] = 0; m.A[2, 2] = 1;

            M.PreMultiply(m);
        }
        public void Rotate(Degree angle, Float xCenter, Float yCenter) {
            Skew(angle, angle, xCenter, yCenter);
        }

        public void Skew(Degree x, Degree y, Float xCenter, Float yCenter) {
            Matrix3 m = Matrix3.Create();
            Float cosX = MathUtil.Cos(MathUtil.ToRadian(x.Value));
            Float cosY = MathUtil.Cos(MathUtil.ToRadian(y.Value));
            Float sinX = MathUtil.Sin(MathUtil.ToRadian(x.Value));
            Float sinY = MathUtil.Sin(MathUtil.ToRadian(y.Value));

            m.A[0, 0] = cosY;   m.A[0, 1] = -sinX;  m.A[0, 2] = xCenter * (1 - cosY) + yCenter * sinX;
            m.A[1, 0] = sinY;   m.A[1, 1] = cosX;   m.A[1, 2] = yCenter * (1 - cosX) - xCenter * sinY;
            m.A[2, 0] = 0;      m.A[2, 1] = 0;      m.A[2, 2] = 1;

		    M.PreMultiply(m);	
	    }
    }
}
