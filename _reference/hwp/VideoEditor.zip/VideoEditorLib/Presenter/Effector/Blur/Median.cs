﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Int = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    // 주어진 마스크 영역의 값들중 중간을 취한다.
    // 중값을 취하므로 색상수가 줄어들면서 잡음이 제거될 수 있다.
    // 허나 주변값조차 노이즈일수가 있으며, 사진의 선명한 영역이 잡음으로 판단되어 1픽셀씩 조금씩 특정 방향으로 움직이는 경향이 있다.
    public class Median {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Count Radius = 1; // 1~
        private Count Diameter;
        private Count Length;
        private static Int MaxVal = 255 * 3;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Median(Count radius) {
            Radius = (radius < 1) ? 1 : radius;
            
            Diameter = Radius + Radius + 1;
            Length = Diameter * Diameter;
        }

        public static Median Create(Count radius) {
            return new Median(radius);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Count width = pixels.Width;
            Count height = pixels.Height;
            ArgbChannel target = ArgbChannel.Create(width, height);

            Byte[] r = new Byte[Length];
            Byte[] g = new Byte[Length];
            Byte[] b = new Byte[Length];
            Index targetPixelPos = 0;
            Index matrixIndex;
            Index xPos;
            Index yPos;
            Index pos;
            Index startPos;


            for (Index y = 0; y < height; ++y) {
                for (Index x = 0; x < width; ++x) {

                    // ----------------------------------------------
                    // diameter x diameter 영역의 인근 픽셀 추출. 이미지 영역바깥이면 걍 현재 픽셀을 추출한다.
                    // ----------------------------------------------
                    matrixIndex = 0;
                    for (Index row = -Radius; row <= Radius; ++row) {
                        yPos = y + row;

                        // 이미지 내부
                        if (0 <= yPos && yPos < height) {
                            startPos = yPos * width;

                            for (Index col = -Radius; col <= Radius; ++col) {
                                xPos = x + col;

                                // 이미지 내부
                                if (0 <= xPos && xPos < width) {
                                    pos = startPos + xPos;
                                    r[matrixIndex] = pixels.R[pos];
                                    g[matrixIndex] = pixels.G[pos];
                                    b[matrixIndex] = pixels.B[pos];
                                }
                                // 이미지 외부
                                else {
                                    r[matrixIndex] = pixels.R[targetPixelPos];
                                    g[matrixIndex] = pixels.G[targetPixelPos];
                                    b[matrixIndex] = pixels.B[targetPixelPos];
                                }
                                ++matrixIndex;
                            }
                        }
                        // 이미지 외부
                        else {
                            for (Index col = -Radius; col <= Radius; ++col) {
                                r[matrixIndex] = pixels.R[targetPixelPos];
                                g[matrixIndex] = pixels.G[targetPixelPos];
                                b[matrixIndex] = pixels.B[targetPixelPos];

                                ++matrixIndex;
                            }
                        }

                    }
                    // ----------------------------------------------
                    // 추출된 rgb에서 노이즈영역을 판단하여 평균값으로 대치
                    // ----------------------------------------------
                    Index index = RgbMedian(r, g, b);
                    target.R[targetPixelPos] = r[index];
                    target.G[targetPixelPos] = g[index];
                    target.B[targetPixelPos] = b[index];


                    ++targetPixelPos;
                }

            }
            pixels.R = target.R;
            pixels.G = target.G;
            pixels.B = target.B;
        }
        // 값의 차이가 가장 적은 항목의 위치를 찾아 리턴.(평균값의 위치임)
        private Index RgbMedian(Byte[] r, Byte[] g, Byte[] b) {
            Int sum;
            Index index = 0;
            Int min = MaxVal;

            for (Index i = 0; i < Length; ++i) {

                sum = 0;
                for (Index j = 0; j < Length; ++j) {

                    sum += MathUtil.Abs(r[i] - r[j]);
                    sum += MathUtil.Abs(g[i] - g[j]);
                    sum += MathUtil.Abs(b[i] - b[j]);

                }

                if (sum < min) {
                    min = sum;
                    index = i;
                }

            }

            return index;
        }
    }
}