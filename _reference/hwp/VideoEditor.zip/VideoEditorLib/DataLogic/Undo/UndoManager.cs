﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Count = System.Int32;
using Int = System.Int32;
using Index = System.Int32;
using Bool = System.Boolean;
using String = System.String;

namespace Hnc.DataLogic {

    public interface UndoItem {
        void Undo();
        void Redo();
    }

    public class GroupUndoItem : UndoItem {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        // 상위 그룹. UndoManager에서 사용되지 않는다면 굳이 세팅할 필요 없음
        public GroupUndoItem Parent { get; set; }

        // this에 포함된 UndoItem들
        private readonly List<UndoItem> collection;
        public List<UndoItem> Collection {
            get {
                Debug.Assert(collection != null);
                return collection;
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        protected GroupUndoItem() {
            this.collection = List<UndoItem>.Create();
        }
        public static GroupUndoItem Create() {
            return new GroupUndoItem();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region UndoItem 구현
        public virtual void Undo() {
            Debug.Assert(Collection != null);

            Count count = Collection.Count;
            for (Index index = Collection.Count; 0 < index; --index) {
                Collection[index - 1].Undo();
            }
        }
        public virtual void Redo() {
            Debug.Assert(Collection != null);

            foreach (UndoItem item in Collection) {
                Debug.Assert(item != null);
                item.Redo();
            } 
        }
        #endregion
 
    }

    // singleton 혹은 개별로 생성하여 사용할 수 있음
    public class UndoManager : GroupUndoItem {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        private static readonly UndoManager instance;
        public static UndoManager Instance {
            get {
                Debug.Assert(instance != null);
                return instance;
            }
        }

        // 현재 삽입되어야할 컬렉션. GroupUndoItem의 collection 일 수 있다.
        private List<UndoItem> CurCollection { get; set; }

        // undo 항목의 갯수. 최소 1개
        private Count limit = 20;
        public Count Limit {
            get { return limit; }
            set {
                Debug.Assert(0 < value);
                limit = value;
                if (!(0 < limit)) {
                    limit = 1;
                }
            }
        }

        // 현재 undo 항목의 위치
        private Int pos = -1;
        public Int Pos {
            get { return pos; }
            private set {
                Debug.Assert(-1 <= value && value <= Collection.Count -1);
                pos = value; 
            }
        }

        public Bool IsEnableUndo {
            get {
                Debug.Assert(Collection != null);
                Debug.Assert(Pos < Collection.Count);
           
                return (-1 < Pos) ? true :false;
            }
        }
        public Bool IsEnableRedo {
            get {
                Debug.Assert(Collection != null);

                return ((Pos + 1) < Collection.Count) ? true : false;
            }
        }

        private GroupUndoItem BeginItem { get; set; }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        static UndoManager() {
            instance = new UndoManager();
        }
        private UndoManager() {

            CurCollection = Collection;
            Limit = 20; // 초기 undo갯수 20
            Pos = -1;
        }

        public static UndoManager CreateInstance() { 
            return new UndoManager();
        }

        public void Clear() {
            CurCollection.Clear();
            Limit = 20; // 초기 undo갯수 20
            Pos = -1;
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        // ignore 동일한 Type의 undo가 있다면 새로 입력하는 것은 무시한다.
        public void Record(UndoItem item, Bool ignore) {
            Debug.Assert(Collection != null);
            Debug.Assert(CurCollection != null);

            Debug.AssertThrow(item != null, eErrorCode.NullArgument);


            // 현재 삽입하려는 undo가 이전 collection에 추가되어 있다면 현 item은 무시한다.
            if (ignore == true) {
                
                // 주 컬렉션에 추가하는 상태라면 Undo/Redo에 의한 Pos 를 고려한다.
                if (object.ReferenceEquals(Collection, CurCollection)) {
                    if (0 <= Pos && CurCollection[Pos].GetType() == item.GetType()) {
                        return;
                    }
                }
                
                else if (0 < CurCollection.Count) { 
                    if (CurCollection[CurCollection.Count - 1].GetType() == item.GetType()) {
                        return;
                    }
                }
            }

            
            // 주 컬렉션에 Undo를 추가하는 상태라면 
            // 추가될 위치 다음의 Undo들은 더이상 사용할 수 없으므로 모두 제거하고
            // pos 위치를 새롭게 세팅한다.
            if (object.ReferenceEquals(Collection, CurCollection)) {

                // 새롭게 Undo가 추가될 것이므로 해당위치 다음 것들은 모두 제거
                if (Pos + 1 < Collection.Count) {
                    Collection.Remove(Pos + 1, Collection.Count - (Pos + 1));
                }

                // 최대 갯수만큼 이미 추가되었다면 제일 앞의 것을 삭제한다.
                if (Collection.Count == Limit) {
                    Collection.RemoveAt(0);
                }
                Collection.Add(item);

                // 컬렉션의 가장 마지막 위치로 세팅
                Pos = Collection.Count - 1;
            }
            // 주 컬렉션이 아니라면(GroupUndoItem에 추가중이라면) 단순히 추가한다.
            else {
                CurCollection.Add(item);
            }
        }

        // Begin() - End() 과정중 호출된 모든 Record들은 Group의 child로 추가된다.
        public void Begin() {
            GroupUndoItem group = GroupUndoItem.Create();
            Begin(group);
        }
        // 사용자에 의해 재정의된 GroupUndoItem을 사용할 수 있음
        public void Begin(GroupUndoItem group) {
            Debug.AssertThrow(group != null, eErrorCode.NullArgument);
            Debug.Assert(CurCollection != null);

            Record(group, false);
            group.Parent = (BeginItem == null) ? this : BeginItem;
            BeginItem = group;
            CurCollection = group.Collection; // GroupItem의 컬렉션을 curCollection으로 변경하여 이후로 Record되는 undo는 GroupUndoItem에 되도록 시뮬레이션 한다.
        }

        // Record가 상위 Collection에 추가되도록 되돌린다.
        public void End() {
            
            Debug.Assert(BeginItem != null);
            Debug.Assert(BeginItem.Parent != null);
            Debug.Assert(BeginItem.Parent.Collection != null);

            CurCollection = BeginItem.Parent.Collection;
            BeginItem = BeginItem.Parent;
            if (object.ReferenceEquals(BeginItem, this)) {
                BeginItem = null;
            }
            Debug.Assert(CurCollection != null);
        }
        #region UndoItem 구현
        public override void Undo() {
            Debug.Assert(Collection != null);
            Debug.Assert(Pos < Collection.Count);

            if (!IsEnableUndo) {
                return;
            }
            Collection[Pos].Undo();
            --Pos;
        }
        public override void Redo() {
            Debug.Assert(Collection != null);
            if (!IsEnableRedo) {
                return;
            }
            ++Pos;
            Debug.Assert(Pos < Collection.Count);

            Collection[Pos].Redo();
        }
        #endregion

        // className인 UndoItem을 현 Pos이전에서 찾아 삭제한다.
        public void RemoveAllPrev(String className) {
            Debug.Assert(Collection != null);
            Debug.Assert(Pos < Collection.Count);
            Debug.AssertThrow(className != null, eErrorCode.NullArgument);

            if (!IsEnableUndo) {
                return;
            }

            for (Index index = Pos + 1; 0 < index; --index) {

                if (Collection[index - 1].GetType().Name == className) {
                    Collection.RemoveAt(index - 1);
                    --Pos;
                }
            }
        }
    }
}
