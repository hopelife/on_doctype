﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor {
	using String = System.String;
	using System.Collections.Generic;
	using System.ComponentModel;
	using Hnc.Type;
	using Hnc.VideoEditor.Base.Type;
	using Hnc.VideoEditor.Controls;
	using Hnc.VideoEditor.Engine;
	using Hnc.VideoEditor.Service;

	public class ViewUtil {
		private TimelineView _videoTimeline = null;
		private TimelineView _soundTimeline = null;
		private TimelineView _subtitleTimeline = null;
		private ViewModel _viewModel = new ViewModel();

		public ViewUtil(TimelineView videoTimeline, TimelineView soundTimeline, TimelineView subtitleTimeline) {
			if (videoTimeline == null || soundTimeline == null || subtitleTimeline == null) {
			}

			_videoTimeline = videoTimeline;
			_soundTimeline = soundTimeline;
			_subtitleTimeline = subtitleTimeline;

			_viewModel.PropertyChanged += new PropertyChangedEventHandler(Timeline_PropertyChanged);
		}

		private void Timeline_PropertyChanged(object sender, PropertyChangedEventArgs e) {
			KeyValuePair<String, TimelineInfo> item = ChangedTimeline.Pop();

			switch (item.Key) {
				case "AddTimelineInfo":
					AddInfo(item.Value);
					break;
				case "RemoveTimelineInfo":
					RemoveInfo(item.Value);
					break;
				case "Changed_Property":
					ChangedProperty(item.Value);
					break;
			}

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
			}
		}

		private void ChangedProperty(TimelineInfo info) {
			if (info == null) {
#if DEBUG
				Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
				return;
			}

			if (info.GetType() == typeof(VideoInfo)) {
				_videoTimeline.Dispatcher.Invoke(_videoTimeline.DelegateChangedTimelineInfoInstance, new object[] { info });
				//     videoTimeline.ChangedTimelineInfo(info);
				/*
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditPlay();
				}
				*/
			} else if (info.GetType() == typeof(SoundInfo)) {
				_soundTimeline.ChangedTimelineInfo(info);
			} else if (info.GetType() == typeof(SubtitleInfo)) {
				_subtitleTimeline.ChangedTimelineInfo(info);
			}
		}

		private void AddInfo(TimelineInfo info) {
			if (info == null) {
#if DEBUG
				Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
				return;
			}

			if (info.GetType() == typeof(VideoInfo)) {
				_videoTimeline.AddTimelineInfo(info);

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.AutoZoom();
				}

			} else if (info.GetType() == typeof(SoundInfo)) {
				_soundTimeline.AddTimelineInfo(info);
			} else if (info.GetType() == typeof(SubtitleInfo)) {
				_subtitleTimeline.AddTimelineInfo(info);
			}
		}

		private void RemoveInfo(TimelineInfo info) {
			if (info.GetType() == typeof(VideoInfo)) {
				_videoTimeline.RemoveTimelineInfo(info.ID);
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditOpen();
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.CheckTimelineInfoCount();
				}
			} else if (info.GetType() == typeof(SoundInfo)) {
				_soundTimeline.RemoveTimelineInfo(info.ID);
			} else if (info.GetType() == typeof(SubtitleInfo)) {
				_subtitleTimeline.RemoveTimelineInfo(info.ID);
			}
		}
	}
}