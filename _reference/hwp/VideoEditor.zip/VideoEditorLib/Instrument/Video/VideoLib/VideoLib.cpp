﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "Debug.h"
#include "VideoLib.h"
#include "VideoInfo.h"
#include "VEFrame.h"

// 생성자
VideoLib::VideoLib(void) {
	static Int isStart = 0;

	if (isStart == 0) {
		avcodec_register_all();
		av_register_all();

		++isStart;
	}

	outputFileInfo = NULL;

	exportInfo.isCancel = FALSE;
	exportInfo.state = ExportNone;
	exportInfo.encodingFrameCount = 0;
	exportInfo.totalFrameCount = 0;

	sws_flags = SWS_BICUBIC;

	outputInfo = NULL;
}

// 소멸자
VideoLib::~VideoLib(void) {
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// 멤버 함수

// 프레임 이동
Int64_t  VideoLib::SeekMs(Int tsms, AVStream* videoStream) {
	Int64_t desiredFrameNumber = av_rescale(tsms, videoStream->time_base.den, videoStream->time_base.num);
	desiredFrameNumber /= 1000;

	return desiredFrameNumber; //SeekFrame(desiredFrameNumber);
}

Int VideoLib::FindFrame(AVFrame* frame, Int width, Int height, Int threshold) {
	Int percent = 0;

	if (frame == NULL) {
		return FAIL;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return FAIL;
	}

	UInt8_t R = 0;
	UInt8_t G = 0;
	UInt8_t B = 0;
	UInt8_t result;

	Int find = 0;

	for (Int y=0; y<height; ++y) {
		for (Int x=0; x<width*3; x += 3) {
			R = *(frame->data[0] + y * frame->linesize[0] + x + 0);
			G = *(frame->data[0] + y * frame->linesize[0] + x + 1);
			B = *(frame->data[0] + y * frame->linesize[0] + x + 2);
			
			result = (R + G + B) / 3;

			if (threshold <= result) {
				++find;
			}
		}
	}

	if (height * width != 0) {
		percent = (Int) (((Double)find / (Double)(height * width) ) * 100.0);
	} else {
		percent = 0;
	}

	return percent;
}


Int VideoLib::GetFrame(const Char* inputFilePath, Frame* output, Int width, Int height) {
	Int frameIndex = 0;  
	Int outputWidth = width;
	Int outputHeight = height;

	Int percent = 20;
	Int threshold = 30;

	frameIndex = 0;

	try {
		Int ret = 0;

		Int find = 0;
		Int findCount = 0;

		AVFrame* frame = NULL;
		AVFrame* frameRGB = NULL;
		UInt8_t* buffer = NULL;

		while (true) {
			AVFormatContext* formatContext = NULL;
			AVStream* videoStream = NULL;
			AVCodecContext* codecContext = NULL;
			AVCodec* codec = NULL;
			
			// 비디오 파일 열기
			if (avformat_open_input(&formatContext, inputFilePath, NULL, NULL) < 0) {
				Debug::Trace("VideoLib::GetFrame 파일을 열지 못하였습니다.");
				return FileOpenFail;
			}

			// 스트림 정보 찾기
			if (avformat_find_stream_info(formatContext, NULL) < 0) {
				Debug::Trace("VideoLib::GetFrame 스트림 정보를 찾지 못하였습니다.");
				return NotFindAllStream;
			}

			// 스트림 중 비디오 타입의 인덱스 찾기
			Int stream_idx = av_find_best_stream(formatContext, AVMEDIA_TYPE_VIDEO, -1, -1, &codec, 0);
			if (stream_idx < 0) {
				Debug::Trace("VideoLib::GetFrame 스트림들 중 비디오 스트림이 존재하지 않습니다.");
				return NotFindVideoStream;
			}

			videoStream = formatContext->streams[stream_idx];
			codecContext = videoStream->codec;

			if (codec == NULL) {
				Debug::Trace("VideoLib::GetFrame 비디오 코덱을 찾지 못하였습니다.");
				return VideoCodecFindFail;
			}

			if ((ret = avcodec_open2(codecContext, codec, NULL)) < 0) {
				Debug::Trace("VideoLib::GetFrame 비디오 코덱을 열지 못하였습니다.");
				return VideoCodecOpenFail;
			}

			av_dump_format(formatContext, 0, inputFilePath, 0);

			frame = avcodec_alloc_frame();
			if (frame == NULL) {
				Debug::Trace("VideoLib::GetFrame 프레임 메모리 할당 실패");
				return FrameAllocFail;
			}

			 //ret = MoveFrame(formatContext, stream_idx, frameIndex);
			ret = MoveFrame3(formatContext, stream_idx, frameIndex);
			if (ret < 0) {
				Debug::Trace("VideoLib::GetFrame 프레임 이동에 실패하였습니다.");
				return FrameSeekMoveFail;
			}

			Int numBytes;
			frameRGB = avcodec_alloc_frame();
			if (frameRGB == NULL) {
				Debug::Trace("VideoLib::GetFrame 프레임 메모리 할당 실패");
				return FrameAllocFail;
			}

			numBytes = avpicture_get_size(PIX_FMT_RGB24, codecContext->width, codecContext->height);
			buffer = new UInt8_t[numBytes];
			if (buffer == NULL) {
				Debug::Trace("VideoLib::GetFrame 메모리 할당 실패");
				return MemoryAllocFail;
			}

			avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, codecContext->width, codecContext->height);

			if (GetVideoFrame(formatContext, codecContext, stream_idx, frame) == 1) {

				if (codecContext->width < outputWidth) {
					outputWidth = codecContext->width;
				}

				if (codecContext->height < outputHeight) {
					outputHeight = codecContext->height;
				}

				struct SwsContext* toRGBContext = sws_getContext(codecContext->width,
																				codecContext->height,
																				codecContext->pix_fmt,
																				outputWidth,
																				outputHeight,
																				PIX_FMT_RGB24,
																				SWS_BICUBIC,
																				NULL,
																				NULL,
																				NULL);

				if (toRGBContext != NULL) {
					sws_scale(toRGBContext, frame->data, frame->linesize, 0, codecContext->height, frameRGB->data, frameRGB->linesize);
					sws_freeContext(toRGBContext);
				} else {
					Debug::Trace("VideoLib::GetFrame toRGBContext를 생성하지 못하였습니다.");
					return GetSwsContextFail;
				}
			} else {
				Debug::Trace("VideoLib::GetFrame 비디오 프레임을 가져오는데 실패 하였습니다.");
				return GetVideoFrameFail;
			}
			
			frameRGB->format = PIX_FMT_RGB24;

			find = FindFrame(frameRGB, outputWidth, outputHeight, threshold);

			if (percent < find) {
				if (NewAVFrameToImage(frameRGB, outputWidth, outputHeight, output) == FAIL) {
					Debug::Trace("VideoLib::GetFrame Frame을 Char*로 변환하는데 실패하였습니다.");
		
					avcodec_close(codecContext);
					av_close_input_file(formatContext);

					return ToImageFail;
				}

				avcodec_close(codecContext);
				av_close_input_file(formatContext);

				break;
			} else {
				Double frameRate = av_q2d(videoStream->r_frame_rate);
				Double runningTime = (Double) videoStream->duration * av_q2d(videoStream->time_base);
				Int64_t totalFrame = Round(runningTime * frameRate);

				if (totalFrame > 2000) {
					frameIndex += 300;
				} else {
					frameIndex += 30;
				}
				
			}

			++findCount;

			if (findCount >= 6) {
				if (NewAVFrameToImage(frameRGB, outputWidth, outputHeight, output) == FAIL) {
					Debug::Trace("VideoLib::GetFrame Frame을 Char*로 변환하는데 실패하였습니다.");
		
					avcodec_close(codecContext);
					av_close_input_file(formatContext);

					return ToImageFail;
				}
	
				avcodec_close(codecContext);
				av_close_input_file(formatContext);

				break;
			}

			avcodec_close(codecContext);
			av_close_input_file(formatContext);

			if (buffer != NULL) {
				delete [] buffer;
			}

			if (frameRGB != NULL) {
				av_free(frameRGB);
			}

			if (frame != NULL) {
				av_free(frame);
			}
		}

		if (buffer != NULL) {
			delete [] buffer;
		}

		if (frameRGB != NULL) {
			av_free(frameRGB);
		}

		if (frame != NULL) {
			av_free(&frame->extended_data);
			av_free(frame);
		}
	} catch(...) {
		Debug::Trace("VideoLib::GetFrame  예외발생!!!");
		return ExceptionCatch;
	}

	return SUCCESS;
}

// 특정 프레임 이미지 가져오기
Int VideoLib::GetFrame(const Char* inputFilePath, Int frameIndex, Frame* output, Int width, Int height) {
	try {
		Int ret = 0;
		AVFormatContext* formatContext = NULL;
		AVStream* videoStream = NULL;
		AVCodecContext* codecContext = NULL;
		AVCodec* codec = NULL;
		
		// 비디오 파일 열기
		if (avformat_open_input(&formatContext, inputFilePath, NULL, NULL) < 0) {
			Debug::Trace("VideoLib::GetFrame 파일을 열지 못하였습니다.");
			return FileOpenFail;
		}

		// 스트림 정보 찾기
		if (avformat_find_stream_info(formatContext, NULL) < 0) {
			Debug::Trace("VideoLib::GetFrame 스트림 정보를 찾지 못하였습니다.");
			return NotFindAllStream;
		}

		// 스트림 중 비디오 타입의 인덱스 찾기
		Int stream_idx = av_find_best_stream(formatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
		if (stream_idx < 0) {
			Debug::Trace("VideoLib::GetFrame 스트림들 중 비디오 스트림이 존재하지 않습니다.");
			return NotFindVideoStream;
		}

		videoStream = formatContext->streams[stream_idx];
		codecContext = videoStream->codec;
		codec = avcodec_find_decoder(codecContext->codec_id);

		if (codec == NULL) {
			Debug::Trace("VideoLib::GetFrame 비디오 코덱을 찾지 못하였습니다.");
			return VideoCodecFindFail;
		}

		if ((ret = avcodec_open2(codecContext, codec, NULL)) < 0) {
			Debug::Trace("VideoLib::GetFrame 비디오 코덱을 열지 못하였습니다.");
			return VideoCodecOpenFail;
		}

		av_dump_format(formatContext, 0, inputFilePath, 0);

		AVFrame* frame;
		frame = avcodec_alloc_frame();

		// output 크기 설정
		if (width <= 0 && height <= 0) {
			width = codecContext->width;
			height = codecContext->height;
		}

		ret = MoveFrame(formatContext, stream_idx, frameIndex);

		if (ret < 0) {
			Debug::Trace("VideoLib::GetFrame 프레임 이동에 실패하였습니다.");
			return FrameSeekMoveFail;
		}

		AVFrame* frameRGB;
		Int numBytes;
		UInt8_t* buffer;

		frameRGB = avcodec_alloc_frame();

		if (frameRGB == NULL) {
			Debug::Trace("VideoLib::GetFrame 프레임 메모리 할당 실패");
			return FrameAllocFail;
		}

		numBytes = avpicture_get_size(PIX_FMT_RGB24, codecContext->width, codecContext->height);
		buffer = new UInt8_t[numBytes];

		if (buffer == NULL) {
			Debug::Trace("VideoLib::GetFrame 메모리 할당 실패");
			return MemoryAllocFail;
		}

		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, codecContext->width, codecContext->height);

		if (GetVideoFrame(formatContext, codecContext, stream_idx, frame) == 1) {
			struct SwsContext* toRGBContext = sws_getContext(codecContext->width,
																			codecContext->height,
																			codecContext->pix_fmt,
																			width,
																			height,
																			PIX_FMT_RGB24,
																			SWS_BICUBIC,
																			NULL,
																			NULL,
																			NULL);

			if (toRGBContext != NULL) {
				sws_scale(toRGBContext, frame->data, frame->linesize, 0, codecContext->height, frameRGB->data, frameRGB->linesize);
				sws_freeContext(toRGBContext);
			} else {
				Debug::Trace("VideoLib::GetFrame toRGBContext를 생성하지 못하였습니다.");
				return GetSwsContextFail;
			}

			if (AVFrameToImage(frameRGB, width, height, output) == FAIL) {
				Debug::Trace("VideoLib::GetFrame Frame을 Char*로 변환하는데 실패하였습니다.");
				return ToImageFail;
			}
		} else {
			Debug::Trace("VideoLib::GetFrame 비디오 프레임을 가져오는데 실패 하였습니다.");
			return GetVideoFrameFail;
		}

		if (buffer != NULL) {
			delete [] buffer;
		}

		if (frameRGB != NULL) {
			av_free(frameRGB);
		}

		if (frame != NULL) {
			av_free(frame);
		}

		avcodec_close(codecContext);
		av_close_input_file(formatContext);
	} catch(...) {
		Debug::Trace("VideoLib::GetFrame  예외발생!!!");
		return ExceptionCatch;
	}

	return SUCCESS;
}

Int64_t VideoLib::SeekMs(AVFormatContext* formatContext, Int streamIndex, Int tsms) {
	Int64_t seek_target = av_rescale(tsms, formatContext->streams[streamIndex]->time_base.den, formatContext->streams[streamIndex]->time_base.num);
	//seek_target /= 1000;

	return seek_target;
}

Int VideoLib::MoveFrame(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex) {
	/*
	Int64_t seek_target = frameIndex;

	AVRational avTimeBaseQ;
	avTimeBaseQ.num = 1;
	avTimeBaseQ.den = AV_TIME_BASE;

	AVRational timebase = formatContext->streams[streamIndex]->time_base;

	seek_target = av_rescale_q(seek_target, timebase, avTimeBaseQ);
	*/

	//return av_seek_frame(formatContext, streamIndex, seek_target, AVSEEK_FLAG_ANY);


	// Int64_t seek_target = SeekMs(formatContext, streamIndex, 20);

	AVStream* videoStream = formatContext->streams[streamIndex];


	Double frameRate = av_q2d(videoStream->r_frame_rate);
	Double runningTime = (Double) videoStream->duration * av_q2d(videoStream->time_base);
	Double totalFrame = runningTime * frameRate;

	Int64_t seek_target = 0;
	if (totalFrame != 0.0) {
		seek_target = (int64_t) (frameIndex * videoStream->duration / totalFrame);
	}

	if (seek_target < 0 || seek_target > videoStream->duration) {
		seek_target = 0;
	}

	/*
	if (seek_target > totalFrame) {
		seek_target = totalFrame;
	}
	*/
	return avformat_seek_file(formatContext, streamIndex, 0, seek_target, seek_target, AVSEEK_FLAG_FRAME);

}

Int64_t VideoLib::FrameCountToMS(AVFormatContext* formatContext, Int64_t frameNumber) {

	frameNumber *= 1000;

	return 0;
}


Int VideoLib::MoveFrame3(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex) {
	/*
	Int64_t seek_target = frameIndex;

	AVRational avTimeBaseQ;
	avTimeBaseQ.num = 1;
	avTimeBaseQ.den = AV_TIME_BASE;

	AVRational timebase = formatContext->streams[streamIndex]->time_base;

	seek_target = av_rescale_q(seek_target, timebase, avTimeBaseQ);
	*/

	//return av_seek_frame(formatContext, streamIndex, seek_target, AVSEEK_FLAG_ANY);


	// Int64_t seek_target = SeekMs(formatContext, streamIndex, 20);
/*
	AVStream* videoStream = formatContext->streams[streamIndex];


	Double frameRate = av_q2d(videoStream->r_frame_rate);
	Double runningTime = (Double) videoStream->duration * av_q2d(videoStream->time_base);
	Double totalFrame = runningTime * frameRate;

	Int64_t seek_target = 0;
	if (totalFrame != 0.0) {
		seek_target = (int64_t) (frameIndex * videoStream->duration / totalFrame);
	}

	if (seek_target < 0 || seek_target > videoStream->duration) {
		seek_target = 0;
	}
	*/

	/*
	if (seek_target > totalFrame) {
		seek_target = totalFrame;
	}
	*/
	// return avformat_seek_file(formatContext, streamIndex, 0, seek_target, seek_target, AVSEEK_FLAG_FRAME);

	Int64_t duration = formatContext->duration * 1000 / AV_TIME_BASE;
	/*
	Int64_t seek_target = frameIndex - 5 * 30;

	if (seek_target < 0) {
		seek_target = 0;
	}

	if (seek_target > duration) {
		seek_target = duration;
	}

	AVStream* videoStream = formatContext->streams[streamIndex];

	
	AVCodecContext* codecVideoContext = videoStream->codec;
	int ret = avformat_seek_file(formatContext, streamIndex, 0, frameIndex, duration, AVSEEK_FLAG_FRAME);

	while(seek_target < frameIndex) {

		AVFrame* frame = avcodec_alloc_frame();
		Int state = PrevFrame(formatContext, codecVideoContext, streamIndex, frame);

		if (state == -1) {
			exportInfo.state = ExportFail;
			return GetDecodeVideoFrameFail;
		} else if(state == 0) {
			break;
		}

		int64_t ms = videoStream->cur_dts * av_q2d(videoStream->time_base) * 1000;

		seek_target = ms * 1000 * 30;

		av_free(&frame->extended_data);
		av_free(frame);
	}

	return 0;
*/




	return avformat_seek_file(formatContext, streamIndex, 0, frameIndex, duration, AVSEEK_FLAG_FRAME);
}

Int VideoLib::MoveFrame2(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex) {
	Int64_t minIndex = frameIndex - 500;
	if (minIndex < 0) {
		minIndex = 0;
	}

	Int64_t maxIndex = frameIndex + 500;

	if (maxIndex > formatContext->streams[streamIndex]->duration) {
		maxIndex = formatContext->streams[streamIndex]->duration;
	}

	return avformat_seek_file(formatContext, streamIndex, minIndex, frameIndex, maxIndex, AVSEEK_FLAG_FRAME);
}

Int VideoLib::SaveFrame(const Char* outputFileName, AVFrame* frame, enum PixelFormat fmt, Int width, Int height, Int64_t index) {
	AVFrame* frameRGB;
	Int numBytes;
	UInt8_t* buffer = NULL;

	if (fmt != PIX_FMT_RGB24) {
		frameRGB = avcodec_alloc_frame();

		if (frameRGB == NULL) {
			return FrameAllocFail;
		}

		numBytes = avpicture_get_size(PIX_FMT_RGB24, width, height);

		if (numBytes <= 0) {
			return GetSizeFail;
		}

		buffer = new UInt8_t[numBytes];
		if( buffer == NULL) {
			return MemoryAllocFail;
		}

		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, width, height);

		struct SwsContext* toRGBContext = sws_getContext(width,
														 height,
														 fmt,
														 width,
														 height,
														 PIX_FMT_RGB24,
														 SWS_BICUBIC,
														 NULL,
														 NULL,
														 NULL);

		if (toRGBContext != NULL) {
			sws_scale(toRGBContext, frame->data, frame->linesize, 0, height, frameRGB->data, frameRGB->linesize);
		} else {
		}
	} else {
		frameRGB = frame;
	}

	FILE* pFile = NULL;
	Char filePath[MAX_FILEPATH];
	Int y;

	sprintf_s(filePath, MAX_FILEPATH, outputFileName, index);
	if (fopen_s(&pFile, filePath, "wb") != 0) {
		Debug::Trace("VideoLib::SaveFrame 파일 포인터를 가져오지 못하였습니다.");
		return FileOpenFail;
	}

	fprintf(pFile, "P6\n%d %d\n255\n", width, height);

	for (y=0; y<height; ++y) {
		fwrite(frameRGB->data[0] + y * frameRGB->linesize[0], 1, width*3, pFile);
	}

	fclose(pFile);

	return SUCCESS;
}

Bool VideoLib::SetVideoFrame(Int64_t dts, AVFormatContext* formatContext, AVStream* stream, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* inputFrame) {
	Int ret;
	Int got_output;
	
    AVPacket pkt;
	av_new_packet(&pkt, 1200*1000);

    av_init_packet(&pkt);
    pkt.data = NULL;
    pkt.size = 0;
	
	static Int64_t frameDts = 0;

	while (avcodec_encode_video2(codecContext, &pkt, inputFrame, &got_output) >= 0) {
		if (got_output) {
			if (codecContext->coded_frame->pts != AV_NOPTS_VALUE) {
				pkt.pts = av_rescale_q(codecContext->coded_frame->pts, codecContext->time_base, stream->time_base);
			}

			if (codecContext->coded_frame->key_frame) {
				pkt.flags |= AV_PKT_FLAG_KEY;
			}

			pkt.stream_index = videoStreamIndex;

			ret = av_write_frame(formatContext, &pkt);
			break;
		} 
	}

	return SUCCESS;
}

// 특정 프레임 가져오기
Int VideoLib::PrevFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame) {
	AVPacket packet;
	Int frameFinished = 0;

//	av_init_packet(&packet);

	while (true) {
		if (av_read_frame(formatContext, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  프레임을 가져오지 못하였습니다.");
				return 0;
		}

		if (packet.stream_index == videoStreamIndex) {
			if (avcodec_decode_video2(codecContext, outputFrame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				break;
			}
		} else {
			av_free_packet(&packet);
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

Int VideoLib::GetNextFrame(AVFormatContext* formatContext, AVCodecContext* codecVideoContext, AVCodecContext* codecAudioContext, 
						   Int videoStreamIndex, Int audioStreamIndex) {
	AVPacket packet;
	Int frameFinished = 0;

//	av_init_packet(&packet);

	while (true) {
		if (av_read_frame(formatContext, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  프레임을 가져오지 못하였습니다.");
				return 0;
		}

		if (packet.stream_index == videoStreamIndex) {
			if (avcodec_decode_video2(codecVideoContext, outputInfo->frame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				outputInfo->streamIndex = videoStreamIndex;
				break;
			}
		} else if (packet.stream_index == audioStreamIndex) {
			if (avcodec_decode_audio4(codecAudioContext, outputInfo->frame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				outputInfo->streamIndex = audioStreamIndex;
				break;
			}
		} else {
			av_free_packet(&packet);
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

Int VideoLib::GetBothFrame(AVFormatContext* formatContext, AVCodecContext* codecVideoContext, AVCodecContext* codecAudioContext, 
						   Int videoStreamIndex, Int audioStreamIndex, OutputFrame* outputFrame)
{
	AVPacket packet;
	Int frameFinished = 0;

//	av_init_packet(&packet);

	while (true) {
		if (av_read_frame(formatContext, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  프레임을 가져오지 못하였습니다.");
				return 0;
		}

		if (packet.stream_index == videoStreamIndex) {
			if (avcodec_decode_video2(codecVideoContext, outputFrame->frame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				outputFrame->streamIndex = videoStreamIndex;
				break;
			}
		} else if (packet.stream_index == audioStreamIndex) {
			if (avcodec_decode_audio4(codecAudioContext, outputFrame->frame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				outputFrame->streamIndex = audioStreamIndex;
				break;
			}
		} else {
			av_free_packet(&packet);
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

Int VideoLib::GetVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame)
{
	AVPacket packet;
	Int frameFinished = 0;

//	av_init_packet(&packet);

	while (true) {
		if (av_read_frame(formatContext, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  프레임을 가져오지 못하였습니다.");
				return 0;
		}

		if (packet.stream_index == videoStreamIndex) {
			if (avcodec_decode_video2(codecContext, outputFrame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetVideoFrame  비디오 디코딩 정보를 가져오지 못하였습니다.");
				return -1;
			}

			if (frameFinished != 0) {
				break;
			}
		} else {
			av_free_packet(&packet);
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

void VideoLib::ClearImage(Frame* image) {
	if (image == NULL) {
		return;
	}

	if (image->pixel == NULL) {
		return;
	}

	for (Int i=0; i<image->height; ++i) {
		if (image->pixel[i] == NULL) {
			continue;
		}

		delete [] *(image->pixel+i);
	}

	delete [] image->pixel;
}

// AVFrame을 RGB Image 형태로 변환
Int VideoLib::NewAVFrameToImage(AVFrame* frame, Int width, Int height, Frame* output) {
	
	output->height = height;
	output->width = width;

	output->pixel = 0;
	output->pixel = new UInt8_t* [height];

	if (output->pixel == 0) {
		return FAIL;
	}

	for (Int i=0; i<height; ++i) {
		output->pixel[i] = 0;
		output->pixel[i] = new UInt8_t[width*3];

		if (output->pixel[i] == 0) {
			return FAIL;
		}
	}
	
	UInt8_t* inputImage = frame->data[0];
	UInt8_t* outputImage = output->pixel[0];

	Int size = frame->linesize[0];

	for (Int y=0; y<height; ++y) {
		memcpy(output->pixel[y], frame->data[0] + y * frame->linesize[0], width*3);
	}

	return SUCCESS;
}

// AVFrame을 RGB Image 형태로 변환
Int VideoLib::AVFrameToImage(AVFrame* frame, Int width, Int height, Frame* output) {
	
	output->height = height;
	output->width = width;

	//output->pixel = new UInt8_t* [height];
	output->pixel = 0;
	output->pixel = (UInt8_t**) malloc(sizeof(UInt8_t*)*height);

	if (output->pixel == 0) {
		return FAIL;
	}

	for (Int i=0; i<height; ++i) {
		output->pixel[i] = 0;
		output->pixel[i] = (UInt8_t*) malloc(sizeof(UInt8_t)*width*3);

		if (output->pixel[i] == 0) {
			return FAIL;
		}
	}
	
	UInt8_t* inputImage = frame->data[0];
	UInt8_t* outputImage = output->pixel[0];

	Int size = frame->linesize[0];

	for (Int y=0; y<height; ++y) {
		memcpy(output->pixel[y], frame->data[0] + y * frame->linesize[0], width*3);
	}

	return SUCCESS;
}

Double VideoLib::GetEstimateTime(const Char* inputFilePath, Int width, Int height) {
	try {
		Debug::Start();

		Frame output;
		output.pixel = 0;
		output.height = 0;
		output.width = 0;
		GetFrame(inputFilePath, 10, &output, width, height);

		Debug::End();
		ClearImage(&output);

		double sec = Debug::ResultPerSEC();
		return sec;

	} catch (...) {
		Debug::Trace("VideoLib::GetEstimateTime 예외발생!!!");
		return ExceptionCatch;
	}

	return -1.0;
}

Int VideoLib::GetVideoInfo(const Char* inputFilePath, VideoInfoStruct* info) {
	try {
		VideoInfo videoInfo(inputFilePath);
		if (videoInfo.GetVideoInfo(info) == false) {
			return FileOpenFail;
		}
	} catch(...) {
		Debug::Trace("VideoLib::GetVideoInfo 예외발생!!!");
		return ExceptionCatch;
	}

	return SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// 비디오 편집 관련 함수

// 비디오 편집 시작(무조건 새로 시작)
void VideoLib::NewTimeline() {
	Int size = timelineInfoList.size();

	for(Int i=0; i<size; ++i) {
		delete timelineInfoList[i];
	}

	timelineInfoList.clear();

	DeleteOutputfileInfo();

	exportInfo.isCancel = FALSE;
	exportInfo.state = ExportNone;
	exportInfo.encodingFrameCount = 0;
	exportInfo.totalFrameCount = 0;
}

void VideoLib::DeleteTimeline() {
	Int size = timelineInfoList.size();

	for(Int i=0; i<size; ++i) {
		delete timelineInfoList[i];
	}

	timelineInfoList.clear();
}

Int VideoLib::AddTimelineInfo(Char* filePath, Effect enumEffect, Int startFrame, Int endFrame) {
	TimelineInfo* info = NULL;
	info = new TimelineInfo(filePath, enumEffect, startFrame, endFrame);

	if (info == NULL) {
		return TimelineInfoAllocFail;
	}

	return AddTimelineInfo(info);
}

Int VideoLib::AddTimelineInfo(TimelineInfo* info) {
	if (info == NULL) {
		return TimelineInfoAllocFail;
	}

	if (info->emptyFrame == true) {
		// 빈 프레임일 경우
		timelineInfoList.push_back(info);
	} else {
		try {
			Int ret = 0;

			// 변환 할 비디오 파일 열기
			if (avformat_open_input(&info->inputFormatContext, info->filePath, NULL, NULL) < 0) {
				Debug::Trace("VideoLib::AddTimelineInfo 비디오 파일을 열지 못하였습니다.");
				return FileOpenFail;
			}

			// 스트림 정보 찾기
			if (avformat_find_stream_info(info->inputFormatContext, NULL) < 0) {
				Debug::Trace("VideoLib::AddTimelineInfo 스트림 정보를 찾지 못하였습니다.");
				return NotFindAllStream;
			}

			// 비디오 타입 스트림의 인덱스 찾기
			AVCodec* videoDecoderCodec = NULL;

			info->videoStreamIndex = av_find_best_stream(info->inputFormatContext, AVMEDIA_TYPE_VIDEO, -1, -1, &videoDecoderCodec, 0);
			if (info->videoStreamIndex < 0) {
				Debug::Trace("VideoLib::AddTimelineInfo 스트림 정보 중 비디오 스트림이 존재하지 않습니다.");
				return NotFindVideoStream;
			}

			// video decoder Codec 찾기
			info->inputVideoCodecContext = info->inputFormatContext->streams[info->videoStreamIndex]->codec;

			if (videoDecoderCodec == NULL) {
				Debug::Trace("VideoLib::GetFrame 비디오 코덱을 찾지 못하였습니다.");
				return VideoCodecFindFail;
			}

			if ((ret = avcodec_open2(info->inputVideoCodecContext, videoDecoderCodec, NULL)) < 0) {
				Debug::Trace("VideoLib::AddTimelineInfo 비디오 디코더 코덱을 열지 못하였습니다.");
				return VideoCodecOpenFail;
			}

			AVCodec* audioDecoderCodec = NULL;

			info->audioStreamIndex = av_find_best_stream(info->inputFormatContext, AVMEDIA_TYPE_AUDIO, -1, -1, &audioDecoderCodec, 0);

			if (info->audioStreamIndex >= 0) {
				// audio decoder Codec 찾기
				info->inputAudioCodecContext = info->inputFormatContext->streams[info->audioStreamIndex]->codec;

				if (audioDecoderCodec != NULL) {
					if ((ret = avcodec_open2(info->inputAudioCodecContext, audioDecoderCodec, NULL)) < 0) {
						audioDecoderCodec = NULL;
					}
				} else {
					audioDecoderCodec = NULL;
				}
			} else {
				audioDecoderCodec = NULL;
			}

			if (audioDecoderCodec == NULL) {
				if (info->inputAudioCodecContext != NULL) {
					avcodec_close(info->inputAudioCodecContext);
				}

				info->audioStreamIndex = -1;
			}

			info->timebase = info->inputFormatContext->streams[info->videoStreamIndex]->r_frame_rate;
			Double framerate = av_q2d(info->inputFormatContext->streams[info->videoStreamIndex]->r_frame_rate);

			info->frameRate = (int) (framerate + 0.5);

			// 시작 위치가 0보다 작을 경우 값 보정
			if (info->startFrame < 0) {
				info->startFrame = 0;
				info->lengthFrame = info->endFrame - info->startFrame;
			}

			// 끝 위치가 전체 프레임 보다 클 경우 값 보정
			Int64_t totalFrame = (Int64_t) GetTotalFrame(info->inputFormatContext->streams[info->videoStreamIndex]) - 1;
			if (info->endFrame > totalFrame) {
				info->endFrame = totalFrame;
				info->lengthFrame = info->endFrame - info->startFrame;
			}

			Int64_t realTotalFrame = 0;
			Double temp = 0.0;

			if (info->inputFormatContext->streams[info->videoStreamIndex]->time_base.den != 0) {
				temp = (Double) info->inputFormatContext->streams[info->videoStreamIndex]->time_base.num / 
					   (Double) info->inputFormatContext->streams[info->videoStreamIndex]->time_base.den;
			}

			Double runningTime = (Double) info->inputFormatContext->streams[info->videoStreamIndex]->duration * temp;
			realTotalFrame = (int64_t) (runningTime * 30.0);

			int gap = 0;
			if (totalFrame > 0) {
				gap = (int) (realTotalFrame / totalFrame);
			}

			if (gap > 1) {
				info->loop = gap;
			}

			if (info->inputVideoCodecContext->codec_id == AV_CODEC_ID_MSMPEG4V2) {
				info->isMSCodec = true;
				//info->loop = 6;
			}

			timelineInfoList.push_back(info);
		} catch(...) {
			Debug::Trace("VideoLib::AddTimelineInfo 예외가 발생하였습니다.");
			return ExceptionCatch;
		}
	}

	return SUCCESS;
}

Int64_t VideoLib::GetTotalFrame(AVStream* videoStream) {
	Double frameRate = 0.0;

	if (videoStream->r_frame_rate.den != 0) {
		frameRate = (Double) videoStream->r_frame_rate.num / (Double) videoStream->r_frame_rate.den;
	}

	Double temp = 0.0;

	if (videoStream->time_base.den != 0) {
		temp = (Double) videoStream->time_base.num / (Double) videoStream->time_base.den;
	}

	Double runningTime = (Double) videoStream->duration * temp;
	Int time = Round(runningTime);

	return Round(((Double) time * frameRate));
	
//	return videoStream->duration / av_q2d(videoStream->r_frame_rate);
}

Int ANSIToUTF8(Char* ansiString, Char* utf8String) {
	WCHAR unicode[100] = {0,};
	Char utf8[100] = {0,};

	Int unicodeSize = MultiByteToWideChar(CP_ACP, 0, ansiString, strlen(ansiString), unicode, sizeof(unicode));

	Int utf8CodeSize = WideCharToMultiByte(CP_UTF8, 0, unicode, unicodeSize, utf8String, sizeof(unicode), NULL, NULL);

	MultiByteToWideChar(CP_UTF8, 0, utf8, utf8CodeSize, unicode, sizeof(unicode));

	return utf8CodeSize;
}

Int UTF8ToANSI(Char* utf8String, Char* ansiString) {
	WCHAR unicode[100] = {0,};
	Char utf8[100] = {0,};

	Int unicodeSize = MultiByteToWideChar(CP_UTF8, 0, utf8String, strlen(utf8String), unicode, sizeof(unicode));
	Int utf8CodeSize = WideCharToMultiByte(CP_ACP, 0, unicode, -1, NULL, NULL, NULL, NULL);
	Int ansiCodeSize = WideCharToMultiByte(CP_ACP, 0, unicode, -1, ansiString, utf8CodeSize, NULL, NULL);

	return ansiCodeSize;
}

// 생성
Int VideoLib::CreateOutputfileInfo(const Char* outputFilePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID) {
	if (videoCodecID == AV_CODEC_ID_NONE && audioCodecID == AV_CODEC_ID_NONE) {
		return FileOpenFail;
	}

	Int size = timelineInfoList.size();

	if (size <= 0) {
		return FileOpenFail;
	}

	Int orignalFrameRate = timelineInfoList[0]->frameRate;
	TimelineInfo* timelineInfo;
	
	if (timelineInfoList[0]->inputAudioCodecContext != NULL) {
		timelineInfo = timelineInfoList[0];
	} else {
		timelineInfo = NULL;
	}

	Int sameFrameRate = 1;
	for (Int i=1; i<size; ++i) {
		if (orignalFrameRate != timelineInfoList[i]->frameRate) {
			timelineInfo = NULL;
			sameFrameRate = 0;
			break;
		} else {
			if (timelineInfoList[i]->inputAudioCodecContext != NULL) {
				timelineInfo = timelineInfoList[i];
			}
		}
	}

	if (sameFrameRate == 1) {
		frameRate = orignalFrameRate;
		outputFileInfo = new OutputFileInfo(outputFilePath, width, height, frameRate, videoCodecID, audioCodecID, timelineInfo);
	} else {
		timelineInfo = NULL;
		outputFileInfo = new OutputFileInfo(outputFilePath, width, height, frameRate, videoCodecID, audioCodecID);
	}

	if (outputFileInfo != NULL) {
		if (outputFileInfo->IsOpened() != 1) {
			Debug::Trace("VideoLib::CreateOutputfileInfo OutputFileInfo를 생성하지 못하였습니다.");
			delete outputFileInfo;
			outputFileInfo = NULL;
			return outputFileInfo->IsOpened();
		}
	} else {
		Debug::Trace("VideoLib::CreateOutputfileInfo OutputFileInfo를 생성하지 못하였습니다.");
		return MemoryAllocFail;
	}

	return SUCCESS;
}

Int VideoLib::DeleteOutputfileInfo() {
	if (outputFileInfo == NULL) {
		Debug::Trace("VideoLib::DeleteOutputfileInfo OutputFileInfo가 NULL 입니다.");
		return MemoryAllocFail;
	} else {
		delete outputFileInfo;
		outputFileInfo = NULL;
	}

	return SUCCESS;
}

Int VideoLib::SetFrameRate(AVCodecContext* outputCodecContext, Int frameRate) {
	if (outputCodecContext == NULL) {
		Debug::Trace("VideoLib::SetFrameRate outputCodecContext이 NULL이 들어왔습니다.");
		return NullPointInput;
	}

	outputCodecContext->time_base.num = 1;
	outputCodecContext->time_base.den = frameRate;

	return SUCCESS;
}

ExportInfo VideoLib::GetExportInfo() {
	return exportInfo;
}

bool VideoLib::GetExportIsCancel() {
	return exportInfo.isCancel;
}

void VideoLib::SetExportIsCancel(bool isCancel) {
	exportInfo.isCancel = isCancel;
}

Int VideoLib::GetExportState() {
	return exportInfo.state;
}

void VideoLib::SetExportState(Int state) {
	exportInfo.state = (ExportState) state;
}

Int VideoLib::GetExportProgress() {
	Int per = 0;

	if (exportInfo.state == ExportNone) {
		per = 0;
	} else {
		if (exportInfo.totalFrameCount <= 0 || exportInfo.encodingFrameCount <= 0) {
			per = 0;
		} else {
			if (exportInfo.totalFrameCount != 0) {
				per = (Int) (((Double)exportInfo.encodingFrameCount / (Double)exportInfo.totalFrameCount) * 100);
			} else {
				per = 0;
			}
		}
	}

	if (per < 0) {
		per = 0;
	} else if (per > 100) {
		per = 100;
	}

	return per;
}

Int VideoLib::Export(const Char* inputFilePath, const Char* outputFilePath) {
	Int ret;
	Int videoStreamIndex = -1;

	AVFormatContext* inputFormatContext = NULL;
	AVCodecContext* inputCodecContext = NULL;
	AVCodec* decoderCodec = NULL;

	Int videoStreamIndex2 = -1;
	AVFormatContext* inputFormatContext2 = NULL;
	AVCodecContext* inputCodecContext2 = NULL;
	AVCodec* decoderCodec2 = NULL;

	AVFormatContext* outputFormatContext = NULL;
	AVCodecContext* outputCodecContext = NULL;
	AVCodec* encoderCodec = NULL;

	// 변환 할 비디오 파일 열기
	if (avformat_open_input(&inputFormatContext, inputFilePath, NULL, NULL) < 0) {
		Debug::Trace("VideoLib::Export 비디오 파일을 열지 못하였습니다.");
		return FAIL;
	}

	// 스트림 정보 찾기
	if (avformat_find_stream_info(inputFormatContext, NULL) < 0) {
		Debug::Trace("VideoLib::Export 스트림 정보를 찾지 못하였습니다.");
		return FAIL;
	}

	// 비디오 타입 스트림의 인덱스 찾기
	videoStreamIndex = av_find_best_stream(inputFormatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (videoStreamIndex < 0) {
		Debug::Trace("VideoLib::Export 스트림 정보 중 비디오 스트림이 존재하지 않습니다.");
		return FAIL;
	}

	// decoder Codec 찾기
	AVStream* videoStream = inputFormatContext->streams[videoStreamIndex];
	inputCodecContext = videoStream->codec;
	decoderCodec = avcodec_find_decoder(inputCodecContext->codec_id);

	if (decoderCodec == NULL) {
		Debug::Trace("VideoLib::Export 디코더 코덱을 찾지 못하였습니다.");
		return FAIL;
	}

	if ((ret = avcodec_open2(inputCodecContext, decoderCodec, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 디코더 코덱을 열지 못하였습니다.");
		return FAIL;
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 변환 할 비디오 파일 열기
	// 수정 해야 함!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	if (avformat_open_input(&inputFormatContext2, inputFilePath, NULL, NULL) < 0) {
		Debug::Trace("VideoLib::Export 비디오 파일을 열지 못하였습니다. 수정해야함 패스박았음");
		return FAIL;
	}

	// 스트림 정보 찾기
	if (avformat_find_stream_info(inputFormatContext2, NULL) < 0) {
		Debug::Trace("VideoLib::Export 스트림 정보를 찾지 못하였습니다.");
		return FAIL;
	}

	// 비디오 타입 스트림의 인덱스 찾기
	videoStreamIndex2 = av_find_best_stream(inputFormatContext2, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (videoStreamIndex2 < 0) {
		Debug::Trace("VideoLib::Export 스트림 정보 중 비디오 스트림을 찾지 못하였습니다.");
		return FAIL;
	}

	// decoder Codec 찾기
	AVStream* videoStream2 = inputFormatContext2->streams[videoStreamIndex2];
	inputCodecContext2 = videoStream2->codec;
	decoderCodec2 = avcodec_find_decoder(inputCodecContext2->codec_id);

	if (decoderCodec2 == NULL) {
		Debug::Trace("VideoLib::Export 디코더 코덱을 찾지 못하였습니다.");
		return FAIL;
	}

	if ((ret = avcodec_open2(inputCodecContext2, decoderCodec2, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 디코더 코덱을 열지 못하였습니다.");
		return FAIL;
	}

	// 쓰기 할 코덱 찾기
	encoderCodec = avcodec_find_encoder(inputCodecContext->codec_id);
	if (encoderCodec == NULL) {
		Debug::Trace("VideoLib::Export 인코더 코덱을 찾지 못하였습니다.");
		return FAIL;
	}

	if ((ret = avformat_alloc_output_context2(&outputFormatContext, NULL, "avi", outputFilePath)) < 0) {
		Debug::Trace("VideoLib::Export context를 할당하지 못하였습니다.");
		return FAIL;
	}

	if (outputFormatContext == NULL) {
		Debug::Trace("VideoLib::Export 파일명이 잘못되어 context를 생성하지 못하였습니다.");
		return FAIL;
	}
	
	// 쓰기 할 파일 정보 세팅
	outputFormatContext->oformat->audio_codec = CODEC_ID_NONE;
	outputFormatContext->oformat->video_codec = inputCodecContext->codec_id;
	outputFormatContext->audio_codec_id = CODEC_ID_NONE;
	outputFormatContext->video_codec_id = inputCodecContext->codec_id;
	outputFormatContext->duration = inputFormatContext->duration;
		
	AVStream* stream = avformat_new_stream(outputFormatContext, encoderCodec);
	
    AVCodecContext* c = avcodec_alloc_context3(encoderCodec);

	outputCodecContext = stream->codec;
	outputCodecContext->pix_fmt = inputCodecContext->pix_fmt;

	outputCodecContext->width = inputCodecContext->width;
	outputCodecContext->height = inputCodecContext->height;

	Int width = 320;
	Int height = 240;

    outputCodecContext->bit_rate = 400000;
	AVRational temp;
	temp.num = 1;
	temp.den = 30;
    outputCodecContext->time_base= temp;
    outputCodecContext->gop_size = 10;
    outputCodecContext->max_b_frames=1;

	// 프레임 속도 설정
	SetFrameRate(outputCodecContext, 30);

	if (outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
		outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	// 쓰기할 파일 열기
	if ((ret = avcodec_open2(outputCodecContext, encoderCodec, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 인코더 코덱을 열지 못하였습니다.");
		return FAIL;
	}
	
	if ((ret = avio_open(&(outputFormatContext->pb), outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
		Debug::Trace("VideoLib::Export avio_open을 하지 못하였습니다.");
		return FAIL;
	}

	if ((ret = avformat_write_header(outputFormatContext, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 비디오 헤더를 작성하지 못하였습니다.");
		return FAIL;
	}
	
	AVPacket packet;
	av_init_packet(&packet);

	Int64_t frameCount = 0;
	Int64_t frameDts = 0;

	do {
		if (NULL != packet.data) {
			av_free_packet(&packet);
			packet.data = NULL;
		}

		if (frameCount < 100) {
			// 읽기
			if (av_read_frame(inputFormatContext, &packet) < 0 ) {
				break;
			}
		} else if (frameCount == 100) {
			avcodec_close(inputCodecContext);
			avio_close(inputFormatContext->pb);
			inputFormatContext->pb = NULL;
			avformat_close_input(&inputFormatContext);

			av_init_packet(&packet);
			if (NULL != packet.data) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// 읽기
			if ((ret = av_read_frame(inputFormatContext2, &packet)) < 0 ) {
				break;
			}
		} else {
			// 읽기
			if ((ret = av_read_frame(inputFormatContext2, &packet)) < 0 ) {
				break;
			}
		}
		
		// 쓰기
		if (packet.stream_index == videoStreamIndex) {
			packet.dts = frameDts;

			ret = av_write_frame(outputFormatContext, &packet);

			++frameCount;
			++frameDts;
		} else {
			if (frameCount == 100) {
				++frameCount;
				frameDts += 100;
			}
		}

		if (frameCount > 1000) {
			break;
		}

	} while (true);

	av_write_trailer(outputFormatContext);

	avcodec_close(outputCodecContext);
	avio_close(outputFormatContext->pb);
	outputFormatContext->pb = NULL;
	avformat_free_context(outputFormatContext);

	avcodec_close(inputCodecContext2);
	avio_close(inputFormatContext2->pb);
	inputFormatContext2->pb = NULL;
	avformat_close_input(&inputFormatContext2);

	if (packet.data != NULL) {
		av_free_packet(&packet);
		packet.data = NULL;
	}

	return SUCCESS;
}

Int VideoLib::InitExportEx(AVStream* videoStream, AVStream* audioStream) {
	if (outputInfo != NULL) {
		if (outputInfo->frame != NULL) {
			av_free(outputInfo->frame);
		}

		delete outputInfo;
		outputInfo = NULL;
	}

	outputInfo = new OutputInfo();

	if (outputInfo == NULL) {
		return -1;
	}

	outputInfo->frame = NULL;
	outputInfo->frameCount = 0;
	outputInfo->videoPts = 0;
	outputInfo->audioPts = 0;
	outputInfo->isVideoOpen = false;
	outputInfo->isAudioOpen = false;

	if (videoStream != NULL) {
		outputInfo->isVideoOpen = true;
	}

	if (audioStream != NULL) {
		outputInfo->isAudioOpen = true;
	}

	outputInfo->frame = avcodec_alloc_frame();
	if (outputInfo->frame == NULL) {
		if (outputInfo != NULL) {
			delete outputInfo;
			outputInfo = NULL;
		}

		return -1;
	}

	// 비디오 관련 설정
	/*
	if (videoStream != NULL) {
		if (outputVideoInfo != NULL) {
			delete outputVideoInfo;
			outputVideoInfo = NULL;
		}

		outputVideoInfo = new OutputVideoInfo();

		if (outputVideoInfo == NULL) {
			return -1;
		}

		AVCodecContext* videoCodecContext = videoStream->codec;

		// 비디오 초기 설정
		outputVideoInfo->frame = avcodec_alloc_frame();
		if (!outputVideoInfo->frame) {
			if (outputVideoInfo != NULL) {
				delete outputVideoInfo;
				outputVideoInfo = NULL;
			}

			if (outputAudioInfo != NULL) {
				delete outputAudioInfo;
				outputAudioInfo = NULL;
			}
			return -1;
		}

		int ret;
		ret = avpicture_alloc(&outputVideoInfo->dstPicture, videoCodecContext->pix_fmt, videoCodecContext->width, videoCodecContext->height);
		if (ret<0) {
			if (outputVideoInfo != NULL) {
				delete outputVideoInfo;
				outputVideoInfo = NULL;
			}
			return -1;
		}
		
		if (videoCodecContext->pix_fmt !=  PIX_FMT_YUV420P) {
			ret = avpicture_alloc(&outputVideoInfo->srcPicture, PIX_FMT_YUV420P, videoCodecContext->width, videoCodecContext->height);

			if (ret<0) {
				if (outputVideoInfo != NULL) {
					delete outputVideoInfo;
					outputVideoInfo = NULL;
				}
				return -1;
			}
		}

		*((AVPicture *)outputVideoInfo->frame) = outputVideoInfo->dstPicture;
	}

	// 오디오 관련 설정
	if (audioStream != NULL) {
		AVCodecContext* audioCodecContext = audioStream->codec;

		if (outputAudioInfo != NULL) {
			delete outputAudioInfo;
			outputAudioInfo = NULL;
		}

		outputAudioInfo = new OutputAudioInfo();

		if (outputAudioInfo == NULL) {
			return -1;
		}

		// 오디오 초기 설정
		outputAudioInfo->t = 0;
		outputAudioInfo->tincr = 2 *  (float)M_PI * (float)110.0 / audioCodecContext->sample_rate;
		outputAudioInfo->tincr2 = 2 * (float)M_PI * (float)110.0 / audioCodecContext->sample_rate / audioCodecContext->sample_rate;

		if (audioCodecContext->codec-> capabilities & CODEC_CAP_VARIABLE_FRAME_SIZE) {
			outputAudioInfo->audioInputFrameSize = 10000;
		} else {
			outputAudioInfo->audioInputFrameSize = audioCodecContext->frame_size;
		}

		outputAudioInfo->samples = (int16_t*) av_malloc(outputAudioInfo->audioInputFrameSize * av_get_bytes_per_sample(audioCodecContext->sample_fmt) * audioCodecContext->channels);

		if (!outputAudioInfo->samples) {
			return -1;
		}
	}
	*/

	return SUCCESS;
}

Int VideoLib::GetDecodeFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* videoStream, AVStream* audioStream, int64_t audioPts) {
	static struct SwsContext* sws_ctx;

	AVCodecContext* codecVideoContext = NULL;
	AVCodecContext* codecAudioContext = NULL;

	if (videoStream != NULL) {
		codecVideoContext = videoStream->codec;
	}

	if (audioStream != NULL) {
		codecAudioContext = audioStream->codec;
	}

	outputInfo->streamIndex = -1;

	for(;;) {
		Int state = GetNextFrame(timelineInfoList[timelineInfoIndex]->inputFormatContext, timelineInfoList[timelineInfoIndex]->inputVideoCodecContext, timelineInfoList[timelineInfoIndex]->inputAudioCodecContext,
						timelineInfoList[timelineInfoIndex]->videoStreamIndex, timelineInfoList[timelineInfoIndex]->audioStreamIndex);

		if (state == -1) {
			exportInfo.state = ExportFail;
			return GetDecodeVideoFrameFail;
		} else if(state == 0) {
			if (timelineInfoList[timelineInfoIndex]->emptyFrame == true) {
				av_free(outputInfo->frame->data[0]);
			} else {
				av_free(&outputInfo->frame->extended_data);
			}

			//av_free(outputInfo->frame);
			return -2;
		}

		if (outputInfo->streamIndex == -1) {
			continue;
		} else if (outputInfo->streamIndex == timelineInfoList[timelineInfoIndex]->audioStreamIndex) {
			break;
		} else if (outputInfo->streamIndex == timelineInfoList[timelineInfoIndex]->videoStreamIndex) {
			outputInfo->frame->pts = outputInfo->videoPts;
			break;
		}
	}

	return SUCCESS;
}

Int VideoLib::WriteAudioFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* audioStream, int64_t audioPts, AVFrame* decodeFrame) {
	if (audioStream == NULL) {
		return -1;
	}

	if (outputInfo->streamIndex != timelineInfoList[timelineInfoIndex]->audioStreamIndex) {
		return -1;
	}

	int ret;
	AVCodecContext* codecAudioContext = audioStream->codec;

	AVFrame* tempFrame = NULL;
	tempFrame = avcodec_alloc_frame();

	avcodec_get_frame_defaults(tempFrame);
	
	tempFrame->nb_samples = codecAudioContext->frame_size;

	avcodec_fill_audio_frame(tempFrame, codecAudioContext->channels, codecAudioContext->sample_fmt,
		( uint8_t *)outputInfo->frame->data[0],
		outputInfo->frame->nb_samples *
		av_get_bytes_per_sample(codecAudioContext->sample_fmt) *
		codecAudioContext->channels, 1);

	AVPacket packet = { 0 };
	int got_packet;
	av_init_packet(&packet);

	ret = avcodec_encode_audio2(codecAudioContext, &packet, tempFrame, &got_packet);

	av_free(tempFrame);

	if (ret<0) {
		return -1;
	}

	if (!ret && got_packet && packet.size) {
		packet.stream_index = audioStream->index;
		ret = av_interleaved_write_frame(formatContext, &packet);
	} else {
		ret = 0;
	}

	return SUCCESS;
}

Int VideoLib::WriteVideoFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* videoStream, AVFrame* decodeFrame) {
	if (videoStream == NULL) {
		return -1;
	}

	if (outputInfo->streamIndex != timelineInfoList[timelineInfoIndex]->videoStreamIndex) {
		return -1;
	}

	int ret;
	AVCodecContext* codecVideoContext = videoStream->codec;

	AVPacket packet = { 0 };
	int got_packet;
	av_init_packet(&packet);

	ret = avcodec_encode_video2(codecVideoContext, &packet, decodeFrame, &got_packet);
	if (ret<0) {
		return -1;
	}

	if (!ret && got_packet && packet.size) {
		packet.stream_index = videoStream->index;
		ret = av_interleaved_write_frame(formatContext, &packet);
	} else {
		ret = 0;
	}

	++(outputInfo->frameCount);
	return SUCCESS;
}

Int VideoLib::WriteVideoFrame2(AVFormatContext* formatContext, AVStream* videoStream, AVStream* audioStream, int64_t audioPts) {
	/*
	int ret;
	static struct SwsContext* sws_ctx;

	AVCodecContext* codecVideoContext = NULL;
	AVCodecContext* codecAudioContext = NULL;

	if (videoStream != NULL) {
		codecVideoContext = videoStream->codec;
	}

	if (audioStream != NULL) {
		codecAudioContext = audioStream->codec;
	}

	OutputFrame outputFrame;
	outputFrame.streamIndex = -1;
	outputFrame.frame = outputInfo->frame;

	for(;;) {
		Int state = GetBothFrame(timelineInfoList[0]->inputFormatContext, timelineInfoList[0]->inputVideoCodecContext, timelineInfoList[0]->inputAudioCodecContext,
						timelineInfoList[0]->videoStreamIndex, timelineInfoList[0]->audioStreamIndex, &outputFrame);

		if (state == -1) {
			exportInfo.state = ExportFail;
			return GetDecodeVideoFrameFail;
		} else if(state == 0) {
			if (timelineInfoList[0]->emptyFrame == true) {
				av_free(outputInfo->frame->data[0]);
			} else {
				av_free(&outputInfo->frame->extended_data);
			}

			av_free(outputInfo->frame);
			return -2;
		}

		if (outputFrame.streamIndex == -1) {
			continue;
		} else if (outputFrame.streamIndex == timelineInfoList[0]->audioStreamIndex) {
			break;
		} else if (outputFrame.streamIndex == timelineInfoList[0]->videoStreamIndex) {
			outputInfo->frame->pts = outputInfo->videoPts;
			break;
		}

		// Int state = GetVideoFrame(timelineInfoList[0]->inputFormatContext, timelineInfoList[0]->inputVideoCodecContext, timelineInfoList[0]->videoStreamIndex, outputVideoInfo->frame);

		if (state == -1) {
			exportInfo.state = ExportFail;
			return GetDecodeVideoFrameFail;
		} else if(state == 0) {
			if (timelineInfoList[0]->emptyFrame == true) {
				av_free(outputInfo->frame->data[0]);
			} else {
				av_free(&outputInfo->frame->extended_data);
			}

			av_free(outputInfo->frame);
			return -2;
		}

		outputInfo->frame->pts = outputInfo->videoPts;
	}
	//outputVideoInfo->frame->pts = outputVideoInfo->frameCount;
	// (stream->time_base.num / stream->time_base.den) * outputVideoInfo->frame->sample_rate * outputVideoInfo->frameCount;
	*/

	int ret = 1;

	AVCodecContext* codecVideoContext = NULL;
	AVCodecContext* codecAudioContext = NULL;

	if (videoStream != NULL) {
		codecVideoContext = videoStream->codec;
	}

	if (audioStream != NULL) {
		codecAudioContext = audioStream->codec;
	}

	if (outputInfo->streamIndex == -1) {
		return -1;
	}

	if (outputInfo->streamIndex == timelineInfoList[0]->videoStreamIndex) {
		if (videoStream == NULL) {
			return 10;
		}

		AVPacket packet = { 0 };
		int got_packet;
		av_init_packet(&packet);

		ret =  avcodec_encode_video2(codecVideoContext, &packet, outputInfo->frame, &got_packet);
		if (ret<0) {
			return -1;
		}

		if (!ret && got_packet && packet.size) {
			packet.stream_index = videoStream->index;
			ret = av_interleaved_write_frame(formatContext, &packet);
		} else {
			ret = 0;
		}

		++(outputInfo->frameCount);
		return 10;
	} else if (outputInfo->streamIndex == timelineInfoList[0]->audioStreamIndex) {
		if (audioStream == NULL) {
			return 20;
		}

		AVFrame* tempFrame = NULL;
		tempFrame = avcodec_alloc_frame();

		avcodec_get_frame_defaults(tempFrame);
		
		tempFrame->nb_samples = codecAudioContext->frame_size;

		avcodec_fill_audio_frame(tempFrame, codecAudioContext->channels, codecAudioContext->sample_fmt,
			( uint8_t *)outputInfo->frame->data[0],
			outputInfo->frame->nb_samples *
			av_get_bytes_per_sample(codecAudioContext->sample_fmt) *
			codecAudioContext->channels, 1);

		//tempFrame->pts = audioPts;

		AVPacket packet = { 0 };
		int got_packet;
		av_init_packet(&packet);

		ret = avcodec_encode_audio2(codecAudioContext, &packet, tempFrame, &got_packet);

		av_free(tempFrame);

		if (ret<0) {
			return -1;
		}

		if (!ret && got_packet && packet.size) {
			packet.stream_index = audioStream->index;
			ret = av_interleaved_write_frame(formatContext, &packet);
		} else {
			ret = 0;
		}

		return 20;
	}

	if (ret != 0) {
		char buf[255];
		av_strerror(ret, buf, 255);
		printf("%s\n", buf);
		return -1;
	}

	return SUCCESS;
}

Int VideoLib::WriteAudioFrame(AVFormatContext* formatContext, AVStream* stream) {
/*
	AVPacket packet = { 0 };
	AVFrame* frame =  avcodec_alloc_frame();

	Int ret;
	Int gotPacket;
	av_init_packet(&packet);

	AVCodecContext* codecContext = stream->codec;
	
	GetDecodeAudioFrame(outputAudioInfo->samples, outputAudioInfo->audioInputFrameSize, codecContext->channels);
	frame->nb_samples = outputAudioInfo->audioInputFrameSize;

	avcodec_fill_audio_frame(frame, codecContext->channels, codecContext->sample_fmt, (uint8_t*)outputAudioInfo->samples,
		outputAudioInfo->audioInputFrameSize * av_get_bytes_per_sample(codecContext->sample_fmt) * codecContext->channels, 1);

	ret = avcodec_encode_audio2(codecContext, &packet, frame, &gotPacket);

	if (ret < 0) {
		return -1;
	}

	if (!gotPacket) {
		return 1;
	}

	packet.stream_index = stream->index;

	ret = av_interleaved_write_frame(formatContext, &packet);

	if (ret != 0) {
		return -1;
	}

	av_free(&frame);
*/
	return SUCCESS;
}

Int VideoLib::ExportEx() {
	if (timelineInfoList.size() == 0) {
		return EmptyTimelineInfo;
	}

	if (outputFileInfo == NULL) {
		return NotOutputFileInfo;
	}

	Int ret = 0;

	Double audio_pts;
	Double video_pts;

	if (InitExportEx(outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream()) == -1) {
		return -1;
	}

	Int size = timelineInfoList.size();

	exportInfo.isCancel = FALSE;
	exportInfo.state = ExportStart;
	exportInfo.encodingFrameCount = 0;

	static int64_t audioPts = 0;

	Int i;
	for (i=0; i<size; ++i) {
		exportInfo.totalFrameCount += timelineInfoList[i]->lengthFrame;
	}

	for (i=0; i<size; ++i) {
		ret = 0;
		Int64_t infoFrameCount = 0;

		if (timelineInfoList[i]->emptyFrame != true) {
			if (timelineInfoList[i]->startFrame != 0) {
				ret = MoveFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->videoStreamIndex, timelineInfoList[i]->startFrame);

				if (ret < 0) {
					exportInfo.state = ExportFail;
					return FrameSeekMoveFail;
				}
				avcodec_flush_buffers(timelineInfoList[i]->inputVideoCodecContext);
			}

			/*
			Debug::Start();
			Int64_t frameIndex = 0;
			while(frameIndex != timelineInfoList[i]->startFrame) {
				AVFrame* frame = avcodec_alloc_frame();
				//if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				Int state = PrevFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputVideoCodecContext, timelineInfoList[i]->videoStreamIndex, frame);
				// Int state = GetVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame);
				if (state == -1) {
					exportInfo.state = ExportFail;
					return GetDecodeVideoFrameFail;
				} else if(state == 0) {
					break;
				}

				++frameIndex;
				av_free(&frame->extended_data);
				av_free(frame);
			}
			Debug::End();
			clock_t time = Debug::Result();
			*/
		}

		exportInfo.state = ExportEncoding;

		while (timelineInfoList[i]->lengthFrame >= infoFrameCount) {
			if (exportInfo.isCancel == TRUE) {
				break;
			}

			if (outputFileInfo->GetAudioStream()) {
				audio_pts = (double)outputFileInfo->GetAudioStream()-> pts.val * outputFileInfo->GetAudioStream()-> time_base.num / outputFileInfo->GetAudioStream()->time_base.den;
			} else {
				audio_pts = 0.0;
			}

			if (outputFileInfo->GetVideoStream()) {
				video_pts = (double)outputFileInfo->GetVideoStream()->pts.val * outputFileInfo->GetVideoStream()->time_base.num / outputFileInfo->GetVideoStream()->time_base.den;
			} else {
				video_pts = 0.0;
			}

			int ret = GetDecodeFrame(i, outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);

			if (ret == -2) {
				break;
			}

			if (ret != SUCCESS) {
				continue;
			}

			if (outputInfo->streamIndex == -1) {
				continue;
			}

			if (outputInfo->streamIndex == timelineInfoList[i]->videoStreamIndex) {
				for (int cnt =0; cnt<timelineInfoList[i]->loop; ++cnt) {
					if (outputFileInfo->GetVideoStream() != NULL) {
						VEFrame veFrame(outputInfo->frame, timelineInfoList[i]->inputVideoCodecContext->pix_fmt);
						if (i == 0 && infoFrameCount < 60) {
							veFrame.SetFadeInFadeOut(-1, timelineInfoList[i]->lengthFrame);
						} else {
							veFrame.SetFadeInFadeOut(infoFrameCount, timelineInfoList[i]->lengthFrame);
						}
						veFrame.SetEffect(timelineInfoList[i]->enumEffect);
						veFrame.SetSize(outputFileInfo->GetWidth(), outputFileInfo->GetHeight());
						veFrame.ApplyFrame();

						ret = WriteVideoFrame(i, outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), veFrame.GetFrame());
						outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
						outputInfo->frame->pts = outputInfo->videoPts;
					}
				}

				++infoFrameCount;
				++(exportInfo.encodingFrameCount);
				

			} else if (outputInfo->streamIndex == timelineInfoList[i]->audioStreamIndex) {
				if (outputFileInfo->GetAudioStream() != NULL) {
					ret = WriteAudioFrame(i, outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetAudioStream(), audioPts, outputInfo->frame);
					//audioPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
					//audioPts = (double)outputFileInfo->GetAudioStream()-> pts.val * outputFileInfo->GetAudioStream()-> time_base.num / outputFileInfo->GetAudioStream()->time_base.den;
				}
			}

			if (ret == -2) {
				outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, 
															 outputFileInfo->GetVideoStream()->time_base);

				// outputVideoInfo->videoPts += av_rescale_q(1, timebase1, timebase2);

				outputInfo->frame->pts = outputInfo->videoPts;
				break;
			}
		}
	}
/*
	const char* filename = outputFileInfo->GetFilePath();

	if (outputInfo->frame) {
		outputInfo->frame->pts = 0;
	}

	outputInfo->videoPts = 0;

	static int64_t audioPts = 0;

	for (;;) {
		if (outputFileInfo->GetAudioStream()) {
			audio_pts = (double)outputFileInfo->GetAudioStream()-> pts.val * outputFileInfo->GetAudioStream()-> time_base.num / outputFileInfo->GetAudioStream()->time_base.den;
		} else {
			audio_pts = 0.0;
		}

		if (outputFileInfo->GetVideoStream()) {
			video_pts = (double)outputFileInfo->GetVideoStream()->pts.val * outputFileInfo->GetVideoStream()->time_base.num / outputFileInfo->GetVideoStream()->time_base.den;
		} else {
			video_pts = 0.0;
		}

		if ((!outputFileInfo->GetAudioStream() || audio_pts >=  STREAM_DURATION) &&
			(!outputFileInfo->GetVideoStream() || video_pts >= STREAM_DURATION)) {
			break;
		}

		if (!outputFileInfo->GetVideoStream() || (outputFileInfo->GetVideoStream() && outputFileInfo->GetAudioStream() && audio_pts<video_pts)) {
			//WriteAudioFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetAudioStream());

			int ret = GetDecodeFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);

			if (ret == -2) {
				break;
			}

			if (ret != SUCCESS) {
				continue;
			}

			if (outputInfo->streamIndex == -1) {
				continue;
			}

			if (outputInfo->streamIndex == timelineInfoList[0]->videoStreamIndex) {
				if (outputFileInfo->GetVideoStream() != NULL) {
					ret = WriteVideoFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);
					outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
					outputInfo->frame->pts = outputInfo->videoPts;
				}
			} else if (outputInfo->streamIndex == timelineInfoList[0]->audioStreamIndex) {
				if (outputFileInfo->GetAudioStream() != NULL) {
					ret = WriteAudioFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);
					audioPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
				}
			}

			if (ret == -2) {
				outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, 
															 outputFileInfo->GetVideoStream()->time_base);

				// outputVideoInfo->videoPts += av_rescale_q(1, timebase1, timebase2);

				outputInfo->frame->pts = outputInfo->videoPts;
				break;
			}
		} else {

			int ret = GetDecodeFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);

			if (ret != SUCCESS) {
				continue;
			}

			if (outputInfo->streamIndex == -1) {
				continue;
			}

			if (outputInfo->streamIndex == timelineInfoList[0]->videoStreamIndex) {
				if (outputFileInfo->GetVideoStream() != NULL) {
					ret = WriteVideoFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);
					outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
					outputInfo->frame->pts = outputInfo->videoPts;
				}
			} else if (outputInfo->streamIndex == timelineInfoList[0]->audioStreamIndex) {
				if (outputFileInfo->GetAudioStream() != NULL) {
					ret = WriteAudioFrame(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream(), outputFileInfo->GetAudioStream(), audioPts);
					audioPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, outputFileInfo->GetVideoStream()->time_base);
				}
			}

			if (ret == -2) {
				outputInfo->videoPts += av_rescale_q(1, outputFileInfo->GetVideoStream()->codec->time_base, 
															 outputFileInfo->GetVideoStream()->time_base);

				// outputVideoInfo->videoPts += av_rescale_q(1, timebase1, timebase2);

				outputInfo->frame->pts = outputInfo->videoPts;
				break;
			}
		}
	}
*/
	if (exportInfo.isCancel == TRUE) {
		exportInfo.state = ExportCancel;
		return CANCEL;
	}

	ret = av_write_trailer(outputFileInfo->GetOutputFormatContext());
	if (ret != 0) {
		return WriteTrailerFail;
	}

	exportInfo.state = ExportSuccess;
	/*
	if (outputFileInfo->GetVideoStream()) {
		CloseVideo(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetVideoStream());
	}

	if (outputFileInfo->GetAudioStream()) {
		CloseAudio(outputFileInfo->GetOutputFormatContext(), outputFileInfo->GetAudioStream());
	}
	*/
	return SUCCESS;
}

Bool VideoLib::CloseVideo(AVFormatContext* formatContext, AVStream* stream) {
	if (formatContext == NULL || stream == NULL) {
		return false;
	}

	if (outputInfo == NULL) {
		return false;
	}

	avcodec_close(stream->codec);

	//av_free(outputVideoInfo->srcPicture.data[0]);
	//av_free(outputVideoInfo->dstPicture.data[0]);

	av_free(outputInfo->frame);

	return true;
}

Bool VideoLib::CloseAudio(AVFormatContext* formatContext, AVStream* stream) {
	/*
	if (formatContext == NULL || stream == NULL) {
		return false;
	}

	if (outputAudioInfo == NULL) {
		return false;
	}

	avcodec_close(stream->codec);
	av_free(outputAudioInfo->samples);
	*/

	return true;
}

Int VideoLib::FillYuvImage(AVPicture *pict, int frame_index, int width, int height) {
	int x,  y, i;
	i = frame_index;
	/* Y */
	for (y = 0; y <height; y++) {
		for (x = 0; x <width; x++) {
			pict-> data[0][y * pict-> linesize[0] + x] = x + y + i * 3;
		}
	}

	/* Cb and Cr */
	for (y = 0; y <height / 2; y++) {
		for (x = 0; x <width / 2; x++) {
			pict->data[1][y * pict->linesize[1] + x] = 128 + y + i * 2;
			pict->data[2][y * pict->linesize[2] + x] = 64 + x + i * 5;
		}
	}

	return SUCCESS;
}

Int VideoLib::Export() {
	if (timelineInfoList.size() == 0) {
		return EmptyTimelineInfo;
	}

	if (outputFileInfo == NULL) {
		return NotOutputFileInfo;
	}

	Int ret = 0;

	Int size = timelineInfoList.size();

	exportInfo.state = ExportStart;
	exportInfo.encodingFrameCount = 0;

	Int i;
	for (i=0; i<size; ++i) {
		exportInfo.totalFrameCount += timelineInfoList[i]->lengthFrame;
	}
	
	for (i=0; i<size; ++i) {
		ret = 0;

		AVPacket packet;
		av_init_packet(&packet);

		Int64_t infoFrameCount = 0;

		if (timelineInfoList[i]->emptyFrame != true) {
			
			//ret = MoveFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->videoStreamIndex, timelineInfoList[i]->startFrame);

			//if (ret < 0) {
			//	exportInfo.state = ExportFail;
			//	return FrameSeekMoveFail;
			//}

			Int64_t frameIndex = 0;

			Debug::Start();
			while(frameIndex != timelineInfoList[i]->startFrame) {
				AVFrame* frame = avcodec_alloc_frame();
				//if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				Int state = PrevFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputVideoCodecContext, timelineInfoList[i]->videoStreamIndex, frame);
				// Int state = GetVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame);
				if (state == -1) {
					exportInfo.state = ExportFail;
					return GetDecodeVideoFrameFail;
				} else if(state == 0) {
					break;
				}

				++frameIndex;
				av_free(&frame->extended_data);
				av_free(frame);
			}
			avcodec_flush_buffers(timelineInfoList[i]->inputVideoCodecContext);
			Debug::End();

			clock_t time = Debug::Result();
		}

		exportInfo.state = ExportEncoding;

		while (timelineInfoList[i]->lengthFrame >= infoFrameCount) {
			if (packet.data != NULL) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// read를 해서 packet를 가져오는데 한개 프레임에 대한 packet를 다 받으면
			// bitmap으로 변환
			// bitmap 변환 후 이미지 효과 및 자막을 넣고
			// 해당 bitmap을 다시 packet으로 변환 
			// 변환된 packet를 하나씩 Write
			AVFrame* frame = avcodec_alloc_frame();

			if (timelineInfoList[i]->emptyFrame == true) {
				
				av_image_alloc(frame->data, frame->linesize, outputFileInfo->GetWidth(), outputFileInfo->GetHeight(), PIX_FMT_YUV420P, 1);

				Int x;
				Int y;

				// yCbCr을 검은색으로 설정

				// y
				for(y=0;y<outputFileInfo->GetHeight();y++) {
					for(x=0;x<outputFileInfo->GetWidth();x++) {
						frame->data[0][y * frame->linesize[0] + x] = 16;
					}
				}

				// Cb  Cr
				for(y=0;y<outputFileInfo->GetHeight()/2;y++) {
					for(x=0;x<outputFileInfo->GetWidth()/2;x++) {
						frame->data[1][y * frame->linesize[1] + x] = 128;
						frame->data[2][y * frame->linesize[2] + x] = 128;
					}
				}
			} else {
				//if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				Int state = GetVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputVideoCodecContext, timelineInfoList[i]->videoStreamIndex, frame);
				if (state == -1) {
					exportInfo.state = ExportFail;
					return GetDecodeVideoFrameFail;
				} else if(state == 0) {
					if (timelineInfoList[i]->emptyFrame == true) {
						av_free(frame->data[0]);
					} else {
						av_free(&frame->extended_data);
					}

					av_free(frame);
					break;
				}


			}

			//frame->pts = exportInfo.encodingFrameCount;
			VEFrame veFrame(frame, timelineInfoList[i]->inputVideoCodecContext->pix_fmt);

			if (i == 0 && infoFrameCount < 60) {
				veFrame.SetFadeInFadeOut(-1, timelineInfoList[i]->lengthFrame);
			} else {
				veFrame.SetFadeInFadeOut(infoFrameCount, timelineInfoList[i]->lengthFrame);
			}
			veFrame.SetEffect(timelineInfoList[i]->enumEffect);
			veFrame.SetSize(outputFileInfo->GetWidth(), outputFileInfo->GetHeight());
			veFrame.ApplyFrame();

			Int maxCount = 1;
			if (timelineInfoList[i]->isMSCodec == true) {
				maxCount = 6;
			}

			for (Int maxIndex=0; maxIndex<maxCount; ++maxIndex) {
				AVPacket encodePacket;
				av_init_packet(&encodePacket);

				if (GetEncodeVideoFrame(outputFileInfo->GetOutputCodecContext(), veFrame.GetFrame(), &encodePacket, outputFileInfo->GetVideoStreamIndex()) == false) {
					av_free_packet(&encodePacket);
					continue;
				}

				AVRational inputTimebase;
				Double framerate = av_q2d(timelineInfoList[i]->timebase);
				inputTimebase.num = 1;
				inputTimebase.den = Round(framerate);

				if (encodePacket.pts != AV_NOPTS_VALUE) {
					encodePacket.pts = av_rescale_q(encodePacket.pts, inputTimebase, outputFileInfo->GetTimebase());
				}

				if (encodePacket.dts != AV_NOPTS_VALUE) {
					encodePacket.dts = av_rescale_q(encodePacket.dts, inputTimebase, outputFileInfo->GetTimebase());
				}

				ret = av_interleaved_write_frame(outputFileInfo->GetOutputFormatContext(), &encodePacket);
				av_free_packet(&encodePacket);
				// av_write_frame(outputFileInfo->GetOutputFormatContext(), &encodePacket);

				/*
				AVPacket encodeAudioPacket;
				av_init_packet(&encodeAudioPacket);

				AVFrame* audioFrame = avcodec_alloc_frame();

				AudioStruct* audioStruct = outputFileInfo->GetAudioStruct();
				if (audioStruct != NULL) {
					GetDecodeAudioFrame(audioStruct->samples, outputFileInfo->GetOutputAudioCodecContext(), audioStruct);

					avcodec_fill_audio_frame(audioFrame, outputFileInfo->GetOutputAudioCodecContext()->channels, outputFileInfo->GetOutputAudioCodecContext()->sample_fmt,
						(uint8_t *)audioStruct->samples, audioStruct->audio_input_frame_size * av_get_bytes_per_sample(outputFileInfo->GetOutputAudioCodecContext()->sample_fmt) *
						outputFileInfo->GetOutputAudioCodecContext()->channels, 1);

					GetEncodeAudioFrame(outputFileInfo->GetOutputAudioCodecContext(), audioFrame, &encodeAudioPacket, outputFileInfo->GetAudioStreamIndex());
					ret = av_interleaved_write_frame(outputFileInfo->GetOutputFormatContext(), &encodeAudioPacket);
				}

				av_free_packet(&encodeAudioPacket);

				if (audioFrame != NULL) {
					av_free(audioFrame);
				}
				*/
			}

			++infoFrameCount;
			++(exportInfo.encodingFrameCount);

			if (timelineInfoList[i]->emptyFrame == true) {
				av_free(frame->data[0]);
			} else {
				av_free(&frame->extended_data);
			}

			//av_free(frame);
			// avcodec_free_frame(&frame);
		}

		if (packet.data != NULL) {
			av_free_packet(&packet);
			packet.data = NULL;
		}
	}
	
	ret = av_write_frame(outputFileInfo->GetOutputFormatContext(), NULL);

	if (ret <= 0) {
		return WriteFrameFail;
	}

	ret = av_write_trailer(outputFileInfo->GetOutputFormatContext());

	if (ret != 0) {
		return WriteTrailerFail;
	}

	exportInfo.state = ExportSuccess;

	return SUCCESS;
}


Int VideoLib::Export(const Char* outputFilePath) {

	if (timelineInfoList.size() == 0) {
		return FAIL;
	}

	Int ret;

	AVFormatContext* outputFormatContext = NULL;
	AVCodecContext* outputCodecContext = NULL;
	AVCodec* outputCodec = NULL;

	// 쓰기 할 코덱 찾기
	outputCodec = avcodec_find_encoder(AV_CODEC_ID_H264);
	if (outputCodec == NULL) {
		Debug::Trace("VideoLib::Export 인코딩 코덱을 찾지 못하였습니다.");
		return FAIL;
	}

	AVOutputFormat* ouputFormat = av_guess_format(NULL, outputFilePath, NULL);

	if ((ret = avformat_alloc_output_context2(&outputFormatContext, ouputFormat, NULL, outputFilePath)) < 0) {
		Debug::Trace("VideoLib::Export context를 생성하지 못하였습니다.");
		return FAIL;
	}

	if (outputFormatContext == NULL) {
		Debug::Trace("VideoLib::Export 파일 이름이 잘못되었습니다.");
		return FAIL;
	}
	
	// 쓰기 할 파일 정보 세팅 - 첫번째 파일로 하지 않고 설정되로 변경
	// 코덱들 테스트
	outputFormatContext->oformat->audio_codec = CODEC_ID_NONE;
	outputFormatContext->audio_codec_id = CODEC_ID_NONE;

	outputFormatContext->oformat->video_codec = timelineInfoList[0]->inputVideoCodecContext->codec_id;
	outputFormatContext->video_codec_id = timelineInfoList[0]->inputVideoCodecContext->codec_id;
//	outputFormatContext->duration = timelineInfoList[0]->inputFormatContext->duration;
	
//	av_dict_copy(&(outputFormatContext->metadata), inputFormatContext->metadata, 0);
//	av_dict_set(&(outputFormatContext->metadata), "Author", "VPI", 0 );
	
	AVStream* stream = avformat_new_stream(outputFormatContext, outputCodec);
	outputCodecContext = stream->codec;
	
	// outputCodecContext = avcodec_alloc_context3(outputCodec);
	
//	outputCodecContext->pkt_timebase = stream->codec->pkt_timebase;
	// avcodec_copy_context( outputCodecContext, inputCodecContext );
	outputCodecContext->pix_fmt = timelineInfoList[0]->inputVideoCodecContext->pix_fmt;

	outputCodecContext->width = 1920;// timelineInfoList[0]->inputCodecContext->width;
	outputCodecContext->height = 1080;// timelineInfoList[0]->inputCodecContext->height;

	// put sample parameters
	outputCodecContext->bit_rate = outputCodecContext->width * outputCodecContext->height * 4;
	// resolution must be a multiple of two
	//c->width = 352;
	//c->height = 288;
	// frames per second
	
	AVRational temp;
	temp.num = 1;
	temp.den = 30;
	outputCodecContext->time_base= temp;
	outputCodecContext->gop_size = 10; // emit one intra frame every ten frames
	outputCodecContext->max_b_frames=1;

	/*
	outputCodecContext->bit_rate = inputCodecContext->bit_rate;
	outputCodecContext->bit_rate_tolerance = inputCodecContext->bit_rate_tolerance;
	outputCodecContext->qmax = inputCodecContext->qmax;
	outputCodecContext->qmin = inputCodecContext->qmin;	
	*/

	// 프레임 속도 설정
	SetFrameRate(outputCodecContext, 30);

	// videoStream->r_frame_rate.num / (Double) videoStream->r_frame_rate.den;

	if (outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
		outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	// 쓰기할 파일 열기
	if ((ret = avcodec_open2(outputCodecContext, outputCodec, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 코덱을 열지 못하였습니다.");
		return FAIL;
	}
	
	if ((ret = avio_open(&(outputFormatContext->pb), outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
		Debug::Trace("VideoLib::Export avio_open을 하지 못하였습니다.");
		return FAIL;
	}

	if ((ret = avformat_write_header(outputFormatContext, NULL)) < 0) {
		Debug::Trace("VideoLib::Export 동영상 헤더를 작성하지 못하였습니다.");
		return FAIL;
	}

	/*
	// outputFileInfo가 활당되었는지 확인
	if (outputFileInfo == NULL) {
		return FAILED;
	}

	// outputFileInfo의 쓰기 정보가 저장된 outputFormatContext가 제대로 생성되었는지 확인
	if (outputFileInfo->outputFormatContext == NULL) {
		return FAILED;
	}
	*/


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 쓰기
	Int64_t frameCount = 0;
	Int64_t frameDts = 0;

	Int size = timelineInfoList.size();
	for (Int i=0; i<size; ++i) {
		AVPacket packet;
		av_init_packet(&packet);

		Int64_t selectInfoFrameCount = 0;

		while (true) {
			if (packet.data != NULL) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// read를 해서 packet를 가져오는데 한개 프레임에 대한 packet를 다 받으면
			// bitmap으로 변환
			// bitmap 변환 후 이미지 효과 및 자막을 넣고
			// 해당 bitmap을 다시 packet으로 변환 
			// 변환된 packet를 하나씩 Write

			
			AVFrame* frame = avcodec_alloc_frame();

			if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputVideoCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				return false;
			}

			VEFrame veFrame(frame, timelineInfoList[i]->inputVideoCodecContext->pix_fmt);

	//		++frameCount;
	//		++frameDts;


			if (timelineInfoList[i]->startFrame <= selectInfoFrameCount && timelineInfoList[i]->endFrame >= selectInfoFrameCount) {

				veFrame.SetEffect(enumYellow);
				veFrame.SetSize(1920, 1080);
				veFrame.ApplyFrame();
				
				/*
				AVFrame* resizeFrame2 = NULL;
				ResizeFrame(&resizeFrame2, 320, 240, PIX_FMT_RGB24, 
								frame, timelineInfoList[i]->inputCodecContext->width, timelineInfoList[i]->inputCodecContext->height, timelineInfoList[i]->inputCodecContext->pix_fmt);

				ApplyEffect(resizeFrame2);

				AVFrame* resizeFrame = NULL;
				ResizeFrame(&resizeFrame, 320, 240, PIX_FMT_YUV420P, 
								resizeFrame2, resizeFrame2->width, resizeFrame2->height, PIX_FMT_RGB24);
				*/

				AVPacket encodePacket;
				av_init_packet(&encodePacket);

				/* // 지금
				if (GetEncodeVideoFrame(outputCodecContext, resizeFrame, &encodePacket) == false) {
					av_free_packet(&encodePacket);
					continue;
				}
				*/
				if (GetEncodeVideoFrame(outputCodecContext, veFrame.GetFrame(), &encodePacket, outputFileInfo->GetVideoStreamIndex()) == false) {
					av_free_packet(&encodePacket);
					continue;
				}

				//	ret = av_interleaved_write_frame(outputFormatContext, &encodePacket);

				encodePacket.dts = frameDts;
				ret = av_write_frame(outputFormatContext, &encodePacket);
				++frameCount;
				++frameDts;


				//	ret = av_write_frame(outputFormatContext, &encodePacket);

		//		av_free(resizeFrame);
				av_free_packet(&encodePacket);
			}

			if (timelineInfoList[i]->endFrame < selectInfoFrameCount) {
	//			av_free(frame);
				break;
			}
			++selectInfoFrameCount;
		}

/*
		do {
			if (NULL != packet.data) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// read를 해서 packet를 가져오는데 한개 프레임에 대한 packet를 다 받으면
			// bitmap으로 변환
			// bitmap 변환 후 이미지 효과 및 자막을 넣고
			// 해당 bitmap을 다시 packet으로 변환 
			// 변환된 packet를 하나씩 Write
			AVFrame* frame = avcodec_alloc_frame();
			

			if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				return false;
			}

			AVPacket encodePacket;
			av_init_packet(&encodePacket);

			if (GetEncodeVideoFrame(outputFormatContext, frame, encodePacket) == false) {
				return false;
			}

			ret = av_write_frame(outputFormatContext, &encodePacket);
			++frameCount;
			++frameDts;


			if (av_read_frame(timelineInfoList[i]->inputFormatContext, &packet) < 0 ) {
				break;
			}

			if (packet.stream_index == timelineInfoList[i]->videoStreamIndex) {

				AVFrame* frame;
				frame = avcodec_alloc_frame();

				Int frameFinished = 0;
				Int got_output;

				
				if (avcodec_decode_video2(timelineInfoList[i]->inputCodecContext, frame, &frameFinished, &packet) < 0) {
					Debug::Trace("VideoLib::Export 디코딩 프레임을 가져오지 못하였습니다.");
					return false;
				}

				if (frameFinished == 0) {
					av_free_packet(&packet);
					continue;
				}

				Int po = avcodec_encode_video2(outputCodecContext, &packet, frame, &got_output);




				if (got_output) {
					if (timelineInfoList[i]->startFrame <= infoFrameCount && timelineInfoList[i]->endFrame >= infoFrameCount) {
						packet.dts = frameDts;
						ret = av_write_frame(outputFormatContext, &packet);
						++frameCount;
						++frameDts;
					}

					++infoFrameCount;
				}

				if (timelineInfoList[i]->endFrame < infoFrameCount) {
					av_free(frame);
					break;
				}

				//++infoFrameCount;
				av_free_packet(&packet);
		//		av_free(frame);
			}
		} while (true);
		*/

		if (packet.data != NULL) {
			av_free_packet(&packet);
			packet.data = NULL;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 완료
	av_write_frame(outputFormatContext, NULL);
	av_write_trailer(outputFormatContext);

	avcodec_close(outputCodecContext);
	avio_close(outputFormatContext->pb);
	outputFormatContext->pb = NULL;
	avformat_free_context(outputFormatContext);

	return SUCCESS;
}

Bool VideoLib::GetDecodeVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame)
{
	AVPacket packet;
	Int frameFinished = 0;

	av_init_packet(&packet);

	while (av_read_frame(formatContext, &packet) >= 0) {
		if (packet.stream_index == videoStreamIndex) {
			if (avcodec_decode_video2(codecContext, outputFrame, &frameFinished, &packet) < 0) {
				Debug::Trace("VideoLib::GetDecodeVideoFrame 디코딩 프레임을 가져오지 못하였습니다.");
				return false;
			}

			if (frameFinished != 0) {
				break;
			}
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

Bool VideoLib::GetEncodeVideoFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet, int streamIndex) {

	Int gotOutput;

	
	//AVPacket pkt;
//	av_new_packet(packet, 1200*1000);
//	av_init_packet(packet);
//	pkt.data = NULL;    // packet data will be allocated by the encoder
//	pkt.size = 0;

	while (avcodec_encode_video2(codecContext, packet, frame, &gotOutput) >= 0) {
		if (gotOutput) {
			if (codecContext->coded_frame->pts != AV_NOPTS_VALUE) {
			//	packet->pts = av_rescale_q(codecContext->coded_frame->pts, codecContext->time_base, stream->time_base);
			}

			if (codecContext->coded_frame->key_frame) {
				packet->flags |= AV_PKT_FLAG_KEY;
			}

			packet->stream_index = streamIndex;
			return true;
		}
	}
	
/*
	while (true) {
		if (packet->data != NULL) {
			av_free_packet(packet);
			packet->data = NULL;

			av_new_packet(packet, 1200*1000);
			av_init_packet(packet);
		}

		Int ret = avcodec_encode_video2(codecContext, packet, frame, &gotOutput);

		if (ret != 0) {
			Int result = 0;
			result = 1;
		}

		if (gotOutput) {
			if (codecContext->coded_frame->pts != AV_NOPTS_VALUE) {
			//	packet->pts = av_rescale_q(codecContext->coded_frame->pts, codecContext->time_base, stream->time_base);
			}

			if (codecContext->coded_frame->key_frame) {
				packet->flags |= AV_PKT_FLAG_KEY;
			}
			return true;
		}
	}
	*/

	return false;
/*
	while (true) {
		if (packet->data != NULL) {
			av_free_packet(packet);
			packet->data = NULL;

			av_new_packet(packet, 1200*1000);
			av_init_packet(packet);
		}

		Int ret = avcodec_encode_video2(codecContext, packet, frame, &gotOutput);

		if (ret != 0) {
			Int result = 0;
			result = 1;
		}

		if (gotOutput) {
			return true;
		}
	}

	return false;
	*/
}

Bool VideoLib::GetDecodeAudioFrame(int16_t* samples, int frame_size, int nb_channels) {
	/*
	if (samples == NULL) {
		return false;
	}

	int j, i, v;
	int16_t* q;
	q = samples;

	for (j=0; j<frame_size; ++j) {
		v = (int)(sin(outputAudioInfo->t) * 10000);

		for (i=0; i<nb_channels; ++i) {
			*q = v;
			++q;
		}

		outputAudioInfo->t += outputAudioInfo->tincr;
		outputAudioInfo->tincr += outputAudioInfo->tincr2;
	}
*/
	return true;
}

/*
Bool VideoLib::GetDecodeAudioFrame(int16_t* samples, AVCodecContext* codecContext, AudioStruct* audioStruct) {

	if (codecContext == NULL) {
		return false;
	}

	int frame_size = codecContext->channels;
	int nb_channels = codecContext->sample_fmt;

	Int j, i, v;
	int16_t* q;

	q = audioStruct->samples;

	for (j=0; j<frame_size; ++j) {
		v = (Int) (sin(audioStruct->t) * 10000);

		for (i=0; i<nb_channels; ++i) {
			*q = v;
			++q;
		}

		audioStruct->t += audioStruct->tincr;
		audioStruct->tincr += audioStruct->tincr2;
	}

	return true;
}

Bool VideoLib::GetEncodeAudioFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet, int streamIndex) {
	Int gotOutput;

	while (avcodec_encode_audio2(codecContext, packet, frame, &gotOutput) >= 0) {
		if (gotOutput) {
			if (codecContext->coded_frame->pts != AV_NOPTS_VALUE) {
			//	packet->pts = av_rescale_q(codecContext->coded_frame->pts, codecContext->time_base, stream->time_base);
			}

			if (codecContext->coded_frame->key_frame) {
				packet->flags |= AV_PKT_FLAG_KEY;
			}
			packet->stream_index = streamIndex;
			return true;
		}
	}

	return false;
}
*/
/*
Bool VideoLib::GetDecodeAudioFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int audioStreamIndex, AVFrame* outputFrame)
{
	Int frameFinished = 0;

	Int j, i, v;
	int16_t* q;

	q = samples;

	for (j=0; j<frame_size; ++j) {
		v = (Int) (sin(t) * 10000);

		for (i=0; i<nb_channels; ++i) {
			*q = v;
			++q;
		}

		t += tincr;
		tincr += tincr2;
	}

	frame->nb_samples = audio_input_frame_size;
	avcodec_fill_audio_frame(outputFrame, codecContext->channels, codecContext->sample_fmt, 
							 (uint8_t *) samples, audio_input_frame_size * av_get_bytes_per_sample(codecContext->sample_fmt) 
							 * codecContext->channels, 1);

	return (frameFinished!=0);
}
*/

/*
Bool VideoLib::GetEncodeAudioFrame(AVFormatContext* oc, AVStream* st) {
	AVCodecContext* c;
	AVPacket pkt = {0};
	AVFrame* frame = avcodec_alloc_frame();
	int got_packet, ret;

	av_init_packet(&pkt);
	c = st->codec;

	frame->nb_samples = audio_input_frame_size;
	avcodec_fill_audio_frame(frame, c->channels, c->sample_fmt, (uint8_t *) samples, audio_input_frame_size * av_get_bytes_per_sample(c->sample_fmt) * c->channels, 1);

	ret = avcodec_encode_audio2(c, &pkt, frame, &got_packet);

	if (ret < 0) {
		return false;
	}

	if (!got_packet) {
		continue;
	}

	pkt.stream_index = st->index;

	ret = av_interleaved_write_frame(oc, &pkt);

	if (ret != 0) {
		return;
	}

	avcodec_free_frame(&frame);

	return true;
}
*/