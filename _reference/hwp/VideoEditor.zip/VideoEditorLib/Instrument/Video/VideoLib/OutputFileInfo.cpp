/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "OutputFileInfo.h"

#include "Debug.h"


OutputFileInfo::OutputFileInfo() {
	InitVar();
	isOpen = 1;
}

void OutputFileInfo::InitVar() {
	memset(this->fileName, 0x00, MAX_FILENAME);
	memset(this->filePath, 0x00, MAX_FILEPATH);
	memset(this->ext, 0x00, MAX_EXTENSION);

	frameRate = 30;

	timebase.num = 1;
	timebase.den = 30;

	ouputFormat = NULL;
	outputFormatContext = NULL;
	// outputCodecContext = NULL;

	videoStream = NULL;
	audioStream = NULL;
	outputVideoCodec = NULL;
	outputAudioCodec = NULL;

	ouputVideoCodecID = AV_CODEC_ID_NONE;
	ouputAudioCodecID = AV_CODEC_ID_NONE;

	width = 640;
	height = 480;

	isOpen = 1;
}

OutputFileInfo::OutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID, TimelineInfo* timelineInfo) {
	CreateOutputFileInfo(filePath, width, height, frameRate, videoCodecID, audioCodecID, timelineInfo);
}

OutputFileInfo::OutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID) {
	CreateOutputFileInfo(filePath, width, height, frameRate, videoCodecID, audioCodecID, NULL);
}

void OutputFileInfo::CreateOutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID, TimelineInfo* timelineInfo) {

	InitVar();

	// ���ϸ� ����
	strcpy_s(this->filePath, MAX_FILEPATH, filePath);
	
	Int filePathLen = strlen(filePath);

	Int i;
	for (i = filePathLen-1; i>0; i--) {
		if (filePath[i]=='.') {
			++i;
			break;
		}
	}

	strcpy_s(ext, MAX_EXTENSION, &filePath[i]);
	for (i = filePathLen-1; i>0; i--) {
		if (filePath[i]=='\\') {
			break;
		}
	}

	strcpy_s(fileName, MAX_FILENAME, &filePath[i+1]);

	// ���� ���� ����
	this->width = width;
	this->height = height;
	this->frameRate = frameRate;
	this->timebase.num = 1;
	this->timebase.den = frameRate;
	ouputVideoCodecID = videoCodecID;
	ouputAudioCodecID = audioCodecID;

	// �ڵ� ����
	Int ret;

	//outputVideoCodec = avcodec_find_encoder(ouputVideoCodecID);
	//if (outputVideoCodec == NULL) {
	//	Debug::Trace("OutputFileInfo::OutputFileInfo ���ڵ� �ڵ��� ã�� ���Ͽ����ϴ�.");
	//	isOpen = false;
	//	return;
	//}

	AVOutputFormat* guessFormat = av_guess_format(NULL, filePath, NULL);

	if ((ret = avformat_alloc_output_context2(&outputFormatContext, guessFormat, NULL, filePath)) < 0) {
		Debug::Trace("OutputFileInfo::OutputFileInfo context�� �������� ���Ͽ����ϴ�.");
		isOpen = OutputContextAllocFail;
		return;
	}

	//AVCodec* _pCodec2 = avcodec_find_encoder(AV_CODEC_ID_WMV1);
	//AVCodecContext* outputCodecContext2 = avcodec_alloc_context3(_pCodec);




	if (outputFormatContext == NULL) {
		Debug::Trace("OutputFileInfo::OutputFileInfo ���� �̸��� �߸��Ǿ����ϴ�.");
		isOpen = OutputContextAllocFail;
		return;
	}

	ouputFormat = outputFormatContext->oformat;

	Int isVideoOpen = 0;
	Int isAudioOpen = 0;

	if (ouputVideoCodecID != AV_CODEC_ID_NONE) {
		outputFormatContext->oformat->video_codec = ouputVideoCodecID;
		//outputFormatContext->video_codec_id = ouputVideoCodecID;

		videoStream = AddStream(outputFormatContext, &outputVideoCodec, ouputFormat->video_codec);

		if(OpenVideo() == false) {
			isVideoOpen = 0;
			isOpen = OutputOpenVideoFail;
			return;
		}

		isVideoOpen = 1;
	} else {
		videoStream = NULL;
		outputFormatContext->oformat->video_codec = AV_CODEC_ID_NONE;
		outputFormatContext->video_codec_id = AV_CODEC_ID_NONE;
		isVideoOpen = 0;
	}

	if (ouputAudioCodecID != AV_CODEC_ID_NONE) {
		outputFormatContext->oformat->audio_codec = ouputAudioCodecID;
		//outputFormatContext->audio_codec_id = ouputAudioCodecID;

		audioStream = AddStream(outputFormatContext, &outputAudioCodec, ouputFormat->audio_codec, timelineInfo);

		if(OpenAudio() == false) {
			isAudioOpen = 0;
			isOpen = OutputOpenAudioFail;
			return;
		}

		isAudioOpen = 1;
	} else {
		audioStream = NULL;
		outputFormatContext->oformat->audio_codec = AV_CODEC_ID_NONE;
		outputFormatContext->audio_codec_id = AV_CODEC_ID_NONE;
		isAudioOpen = 0;
	}

	if (isVideoOpen ==0 && isAudioOpen == 0) {
		isOpen = -1;
		return;
	}
	
//	outputFormatContext->duration = timelineInfoList[0]->inputFormatContext->duration;

//	videoStream = avformat_new_stream(outputFormatContext, outputVideoCodec);

	//outputCodecContext = avcodec_alloc_context3(outputCodec);
//	outputCodecContext = videoStream->codec;
//	outputCodecContext->pix_fmt = PIX_FMT_YUV420P;

//	outputCodecContext->width = this->width;
//	outputCodecContext->height = this->height;

//	outputCodecContext->bit_rate = this->width * this->height * 4;

//    outputCodecContext->time_base= timeBase;
 //   outputCodecContext->gop_size = 10;
  //  outputCodecContext->max_b_frames=1;

//	if (outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
//		outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
//	}

	
	// ������ ���� ����

	//if ((ret = avcodec_open2(outputCodecContext, outputVideoCodec, NULL)) < 0) {
	//	Debug::Trace("OutputFileInfo::OutputFileInfo ���ڴ� �ڵ��� ���� ���Ͽ����ϴ�.");
	//	isOpen = false;
	//	return;
	//}

	av_dump_format(outputFormatContext, 0, outputFormatContext->filename, 1);

	if (!(outputFormatContext->flags & AVFMT_NOFILE)) {
		if ((ret = avio_open(&(outputFormatContext->pb), outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
			Debug::Trace("OutputFileInfo::OutputFileInfo avio_open�� ���� ���Ͽ����ϴ�.");
			isOpen = AvioOpenFail;
			return;
		}
	}

	if ((ret = avformat_write_header(outputFormatContext, NULL)) < 0) {
		Debug::Trace("OutputFileInfo::OutputFileInfo ���� ����� �ۼ����� ���Ͽ����ϴ�.");
		isOpen = WriteHeaderFail;
		return;
	}
}

/*
void OutputFileInfo::GetAudioFrame(Int frameSize, Int nbChannels) {
    Int j, i, v;

	if (samples == NULL) {
		return;
	}

    int16_t* q = samples;

    for (j = 0; j < frameSize; ++j) {
        v = (Int)(sin(t) * 10000);

		for (i = 0; i < nbChannels; ++i) {
            *q++ = v;
		}

        t += tincr;
        tincr += tincr2;
    }
}
*/

/*
Bool OutputFileInfo::WriteAudioFrame(AVFormatContext* oc, AVStream* st) {
    AVCodecContext *c;
    AVPacket pkt = { 0 }; // data and size must be 0;
    AVFrame *frame = avcodec_alloc_frame();
    Int got_packet, ret;

    av_init_packet(&pkt);
    c = st->codec;

    GetAudioFrame(audio_input_frame_size, c->channels);
    frame->nb_samples = audio_input_frame_size;

    avcodec_fill_audio_frame(frame, c->channels, c->sample_fmt,
                             (UInt8_t *)samples,
                             audio_input_frame_size *
                             av_get_bytes_per_sample(c->sample_fmt) *
                             c->channels, 1);

    ret = avcodec_encode_audio2(c, &pkt, frame, &got_packet);
    if (ret < 0) {
        return false;
    }

	if (!got_packet) {
        return true;
	}

    pkt.stream_index = st->index;

    ret = av_interleaved_write_frame(oc, &pkt);
    if (ret != 0) {
        return false;
    }

    av_free(&frame);

	return true;
}
*/

OutputFileInfo::OutputFileInfo(const Char* filePath, TimelineInfo* info, Int frameRate) {
}

OutputFileInfo::~OutputFileInfo()
{
	if (videoStream != NULL) {
		avcodec_close(videoStream->codec);
	}

	if (outputFormatContext != NULL) {
		if (!(outputFormatContext->flags & AVFMT_NOFILE)) {
			avio_close(outputFormatContext->pb);
		}
		av_free(outputFormatContext);
		outputFormatContext->pb = NULL;
	}

	if (audioStream != NULL) {
		avcodec_close(audioStream->codec);
	}
}

Bool OutputFileInfo::OpenAudio() {
	if (audioStream == NULL) {
		return false;
	}

	if (audioStream->codec == NULL) {
		return false;
	}

    AVCodecContext *c = audioStream->codec;

    Int ret;

    ret = avcodec_open2(c, outputAudioCodec, NULL);
    if (ret < 0) {
		return false;
    }

	return true;
}

Bool OutputFileInfo::OpenVideo() {
	AVCodecContext *c = videoStream->codec;

	if ((avcodec_open2(c, outputVideoCodec, NULL)) < 0) {
		Debug::Trace("OutputFileInfo::OutputFileInfo ���ڴ� �ڵ��� ���� ���Ͽ����ϴ�.");
		return false;
	}

	return true;
}

AVStream* OutputFileInfo::AddStream(AVFormatContext* oc, AVCodec** codec, AVCodecID codecID) {
	return AddStream(oc, codec, codecID, NULL);
}

AVStream* OutputFileInfo::AddStream(AVFormatContext* oc, AVCodec** codec, AVCodecID codecID, TimelineInfo* timelineInfo) {
	AVCodecContext *c;
	AVStream *st;

	// ���ڴ� �ڵ� ã��
	*codec = avcodec_find_encoder(codecID);
	if (!(*codec)) {
		return NULL;
	}

	st = avformat_new_stream(oc, *codec);
	if (!st) {
		return NULL;
	}

	st->id = oc->nb_streams-1;
	c = st->codec;

	switch ((*codec)->type) {
	case AVMEDIA_TYPE_AUDIO:

		c->bit_rate    = 64000;
		c->sample_rate = 44100;
		c->channels    = 2;

		c->time_base.num = 1;
		c->time_base.den = 44100;

		if (timelineInfo != NULL) {
			if (timelineInfo->inputAudioCodecContext != NULL) {
				avcodec_get_context_defaults3(c, *codec);
				c->bit_rate    = timelineInfo->inputAudioCodecContext->bit_rate;
				c->sample_rate = timelineInfo->inputAudioCodecContext->sample_rate;
				c->channels    = timelineInfo->inputAudioCodecContext->channels;

				c->time_base.num = timelineInfo->inputAudioCodecContext->time_base.num;
				c->time_base.den = timelineInfo->inputAudioCodecContext->time_base.den;
			}
		}

		st->id = 1;
		c->sample_fmt  = AV_SAMPLE_FMT_S16;
		break;

	case AVMEDIA_TYPE_VIDEO:
		//avcodec_get_context_defaults3(c, *codec);
		c->codec_id = codecID;

		if (codecID == AV_CODEC_ID_MPEG4) {
			c->bit_rate = this->width * this->height * 4;
		} else {
			c->bit_rate = 400000;
		}

		c->width = this->width;
		c->height = this->height;

		c->time_base = timebase;
		/*
		oc->duration = 1603;
		c->time_base.num = 1;
		c->time_base.den = 60;
		st->time_base.num = 1;
		st->time_base.den = 30;
		st->duration = 1603;
		st->nb_frames = 1603;
		st->nb_index_entries = 1603;
		st->pts.den = 0;
		st->pts.num = 0;
		st->pts.val = 0;
		st->start_time = 0;
		*/
		
		// den = STREAM_FRAME_RATE;

		c->gop_size = 12;
		c->pix_fmt = STREAM_PIX_FMT;

		//c->max_b_frames = 1;

		if (c->codec_id ==  AV_CODEC_ID_MPEG2VIDEO) {
			c-> max_b_frames = 2;
		}

		if (c->codec_id ==  AV_CODEC_ID_MPEG1VIDEO) {
			c-> mb_decision = 2;
		}
	break;

	default:
		break;
	}

	if (oc->oformat->flags & AVFMT_GLOBALHEADER) {
		c->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	return st;
}

Char* OutputFileInfo::GetFilePath() {
	return filePath;
}

Char* OutputFileInfo::GetFileName() {
	return fileName;
}

Char* OutputFileInfo::GetExt() {
	return ext;
}

Int OutputFileInfo::GetFrameRate() {
	return frameRate;
}

AVRational OutputFileInfo::GetTimebase() {
	return timebase;
}

AVFormatContext* OutputFileInfo::GetOutputFormatContext() {
	return outputFormatContext;
}

AVCodecContext* OutputFileInfo::GetOutputCodecContext() {
	return videoStream->codec;
}

AVCodecContext* OutputFileInfo::GetOutputAudioCodecContext() {
	return audioStream->codec;
}

int OutputFileInfo::GetVideoStreamIndex() {
	return videoStream->index;
}

int OutputFileInfo::GetAudioStreamIndex() {
	return audioStream->index;
}

AVStream* OutputFileInfo::GetVideoStream() {
	return videoStream;
}

AVStream* OutputFileInfo::GetAudioStream() {
	return audioStream;
}

AVCodec* OutputFileInfo::GetOutputCodec() {
	return outputVideoCodec;
}

Int OutputFileInfo::GetWidth() {
	return width;
}

Int OutputFileInfo::GetHeight() {
	return height;
}

AVCodecID OutputFileInfo::GetOuputVideoCodecID() {
	return ouputVideoCodecID;
}

AVCodecID OutputFileInfo::GetOuputAudioCodecID() {
	return ouputVideoCodecID;
}

Int OutputFileInfo::IsOpened() {
	return isOpen;
}