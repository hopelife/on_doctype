﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using System.Collections;
using System.Windows.Input;

namespace Hnc.Control {

    /// <summary>
    /// PhotoListBox에 바인딩 되는 데이터 클래스입니다.
    /// </summary>
    public class PhotoListBoxItem : INotifyPropertyChanged {

        #region -> Constructor

        public PhotoListBoxItem(string id, Image content) {

            Id = id;
            Content = content;
            LabelColor = Brushes.Black;
        }

		public PhotoListBoxItem(string id, string path, Image content) {
			Id = id;
			ItemName = System.IO.Path.GetFileName(path);
			Path = path;
			Content = content;
            LabelColor = Brushes.Black;
		}

        public PhotoListBoxItem(string id, Image content, String information) {

            Id = id;
            Content = content;
            Information = information;
            LabelColor = Brushes.Black;
        }

        public PhotoListBoxItem(string id, Image content, String label, double labelHeight) {

            Id = id;
            Content = content;
            Label = label;
            LabelHeight = labelHeight;
            LabelColor = Brushes.Black;
        }

        public PhotoListBoxItem(string id, Image content, String label, double labelHeight, SolidColorBrush labelColor) {

            Id = id;
            Content = content;
            Label = label;
            LabelHeight = labelHeight;
            LabelColor = labelColor;
        }

        #endregion

        #region -> Properties

        public string Id {
            get;
            set;
        }

        private Image content;
        public Image Content {
            get { return content; }
            set {
                content = value;
                NotifyPropertyChanged("Content");
            }
        }

        public string Path {
            get;
            set;
        }

        private String label;
        public String Label {
            get { return label; }
            set {
                label = value;
                NotifyPropertyChanged("Label");
            }
        }

        public double ContentWidth {
            get;
            set;
        }

        public double ContentHeight {
            get;
            set;
        }

        public SolidColorBrush LabelColor {
            get;
            set;
        }

        public double LabelHeight {
            get;
            set;
        }

        public Thickness LabelMargin {
            get;
            set;
        }

        /// <summary>
        /// 아이템의 이름으로서 정렬에 사용되는 속성입니다.
        /// </summary>
        private string itemName;
        public string ItemName {
            get {
                return itemName;
            }
            set {
                itemName = value;
                NotifyPropertyChanged("ItemName");
            }
        }

        /// <summary>
        /// 사진을 찍은 시각 또는 파일의 수정 시각이며 필터링과 정렬에 사용되는 속성입니다.
        /// </summary>
        public DateTime DateImageTaken {
            get;
            set;
        }

        /// <summary>
        /// 사진에 첨부된 태그들의 목록이며 필터링에 사용되는 속성입니다.
        /// </summary>
        public List<string> Tags {
            get;
            set;
        }

        private bool IsDirectory {
            get {
                // 유효한 디렉토리인지 검사
                if (Directory.Exists(Path))
                    return true;
                else
                    return false;
            }
        }

        /// <summary>
        /// 사진의 상세 정보이며 툴팁으로 사용되는 속성입니다.
        /// </summary>
        private String information = null;
        public String Information {

            get {
                if (String.IsNullOrEmpty(information)) {
                    if (IsDirectory) {
                        DirectoryInfo dirInfo = new DirectoryInfo(Path);
                        information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as string + ": " + Path + Environment.NewLine;
                        information += Application.Current.Resources["IDS_CreationTime"] as string + ": " + dirInfo.CreationTime;
                    } else {
                        FileInfo fileInfo = new FileInfo(Path);
                        information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as string + ": " + fileInfo.DirectoryName + Environment.NewLine;
                        information += Application.Current.Resources["IDS_Size"] as string + ": " + Math.Round(fileInfo.Length / 1024.0, 2) + "KB" + Environment.NewLine;
                        information += Application.Current.Resources["IDS_ModifiedTime"] as string + ": " + DateImageTaken.ToString();
                    }
                }

				information = null;
                return information;
            }
            set {
                information = value;
            }
        }

        #endregion

        #region -> INotifyPropertyChanged Impl.

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(String propertyName) {

            Debug.Assert(!String.IsNullOrEmpty(propertyName));

            if (PropertyChanged != null) {
                PropertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }

    /// <summary>
    /// 사진들을 썸네일 형태로 출력하는 리스트 박스입니다.
    /// </summary>
    public class PhotoListBox : System.Windows.Controls.ListBox {

        #region -> Enumerations

        public enum ItemStyles {
            Simple,
            Border,
            Check
        }

        /// <summary>
        /// 사진 정렬 타입입니다.
        /// </summary>
        public enum SortType {
            /// <summary>
            /// 이름순 정렬
            /// </summary>
            Name_Acs,
            /// <summary>
            /// 이름 역순 정렬
            /// </summary>
            Name_Desc,
            /// <summary>
            /// 오래된 날짜순 정렬
            /// </summary>
            Date_Acs,
            /// <summary>
            /// 최신 날짜순 정렬
            /// </summary>
            Date_Desc,
            /// <summary>
            /// Id순 정렬
            /// </summary>
            Id_Asc,
            /// <summary>
            /// Id역순 정렬
            /// </summary>
            Id_Desc
        }

        #endregion

        #region -> Fields

        private bool isEnableToggle = true;

        private readonly double KeyDownOffset = 120;
        private DateTime filteringStartDate = new DateTime(1981, 1, 1);
        private DateTime filteringEndDate = new DateTime(2100, 12, 31);

        private ObservableCollection<string> filteringTags = new ObservableCollection<string>();

        private FlickingScrollViewer scrollViewer;

        #endregion

        #region -> Constructor

        static PhotoListBox() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(PhotoListBox), new FrameworkPropertyMetadata(typeof(PhotoListBox)));
        }

        #endregion

        #region -> Properties

        /// <summary>
        /// 필터링할 기간의 시작날짜입니다.
        /// 필터링 조건은 시작날짜 ~ 끝날짜가 아니라 시작년도~종료년도이면서 시작달~종료달인 아이템입니다.
        /// </summary>
        public DateTime FilteringStartDate {
            private get { return filteringStartDate; }
            set {
                if (filteringStartDate != value) {
                    filteringStartDate = value;
                    Filtering();
                }
            }
        }

        /// <summary>
        /// 필터링할 기간의 종료날짜입니다.
        /// 필터링 조건은 시작날짜 ~ 끝날짜가 아니라 시작년도~종료년도이면서 시작달~종료달인 아이템입니다.
        /// </summary>
        public DateTime FilteringEndDate {
            private get { return filteringEndDate; }
            set {
                if (filteringEndDate != value) {
                    filteringEndDate = value;
                    Filtering();
                }
            }
        }

        /// <summary>
        /// 필터링 태그 목록으로서 이 태그 목록을 기준으로 사진을 필터링하여 보여줍니다.
        /// </summary>
        public ObservableCollection<string> FilteringTags {
            get { return filteringTags; }
        }  

        private bool autoScroll = false;
        public bool AutoScroll {
            get { return autoScroll; }
            set { autoScroll = value; }
        }

        public bool IsEnableToggle {
            get {
                return isEnableToggle;
            }
            set {
                isEnableToggle = value;
            }
        }

        public double HorizontalOffset {
            get {
                return scrollViewer.HorizontalOffset;
            }
            set {
                if (value >= -KeyDownOffset && value <= scrollViewer.ScrollableWidth + KeyDownOffset)
                    scrollViewer.ScrollToHorizontalOffset(value);
            }
        }

        public double VerticalOffset {
            get {
                return scrollViewer.VerticalOffset;
            }
            set {
                if (value >= -KeyDownOffset && value <= scrollViewer.VerticalOffset + KeyDownOffset)
                    scrollViewer.ScrollToVerticalOffset(value);
            }
        }

        #endregion

        #region -> Dependency Properties

        public ItemStyles ItemStyle {
            get { return (ItemStyles)GetValue(ItemStyleProperty); }
            set { SetValue(ItemStyleProperty, value); }
        }

        public double ItemContainerWidth {
            get { return (ItemWidth + ItemMargin.Left + ItemMargin.Right) * Items.Count; }
        }

        public double ItemWidth {
            get { return (double)GetValue(ItemWidthProperty); }
            set { SetValue(ItemWidthProperty, value); }
        }

        public double ItemHeight {
            get { return (double)GetValue(ItemHeightProperty); }
            set { SetValue(ItemHeightProperty, value); }
        }

        public Thickness ItemMargin {
            get {
                return (Thickness)base.GetValue(ItemMarginProperty);
            }
            set {
                base.SetValue(ItemMarginProperty, value);
            }
        }        

        public bool IsRemovableItem {
            get { return (bool)GetValue(IsRemovableItemProperty); }
            set { SetValue(IsRemovableItemProperty, value); }
        }

        public Orientation Orientation {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }

        public static readonly DependencyProperty ItemStyleProperty =
            DependencyProperty.Register("ItemStyle", typeof(ItemStyles), typeof(PhotoListBox), new PropertyMetadata(ItemStyles.Simple));

        public static readonly DependencyProperty ItemWidthProperty =
            DependencyProperty.Register("ItemWidth", typeof(double), typeof(PhotoListBox), new PropertyMetadata(100d));

        public static readonly DependencyProperty ItemHeightProperty =
            DependencyProperty.Register("ItemHeight", typeof(double), typeof(PhotoListBox), new PropertyMetadata(100d));

        public static readonly DependencyProperty ItemMarginProperty =
            DependencyProperty.Register("ItemMargin", typeof(Thickness), typeof(PhotoListBox), new PropertyMetadata(new Thickness(0, 5, 0, 5)));

        public static readonly DependencyProperty IsRemovableItemProperty =
            DependencyProperty.Register("IsRemovableItem", typeof(bool), typeof(PhotoListBox), new PropertyMetadata(false));

        public static readonly DependencyProperty OrientationProperty =
            DependencyProperty.Register("Orientation", typeof(Orientation), typeof(PhotoListBox), new PropertyMetadata(Orientation.Vertical));

        #endregion

        #region -> Public Methods

        /// <summary>
        /// 리스트 박스내의 사진을 정렬합니다.
        /// </summary>
        /// <param name="type">정렬 타입</param>
        public void Sort(SortType type) {

            using (this.Items.DeferRefresh()) {
                Items.SortDescriptions.Clear();

                if (type == SortType.Date_Acs)
                    Items.SortDescriptions.Add(new SortDescription("DateImageTaken", ListSortDirection.Ascending));
                else if (type == SortType.Date_Desc)
                    Items.SortDescriptions.Add(new SortDescription("DateImageTaken", ListSortDirection.Descending));
                else if (type == SortType.Name_Acs)
                    Items.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Ascending));
                else if (type == SortType.Name_Desc)
                    Items.SortDescriptions.Add(new SortDescription("ItemName", ListSortDirection.Descending));
                else if (type == SortType.Id_Asc)
                    Items.SortDescriptions.Add(new SortDescription("Id", ListSortDirection.Ascending));
                else if (type == SortType.Id_Desc)
                    Items.SortDescriptions.Add(new SortDescription("Id", ListSortDirection.Descending));
            }
        }    

        /// <summary>
        /// Items에서 Id와 일치하는 PhotoListBoxItem을 가져옵니다.
        /// </summary>
        public PhotoListBoxItem GetItem(string id) {

            foreach (PhotoListBoxItem item in this.Items) {
                if (id.Equals(item.Id))
                    return item;
            }

            return null;
        }

        /// <summary>
        /// 입력한 인덱스의 아이템으로 스크롤합니다.
        /// </summary>        
        public void ScrollToIndex(int itemIndex) {

            if (Items != null && Items.Count != 0) {

                object item = Items.GetItemAt(itemIndex);
                if (item != null) {
                    ScrollIntoView(item);
                    UpdateLayout();
                }
            }
        }

        /// <summary>
        /// 목록의 마지막 아이템까지 스크롤합니다.
        /// </summary>
        public void ScrollToEnd() {

            if (scrollViewer != null)
                scrollViewer.ScrollToEnd();
        }

        #endregion

        #region -> Private Methods

        /// <summary>
        /// 현재 설정된 필터조건(FileringStartDate, FileringEndDate, FileringTags)으로 아이템을 필터링하여 출력합니다.
        /// </summary>
        private void Filtering() {

            Items.Filter = delegate(object obj) {

                PhotoListBoxItem item = obj as PhotoListBoxItem;

                // 기간 필터 체크
                if (item.DateImageTaken.Year >= filteringStartDate.Year && item.DateImageTaken.Year <= filteringEndDate.Year &&
                    item.DateImageTaken.Month >= filteringStartDate.Month && item.DateImageTaken.Month <= filteringEndDate.Month) {

                    // 태그 필터 체크
                    if (filteringTags.Count == 0) {
                        return true;
                    } else {
                        foreach (string filteringTag in filteringTags) {
                            if (item.Tags != null && item.Tags.Contains(filteringTag))
                                return true;
                        }
                    }
                }

                return false;
            };
        }

        private void filteringTags_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e) {
            Filtering();
        }

        private void PhotoListBox_MouseEnter(object sender, MouseEventArgs e) {
            // 방향키 이동을 위해 사용할 KeyDown 이벤트를 받기 위해 포커스를 설정
            this.Focus();
        }

        private void PhotoListBox_PreviewKeyDown(object sender, KeyEventArgs e) {

            if (e.Key == System.Windows.Input.Key.Left) {
                HorizontalOffset -= KeyDownOffset;
            } else if (e.Key == System.Windows.Input.Key.Right) {
                HorizontalOffset += KeyDownOffset;
            } else if (e.Key == Key.Up) {
                VerticalOffset -= KeyDownOffset;
            } else if (e.Key == Key.Down) {
                VerticalOffset += KeyDownOffset;
            }
        }

        #endregion

        #region -> Overrided Methods

        protected override void OnInitialized(EventArgs e) {
            base.OnInitialized(e);

            filteringTags.CollectionChanged +=
                new System.Collections.Specialized.NotifyCollectionChangedEventHandler(filteringTags_CollectionChanged);

            this.PreviewKeyDown += new KeyEventHandler(PhotoListBox_PreviewKeyDown);
            this.MouseEnter += new MouseEventHandler(PhotoListBox_MouseEnter);
        }        

        public override void OnApplyTemplate() {

            scrollViewer = GetTemplateChild("scrollViewer") as FlickingScrollViewer;
            Debug.Assert(scrollViewer != null);

            base.OnApplyTemplate();
        }

        protected override void OnItemsChanged(System.Collections.Specialized.NotifyCollectionChangedEventArgs e) {

            if (autoScroll &&
                (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add ||
                e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Reset)) {

                this.ScrollToEnd();
            }

            base.OnItemsChanged(e);
        }

        protected override void OnItemsSourceChanged(System.Collections.IEnumerable oldValue, System.Collections.IEnumerable newValue) {

            if (autoScroll)
                this.ScrollToEnd();

            base.OnItemsSourceChanged(oldValue, newValue);
        }

        protected override DependencyObject GetContainerForItemOverride() {
            return new Hnc.Control.ListBoxItem(isEnableToggle);
        }

        #endregion
    }
}