﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Collections.ObjectModel;

namespace Hnc.Control
{	
	public class AniWrapPanel : WrapPanel
	{
		static AniWrapPanel()
		{
			FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata();
		}

		private Size ourSize;

		//protected override Size MeasureOverride(Size constraint)
		//{
		//    // WrapPanel 특성상 Children의 사이즈에 따라 Content가 커지므로
		//    // 가로 MinSize 개념을 두어 가로로 커지지 않고 세로로 커지도록 설정
		//    // 추후 확인!!
		//    Size size = constraint;
		//    size.Width = 160;
		//    //size.Height = 240;
		//    return base.MeasureOverride(size);
		//}

		protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
		{
			base.OnRenderSizeChanged(sizeInfo);

			if (this.Children == null || this.Children.Count == 0)
				return;

			Size currentLineSize = new Size();
			double accumulatedHeight = 0;
			bool isLineFirst = true;

			foreach (UIElement child in this.Children)
			{
				if (child.RenderTransform as TranslateTransform == null)
					child.RenderTransform = new TranslateTransform();

				Size desiredSize = new Size();
				desiredSize.Width = ItemWidth.CompareTo(double.NaN) == 0 ? child.DesiredSize.Width : ItemWidth;
				desiredSize.Height = ItemHeight.CompareTo(double.NaN) == 0 ? child.DesiredSize.Height : ItemHeight;

				currentLineSize.Width += desiredSize.Width;
				currentLineSize.Height = Math.Max(desiredSize.Height, currentLineSize.Height);

				if (currentLineSize.Width > sizeInfo.NewSize.Width)
				{
					isLineFirst = true;
					currentLineSize = desiredSize;
				}

				if (isLineFirst)
				{
					accumulatedHeight += currentLineSize.Height;
					isLineFirst = false;
				}
			}

			this.Height = accumulatedHeight;
		}

		protected override Size ArrangeOverride(Size finalSize)
		{
			if (this.Children == null || this.Children.Count == 0)
				return finalSize;

			ourSize = finalSize;

			foreach (UIElement child in this.Children)
			{
				if (child.RenderTransform as TranslateTransform == null)
					child.RenderTransform = new TranslateTransform();

				double width = ItemWidth.CompareTo(double.NaN) == 0 ? child.DesiredSize.Width : ItemWidth;
				double height = ItemHeight.CompareTo(double.NaN) == 0 ? child.DesiredSize.Height : ItemHeight;

				child.Arrange(new Rect(0, 0, width, height));
			}

			AnimateAll();

			return finalSize;
		}

		// 패널의 Child의 Translate 애니메이션 적용
		private void AnimateAll()
		{
			double maxHeight = 0, x = 0, y = 0;
			foreach (UIElement child in this.Children)
			{
				if (child.DesiredSize.Height > maxHeight)
					maxHeight = child.DesiredSize.Height;
				if (x + child.DesiredSize.Width > this.ourSize.Width)
				{
					x = 0;
					y += maxHeight;
				}

				if (y > this.ourSize.Height - maxHeight)
					child.Visibility = Visibility.Hidden;
				else
					child.Visibility = Visibility.Visible;

				AnimateTo(child, 0, x, y, 1);
				x += child.DesiredSize.Width;
			}
		}

		private void AnimateTo(UIElement child, double r, double x, double y, double s)
		{
			TranslateTransform trans = (TranslateTransform)child.RenderTransform;

			trans.BeginAnimation(TranslateTransform.XProperty, MakeAnimation(x));
			trans.BeginAnimation(TranslateTransform.YProperty, MakeAnimation(y));
		}

		private DoubleAnimation MakeAnimation(double to)
		{
			return MakeAnimation(to, null);
		}

		private DoubleAnimation MakeAnimation(double to, EventHandler endEvent)
		{
			DoubleAnimation anim = new DoubleAnimation(to, TimeSpan.FromMilliseconds(200));
			anim.AccelerationRatio = 0.2;
			anim.DecelerationRatio = 0.7;
			return anim;
		}
	}
}
