#include "gdevwmf.h"
#include "gdevwmf_.h"

#define WMF_TRANSPARENT_COLOR	RGB(254,255,255)

typedef struct wmf_image_enum_s {
	gx_image_enum_common;
	
	const gs_imager_state *pis;
	const gs_color_space *pcs;
	const gx_clip_path *pcpath;
	gs_matrix_fixed ctm;
	gs_matrix ImageMatrix;
	int image_width;
	int image_height;
	gs_color_space_index color_space; 
	int bits_per_component;
	int num_components;
	gs_image_format_t image_format;   // chunky or planar
	bool imagemask;
	const gx_drawing_color * pdcolor;
	gs_int_rect clip_rect;            // ����̽� ���� Ŭ���� ����, �� ������ ���� ǥ�õȴ�.
	const gs_int_rect *prect;         // NULL �� �ƴϸ�, ó���� �̹��� ũ��
	BITMAPINFOHEADER* pbmi;           // ���� �޸� �Ҵ��� �޴� ������
	int pbmi_size;                    // �޸� ũ��
	BYTE* pdib;                       // DIB �������� ������ ����Ű�� ������
	int dib_bits_per_component;       // 24bit �̹����� ����
	int dib_num_components;
	int dib_bits_per_pixel;
	int dib_byte_width;
	wmf_dib_color_format_type dib_color_format;  // RGB �� �ϴ� ����
	int last_height;                  // ���������� ó���� height ��

	// begin_typed_image �� ���� ���
	int type;						// �̹��� Ÿ��

} wmf_image_enum;

gs_private_st_suffix_add0(st_wmf_image_enum, wmf_image_enum,
  "wmf_image_enum", wmf_image_enum_enum_ptrs, wmf_image_enum_reloc_ptrs,
  st_gx_image_enum_common);

extern_st(st_gx_image_enum_common);

int wmf_image_plane_data(gx_image_enum_common_t *info, const gx_image_plane_t *planes, int height, int *rows_used)
{
	wmf_image_enum *pwe = (wmf_image_enum*)info;
	gx_device_wmf *wdev = (gx_device_wmf*)(pwe->dev);
	BYTE *pDib = NULL;
	int i, x, y, c, start_x, end_x, start_y, end_y;
	int code;
	const BYTE *pSrc;
	BYTE *pDest;
	int nSrcBitIndex, nDestBitIndex;  // ����Ʈ �� ��Ʈ ��ȣ : 0 1 2 3 4 5 6 7, �� ������ ��ǥ�� ����ȴ�.
	gx_color_value nSrcValues[gs_image_max_planes], nDestValues[WMF_MAX_COMPONENTS];
	int bits_per_component = pwe->bits_per_component;

	if (!wdev || !wdev->hdc || !pwe || !pwe->pdib)
		return 1;
	if (!wdev->bRecord)
		return 1;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_image_plane_data()=========================================Image\n");
		fprintf(wdev->pFile, "image type : %d\n", info->image_type->index);
		fprintf(wdev->pFile, "height     : %d\n", height);
		fprintf(wdev->pFile, "num planes : %d\n", info->num_planes);
		for (i = 0; i < info->num_planes; i++) {
			fprintf(wdev->pFile, "plane_depth[%d] : %d\n", i + 1, info->plane_depths[i]);
			fprintf(wdev->pFile, "plane_width[%d] : %d\n", i + 1, info->plane_widths[i]);
			fprintf(wdev->pFile, "data_x[%d]      : %d\n", i + 1, planes[i].data_x);
			fprintf(wdev->pFile, "raster[%d]      : %d\n", i + 1, planes[i].raster);
		}
	}
#endif // _DEBUG

	if (pwe->last_height + height > pwe->image_height)
		height = pwe->image_height - pwe->last_height;
	
	*rows_used = height;

	// �̹����� ������ ������ ���Ѵ�.
	if (pwe->prect) {
		start_x = planes[0].data_x;
		end_x = (pwe->prect->q.x + 1 < info->plane_widths[0]) ? pwe->prect->q.x + 1 : info->plane_widths[0];
		start_y = pwe->last_height;
		end_y = (pwe->prect->q.y + 1 < height + pwe->last_height) ? pwe->prect->q.y + 1 : height + pwe->last_height;
	}
	else {
		start_x = planes[0].data_x;
		end_x = info->plane_widths[0];
		start_y = pwe->last_height;
		end_y = height + pwe->last_height;
	}

	// DIB �����͸� ������ ��ġ�� ����
	for (y = start_y; y < end_y; y++) {
		for (x = start_x; x < end_x; x++) {

			// �� Component �� ���� ���Ѵ�.
			switch (pwe->image_format) {
				DWORD temp;
				case gs_image_format_chunky: {
					pSrc = planes[0].data + (y - start_y) * planes[0].raster + x * pwe->plane_depths[0] / 8;
					nSrcBitIndex = x * pwe->plane_depths[0] % 8;
					// �� Component ���� depth ��ŭ ��Ʈ�� �����Ѵ�.
					for (c = 0; c < pwe->num_components; c++) {
						temp = (pSrc[0] << 24) | (pSrc[1] << 16) | (pSrc[2] << 8) | pSrc[3];
						temp = (temp >> (32 - nSrcBitIndex - bits_per_component)) & ((1 << bits_per_component) - 1);
						nSrcValues[c] = temp;
						pSrc += bits_per_component / 8;
						nSrcBitIndex += bits_per_component % 8;
					}
					break;
				}
				case gs_image_format_component_planar: {
					for (c = 0; c < pwe->num_components; c++) {
						pSrc = planes[c].data + (y - start_y) * planes[c].raster + x * pwe->plane_depths[c] / 8;
						nSrcBitIndex = x * pwe->plane_depths[c] % 8;
						temp = (pSrc[0] << 24) | (pSrc[1] << 16) | (pSrc[2] << 8) | pSrc[3];
						temp = (temp >> (32 - nSrcBitIndex - pwe->plane_depths[c])) & ((1 << pwe->plane_depths[c]) - 1);
						nSrcValues[c] = temp;
						pSrc += pwe->plane_depths[c] / 8;
						nSrcBitIndex += pwe->plane_depths[c] % 8;
					}
					break;
				}
				case gs_image_format_bit_planar: {
					break;
				}
			} // switch (pwe->image_format)

			// ��Ÿ������ Color Format �� �����.
			switch (pwe->color_space) {
				case gs_color_space_index_DeviceGray:
					switch (pwe->dib_color_format) {
						case RGB24:
							nDestValues[0] = nSrcValues[0] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[1] = nSrcValues[0] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[2] = nSrcValues[0] * 255 / ((1 << bits_per_component) - 1);
							break;
					}
					break;
				case gs_color_space_index_DeviceRGB:
					switch (pwe->dib_color_format) {
						case RGB24:
							nDestValues[0] = nSrcValues[0] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[1] = nSrcValues[1] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[2] = nSrcValues[2] * 255 / ((1 << bits_per_component) - 1);
							break;
					}
					break;
				case gs_color_space_index_DeviceCMYK:
					switch (pwe->dib_color_format) {
						gx_color_index rgb;
						case RGB24:
							nSrcValues[0] = nSrcValues[0] * 32767 / ((1 << bits_per_component) - 1);
							nSrcValues[1] = nSrcValues[1] * 32767 / ((1 << bits_per_component) - 1);
							nSrcValues[2] = nSrcValues[2] * 32767 / ((1 << bits_per_component) - 1);
							nSrcValues[3] = nSrcValues[3] * 32767 / ((1 << bits_per_component) - 1);
							rgb = wdev->procs.map_cmyk_color( (gx_device*)wdev, nSrcValues );
							nDestValues[0] = (rgb >> 16) & 255;
							nDestValues[1] = (rgb >> 8) & 255;
							nDestValues[2] = rgb & 255;
							break;
					}
					break;
				case gs_color_space_index_CIEABC:
					switch (pwe->dib_color_format) {
						case RGB24:
							nDestValues[0] = nSrcValues[0] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[1] = nSrcValues[1] * 255 / ((1 << bits_per_component) - 1);
							nDestValues[2] = nSrcValues[2] * 255 / ((1 << bits_per_component) - 1);
							break;
					}
					break;
				case gs_color_space_index_Indexed:
					switch (pwe->dib_color_format) {
						case RGB24: {
							gs_client_color cc;
							gs_cspace_indexed_lookup( pwe->pcs, nSrcValues[0], &cc );
							nDestValues[0] = (BYTE)(cc.paint.values[0] * 255);
							nDestValues[1] = (BYTE)(cc.paint.values[1] * 255);
							nDestValues[2] = (BYTE)(cc.paint.values[2] * 255);
							break;
						}
					}
					break;
				case gs_color_space_index_CIEICC:
					switch (pwe->dib_color_format) {
						case RGB24: {
							gs_client_color cc;
							frac conc[3];
							gx_device_color dc;
							cc.paint.values[0] = (double)nSrcValues[0] / ((1 << bits_per_component) - 1);
							cc.paint.values[1] = (double)nSrcValues[1] / ((1 << bits_per_component) - 1);
							cc.paint.values[2] = (double)nSrcValues[2] / ((1 << bits_per_component) - 1);
							pwe->pcs->type->remap_color(&cc, pwe->pcs,	&dc, pwe->pis, pwe->dev, gs_color_select_source);
							nDestValues[0] = (BYTE)(dc.colors.pure >> 16);
							nDestValues[1] = (BYTE)(dc.colors.pure >> 8);
							nDestValues[2] = (BYTE)(dc.colors.pure);
							break;
						}
					}
					break;
			} // switch (pwe->color_space)

			// ����ũ ������ �ٲ۴�.
			if (pwe->imagemask && nDestValues[0] == 0) {
				if (pwe->pdcolor->type == gx_dc_type_pure) {
					COLORREF color = MakeColorRef(pwe->pdcolor->colors.pure);
					// �������� ������ ��µ��� �����Ƿ� RGB(255,255,255) ���� �ٲ۴�.
					// ����� �����Ϸ��� MaskBlt() ���°� �Ǿ�� �� �� ����.

					if (color == WMF_TRANSPARENT_COLOR)
						color = WMF_TRANSPARENT_COLOR + 1;

					nDestValues[0] = GetRValue(color);
					nDestValues[1] = GetGValue(color);
					nDestValues[2] = GetBValue(color);
				}
			}

			// ��Ÿ������ DIB ������ ���� �����Ѵ�.
			pDest = pwe->pdib + y * pwe->dib_byte_width + (x * pwe->dib_bits_per_pixel) / 8;
			nDestBitIndex = (x * pwe->dib_bits_per_pixel) % 8;
			switch (pwe->dib_color_format) {
				case RGB24:
					pDest[0] = nDestValues[2];
					pDest[1] = nDestValues[1];
					pDest[2] = nDestValues[0];
					break;
			}

		} // for (x = start_x; x < end_x; x++)
	} // for (y = start_y; y < end_y; y++)

	pwe->last_height += height;

#if defined(_DEBUG) || defined(DEBUG)
	jTRACE( "Image Plane Data Processed : %d lines... (%d%%)\n",
			pwe->last_height, pwe->last_height * 100 / pwe->image_height);

	if (wdev->pFile)
		fprintf(wdev->pFile, "processed : %d lines\n", pwe->last_height);
#endif // _DEBUG

	// �̹��� �����Ͱ� ��� ������, ��Ÿ���ڵ带 �����Ѵ�.
	if ((!pwe->prect && pwe->last_height >= pwe->image_height)
		|| (pwe->prect && pwe->last_height >= pwe->prect->q.y - pwe->prect->p.y + 1)) {

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "end of image data\n");
#endif // _DEBUG

		return 1;
	}

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	return 0;
}

int wmf_end_plane_image(void *info, bool draw_last)
{
	wmf_image_enum *pwe = (wmf_image_enum*)info;
	gx_device_wmf *wdev = (gx_device_wmf*)(pwe->dev);
	int x, y, w, h, ix, iy, iw, ih;
	int code;
	BOOL bHConv, bVConv; // DIB �������� ����
	BOOL bClipRequired = FALSE;

	gs_point SrcLeftTop, DestLeftTop;
	double scale_x, scale_y;
	double extra_tx, extra_ty;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "wmf_end_plane_image()================================================Image\n");
#endif // _DEBUG

	memset(pwe->pbmi, 0, sizeof(BITMAPINFOHEADER));
	pwe->pbmi->biSize = sizeof(BITMAPINFOHEADER);
	pwe->pbmi->biWidth = pwe->image_width;
	pwe->pbmi->biHeight = pwe->image_height;
	pwe->pbmi->biPlanes = 1;
	pwe->pbmi->biBitCount = pwe->dib_bits_per_pixel;
	pwe->pbmi->biCompression = BI_RGB;

	// ImageMatrix �� CTM ���� ���踦 ���Ѵ�.
	scale_x = (double)pwe->ctm.xx / pwe->ImageMatrix.xx;
	scale_y = (double)pwe->ctm.yy / pwe->ImageMatrix.yy;
	SrcLeftTop.x = (pwe->ImageMatrix.xx > 0) ? pwe->ImageMatrix.tx : pwe->ImageMatrix.tx + pwe->ImageMatrix.xx;
	SrcLeftTop.y = (pwe->ImageMatrix.yy > 0) ? pwe->ImageMatrix.ty : pwe->ImageMatrix.ty + pwe->ImageMatrix.yy;
	DestLeftTop.x = (pwe->ctm.xx > 0) ? pwe->ctm.tx : pwe->ctm.tx + pwe->ctm.xx;
	DestLeftTop.y = (pwe->ctm.yy > 0) ? pwe->ctm.ty : pwe->ctm.ty + pwe->ctm.yy;
	extra_tx = (0 - SrcLeftTop.x) * scale_x;
	extra_ty = (0 - SrcLeftTop.y) * scale_y;

	// �̹����� ���ϰ� ���������� �ϴ��� ����
	bHConv = (scale_x > 0) ? FALSE : TRUE;
	bVConv = (scale_y > 0) ? TRUE : FALSE;
	scale_x = ABS(scale_x);
	scale_y = ABS(scale_y);

	// ImageMatrix �� �������� ǥ�� ��ǥ�� ���·� ��ȯ�Ѵ�.
	pwe->ImageMatrix.xx = ABS((double)pwe->ImageMatrix.xx);
	pwe->ImageMatrix.yy = ABS((double)pwe->ImageMatrix.yy);
	pwe->ImageMatrix.tx = SrcLeftTop.x;
	pwe->ImageMatrix.ty = SrcLeftTop.y;

	// CTM �� ���� �����.
	pwe->ctm.xx = ABS((double)pwe->ctm.xx);
	pwe->ctm.yy = ABS((double)pwe->ctm.yy);
	pwe->ctm.tx = DestLeftTop.x + extra_tx;
	pwe->ctm.ty = DestLeftTop.y + extra_ty;

	// ����̽� ��ǥ���� ����
	x = round(pwe->ctm.tx);
	y = round(pwe->ctm.ty);
	w = round(pwe->ctm.xx);
	h = round(pwe->ctm.yy);

	// �̹��� ��ǥ�� ����
	ix = 0;
	iy = 0;
	iw = round(pwe->ImageMatrix.xx);
	ih = round(pwe->ImageMatrix.yy);

	// �̹��� �ҽ����� Ŭ���� �Ǿ� ���� ǥ�õ� ���� ���
	// prect �� ���� ����� Ŭ���� ���� ��ȭ�� �����Ѵ�.  ===> ������ �����....
	if (round(pwe->clip_rect.p.x) > x) {
		double delta = pwe->clip_rect.p.x - x;
		ix += round(delta / scale_x);
		iw -= round(delta / scale_x);
		x += round(delta);
		w -= round(delta);
		bClipRequired = TRUE;
	}

	if (round(pwe->clip_rect.p.y) > y) {
		double delta = pwe->clip_rect.p.y - y;
		iy += round(delta / scale_y);
		ih -= round(delta / scale_y);
		y += round(delta);
		h -= round(delta);
		bClipRequired = TRUE;
	}

	if (round(pwe->clip_rect.q.x) < x + w - 1) {
		double delta = x + w - 1 - pwe->clip_rect.q.x;
		iw -= round(delta / scale_x);
		w -= round(delta);
		bClipRequired = TRUE;
	}

	if (round(pwe->clip_rect.q.y) < y + h - 1) {
		double delta = y + h - 1 - pwe->clip_rect.q.y;
		ih -= round(delta / scale_y);
		h -= round(delta);
		bClipRequired = TRUE;
	}

	// ���� �� ����
	if (w < 0 || h < 0 || iw < 0 || ih < 0) {
		w = h = iw = ih = 0;
	}

	// Ŭ�����Ѵ�.
	if (bClipRequired || bHConv || bVConv) {
		wmf_clip_image((BITMAPINFO*)pwe->pbmi, ix, iy, iw, ih, bHConv, bVConv);
		ix = 0;
		iy = 0;
	}

	if (pwe->pbmi) {

		if (wdev->bRecord) {
			if (pwe->imagemask) {
				int code;
				HDC hdcMem = CreateCompatibleDC(wdev->hdc);
				HBITMAP hBitmap = CreateCompatibleBitmap(wdev->hdc, iw, ih);
				HBITMAP hBitmapOld = SelectObject(hdcMem, hBitmap);
				code = SetDIBitsToDevice(hdcMem, ix, iy, iw, ih, ix, iy, 0, ih,
								  pwe->pdib, (BITMAPINFO*)pwe->pbmi, DIB_RGB_COLORS);
				code = TransparentBlt(wdev->hdc, x, y, w, h, hdcMem, ix, iy, iw, ih, WMF_TRANSPARENT_COLOR);
				SelectObject(hdcMem, hBitmapOld);
				DeleteObject(hBitmap);
				DeleteDC(hdcMem);

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "TransparentBlt(hdc, %d, %d, %d, %d,   %d, %d, %d, %d)\n",
							x, y, w, h, ix, iy, iw, ih);
#endif // _DEBUG
			}
			else {
				code = StretchDIBits(wdev->hdc, x, y, w, h, ix, iy, iw, ih,
							  pwe->pdib, (BITMAPINFO*)pwe->pbmi, DIB_RGB_COLORS, SRCCOPY);

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "StretchDIBits(hdc, %d, %d, %d, %d,   %d, %d, %d, %d) return = %d\n",
							x, y, w, h, ix, iy, iw, ih, code);
#endif // _DEBUG
			}
		}

#if defined(_DEBUG) || defined(DEBUG)
		{
			FILE* pFile;
			BITMAPFILEHEADER BMP;
			static nCount = 0;
			char sName[1024];
			int size = DwordAlignWidth(pwe->pbmi->biWidth, pwe->pbmi->biBitCount) * pwe->pbmi->biHeight;
			BMP.bfType = 0x4D42;
			BMP.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + size;
			BMP.bfReserved1 = 0;
			BMP.bfReserved2 = 0;
			BMP.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

			sprintf(sName, "C:\\GhostImageDIBDump%d.bmp", ++nCount);
			pFile = fopen(sName, "wb");
			if ( pFile )
			{
				fwrite(&BMP, 1, sizeof(BITMAPFILEHEADER), pFile);
				fwrite(pwe->pbmi, 1, size, pFile);
				fclose(pFile);
			}
		}
#endif // _DEBUG

		gs_free( pwe->memory, pwe->pbmi, sizeof(BYTE), pwe->pbmi_size, "wmf_end_plane_image" );
	}

	gs_free_object(pwe->memory, info, "wmf_end_plane_image");

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	return 0;
}

private const gx_image_enum_procs_t wmf_image_enum_procs = {
    wmf_image_plane_data, wmf_end_plane_image
};

#if defined(_DEBUG) || defined(DEBUG)
static char* color_space_names[] = { // gscspace.h
	"DeviceGray", "DeviceRGB", "DeviceCMYK", "DevicePixel", "DeviceN",
    "CIEBasedDEFG", "CIEBasedDEF", "CIEBasedABC", "CIEBasedA",
    "Separation", "Indexed", "Pattern", "ICCBased", "None"
};
#endif // _DEBUG

int wmf_begin_image(gx_device *dev, const gs_imager_state * pis, const gs_image_t * pim, gs_image_format_t format,
					const gs_int_rect * prect, const gx_drawing_color * pdcolor, const gx_clip_path * pcpath,
					gs_memory_t * memory, gx_image_enum_common_t **pinfo)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	int code;
	wmf_image_enum *pwe;
	const gs_color_space *pcs = pim->ColorSpace;
	int num_components;

	if (!wdev || !wdev->hdc)
		return 0;

	// gx_image_enum_common_t ����ü ����
    pwe = gs_alloc_struct(memory, wmf_image_enum, &st_wmf_image_enum, "wmf_begin_image");
    if (pwe == 0)
		return_error(gs_error_VMerror);

	if (pim->ImageMask)
		num_components = 1;
	else
		num_components = gs_color_space_num_components(pcs);

	// Ŭ���� ���� ����
	WmfSetClipPath(dev, pcpath, RGN_COPY);

	// �ʿ��� ���� ����
	pwe->memory = memory;
	pwe->pis = pis;
	pwe->pcs = pcs;
	pwe->pcpath = pcpath;
	pwe->image_width = pim->Width;
	pwe->image_height = pim->Height;
	if (pim->ColorSpace)
		pwe->color_space = pim->ColorSpace->type->index;
	else
		pwe->color_space = gs_color_space_index_CIEICC + 1;
	pwe->bits_per_component = pim->BitsPerComponent;
	pwe->num_components = num_components;
	pwe->image_format = format;
	pwe->imagemask = pim->ImageMask;
	pwe->pdcolor = pdcolor;
	pwe->clip_rect.p.x = ftoi(pcpath->outer_box.p.x);
	pwe->clip_rect.p.y = ftoi(pcpath->outer_box.p.y);
	pwe->clip_rect.q.x = ftoi(pcpath->outer_box.q.x);
	pwe->clip_rect.q.y = ftoi(pcpath->outer_box.q.y);
	pwe->prect = prect;
	pwe->pdib = NULL;
	pwe->dib_bits_per_component = 8; // 24bit RGB �̹����� ����
	pwe->dib_num_components = 3;
	pwe->dib_bits_per_pixel = 24;
	pwe->dib_color_format = RGB24;
	pwe->ctm = pis->ctm;
	pwe->ImageMatrix = pim->ImageMatrix;
	pwe->last_height = 0;

	// begin_typed_image
	pwe->type = 0;

	if (prect)
		pwe->last_height = prect->p.y;

	// ����ũ �̹����� ��� Color Space �� DeviceGray �� �ٲ۴�.
	if (pwe->imagemask)
		pwe->color_space = gs_color_space_index_DeviceGray;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_begin_image()==============================================Image\n");
		fprintf(wdev->pFile, "Item Count       : %d\n", wdev->nItems);
		if (format == gs_image_format_chunky)
			fprintf(wdev->pFile, "image format     : chunky\n");
		else if (format == gs_image_format_component_planar)
			fprintf(wdev->pFile, "image format     : component planar\n");
		else if (format == gs_image_format_bit_planar)
			fprintf(wdev->pFile, "image format     : bit planar\n");
		if (prect)
			fprintf(wdev->pFile, "prect            : (%d, %d, %d, %d)\n", prect->p.x, prect->p.y, prect->q.x, prect->q.y);
		fprintf(wdev->pFile, "color            : %08X\n", pdcolor->colors.pure);
		fprintf(wdev->pFile, "width            : %d\n", pim->Width);
		fprintf(wdev->pFile, "height           : %d\n", pim->Height);
		fprintf(wdev->pFile, "BitsPerComponent : %d\n", pim->BitsPerComponent);
		fprintf(wdev->pFile, "Num Component    : %d\n", pwe->num_components);
		fprintf(wdev->pFile, "bInterpolate     : %d\n", pim->Interpolate);
		fprintf(wdev->pFile, "bImageMask       : %d\n", pim->ImageMask);
		fprintf(wdev->pFile, "Color space      : %s(%d)\n", color_space_names[pwe->color_space],pwe->color_space);
		fprintf(wdev->pFile, "Image type       : %d\n", pim->type->index);
	}
#endif // _DEBUG

	// gx_image_enum_common_t ����ü �ʱ�ȭ
	code = gx_image_enum_common_init((gx_image_enum_common_t*)pwe, (const gs_data_image_t *)pim,
									 &wmf_image_enum_procs, dev, num_components, format);
	
	if (code < 0) {
		gs_free_object(memory, pwe, "wmf_begin_image");

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "gx_image_enum_common_init() ����\n");
#endif // _DEBUG

		return code;
	}

	// DIB ������ �޸� �Ҵ�
	if ((((((unsigned long long)pwe->image_width * (unsigned long long)pwe->dib_bits_per_pixel + 7) >> 3) + 3) >> 2) << 2 > UINT_MAX) {
		_ASSERTE(0&&"UINT ���� ���� �ڵ�");
		gs_free_object(memory, pwe, "wmf_begin_image");
		return_error(gs_error_VMerror);
	}
	pwe->dib_byte_width = ((((pwe->image_width * pwe->dib_bits_per_pixel + 7) >> 3) + 3) >> 2) << 2;

	if(sizeof(BITMAPINFOHEADER) + (unsigned long long)pwe->dib_byte_width * (unsigned long long)pwe->image_height > UINT_MAX){
		_ASSERTE(0&&"UINT ���� ���� �ڵ�");
		gs_free_object(memory, pwe, "wmf_begin_image");
		return_error(gs_error_VMerror);

	}
	pwe->pbmi_size = sizeof(BITMAPINFOHEADER) + pwe->dib_byte_width * pwe->image_height;
	pwe->pbmi = (BITMAPINFOHEADER*)gs_malloc( pwe->memory, sizeof(BYTE), pwe->pbmi_size, "wmf_begin_image" );
	
	if (pwe->pbmi == NULL) {
		gs_free_object(memory, pwe, "wmf_begin_image");

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "DIB ������ ������ ���� gs_malloc() ����\n");
#endif // _DEBUG

		return_error(gs_error_VMerror);
	}

	pwe->pdib = (BYTE*)(pwe->pbmi) + sizeof(BITMAPINFOHEADER);

	*pinfo = (gx_image_enum_common_t*)pwe;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	wdev->nItems++;

	return 0;
}

int wmf_begin_typed_image(gx_device *dev, const gs_imager_state *pis, const gs_matrix *pmat,
						  const gs_image_common_t *pim, const gs_int_rect *prect, const gx_drawing_color *pdcolor,
						  const gx_clip_path *pcpath, gs_memory_t *memory, gx_image_enum_common_t **pinfo)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	int code;
	wmf_image_enum *pwe;

	if (!wdev || !wdev->hdc)
		return 0;

	// fill_rectangle() ���� �����͸� ��Ƽ� ó���Ѵ�.
	return gx_default_begin_typed_image(dev, pis, pmat, pim, prect, pdcolor, pcpath, memory, pinfo);
}
