﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Type {
	using Int = System.Int32;
	using Index = System.Int32;
	using Frame = System.Double;
	using String = System.String;
	using Bool = System.Boolean;
	using System.ComponentModel;

	// VideoInfo, SoundInfo, SubtitleInfo를 관리 하기 위한 부모 클래스
	public class TimelineInfo : INotifyPropertyChanged {

		#region 멤버변수
		public event PropertyChangedEventHandler PropertyChanged;
		protected Index _id;
		protected FrameScope _timelineScope;
		protected Frame _totalFrame;
		#endregion // 멤버변수

		#region Property
		public Index ID {
			get {
				return _id;
			}
			set {
				_id = value;
			}
		}

		public FrameScope TimelineScope {
			get {
				return _timelineScope;
			}
			set {
				_timelineScope = value.Clone();
			}
		}

		public Frame TotalFrame {
			get {
				return _totalFrame;
			}
			set {
				_totalFrame = value;
			}
		}
		#endregion // Property

		#region 생성자
		protected TimelineInfo() {
			_id = -1;
			_timelineScope = FrameScope.Create();
			_totalFrame = 0;
		}

		protected TimelineInfo(Index id, FrameScope timelineScope, Frame totalFrame) {
			_id = id;
			_timelineScope = timelineScope.Clone();
			_totalFrame = totalFrame;
		}

		protected TimelineInfo(TimelineInfo other) {
			_id = other._id;
			_timelineScope = other._timelineScope.Clone();
			_totalFrame = other._totalFrame;
		}
		#endregion // 생성자

		#region Create
		public static TimelineInfo Create() {
			return new TimelineInfo();
		}

		public static TimelineInfo Create(Index id, FrameScope timelineScope, Frame totalFrame) {
			return new TimelineInfo(id, timelineScope, totalFrame);
		}

		public static TimelineInfo Create(TimelineInfo other) {
			return new TimelineInfo(other);
		}

		public virtual TimelineInfo Clone() {
			return new TimelineInfo(this);
		}
		#endregion // Create

		#region override
		public override Bool Equals(System.Object obj) {
			TimelineInfo other = obj as TimelineInfo;

			if (other == null) {
				return false;
			}

			if (_id != other._id) {
				return false;
			}

			if (_totalFrame != other._totalFrame) {
				return false;
			}

			if (_timelineScope != other._timelineScope) {
				return false;
			}

			return true;
		}

		public override Int GetHashCode() {
			return this.GetHashCode();
		}
		#endregion // override

		#region event
		public virtual void Copy(TimelineInfo other) {
			_id = other._id;
			_timelineScope = other._timelineScope.Clone();
			_totalFrame = other._totalFrame;

			OnPropertyCahnged(ID.ToString());
		}

		protected void OnPropertyCahnged(String propertyName) {
			var Handler = PropertyChanged;

			if (Handler != null) {
				Handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}
		#endregion // event
	}
}