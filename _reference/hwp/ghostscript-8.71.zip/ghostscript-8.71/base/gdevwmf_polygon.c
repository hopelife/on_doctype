#include "gdevwmf.h"
#include "gdevwmf_.h"

int wmf_draw_thin_line(gx_device *dev, fixed fx0, fixed fy0, fixed fx1, fixed fy1,
					   const gx_drawing_color *pdcolor, gs_logical_operation_t lop)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	COLORREF crColor;

	if (!wdev || !wdev->hdc)
		return 0;
	if (!wdev->bRecord)
		return 0;

	crColor = MakeColorRef(pdcolor->colors.pure);
	wmf_change_pen(dev, 1, crColor);
	MoveToEx(wdev->hdc, ftoi(fx0), ftoi(fy0), NULL);
	LineTo(wdev->hdc, ftoi(fx1), ftoi(fy1));

	wdev->nItems++;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_draw_thin_line()=============polygon\n");
		fprintf(wdev->pFile, "(%d, %d)-(%d, %d)\n", ftoi(fx0), ftoi(fy0), ftoi(fx1), ftoi(fy1));
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	return 0;
}
