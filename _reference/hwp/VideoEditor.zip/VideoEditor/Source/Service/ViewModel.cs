﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Service {
	using String = System.String;
	using Hnc.VideoEditor.Engine;
	using System.ComponentModel;
	using System.Collections.Generic;

	public class ViewModel : ViewModelBase {
		private Timeline _timeline;

		public ViewModel() {
			_timeline = MarkerUtil.GetMarker().Doc.Timeline;
			_timeline.PropertyChanged += new PropertyChangedEventHandler(TimelineInfo_PropertyChanged);
		}

		private void TimelineInfo_PropertyChanged(object sender, PropertyChangedEventArgs e) {
			OnPropertyCahnged(e.PropertyName);
		}
	}
}