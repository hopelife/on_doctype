﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {
    // 왼쪽상단에 -1을 적용하고 오른쪽 하단에 1을 적용하여 엠보싱효과를 주는 필터
    // -1, -1, 0
    // -1, 1,  1
    // 0,  1,  1
    // 을 사용하는 Convolution이나 속도향상을 위해 직접 계산한다. 불필요한 곱하기가 생략되어 속도가 빠르다.
    public class Emboss {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Emboss() {

        }
        public static Emboss Create() {

            return new Emboss();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            ArgbChannel target = ArgbChannel.Create(pixels.Width, pixels.Height);

            Int width = pixels.Width;
            Int height = pixels.Height;
  
            Int a = 0;
            Int r = 0;
            Int g = 0;
            Int b = 0;
            Index targetPixelPos = 0;
            Index leftTop;
            Index left;
            Index top;
            Index right;
            Index bottom;
            Index rightBottom;

            Index curLineStartPos = 0;

            for (Index y = 0; y < height; ++y) {

                if (y == 0) {
                    top = 0;
                }
                else {
                    top = curLineStartPos - width;
                }
                if (y == (height - 1)) {
                    bottom = curLineStartPos;
                }
                else {
                    bottom = curLineStartPos + width;
                }

                for (Index x = 0; x < width; ++x) {

                    a = 0;
                    r = 0;
                    g = 0;
                    b = 0;

                    if (x == 0) {
                        left = targetPixelPos;
                        leftTop = top;
                    }
                    else { 
                        left = targetPixelPos - 1;
                        leftTop = top - 1;
                    }

                    if (x == (width - 1)) {
                        right = targetPixelPos;
                        rightBottom = bottom;
                    }
                    else {
                        right = targetPixelPos + 1;
                        rightBottom = bottom + 1;
                    }
                    

                    // 왼쪽상단
                    a -= pixels.A[leftTop];
                    r -= pixels.R[leftTop];
                    g -= pixels.G[leftTop];
                    b -= pixels.B[leftTop];


                    // 위
                    a -= pixels.A[top];
                    r -= pixels.R[top];
                    g -= pixels.G[top];
                    b -= pixels.B[top];

                    // 왼쪽
                    a -= pixels.A[left];
                    r -= pixels.R[left];
                    g -= pixels.G[left];
                    b -= pixels.B[left];

                    // 자기자신
                    a += pixels.A[targetPixelPos];
                    r += pixels.R[targetPixelPos];
                    g += pixels.G[targetPixelPos];
                    b += pixels.B[targetPixelPos];

                    // 오른쪽
                    a += pixels.A[right];
                    r += pixels.R[right];
                    g += pixels.G[right];
                    b += pixels.B[right];

                    // 아래
                    a += pixels.A[bottom];
                    r += pixels.R[bottom];
                    g += pixels.G[bottom];
                    b += pixels.B[bottom];


                    // 오른쪽하단
                    a += pixels.A[rightBottom];
                    r += pixels.R[rightBottom];
                    g += pixels.G[rightBottom];
                    b += pixels.B[rightBottom];


                    a = (a < 0) ? 0 : ((255 < a) ? 255 : a);
                    r = (r < 0) ? 0 : ((255 < r) ? 255 : r);
                    g = (g < 0) ? 0 : ((255 < g) ? 255 : g);
                    b = (b < 0) ? 0 : ((255 < b) ? 255 : b);

                    target.A[targetPixelPos] = (Byte)a;
                    target.R[targetPixelPos] = (Byte)r;
                    target.G[targetPixelPos] = (Byte)g;
                    target.B[targetPixelPos] = (Byte)b;


                    ++targetPixelPos;
                    ++top;
                    ++bottom;

                }
                curLineStartPos += width;
            }

            pixels.A = target.A;
            pixels.R = target.R;
            pixels.G = target.G;
            pixels.B = target.B;

        }
    }
}