#include "gdevwmf.h"
#include "gdevwmf_.h"
