﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.VideoEditor.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hnc.VideoEditor.Appbar {
    /// <summary>
    /// MessageBoxAppbar.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MessageBoxAppbar : Grid {

        private CustomDialog customDialog = null;

        public CustomDialog _CustomDialog {
            get {
                return customDialog;
            }
            set {
                customDialog = value;
            }
        }

        public MessageBoxAppbar() {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e) {
            _CustomDialog.Result = CustomDialog.ResultType.OK;
            _CustomDialog.Close();
        }

        private void Button2_Click(object sender, RoutedEventArgs e) {
            _CustomDialog.Result = CustomDialog.ResultType.NO;
            _CustomDialog.Close();
        }

        private void Button3_Click(object sender, RoutedEventArgs e) {
            _CustomDialog.Result = CustomDialog.ResultType.CANCEL;
            _CustomDialog.Close();
        }

        public void ChangeMeesageBoxType(string message, string button1, string button2, string button3) {
            Message.Text = message;

            Button1.Content = button1;

            if (button2 == "") {
                Button2.Visibility = System.Windows.Visibility.Collapsed;
            } else {
                Button2.Content = button2;
                Button2.Visibility = System.Windows.Visibility.Visible;
            }

            if (button3 == "") {
                Button3.Visibility = System.Windows.Visibility.Collapsed;
            } else {
                Button3.Content = button3;
                Button2.Visibility = System.Windows.Visibility.Visible;
            }

        }
    }
}
