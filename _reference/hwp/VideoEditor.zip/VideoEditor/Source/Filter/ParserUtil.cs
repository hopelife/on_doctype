﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.VideoEditor.Base.Enum;

namespace Hnc.VideoEditor.Filter{
    public static class ParserUtil {
        public static IParser Create(ParserOption parserOption) {
            IParser filter = null;

            switch (parserOption) {
                case ParserOption.XML:
                    filter = new XMLParser();
#if DEBUG
                    Debug.Assert(filter != null, "XMLParser를 생성하지 못하였습니다.");
#endif
                    break;
            }

            return filter;
        }
    }
}
