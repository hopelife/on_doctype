﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows;
using System.Collections.Generic;

namespace Hnc.Instrument {

    public class VideoUtil {

		private static List<string> possibleVideoCodecs = new List<string>();
		private static List<string> possibleAudioCodecs = new List<string>();

        private static VideoCLI videoCLI = null;



		public static string IsPossibleVideoCodec(string filePath) {
			if (possibleVideoCodecs.Count == 0) {
				possibleVideoCodecs.Add("msvideo1");
				possibleVideoCodecs.Add("vc1");
				possibleVideoCodecs.Add("msmpeg4");
				possibleVideoCodecs.Add("msmpeg4v1");
				possibleVideoCodecs.Add("msmpeg4v2");
				possibleVideoCodecs.Add("msmpeg4v3");
				possibleVideoCodecs.Add("wmv1");
				possibleVideoCodecs.Add("wmv2");
				possibleVideoCodecs.Add("wmv3");
				possibleVideoCodecs.Add("h264");
				possibleVideoCodecs.Add("mpeg4");
			}

			VideoContentInfo info = GetVideoContentInfo(filePath);

			foreach(string codecName in possibleVideoCodecs) {
				if (info.VideoCodec == codecName) {
					return null;
				}
			}

			return info.VideoCodec;
		}

		public static string IsPossibleAudioCodec(string filePath) {
			if (possibleAudioCodecs.Count == 0) {
				possibleAudioCodecs.Add("wmalossless");
			}

			VideoContentInfo info = GetVideoContentInfo(filePath);

			foreach (string codecName in possibleAudioCodecs) {
				if (info.AudioCodec == codecName) {
					return info.AudioCodec;
				}
			}

			return null;
		}

        public static double GetFrameRate(string filePath) {
            VideoContentInfo info = GetVideoContentInfo(filePath);
            return info.FrameRate;
        }

        public static VideoContentInfo GetVideoContentInfo(string filePath) {

            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            VideoContentInfo info = null;

            if (videoCLI.GetVideoInfo(filePath) > 0) {
                info = new VideoContentInfo();

                info.FilePath = videoCLI.GetVideoInfoFilePath();
                info.FileName = videoCLI.GetVideoInfoFileName();
                info.Width = videoCLI.GetVideoInfoWidth();
                info.Height = videoCLI.GetVideoInfoHeight();
                info.FrameRate = videoCLI.GetVideoInfoFrameRate();
                info.TotalFrame = videoCLI.GetVideoInfoTotalFrame();
                info.RunningTime = videoCLI.GetVideoInfoRunningTime();
                info.ModifyDate = videoCLI.GetVideoInfoModifyDate();
                info.VideoCodec = videoCLI.GetVideoInfoVideoCodec();
                info.AudioCodec = videoCLI.GetVideoInfoAudioCodec();
            }

            return info;
        }

        public static ImageSource GetVideoAutoThumbnail(string path, int width, int height) {
			try {
				if (videoCLI == null) {
					videoCLI = new VideoCLI();
				}

				System.Drawing.Bitmap bitmap = null;

				bitmap = videoCLI.GetThumbnail(path, width, height);

				if (bitmap == null) {
					return null;
				}

				return BitmapToBitmapImage(bitmap);
			} catch {
				return null;
			}
        }

		public static double GetEstimateTime(string path, int width, int height) {
			if (videoCLI == null) {
				videoCLI = new VideoCLI();
			}

			return videoCLI.GetEstimateTime(path, width, height);
		}

        public static ImageSource GetVideoThumbnail(string path, int frame, int width, int height) {

            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            System.Drawing.Bitmap bitmap = null;

            bitmap = videoCLI.GetThumbnail(path, frame, width, height);

            if (bitmap == null) {
                return null;
            }

            return BitmapToBitmapImage(bitmap);
        }

        public static void NewTimeline() {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            videoCLI.NewTimeline();
        }

        public static int AddTimelineInfo(string path, int effect, int startFrame, int endFrame) {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.AddTimelineInfo(path, effect, startFrame, endFrame);
        }

        public static int CreateOutputfileInfo(string outputFilePath, int width, int height, int frameRate, int videoCodecID, int audioCodecID) {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.CreateOutputfileInfo(outputFilePath, width, height, frameRate, videoCodecID, audioCodecID);
        }

        public static int Export() {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.Export();
        }

		public static int ExportEx() {
			if (videoCLI == null) {
				videoCLI = new VideoCLI();
			}

			return videoCLI.ExportEx();
		}

		public static int ExportCancel() {
			if (videoCLI == null) {
				videoCLI = new VideoCLI();
			}

			videoCLI.SetExportIsCancel(true);

			return 1;
		}

        public static int DeleteOutputfileInfo() {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.DeleteOutputfileInfo();
        }

        public static int GetExportState() {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.GetExportState();
        }

        public static void SetExportState(int state) {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            videoCLI.SetExportState(state);
        }

        public static int GetExportProgress() {
            if (videoCLI == null) {
                videoCLI = new VideoCLI();
            }

            return videoCLI.GetExportProgress();
        }

        #region -> Private Methods

        private static BitmapImage BitmapToBitmapImage(System.Drawing.Bitmap source) {
            
            if (source == null) {
                return null;
            }

            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            source.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            ms.Position = 0;

            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
            bi.StreamSource = ms;
            bi.EndInit();
            bi.Freeze();

            return bi;
        }

        #endregion
    }
}
