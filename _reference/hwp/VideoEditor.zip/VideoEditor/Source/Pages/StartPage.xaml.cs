﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using Hnc.Control;
using Hnc.VEFrame;
using System;
using Hnc.VideoEditor.Util;
using System.IO;

namespace Hnc.VideoEditor.Pages {
    /// <summary>
    /// 동영상 편집기의 시작 화면입니다.
    /// </summary>
    public partial class StartPage : Grid {

        private static readonly string[] HvwExtension = { ".hvw", ".xml" };

        public StartPage() {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(StartPage_Loaded);
        }

        private void StartPage_Loaded(object sender, RoutedEventArgs e) {
            // Version.Major
            // 4: Windows95, Windows98, WindowsMe
            // 5: WindowsServer2000, WindowsXP, WindowsServer2003
            // 6: WindowsServer2008, Windows7
            if (Environment.OSVersion.Version.Major < 6) {
                AppDialog dlg = new AppDialog(StringManager.GetString("IDS_RequiredEnvironment"),
                    StringManager.GetString("IDS_Message_06"),                    
                    StringManager.GetString("IDS_Close"));

                dlg.ShowDialog();
                Application.Current.Shutdown();
            }
        }    

        private void loadWorkingSet_Click(object sender, RoutedEventArgs e) {

            // 동영상 편집 작업 파일 열기
            FileDialog filePage = new FileDialog(FileDialog.Mode.SingleOpen, HvwExtension, SetupManager.Instance.LastOpendDirectory);

            if (filePage.ShowDialog() == true) {
                SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;

                if (filePage.SelectedPaths.Count != 0) {
					if (VEFrameManager.Instance.MainPage.LoadFile(filePage.SelectedPaths[0]) == true) {
						// 메인 페이지로 페이지 변경
						VEFrameManager.Instance.GoMainPage();
					}
                }
            }

            System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);
        }

        private void createNew_Click(object sender, RoutedEventArgs e) {

            // 편집할 동영상 소스 열기
            FileDialog filePage = new FileDialog(FileDialog.Mode.Open, FileDialog.VideoExtentions, SetupManager.Instance.LastOpendDirectory);

            if (filePage.ShowDialog() == true) {
                SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;

                if (filePage.SelectedPaths.Count != 0) {
                    //VEFrameManager.Instance.MainPage.SetSelectedItems(filePage.SelectedPaths);
					//VEFrameManager.Instance.MainPage.AddSourceFile(filePage.SelectedPaths);
					
                    // 메인 페이지로 페이지 변경
                    VEFrameManager.Instance.GoMainPage();
                }
            }

            System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);
        }
    }
}
