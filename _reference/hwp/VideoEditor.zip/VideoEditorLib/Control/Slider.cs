﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace Hnc.Control
{
	public class Slider : System.Windows.Controls.Slider
	{
		static Slider()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(Slider), new FrameworkPropertyMetadata(typeof(Slider)));
		}

		private double fromValue = double.NaN;
        protected bool isAnimationCheck;
		protected bool isSliderCheck;

		public Slider()
		{
			isAnimationCheck = false;
			isSliderCheck = false;
		}

		protected override void OnValueChanged(double oldValue, double newValue)
		{
			if (isAnimationCheck == true || isSliderCheck == true)
			{
				if (isAnimationCheck == true)
				{
					if (this.HasAnimatedProperties)
						return;

					if (!AnimationEnabled)
					{
						isAnimationCheck = false;
						isSliderCheck = false;
						base.OnValueChanged(oldValue, newValue);
						RaiseEvent(new RoutedEventArgs(ClickEvent, this));
						return;
					}

					if (oldValue < newValue)
					{
						if (oldValue < Value)
							fromValue = oldValue;
						else
							fromValue = Value;
					}
					else
					{
						if (oldValue < Value)
							fromValue = Value;
						else
							fromValue = oldValue;
					}

					DoubleAnimation anim = new DoubleAnimation(fromValue, newValue, TimeSpan.FromMilliseconds(200));
					anim.AccelerationRatio = 0.8;
					anim.DecelerationRatio = 0.2;
					anim.Completed += new EventHandler(anim_Completed);
					this.BeginAnimation(Slider.ValueProperty, anim);
				}

				if(isSliderCheck == true)
				{
					isSliderCheck = false;
					base.OnValueChanged(oldValue, newValue);
					RaiseEvent(new RoutedEventArgs(ClickEvent, this));
				}
			}
			base.OnValueChanged(oldValue, newValue);
		}

		protected override void OnPreviewMouseLeftButtonDown(System.Windows.Input.MouseButtonEventArgs e)
		{
			isAnimationCheck = true;

			base.OnPreviewMouseLeftButtonDown(e);
		}

		protected override void OnThumbDragStarted(System.Windows.Controls.Primitives.DragStartedEventArgs e)
		{
			isSliderCheck = true;

			base.OnThumbDragStarted(e);
		}

		protected override void OnThumbDragDelta(System.Windows.Controls.Primitives.DragDeltaEventArgs e)
		{
			isSliderCheck = true;

			base.OnThumbDragDelta(e);
		}

		protected override void OnThumbDragCompleted(System.Windows.Controls.Primitives.DragCompletedEventArgs e)
		{
			isSliderCheck = true;

			base.OnThumbDragCompleted(e);
		}

		void anim_Completed(object sender, EventArgs e)
		{
			isAnimationCheck = false;
			isSliderCheck = true;

			this.BeginAnimation(Slider.ValueProperty, null);

			OnValueChanged(fromValue, Value);
		}

		#region Properties

		public static readonly DependencyProperty AnimationEnabledProperty =
			DependencyProperty.Register(
				"AnimationEnabled",
				typeof(bool),
				typeof(Slider),
				new PropertyMetadata(true)
			);

		public bool AnimationEnabled
		{
			get { return (bool)GetValue(AnimationEnabledProperty); }
			set
			{
				SetValue(AnimationEnabledProperty, value);

				if (!value && this.HasAnimatedProperties)
				{
					this.BeginAnimation(Slider.ValueProperty, null);
				}
			}
		}

		#endregion

		#region Events

		public static readonly RoutedEvent ClickEvent =
			EventManager.RegisterRoutedEvent(
				"Click",
				RoutingStrategy.Bubble,
				typeof(RoutedEventHandler),
				typeof(FlexibleTabItem)
			);

		public event RoutedEventHandler Click
		{
			add { AddHandler(ClickEvent, value); }
			remove { RemoveHandler(ClickEvent, value); }
		}

		#endregion
	}
}
