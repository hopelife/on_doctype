﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Input;

namespace Hnc.Control {
    
    /// <summary>
    /// FrameworkElement에 속성을 추가하기 위한 확장 클래스입니다.
    /// </summary>
    public class FrameworkElementExt {
        public static readonly DependencyProperty IsPressedProperty =
            DependencyProperty.RegisterAttached("IsPressed", typeof(bool), typeof(FrameworkElementExt), new PropertyMetadata(false));

        public static readonly DependencyProperty AttachIsPressedProperty =
            DependencyProperty.RegisterAttached("AttachIsPressed", typeof(bool), typeof(FrameworkElementExt), new PropertyMetadata(false, PropertyChangedCallback));

        public static void PropertyChangedCallback(DependencyObject depObj, DependencyPropertyChangedEventArgs args) {
            FrameworkElement element = (FrameworkElement)depObj;
            if (element != null) {
                if ((bool)args.NewValue) {
                    element.MouseDown += new MouseButtonEventHandler(element_MouseDown);
                    element.MouseUp += new MouseButtonEventHandler(element_MouseUp);
                    element.MouseLeave += new MouseEventHandler(element_MouseLeave);
                } else {
                    element.MouseDown -= new MouseButtonEventHandler(element_MouseDown);
                    element.MouseUp -= new MouseButtonEventHandler(element_MouseUp);
                    element.MouseLeave -= new MouseEventHandler(element_MouseLeave);
                }
            }
        }

        public static bool GetIsPressed(UIElement element) {
            return (bool)element.GetValue(IsPressedProperty);
        }

        public static void SetIsPressed(UIElement element, bool val) {
            element.SetValue(IsPressedProperty, val);
        }

        public static bool GetAttachIsPressed(UIElement element) {
            return (bool)element.GetValue(AttachIsPressedProperty);
        }

        public static void SetAttachIsPressed(UIElement element, bool val) {
            element.SetValue(AttachIsPressedProperty, val);
        }

        private static void element_MouseLeave(object sender, MouseEventArgs e) {
            FrameworkElement element = (FrameworkElement)sender;
            if (element != null) {
                element.SetValue(IsPressedProperty, false);
            }
        }

        private static void element_MouseUp(object sender, MouseButtonEventArgs e) {
            FrameworkElement element = (FrameworkElement)sender;
            if (element != null) {
                element.SetValue(IsPressedProperty, false);
            }
        }

        private static void element_MouseDown(object sender, MouseButtonEventArgs e) {
            FrameworkElement element = (FrameworkElement)sender;
            if (element != null) {
                element.SetValue(IsPressedProperty, true);
            }
        }
    }   
}