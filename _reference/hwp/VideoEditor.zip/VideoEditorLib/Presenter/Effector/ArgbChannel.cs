﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Ratio = System.Single;
using Index = System.Int32;
using Byte = System.Byte;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    public class ArgbChannel {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Byte[] A;
        public Byte[] R;
        public Byte[] G;
        public Byte[] B;

        public Count Width { get; private set; }
        public Count Height { get; private set; }
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private ArgbChannel(Count width, Count height) {

            A = new Byte[width * height];
            R = new Byte[width * height];
            G = new Byte[width * height];
            B = new Byte[width * height];

            Width = width;
            Height = height;
        }
        private ArgbChannel(ArgbChannel other) {
            Debug.AssertThrow(other != null, eErrorCode.NullArgument);

            A = new Byte[other.A.Length];
            R = new Byte[other.R.Length];
            G = new Byte[other.G.Length];
            B = new Byte[other.B.Length];
            
            other.A.CopyTo(this.A, 0);
            other.R.CopyTo(this.R, 0);
            other.G.CopyTo(this.G, 0);
            other.B.CopyTo(this.B, 0);

            Width = other.Width;
            Height = other.Height;
        }

        public static ArgbChannel Create(Count width, Count height) {
            return new ArgbChannel(width, height);
        }
        public static ArgbChannel Create(Pixels pixels) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(pixels.Data.Length != 0, eErrorCode.NullArgument);
          
            ArgbChannel result = Create(pixels.Width, pixels.Height);
            
            for (Index i = 0; i < pixels.Data.Length; ++i) {
                result.A[i] = (Byte)((pixels.Data[i] >> 24) & 0XFF);
                result.R[i] = (Byte)((pixels.Data[i] >> 16) & 0XFF);
                result.G[i] = (Byte)((pixels.Data[i] >> 8) & 0XFF);
                result.B[i] = (Byte)((pixels.Data[i]) & 0XFF);

            }
            return result;
        }

        public ArgbChannel Clone() {

            return new ArgbChannel(this);
        }
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        public Pixel[] ToPixels() {
            Debug.Assert(A != null && R != null && G != null && B != null);

            Pixel[] result = new Pixel[A.Length];
            for (Index i = 0; i < A.Length; ++i) {
                result[i] = (Pixel)((A[i] << 24) | (R[i] << 16) | (G[i] << 8) | B[i]);
            }
            return result;
        }
    }
}
