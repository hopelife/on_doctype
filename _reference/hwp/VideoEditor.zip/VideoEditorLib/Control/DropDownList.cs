﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Hnc.Control {
    public class DropDownListItem : System.Windows.Controls.ComboBoxItem {

        public DropDownListItem() {
        }

        public DropDownListItem(String text, object tag) {
            this.Text = text;
            this.Tag = tag;
        }


        #region -> Properties

        public String Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(DropDownListItem), new PropertyMetadata(string.Empty));

        #endregion
    }

    public class DropDownList : System.Windows.Controls.ComboBox {
        private Popup popup;
        private Grid grid;

        private int lastSelectedIndex = -1;

        #region -> Constructor

        static DropDownList() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(DropDownList), new FrameworkPropertyMetadata(typeof(DropDownList)));
        }

        #endregion

        #region -> Properties

        /// <summary>
        /// 선택된 아이템의 캡션입니다.
        /// </summary>
        public String SelectedText {
            get { return (string)GetValue(SelectedTextProperty); }
            set { SetValue(SelectedTextProperty, value); }
        }

        /// <summary>
        /// 선택된 아이템의 Tag 속성에 셋팅된 값입니다.
        /// </summary>
        public new object SelectedValue {
            get { return (object)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        /// <summary>
        /// DropDownList의 표시 상태를 설정하거나 가져옵니다.
        /// </summary>
        public bool IsOpen {
            get {
                return IsDropDownOpen;
            }
            set {
                if (popup != null) {
                    IsDropDownOpen = value;
                    popup.VerticalOffset = (SelectedIndex + 1) * -Height;
                }
            }
        }

        public static readonly DependencyProperty SelectedTextProperty =
            DependencyProperty.Register("SelectedText", typeof(string), typeof(DropDownList), new PropertyMetadata(string.Empty));

        public static readonly new DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(object), typeof(DropDownList), new PropertyMetadata(null));

        #endregion

        #region -> Overrided Methods

        public override void OnApplyTemplate() {
            popup = GetTemplateChild("Popup") as Popup;
            Debug.Assert(popup != null);
            popup.Closed += new EventHandler(popup_Closed);

            grid = GetTemplateChild("Grid") as Grid;
            Debug.Assert(grid != null);
            grid.MouseDown += new System.Windows.Input.MouseButtonEventHandler(grid_MouseDown);
            grid.MouseUp += new System.Windows.Input.MouseButtonEventHandler(grid_MouseUp);

            base.OnApplyTemplate();
        }        

        private void popup_Closed(object sender, EventArgs e) {

            // 같은 아이템을 선택할 경우에도 선택이벤트가 발생하도록 강제함
            if (lastSelectedIndex == SelectedIndex) {
                SelectedItem = null;
                SelectedIndex = lastSelectedIndex;
            }

            lastSelectedIndex = SelectedIndex;
        }

        private void grid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            // popup 오픈 상태에서 다른 앱으로 포커스가 넘어갈 경우 
            // popup이 StaysOpen 속성에 의해 자동으로 닫히지만 다시 열리지는 않는 버그가 있어서 추가한 코드
            popup.StaysOpen = false;
            IsOpen = false;
        }

        private void grid_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            popup.StaysOpen = true;
            IsOpen = true;

            e.Handled = true;
        }

        protected override void OnSelectionChanged(SelectionChangedEventArgs e) {

            if (SelectedItem != null) {

                DropDownListItem item = SelectedItem as DropDownListItem;
                Debug.Assert(item != null);

                String text = item.Text as String;
                Debug.Assert(text != null);

                SelectedText = text;
                SelectedValue = item.Tag;

                // 선택 팝업이 아직 사용되지 않았을 경우에도 미리 마지막 인덱스를 저장해둬야 
                // popup_Closed에서 정상적인 처리를 할 수 있음
                if (popup == null)
                    lastSelectedIndex = SelectedIndex;
            }

            IsOpen = false;

            base.OnSelectionChanged(e);
        }

        #endregion
    }
}
