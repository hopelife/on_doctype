﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;


namespace Hnc.Control
{

    public class ToolTip : System.Windows.Controls.ToolTip
    {
        static ToolTip()
		{

            DefaultStyleKeyProperty.OverrideMetadata(typeof(ToolTip), new FrameworkPropertyMetadata(typeof(ToolTip)));            
		   
		}

        public ToolTip()
        {
            Opened += new RoutedEventHandler(ToolTip_Opened); 
            Closed += new RoutedEventHandler(ToolTip_Closed);
        }

        IInputElement focusedElement;
        void ToolTip_Opened(object sender, RoutedEventArgs e)
        {

            if (HelpPath != null)
            {
                focusedElement = Keyboard.FocusedElement;
                if (focusedElement != null)
                {
                    focusedElement.PreviewKeyDown += new KeyEventHandler(focusedElement_PreviewKeyDown);
                }
            }
        }

        void ToolTip_Closed(object sender, RoutedEventArgs e)
        {
            if (focusedElement != null)
            {
                focusedElement.PreviewKeyDown -= focusedElement_PreviewKeyDown;
                focusedElement = null;
            }
        }

        void focusedElement_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                e.Handled = true;
                System.Diagnostics.Process.Start((string)HelpPath);
            }
        }  

        // 속성 정의
        #region Properties

        public string TitleText
        {
            get { return (string)GetValue(TitleTextProperty); }
            set { SetValue(TitleTextProperty, value); }
        }

        public static readonly DependencyProperty TitleTextProperty =
            DependencyProperty.Register(
                "TitleText",
                typeof(string),
                typeof(ToolTip),
                new PropertyMetadata("")
            );

        //public Visibility TitleTextVisibility
        //{
        //    get { return (Visibility)GetValue(TitleTextVisibilityProperty); }
        //    set { SetValue(TitleTextVisibilityProperty, value); }
        //}

        //public static readonly DependencyProperty TitleTextVisibilityProperty =
        //    DependencyProperty.Register(
        //        "TitleTextVisibility",
        //        typeof(Visibility),
        //        typeof(ToolTip),
        //        new PropertyMetadata(Visibility.Visible)
        //    );

        public string ImageSource
        {
            get { return (string)GetValue(ImageSourceProperty); }
            set { SetValue(ImageSourceProperty, value); }
        }

        public static readonly DependencyProperty ImageSourceProperty =
            DependencyProperty.Register(
                "ImageSource",
                typeof(string),
                typeof(ToolTip),
                new PropertyMetadata("")
            );

        public Visibility ImageVisibility
        {
            get { return (Visibility)GetValue(ImageVisibilityProperty); }
            set { SetValue(ImageVisibilityProperty, value); }
        }

        public static readonly DependencyProperty ImageVisibilityProperty =
            DependencyProperty.Register(
                "ImageVisibility",
                typeof(Visibility),
                typeof(ToolTip),
                new PropertyMetadata(Visibility.Visible)
            );
 
        public string BodyText
        {
            get { return (string)GetValue(BodyTextProperty); }
            set { SetValue(BodyTextProperty, value); }
        }

        public static readonly DependencyProperty BodyTextProperty =
            DependencyProperty.Register(
                "BodyText",
                typeof(string),
                typeof(ToolTip),
                new PropertyMetadata("")
            );

        public Visibility HelpSectionVisibility
        {
            get { return (Visibility)GetValue(HelpSectionVisibilityProperty); }
            set { SetValue(HelpSectionVisibilityProperty, value); }
        }

        public static readonly DependencyProperty HelpSectionVisibilityProperty =
            DependencyProperty.Register(
                "HelpSectionVisibility",
                typeof(Visibility),
                typeof(ToolTip),
                new PropertyMetadata(Visibility.Visible)
            );

        public string HelpImageSource
        {
            get { return (string)GetValue(HelpImageSourceProperty); }
            set { SetValue(HelpImageSourceProperty, value); }
        }

        public static readonly DependencyProperty HelpImageSourceProperty =
            DependencyProperty.Register(
                "HelpImageSource",
                typeof(string),
                typeof(ToolTip),
                new PropertyMetadata("")
            );

        public string HelpText
        {
            get { return (string)GetValue(HelpTextProperty); }
            set { SetValue(HelpTextProperty, value); }
        }

        public static readonly DependencyProperty HelpTextProperty =
            DependencyProperty.Register(
                "HelpText",
                typeof(string),
                typeof(ToolTip),
                new PropertyMetadata("")
            );

        public object HelpPath
        {
            get { return (object)GetValue(HelpPathProperty); }
            set { SetValue(HelpPathProperty, value); }
        }

        public static readonly DependencyProperty HelpPathProperty =
            DependencyProperty.Register(
                "HelpPath",
                typeof(object),
                typeof(ToolTip),
                new UIPropertyMetadata(null)
            );

        #endregion
    }    
}
