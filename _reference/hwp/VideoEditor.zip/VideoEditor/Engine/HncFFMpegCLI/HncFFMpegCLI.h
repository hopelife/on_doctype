// HncFFMpegCLI.h

#pragma once

using namespace System;

class HncFFMpegLib;

namespace Hnc {
	namespace VideoEditor {
		namespace Engine {
			public ref class HncFFMpegCLI
			{
			protected:
				static int^ index;
				HncFFMpegLib* hncFFMpegLib;

			public:
				HncFFMpegCLI();
				virtual ~HncFFMpegCLI();	

				void SetName(int^ i);
				int GetName();

				void ChangeName();
				
				Drawing::Bitmap^ GetThumnail(System::String^ filePath, int frameIndex);
				Drawing::Bitmap^ GetThumnail(System::String^ filePath, int frameIndex, int width, int height);
				void Export(System::String^ filePath);
				void AddTimelineInfo(System::String^ filePath, int startFrame, int endFrame);
				void NewTimeline();
			};
		}
	}
}
