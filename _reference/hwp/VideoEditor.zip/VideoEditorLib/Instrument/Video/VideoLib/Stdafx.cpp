/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "Type.h"

Int Round(Double d) {
	Int n = (Int) d;
	d = d - n;

	if (d>= 0.5) {
		n++;
	}

	return n;
}