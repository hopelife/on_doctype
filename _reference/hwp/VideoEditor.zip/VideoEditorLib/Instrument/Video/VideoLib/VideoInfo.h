/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once
#include "fileinfo.h"

class VideoInfo : public FileInfo
{
public:
	VideoInfo(const Char* fullFilePath);
	virtual ~VideoInfo();

	Bool IsVideoFile();
	Int GetWidth();
	Int GetHeight();
	Double GetFrameRate();
	Int64_t GetTotalFrame();
	TimeInfo GetRunningTime();
	const Char* GetVideoCodec();
	const Char* GetAudioCodec();

	Bool GetVideoInfo(VideoInfoStruct* info);

private:
	Bool GetVideoInfo();

	Bool isVideoFile;
	Int width;
	Int height;
	Double frameRate;
	Int64_t totalFrame;
	TimeInfo runningTime;
	Char videoCodecName[MAX_CODEC_NAME];
	Char audioCodecName[MAX_CODEC_NAME];
};
