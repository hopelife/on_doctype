#include "gdevwmf.h"

#define DWORD_ALIGN_WIDTH(width, bits) (((((width) * (bits) + 7) / 8) + 3) / 4 * 4)

// PDF 1.4 �� �̹��� ���� �Ӽ�
const int g_nBitsPerPixel = 24;


/* --- vector procedures --- */ 
const gx_device_vector_procs wmf_vector_procs =
{
	/* Page management */
    NULL, /* beginpage */
	/* Imager state */
    NULL, /* setlinewidth */
    NULL, /* setlinecap */
    NULL, /* setlinejoin */
    NULL, /* setmiterlimit */
    NULL, /* setdash */
    NULL, /* setflat */
    NULL, /* setlogop */
	/* Other state */
    NULL, /* can_handle_hl_color */
    NULL, /* setfillcolors */		/* fill & stroke colors are the same */
    NULL, /* setstrokecolors */
	/* Paths */
    NULL, /* dopath */
    NULL, /* dorect */
    NULL, /* beginpath */
    NULL, /* moveto */
    NULL, /* lineto */
    NULL, /* curveto */
    NULL, /* closepath */
    NULL, /* endpath */
};

/* --- device instance --- */
gx_device_wmf gs_wmf_device = {
	std_device_color_stype_body(gs_wmf_device, 0, "emf", NULL,
								(int)WMF_WIDTH, (int)WMF_HEIGHT, WMF_PIXEL_PER_INCH, WMF_PIXEL_PER_INCH,
								24, 255, 255),
	{
		wmf_open_device,              // open_device
		wmf_get_initial_matrix,       // get_initial_matrix //������ 0913 AI PATH������ ����
		NULL,                         // sync_output
		wmf_output_page,              // output_page
		wmf_close_device,             // close_device
		gx_default_rgb_map_rgb_color, // map_rgb_color
		gx_default_rgb_map_color_rgb, // map_color_rgb
		wmf_fill_rectangle,           // fill_rectangle
		NULL,                         // tile_rectangle
		wmf_copy_mono,                // copy_mono
		wmf_copy_color,               // copy_color
		NULL,                         // draw_line
		wmf_get_bits,				  // get_bits
		wmf_get_params,				  // _params
		wmf_put_params,               // put_params
		wmf_map_cmyk_color,           // map_cmyk_color
	    NULL, // wmf_get_xfont_procs,          // get_xfont_procs
		NULL, // win_get_xfont_device,         // get_xfont_device
		NULL,                         // map_rgb_alpha_color
		wmf_get_page_device,          // gx_page_device_get_page_device
		NULL,                         // get_alpha_bits
		wmf_copy_alpha,               // copy_alpha
		NULL,                         // get_band
		NULL,                         // copy_rop
		wmf_fill_path,                // fill_path
		wmf_stroke_path,              // stroke_path
		NULL,						  // fill_mask
		NULL,                         // fill_trapezoid
		NULL,                         // fill_parallelogram
		NULL,                         // fill_triangle
		wmf_draw_thin_line,			  // draw_thin_line
		wmf_begin_image,			  // begin_image
		
		NULL,//wmf_image_data,        // image_data
		NULL,//wmf_end_image,         // end_image
/* 		wmf_image_data,				  // image_data */
/* 		wmf_end_image,				  // end_image */
		NULL,                         // strip_tile_rectangle
		NULL,                         // strip_copy_rop
		NULL,                         // get_clipping_box
		wmf_begin_typed_image,        // begin_typed_image
		NULL,                         // get_bits_rectangle
		gx_default_map_color_rgb_alpha,	// map_color_rgb_alpha
		wmf_create_compositor,        // create_compositor
		NULL,                         // get_hardware_params
		NULL, // wmf_text_begin,               // text_begin 
		NULL //wmf_finish_copydevice  // finish_copydevice
	},

    vector_initial_values,

	0,       // HDC hdc;
	0,       // HENHMETAFILE hEmf;
	FALSE,   // BOOL bCopied;
	TRUE,   // BOOL bRecord;
    {(float)(WMF_PIXEL_PER_INCH / DEFAULT_PIXEL_PER_INCH),300.0,300.0,(float)(WMF_PIXEL_PER_INCH / DEFAULT_PIXEL_PER_INCH), WMF_WIDTH, WMF_HEIGHT}, // matrix
	0,           // nItems;
	{WMF_DEFAULT_PEN_STYLE, 1, BS_SOLID, RGB(0,0,0), HS_CROSS}, // WMF_GEOMETRIC_PEN pen;
	0,                                   // HPEN hpen_old
	{BS_SOLID, RGB(0,0,0), HS_CROSS},    // LOGBRUSH brush
	0,                                   // HBRUSH hbrush_old
	0,                                   // HFONT hfont_old
/* 	0,                                   // int clip_path_id */
	FALSE,                               // BOOL bShading
	FALSE,								// BOOL bpdf14
	NULL,								// BYTE *pbmi
	NULL,								// HTRANSFORM hTransform;
	wmf_finalize_metafile_data,			// void (*finalize_metafile_data)(gx_device *dev);
	wmf_callback						// int (*callback)(gx_device *dev, int message);

#if defined(_DEBUG) || defined(DEBUG)
	,NULL      // FILE pFile;  ������
#endif // _DEBUG
};

int wmf_create_metafile( gx_device *dev )
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
    HPEN hPen;
	HBRUSH hBrush;
	HDC hdc;
	RECT rect;
	int nHorzSize, nVertSize, nHorzRes, nVertRes;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	// ����̽� �ػ� ������ ��´�.
	hdc = GetDC(NULL);
	nHorzSize = GetDeviceCaps(hdc, HORZSIZE);
	nVertSize = GetDeviceCaps(hdc, VERTSIZE);
	nHorzRes = GetDeviceCaps(hdc, HORZRES);
	nVertRes = GetDeviceCaps(hdc, VERTRES);

	rect.left = 0;
	rect.top = 0;
	rect.right = dev->width * nHorzSize * 100 / nHorzRes;
	rect.bottom = dev->height * nVertSize * 100 / nVertRes;

	// ��Ÿ���� ����
	wdev->hdc = CreateEnhMetaFile( hdc, NULL, &rect, NULL );

	ReleaseDC(NULL, hdc);
	if (!wdev->hdc)
		return gs_error_Fatal;

	// ��Ÿ���� �ʱ�ȭ �۾�
	SaveDC(wdev->hdc);

    SetWindowOrgEx( wdev->hdc, 0, 0, NULL );
    SetWindowExtEx( wdev->hdc, dev->width, dev->height, NULL );

	SetPolyFillMode(wdev->hdc, WINDING);
	SetStretchBltMode(wdev->hdc, HALFTONE);

	// WMF ����̽� ���� �ʱ�ȭ
	hPen = ExtCreatePen(wdev->pen.dwPenStyle, wdev->pen.dwWidth, &wdev->pen.lbBrush, 0, NULL);
	wdev->hpen_old = SelectObject(wdev->hdc, hPen);
	hBrush = CreateBrushIndirect(&wdev->brush);
	wdev->hbrush_old = SelectObject(wdev->hdc, hBrush);

	// PDF 1.4 �� �̹��� ���� �Ҵ�
	if (wdev->bpdf14) {
		int nByteWidth, nDibSize;
		if (wdev->pbmi)
			free(wdev->pbmi);
		nByteWidth = DWORD_ALIGN_WIDTH(dev->width, g_nBitsPerPixel);
		nDibSize = nByteWidth * dev->height;
		{
			unsigned long long total = (unsigned long long)nByteWidth * (unsigned long long)dev->height + (unsigned long long)nDibSize;
			if ( total > UINT_MAX) { 
				_ASSERTE(false&&"UINT_MAX");
				return gs_error_Fatal;
			}
		}
		wdev->pbmi = (BYTE*)malloc(sizeof(BITMAPINFOHEADER) + nDibSize);
		if (wdev->pbmi) {
			BITMAPINFOHEADER *pBmih = (BITMAPINFOHEADER*)wdev->pbmi;
			pBmih->biSize = sizeof(BITMAPINFOHEADER);
			pBmih->biBitCount = g_nBitsPerPixel;
			pBmih->biWidth = dev->width;
			pBmih->biHeight = dev->height;
			pBmih->biPlanes = 1;
			pBmih->biCompression = BI_RGB;
			pBmih->biSizeImage = 0;
			pBmih->biXPelsPerMeter = (long)dev->HWResolution[0];
			pBmih->biYPelsPerMeter = (long)dev->HWResolution[1];
			pBmih->biClrImportant = 0;
			pBmih->biClrUsed = 0;
		}
	}

	return 0;
}


private int
wmf_copy_enh_metafile( gx_device* dev )
{
    int code = 0;
	gx_device_wmf *wdev = (gx_device_wmf*)dev;

	HPEN hPen = NULL;
	HBRUSH hBrush = NULL;

	BYTE *pBuf;
	int nBufSize, nReturn;
	ENHMETAHEADER *pHeader;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if (!wdev || !wdev->hdc)
		return gs_error_Fatal;
    
	// PDF 1.4 �̹��� �׸���
	if (wdev->bpdf14 && wdev->pbmi)
    {
        BITMAPINFOHEADER *pBmih = (BITMAPINFOHEADER*)wdev->pbmi;
		BYTE *pBits = (BYTE*)pBmih + pBmih->biSize + sizeof(RGBQUAD) * pBmih->biClrUsed;
		int width = pBmih->biWidth;
		int height = pBmih->biHeight;
		StretchDIBits(wdev->hdc, 0, 0, width, height, 0, 0, width, height,
					  pBits, (BITMAPINFO*)pBmih, DIB_RGB_COLORS, SRCCOPY);

		free(wdev->pbmi);
		wdev->pbmi = NULL;
	}

	// ��Ÿ���� ������ �۾�
	hPen = SelectObject(wdev->hdc, wdev->hpen_old);
	DeleteObject(hPen);
	hBrush = SelectObject(wdev->hdc, wdev->hbrush_old);
	DeleteObject(hBrush);
	if (wdev->hfont_old)
		DeleteObject(SelectObject(wdev->hdc, wdev->hfont_old));

	wdev->hpen_old = NULL;
	wdev->hbrush_old = NULL;
	wdev->hfont_old = NULL;

	RestoreDC(wdev->hdc, -1);
	wdev->hEmf = CloseEnhMetaFile(wdev->hdc);
    
	wdev->hdc = NULL;

    if ( CopyEnhMetaFile( wdev->hEmf, wdev->fname ) == NULL )
        code = gs_error_Fatal;
    else
        code = 0;

    return code;
}

int wmf_initialize_device(gx_device *dev)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	HPEN hPen;
	HBRUSH hBrush;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	// ������ ��Ÿ���� �ڵ��� �������� �ʾ�����, �����Ѵ�.
	if (!wdev->bCopied && wdev->hdc) {
		if (wdev->hpen_old) {
			hPen = SelectObject(wdev->hdc, wdev->hpen_old);
			DeleteObject(hPen);
		}
		if (wdev->hbrush_old) {
			hBrush = SelectObject(wdev->hdc, wdev->hbrush_old);
			DeleteObject(hBrush);
		}

		wdev->hEmf = CloseEnhMetaFile(wdev->hdc);
		DeleteEnhMetaFile(wdev->hEmf);
	}

	// �̹��� ���� ����
	if (wdev->pbmi)
		free(wdev->pbmi);

	wdev->hdc = NULL;
	wdev->hEmf = NULL;
	wdev->bCopied = FALSE;
	wdev->bRecord = TRUE;
	wdev->nItems = 0;
	wdev->pen.dwPenStyle = PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_ROUND | PS_JOIN_ROUND;
	wdev->pen.dwWidth = 1;
	wdev->pen.lbBrush.lbStyle = BS_SOLID;
	wdev->pen.lbBrush.lbColor = RGB(0,0,0);
	wdev->pen.lbBrush.lbHatch = HS_CROSS;
	wdev->hpen_old = NULL;
	wdev->brush.lbStyle = BS_SOLID;
	wdev->brush.lbColor = RGB(0,0,0);
	wdev->brush.lbHatch = HS_CROSS;
	wdev->hbrush_old = NULL;
	wdev->hfont_old = NULL;
	wdev->clip_path_id = 0;
	wdev->bShading = FALSE;
	wdev->bpdf14 = FALSE;
	wdev->pbmi = NULL;
	wdev->hTransform = NULL;
//	wdev->finalize_metafile_data;
//	wdev->callback;

#if defined(_DEBUG) || defined(DEBUG)
//	wdev->pFile;     // ������.....
#endif // _DEBUG

	return 0;
}

void wmf_finalize_metafile_data( gx_device *dev )
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	HPEN hPen = NULL;
	HBRUSH hBrush = NULL;

	BYTE *pBuf;
	int nBufSize, nReturn;
	ENHMETAHEADER *pHeader;

	if (!wdev || !wdev->hdc)
		return;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     


	// PDF 1.4 �̹��� �׸���
	if (wdev->bpdf14 && wdev->pbmi) {
		BITMAPINFOHEADER *pBmih = (BITMAPINFOHEADER*)wdev->pbmi;
		BYTE *pBits = (BYTE*)pBmih + pBmih->biSize + sizeof(RGBQUAD) * pBmih->biClrUsed;
		int width = pBmih->biWidth;
		int height = pBmih->biHeight;
		StretchDIBits(wdev->hdc, 0, 0, width, height, 0, 0, width, height,
					  pBits, (BITMAPINFO*)pBmih, DIB_RGB_COLORS, SRCCOPY);

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile) {
			fprintf(wdev->pFile, "PDF 1.4 Image Drawing...\n");
			fprintf(wdev->pFile,
					"StretchDIBits(hDC, 0, 0, %d, %d, 0, 0, %d, %d, pBits, pBmi, DIB_RGB_COLORS, SRCCOPY)\n",
					width, height, width, height);
		}
#endif
		free(wdev->pbmi);
		wdev->pbmi = NULL;
	}

	// ��Ÿ���� ������ �۾�
	hPen = SelectObject(wdev->hdc, wdev->hpen_old);
	DeleteObject(hPen);
	hBrush = SelectObject(wdev->hdc, wdev->hbrush_old);
	DeleteObject(hBrush);
	if (wdev->hfont_old)
		DeleteObject(SelectObject(wdev->hdc, wdev->hfont_old));

	wdev->hpen_old = NULL;
	wdev->hbrush_old = NULL;
	wdev->hfont_old = NULL;

	RestoreDC(wdev->hdc, -1);
	wdev->hEmf = CloseEnhMetaFile(wdev->hdc);
	wdev->hdc = NULL;
    
	// Bounding Box �� �̿��� SetWindowOrgEx(), SetWindowExtEx() ��ǥ ����
	nBufSize = GetEnhMetaFileBits(wdev->hEmf, 0, NULL);
	pBuf = (BYTE*)malloc(nBufSize);

	if (pBuf) {
		nReturn = GetEnhMetaFileBits(wdev->hEmf, nBufSize, pBuf);
		pHeader = (ENHMETAHEADER*)pBuf;

		pHeader->rclBounds.left = 0;
		pHeader->rclBounds.top = 0;
		pHeader->rclBounds.right = dev->width;
		pHeader->rclBounds.bottom = dev->height;

		pHeader->rclFrame.left = 0;
		pHeader->rclFrame.top = 0;
		pHeader->rclFrame.right = round((double)pHeader->rclBounds.right
			* pHeader->szlMillimeters.cx * 100 / pHeader->szlDevice.cx);
		pHeader->rclFrame.bottom = round((double)pHeader->rclBounds.bottom
			* pHeader->szlMillimeters.cy * 100 / pHeader->szlDevice.cy);

		// SetWindowOrgEx() ����
		*(DWORD*)(pBuf + pHeader->nSize + 16) = 0;
		*(DWORD*)(pBuf + pHeader->nSize + 20) = 0;
		// SetWindowExtEx() ����
		*(DWORD*)(pBuf + pHeader->nSize + 32) = dev->width;
		*(DWORD*)(pBuf + pHeader->nSize + 36) = dev->height;

		// ��Ÿ���� �����Ͱ� �ùٸ��� Ȯ��		
#if defined(_DEBUG) || defined(DEBUG)
		{
			HENHMETAFILE	hEmf;
			HDC				hdcEMF;
			RECT			rt;
			static int		count = 0;
			char			sBuf[64] = {0,};
			
			sprintf( sBuf, "c:\\GhostScriptEMF%d.emf", count++ );

			hdcEMF = CreateEnhMetaFile(NULL, sBuf, NULL,
						"GhostScriptEMF\0GhostScriptEMF Dump\0");

			rt.left = 0;
			rt.top = 0;
			rt.right = dev->width;
			rt.bottom = dev->height;

			PlayEnhMetaFile(hdcEMF, wdev->hEmf, &rt);
            
			hEmf = CloseEnhMetaFile(hdcEMF);
			
			DeleteEnhMetaFile(hEmf);
		}
#endif

		DeleteEnhMetaFile(wdev->hEmf);
		wdev->hEmf = SetEnhMetaFileBits(nBufSize, pBuf);
		free(pBuf);

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "real_rect : (%d, %d) - (%d, %d)\n", 0, 0, dev->width, dev->height);
#endif // _DEBUG
	}
	else {

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "GetEnhMetaFileBits() �� ���� malloc() ����\n");
#endif // _DEBUG
	}

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif
}

int wmf_callback(gx_device *dev, int message)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	switch (message) {
		case WMF_OPEN_DEVICE:
			break;
		case WMF_OUTPUT_PAGE:
			break;
		case WMF_CLOSE_DEVICE:
				wdev->finalize_metafile_data(dev);
				wdev->bCopied = FALSE;
			break;
	}

	return 0;
}

int MonoImageToDIB(const unsigned char *data, int data_x, int raster, int width, int height,
				   gx_color_index color0, gx_color_index color1, BITMAPINFO *pBmpInfo)
{
	int x, y;
	int nDestByteWidth;
	BYTE *pDest, *pDestByte;
	RGBQUAD *pPal;
	int nBitColor;
	COLORREF crColor0, crColor1, crCopyColor;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	// gx_color_index �� COLORREF ���·� ��ȯ
	crColor0 = MakeColorRef(color0); // ��Ʈ 0 �� �ش��ϴ� ����
	crColor1 = MakeColorRef(color1); // ��Ʈ 1 �� �ش��ϴ� ����

	// BITMAPINFOHEADER ����ü ������ ä���.
	memset(pBmpInfo, 0, sizeof(BITMAPINFOHEADER));
	pBmpInfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	pBmpInfo->bmiHeader.biWidth = width - data_x;
	pBmpInfo->bmiHeader.biHeight = height;
	pBmpInfo->bmiHeader.biPlanes = 1;
	pBmpInfo->bmiHeader.biBitCount = 1;
	pBmpInfo->bmiHeader.biCompression = BI_RGB;
	pBmpInfo->bmiHeader.biClrUsed = 2;
	pBmpInfo->bmiHeader.biClrImportant = 2;

	// �ȷ�Ʈ ����
	pPal = (RGBQUAD*)((BYTE*)pBmpInfo + sizeof(BITMAPINFOHEADER));
	pPal[0].rgbRed = GetRValue(crColor0);
	pPal[0].rgbGreen = GetGValue(crColor0);
	pPal[0].rgbBlue = GetBValue(crColor0);
	pPal[1].rgbRed = GetRValue(crColor1);
	pPal[1].rgbGreen = GetGValue(crColor1);
	pPal[1].rgbBlue = GetBValue(crColor1);

	// DIB ������ ����
	pDest = (BYTE*)pBmpInfo + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 2;
	nDestByteWidth = DwordAlignWidth(width - data_x, 1);

	crColor0 = 0;
	crColor1 = 1;

	// data_x �� 0 �̶�� ������ ���� ������, �Ѳ����� �������� ���ϰ� ��Ʈ ������ �����ؾ� �Ѵ�.
	for (y = 0; y < height; y++) {
		for (x = data_x; x < width; x++) {
			// Postscript �� Windows ��ǥ���� Y �� ������ �ٸ��� ������ ������ �ش�.
			nBitColor = (*(data + (height - y - 1) * raster + (x / 8)) >> (7 - (x % 8))) & 0x01; // �Ʒ� -> ��
			crCopyColor = (nBitColor == 0) ? crColor0 : crColor1;
			pDestByte = pDest + y * nDestByteWidth + (x - data_x) / 8;
			if (crCopyColor == 1) {
				crCopyColor = crCopyColor << (7 - ((x - data_x) % 8));
				*pDestByte = *pDestByte | crCopyColor;
			}
		}
	}
	return 0;
}

/**
 * Ŭ���� ����(nX,nY,nWidth,nHeight)���� ����� �κ��� �����ϰ� DIB �� ���� �����ؼ� �̹��� ũ�⸦ ����
 *
 * @param	pBmi ��Ʈ�� ����
 * @param	nX clipping ���� x
 * @param	nY clipping ���� y
 * @param	nWidth clipping ��
 * @param	nHeight clipping ����
 * @param	bHConv ���� Flipping ����
 * @param	hVConv ���� Flipping ����
 * @return	���� true, ���� false
 */
int wmf_clip_image( BITMAPINFO* pBmi, int nX, int nY, int nWidth, int nHeight, BOOL bHConv, BOOL bVConv )
{
	int x, y;
	int nByteWidth = DwordAlignWidth(pBmi->bmiHeader.biWidth, pBmi->bmiHeader.biBitCount);
	int nNewByteWidth = DwordAlignWidth(nWidth, pBmi->bmiHeader.biBitCount);

	BYTE *pSrc, *pDest;
	BYTE *pDib = (BYTE*)pBmi + pBmi->bmiHeader.biSize + sizeof(RGBQUAD) * pBmi->bmiHeader.biClrUsed;	
 	BYTE *pNewDib = (BYTE*)malloc(nNewByteWidth * nHeight * 2);
	if((unsigned long long)nNewByteWidth * (unsigned long long)nHeight * 2 > UINT_MAX) {
		_ASSERTE(false&&"UINT ���� ���� ��ġ");
		return 0;
	}	
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if (!pNewDib)
		return -1;

	for ( y = 0; y < nHeight; y++ )
	{
		if ( bVConv )
			pDest = pNewDib + ( nHeight - y - 1 ) * nNewByteWidth;
		else
			pDest = pNewDib + y * nNewByteWidth;

		pSrc = pDib + ( nY + y ) * nByteWidth;

		if ( bHConv )
		{
			BYTE *s, *d;
			for ( x = 0; x < nWidth; x++ )
			{
				switch ( pBmi->bmiHeader.biBitCount )
				{
				case 8:
					s = pSrc + nX + x;
					d = pDest + nWidth - x - 1;
					*d = *s;
					break;
				case 24:
					s = pSrc + ( nX + x ) * 3;
					d = pDest + ( nWidth - x - 1 ) * 3;

					d[ 0 ] = s[ 0 ];
					d[ 1 ] = s[ 1 ];
					d[ 2 ] = s[ 2 ];
					break;
				case 32:
					s = pSrc + ( nX + x ) * 4;
					d = pDest + ( nWidth - x - 1 ) * 4;

					d[ 0 ] = s[ 0 ];
					d[ 1 ] = s[ 1 ];
					d[ 2 ] = s[ 2 ];
					d[ 3 ] = s[ 3 ];
					break;
				}
			}
		}
		else
		{
			pSrc += nX * pBmi->bmiHeader.biBitCount / 8;
			memcpy( pDest, pSrc, nNewByteWidth );
		}
	}

	memcpy( pDib, pNewDib, nNewByteWidth * nHeight );
	pBmi->bmiHeader.biWidth = nWidth;
	pBmi->bmiHeader.biHeight = nHeight;
    
 	free( pNewDib );

	return 0;
}

int WmfSetClipPathFromPath(gx_device *dev, const gx_path *ppath, int iMode)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
    gs_path_enum pcenum;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if (!ppath || wdev->bShading)
		return 0;

	gx_path_enum_init(&pcenum, ppath);
	BeginPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "BeginClipPath ----------\n");
#endif // _DEBUG

	for (;;) {
		gs_fixed_point pts[3];
		POINT pt[3];

		switch (gx_path_enum_next(&pcenum, pts)) {
			case gs_pe_moveto:
				MoveToEx(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y), NULL);

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "MoveTo(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			case gs_pe_lineto:
				LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "LineTo(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			case gs_pe_curveto:
				pt[0].x = ftoi(pts[0].x); pt[0].y = ftoi(pts[0].y); // control point1
				pt[1].x = ftoi(pts[1].x); pt[1].y = ftoi(pts[1].y); // control point2
				pt[2].x = ftoi(pts[2].x); pt[2].y = ftoi(pts[2].y); // end point
				PolyBezierTo(wdev->hdc, pt, 3);

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "CurveTo(%d, %d)(%d, %d)(%d, %d)\t", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y);
#endif // _DEBUG

				continue;
			case gs_pe_closepath:
				LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "ClosePath(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			default:
				break;
		}
			break;
	}
	EndPath(wdev->hdc);
	SelectClipPath(wdev->hdc, iMode);  // �׽�Ʈ ��, ���߿� �ּ� ����

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "\nEndClipPath ------------\n");
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	return 0;
}

int WmfSetClipPath(gx_device *dev, const gx_clip_path *pcpath, int iMode)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
    gs_path_enum penum, pcenum;
	gx_clip_rect real_rect;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if (wdev->bShading)
		return 0;

	// Ŭ���� �н��� NULL �̸� Ŭ���� ������ ����̽� ��ü �������� �ʱ�ȭ�Ѵ�.
	if (pcpath == NULL) {
		BeginPath(wdev->hdc);
		MoveToEx(wdev->hdc, 0, 0, NULL);
		LineTo(wdev->hdc, wdev->width, 0);
		LineTo(wdev->hdc, wdev->width, wdev->height);
		LineTo(wdev->hdc, 0, wdev->height);
		CloseFigure(wdev->hdc);
		EndPath(wdev->hdc);
		SelectClipPath(wdev->hdc, RGN_COPY);  // �׽�Ʈ ��, ���߿� �ּ� ����
		wdev->clip_path_id = 0;

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "gx_clip_path is NULL, ClipRect(%d, %d, %d, %d)\n", 0, 0, wdev->width, wdev->height);
#endif // _DEBUG
	}
	else if (pcpath->path_valid) {
		if (wdev->clip_path_id != pcpath->id)
			WmfSetClipPathFromPath(dev, &(pcpath->path), iMode);
		wdev->clip_path_id = pcpath->id;
	}
	else {
		const gx_clip_list *list = gx_cpath_list(pcpath);
		const gx_clip_rect *prect = list->head;

		if (prect == 0)
			prect = &list->single;

		real_rect.xmin = (int)((prect->xmin));
		real_rect.xmax = (int)((prect->xmax));
		real_rect.ymin = (int)((prect->ymin));
		real_rect.ymax = (int)((prect->ymax));

		if (wdev->clip_path_id != pcpath->id) {

			BeginPath(wdev->hdc);
			MoveToEx(wdev->hdc, real_rect.xmin, real_rect.ymin, NULL);
			LineTo(wdev->hdc, real_rect.xmax, real_rect.ymin);
			LineTo(wdev->hdc, real_rect.xmax, real_rect.ymax);
			LineTo(wdev->hdc, real_rect.xmin, real_rect.ymax);
			LineTo(wdev->hdc, real_rect.xmin, real_rect.ymin);
			EndPath(wdev->hdc);
			SelectClipPath(wdev->hdc, iMode);  // �׽�Ʈ ��, ���߿� �ּ� ����
			wdev->clip_path_id = pcpath->id;
		}

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "ClipRect(%d, %d, %d, %d)\n", real_rect.xmin, real_rect.ymin, real_rect.xmax, real_rect.ymax);
#endif // _DEBUG
	}

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	return 0;
}

int wmf_change_pen(gx_device *dev, LONG width, COLORREF color)
{

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	return wmf_change_pen_ex(dev, width, color, WMF_DEFAULT_PEN_STYLE, 0, NULL);
}

int wmf_change_pen_ex(gx_device *dev, LONG width, COLORREF color,
					  DWORD dwPenStyle, DWORD dwStyleCount, CONST DWORD *lpStyle)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	HPEN hPen, hOldPen;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if (wdev->pen.dwWidth != width || wdev->pen.lbBrush.lbColor != color 
		|| wdev->pen.dwPenStyle != dwPenStyle) {  // �׽�Ʈ ��, ���߿� �ּ� ����

		wdev->pen.dwPenStyle = dwPenStyle;
		wdev->pen.dwWidth = width;
		wdev->pen.lbBrush.lbColor = color;
		hPen = ExtCreatePen(wdev->pen.dwPenStyle, wdev->pen.dwWidth, &wdev->pen.lbBrush, dwStyleCount, lpStyle);
		hOldPen = SelectObject(wdev->hdc, hPen);
		DeleteObject(hOldPen);
	}  // �׽�Ʈ ��, ���߿� �ּ� ����
	return 0;
}

int wmf_change_brush(gx_device *dev, UINT style, COLORREF color, LONG hatch)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	HBRUSH hBrush, hOldBrush;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	if ((style != BS_SOLID && style != BS_HOLLOW && wdev->brush.lbHatch != hatch)
		|| wdev->brush.lbStyle != style || wdev->brush.lbColor != color) {  // �׽�Ʈ ��, ���߿� �ּ� ����

		wdev->brush.lbStyle = style;
		wdev->brush.lbColor = color;
		wdev->brush.lbHatch = hatch;
		hBrush = CreateBrushIndirect(&wdev->brush);
		hOldBrush = SelectObject(wdev->hdc, hBrush);
		DeleteObject(hOldBrush);
	}  // �׽�Ʈ ��, ���߿� �ּ� ����
	return 0;
}

int wmf_image_data(gx_device *dev,gx_image_enum_common_t *info, const byte **planes, 
		 int data_x,uint raster, int height)
{
	gx_device_wmf* wdev = (gx_device_wmf*)dev;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	return 0;
}

int wmf_end_image(gx_device *dev, gx_image_enum_common_t *info, bool draw_last)
{
	gx_device_wmf* wdev = (gx_device_wmf*)dev;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	return 0;
}


private int wmf_get_bits(gx_device * dev, int y, byte * str, byte ** actual_data)
{
	gx_device_wmf *wmf = (gx_device_wmf *) dev;
	if (wmf->callback == NULL)
		return 0;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	return dev_proc(wmf, get_bits)((gx_device *)wmf, y, str, actual_data);
}

int wmf_open_device(gx_device *dev) 
{
    gx_device_wmf *wdev = (gx_device_wmf*)dev;
    gs_memory_t* mem = gs_memory_stable( dev->memory );
    gx_device_vector *const vdev = ( gx_device_vector* )dev;

	HDC hdc;
	RECT rect;
	int nHorzSize, nVertSize, nHorzRes, nVertRes;
	HPEN hPen = NULL;
	HBRUSH hBrush = NULL;

    vdev->v_memory = mem;
    vdev->vec_procs = &wmf_vector_procs;

    gdev_vector_init( vdev );
    vdev->fill_options = vdev->stroke_options = gx_path_type_optimize;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif

	if (wdev == NULL)
		return gs_error_Fatal;


	wdev->matrix.xx = dev->HWResolution[0] / DEFAULT_PIXEL_PER_INCH;
	wdev->matrix.xy = 0;
	wdev->matrix.yx = 0;
	wdev->matrix.yy = -dev->HWResolution[1] / DEFAULT_PIXEL_PER_INCH;
	wdev->matrix.tx = 0.0;
	wdev->matrix.ty = (float)(dev->MediaSize[1] * -wdev->matrix.yy);

	dev->width = (int)(dev->MediaSize[0] * wdev->matrix.xx + 0.5);
	dev->height = (int)(dev->MediaSize[1] * -wdev->matrix.yy + 0.5);

	wmf_create_metafile(dev);

	return 0;
}

int wmf_output_page(gx_device *dev, int num_copies, int flush)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
    static bool isCalledOutputPage = false;
    
	int code = 0;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	// copypage �� ����.
	if (wdev == NULL || flush == false)
		return gs_error_Fatal;

    // 1 page�� ���
    if ( isCalledOutputPage == false )
    {
        code = wmf_copy_enh_metafile( dev );

        isCalledOutputPage = true;
    }

	wmf_initialize_device( dev);
    wmf_create_metafile( dev );

	return code;
}

int wmf_close_device(gx_device *dev) 
{
 	gx_device_wmf* wdev = (gx_device_wmf*) dev;
   
	HPEN hPen = NULL;
	HBRUSH hBrush = NULL;

	BYTE *pBuf;
	int nBufSize, nReturn;
	ENHMETAHEADER *pHeader;

#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     

	// PDF 1.4 �̹��� �׸���
	if (wdev->bpdf14 && wdev->pbmi)
    {
		BITMAPINFOHEADER *pBmih = (BITMAPINFOHEADER*)wdev->pbmi;
		BYTE *pBits = (BYTE*)pBmih + pBmih->biSize + sizeof(RGBQUAD) * pBmih->biClrUsed;
		int width = pBmih->biWidth;
		int height = pBmih->biHeight;
		StretchDIBits(wdev->hdc, 0, 0, width, height, 0, 0, width, height,
					  pBits, (BITMAPINFO*)pBmih, DIB_RGB_COLORS, SRCCOPY);

		free(wdev->pbmi);
		wdev->pbmi = NULL;
	}

	// ��Ÿ���� ������ �۾�
	hPen = SelectObject(wdev->hdc, wdev->hpen_old);
	DeleteObject(hPen);
	hBrush = SelectObject(wdev->hdc, wdev->hbrush_old);
	DeleteObject(hBrush);
	if (wdev->hfont_old)
		DeleteObject(SelectObject(wdev->hdc, wdev->hfont_old));

	wdev->hpen_old = NULL;
	wdev->hbrush_old = NULL;
	wdev->hfont_old = NULL;

	RestoreDC(wdev->hdc, -1);
	wdev->hEmf = CloseEnhMetaFile(wdev->hdc);
	wdev->hdc = NULL;

	wmf_initialize_device(dev);

	return 0;
}

gx_device* wmf_get_page_device(gx_device *dev)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	if ( dev == NULL )
		return NULL;
#if defined( _DEBUG )
//    jTRACE( "--->%s\n", __FUNCTION__ );
#endif     
	return dev;
}

void wmf_get_initial_matrix(gx_device *dev, gs_matrix *pmat)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
#if defined( _DEBUG )
//    jTRACE( "\n--->%s", __FUNCTION__ );
#endif     

	bool bAI = false;

	if( ( !strcmp( ( fileName + strlen(fileName) - 3 ) , ".ai") ) 
		|| ( !strcmp( ( fileName + strlen(fileName) - 3 ) , ".AI") ) )
		bAI = true;

	if (!wdev) {
		pmat->xx = (float)(WMF_PIXEL_PER_INCH / DEFAULT_PIXEL_PER_INCH);
		pmat->xy = 0.0;
		pmat->yx = 0.0;
		pmat->yy = -(float)(WMF_PIXEL_PER_INCH / DEFAULT_PIXEL_PER_INCH);
		pmat->tx = 0;
		pmat->ty = (float)dev->height;
	}
	else {
		pmat->xx = wdev->matrix.xx;
		pmat->xy = wdev->matrix.xy;
		pmat->yx = wdev->matrix.yx;
		pmat->yy = wdev->matrix.yy;
		pmat->tx = wdev->matrix.tx;

		if( bAI )		
			pmat->ty = (float)dev->height;	
		else
			pmat->ty = wdev->matrix.ty;	
	}	
}

/* --- get/put parameters --- */
private int
wmf_get_params( gx_device* dev, gs_param_list* plist )
{
    int code = gdev_vector_get_params( dev, plist );
#if defined( _DEBUG )
//    jTRACE( "\n--->%s", __FUNCTION__ );
#endif     
    
    return code;
}

private int
wmf_put_params( gx_device* dev, gs_param_list* plist )
{
    int code = gdev_vector_put_params( dev, plist );
#if defined( _DEBUG )
//    jTRACE( "\n--->%s", __FUNCTION__ );
#endif     
 
    return code;
}

#if defined( _DEBUG )
void jTRACE( const char* message, ... )
{
    static char debugString[ 1024 ];
    va_list ap;

    va_start( ap, message );
    vsprintf( debugString, message, ap );
    va_end( ap );

    OutputDebugString( debugString );
}
#endif 
