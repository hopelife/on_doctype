﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Object = System.Object;
using String = System.String;
using Bool = System.Boolean;
using Index = System.Int32;
using Frame = System.Double;

using Hnc.VideoEditor.Base.Type;
using Hnc.Type;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Hnc.VideoEditor.Engine {
	public class Marker {
		private static readonly Object thisLock = new Object();

		private static Marker instance;
		public static Marker Instance {
			get {
				lock (thisLock) {
					if (instance == null) {
						instance = new Marker();
					}
				}
				return instance;
			}
		}

		private Marker() {
			Doc = Document.Create();
#if DEBUG
			Debug.Assert(Doc != null, "Document를 생성하지 못하였습니다.");
#endif
		}

		private Document doc;
		public Document Doc {
			get {
				return doc;
			}
			set {
				doc = value;
			}
		}

		public Bool NewDocument() {
			return Doc.NewDocument();
		}

		public Bool CompareFilePath(String filePath) {
			return Doc.CompareFilePath(filePath);
		}
		

		public TimelineInfo PropertyChangedInfo(TimelineInfo newInfo) {
			TimelineInfo oldInfo = null;

			TimelineInfo info = Doc.FindInfo(newInfo.ID);

			if (info != null) {
				oldInfo = info.Clone();

				info.Copy(newInfo);
			}

			return oldInfo;
		}

		public int ChangingFilePathInfo(String oldFilePath, String newFilePath) {
			return Doc.ChangingFilePathInfo(oldFilePath, newFilePath);
		}

		public System.Collections.Generic.List<TimelineInfo> SortInfo() {
			return Doc.SortInfo();
		}
		

		public TimelineInfo RemoveInfo(Index id) {
			TimelineInfo deleteInfo = Doc.FindInfo(id);

			Doc.RemoveInfo(id);

			return deleteInfo;
		}

		public TimelineInfo AddSubtitleInfo(String sentence, Frame frame) {
			return Doc.AddSubtitleInfo(sentence, frame);
		}

		public TimelineInfo AddVideoInfo(String filePath, Frame totalFrame, FrameScope videoScope) {
			return Doc.AddVideoInfo(filePath, totalFrame, videoScope);
		}

		public void SetNewID() {
			Doc.SetNewID();
		}

		public int AddInfo(TimelineInfo info) {
			return Doc.AddInfo(info);
		}

		public Bool RemoveVideoInfo(String filePath, FrameScope videoScope, FrameScope timelineScope) {
			return Doc.RemoveVideoInfo(filePath, videoScope, timelineScope);
		}

		public Bool RemoveVideoInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif
			return Doc.RemoveVideoInfo(id);
		}

		// VideoInfoValue

		// Document 관련 함수들
		public void SetSaveFilePath(String saveFilePath) {
			SetFilePath(saveFilePath);
		}

		public String GetSaveFilePath() {
			return GetFilePath();
		}

		public String GetLoadFilePath() {
			return GetFilePath();
		}

		private String GetFilePath() {
			return Doc.FileName;
		}

		private void SetFilePath(String saveFilePath) {
			Doc.FileName = saveFilePath;
		}

		public Collection<TimelineInfo> GetTimelineInfoCollection() {
			return Doc.GetTimelineInfoCollection();
		}

		public int ExportCancel() {
			return Doc.ExportCancel();
		}

		public int Export(String filePath, int width, int height, int frameRate, int videoCodec, int audioCodec) {
			return Doc.Export(filePath, width, height, frameRate, videoCodec, audioCodec);
		}
	}

	public class MarkerUtil {
		public static Marker GetMarker() {
			return Marker.Instance;
		}
	}
}
