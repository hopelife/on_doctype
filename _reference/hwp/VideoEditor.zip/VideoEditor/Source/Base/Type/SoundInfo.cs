﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Type {
	using Int = System.Int32;
	using Index = System.Int32;
	using Frame = System.Double;
	using String = System.String;
	using Bool = System.Boolean;

	public class SoundInfo : TimelineInfo {

		#region 멤버변수
		private String _filePath;
		private FrameScope _soundScope;
		#endregion 멤버변수

		#region Property
		public FrameScope SoundScope {
			get {
				return _soundScope;
			}
			set {
				_soundScope = value.Clone();
			}
		}

		public String FilePath {
			get {
				return _filePath;
			}
			set {
				_filePath = (String)value.Clone();
			}
		}
		#endregion Property

		#region 생성자
		private SoundInfo() {
			_id = -1;
			_timelineScope = FrameScope.Create();
			_totalFrame = 0;
			_filePath = "";
			_soundScope = FrameScope.Create();
		}

		private SoundInfo(Index id, FrameScope timelineScope, Frame totalFrame, String path, FrameScope soundScope) {
			_id = id;
			_timelineScope = timelineScope.Clone();
			_totalFrame = totalFrame;
			_filePath = path;
			_soundScope = soundScope.Clone();
		}

		private SoundInfo(SoundInfo other) {
			_id = other._id;
			_timelineScope = other._timelineScope.Clone();
			_totalFrame = other._totalFrame;
			_filePath = (String)other._filePath.Clone();
			_soundScope = other._soundScope.Clone();
		}
		#endregion // 생성자

		#region Create
		public new static SoundInfo Create() {
			return new SoundInfo();
		}

		public static SoundInfo Create(Index id, FrameScope timelineScope, Frame totalFrame, String path, FrameScope soundScope) {
			return new SoundInfo(id, timelineScope, totalFrame, path, soundScope);
		}

		public static SoundInfo Create(SoundInfo other) {
			return new SoundInfo(other);
		}
		#endregion // Create

		#region override
		public override TimelineInfo Clone() {
			return new SoundInfo(this);
		}

		public override void Copy(TimelineInfo other) {
			SoundInfo soundOther = other as SoundInfo;

			_id = soundOther._id;
			_timelineScope = soundOther._timelineScope.Clone();
			_totalFrame = soundOther._totalFrame;
			_filePath = (String)soundOther._filePath.Clone();
			_soundScope = soundOther._soundScope.Clone();

			OnPropertyCahnged(ID.ToString());
		}

		public override Bool Equals(System.Object obj) {
			SoundInfo other = obj as SoundInfo;

			if (base.Equals(obj) == false) {
				return false;
			}

			if (_filePath.Equals(other._filePath) == false) {
				return false;
			}

			if (_soundScope != other._soundScope) {
				return false;
			}

			return true;
		}

		public override Int GetHashCode() {
			return this.GetHashCode();
		}
		#endregion // Event
	}
}