/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "TimelineInfo.h"

TimelineInfo::TimelineInfo() {
	isMSCodec = false;
}

TimelineInfo::TimelineInfo(const Char* path, Effect enumEffect, Int64_t start, Int64_t end) {
	if (path == NULL) {
		emptyFrame = true;
	} else {
		emptyFrame = false;
		strcpy_s(filePath, sizeof(Char) * MAX_FILEPATH, path);
	}

	startFrame = start;
	endFrame = end;
	lengthFrame = endFrame - startFrame;

	timebase.num = 0;
	timebase.den = 30;

	frameRate = 30;

	videoStreamIndex = -1;
	inputFormatContext = NULL;
	inputVideoCodecContext = NULL;
	inputAudioCodecContext = NULL;

	isMSCodec = false;
	loop = 1;

	this->enumEffect = enumEffect;
}

TimelineInfo::~TimelineInfo() {
	if (inputFormatContext != NULL) {
		if (inputVideoCodecContext != NULL) {
			avcodec_close(inputVideoCodecContext);
		}

		if (inputAudioCodecContext != NULL) {
			avcodec_close(inputAudioCodecContext);
		}

		avformat_close_input(&inputFormatContext);

//		avio_close(inputFormatContext->pb);
//		inputFormatContext->pb = NULL;
	}

	/*
	if (inputFormatContext != NULL) {
		avformat_close_input(&inputFormatContext);
	}
	*/
}
