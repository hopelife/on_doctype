﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Float = System.Single;

namespace Hnc.Util {
    public class Vector2D {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Float Radius { get; set; }
        private Degree angle;
        public Degree Angle {
            get {
                Debug.Assert(angle != null);
                return angle;
            }
            set {
                Debug.AssertThrow(value != null, eErrorCode.NullArgument);

                angle = value;
            }
        }
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Vector2D(Float radius, Degree angle) {
            Radius = radius;
            Angle = angle;
        }
        public static Vector2D Create(PointF start, PointF last) {

            return new Vector2D(
                MathUtil.GetInclinedPlane(last.X - start.X, last.Y - start.Y),
                MathUtil.GetSeta(start, last)
                
            );
        }
        public static Vector2D Create(Float radius, Degree angle) {
            return new Vector2D(radius, angle);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
	    // 벡터의 X, Y 성분을 구함
        public SizeF GetXY() {
            Debug.Assert(Angle != null);

		    Float radian = MathUtil.ToRadian(Angle.Value);

		    return SizeF.Create(
			    Radius * MathUtil.Cos(radian),
			    Radius * MathUtil.Sin(radian)
		    );
	    }
	    // 현 벡터 방향에서 start 위치에서 radius 만큼 떨어진 위치를 구함
        public PointF GetPointF(PointF start, Float radius) {
            Debug.AssertThrow(start != null, eErrorCode.NullArgument);
            Debug.Assert(Angle != null);

		    Float radian = MathUtil.ToRadian(Angle.Value);
		    return PointF.Create(
			    start.X + radius * MathUtil.Cos(radian),
			    start.Y + radius * MathUtil.Sin(radian)
		    );	
	    }
        // 현 벡터를 other에 투영했을 때의 크기
	    public Float GetProjectionSize(Vector2D other) {
            Debug.AssertThrow(other != null, eErrorCode.NullArgument);
            Debug.Assert(other.Angle != null);
            Debug.Assert(Angle != null);


            Float radian = MathUtil.ToRadian(Angle.Value) - MathUtil.ToRadian(other.Angle.Value);
		    return Radius * MathUtil.Cos(radian);
	    }
    }
}
