﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Type {
	using Int = System.Int32;
	using Index = System.Int32;
	using Frame = System.Double;
	using String = System.String;
	using Bool = System.Boolean;

	public class SubtitleInfo : TimelineInfo {

		#region 멤버변수
		private String _sentence;
		#endregion // 멤버변수

		#region Property
		public String Sentence {
			get {
				return _sentence;
			}
			set {
				_sentence = (String)value.Clone();
			}
		}
		#endregion // Property

		#region 생성자
		private SubtitleInfo() {
			_id = -1;
			_timelineScope = FrameScope.Create();
			_totalFrame = 0;
			_sentence = "";
		}

		private SubtitleInfo(Index id, FrameScope timelineScope, Frame totalFrame, String sentence) {
			_id = id;
			_timelineScope = timelineScope.Clone();
			_totalFrame = totalFrame;
			_sentence = sentence;
		}

		private SubtitleInfo(SubtitleInfo other) {
			_id = other._id;
			_timelineScope = other._timelineScope.Clone();
			_totalFrame = other._totalFrame;
			_sentence = (String)other._sentence.Clone();
		}
		#endregion // 생성자

		#region Create
		public new static SubtitleInfo Create() {
			return new SubtitleInfo();
		}

		public static SubtitleInfo Create(Index id, FrameScope timelineScope, Frame totalFrame, String sentence) {
			return new SubtitleInfo(id, timelineScope, totalFrame, sentence);
		}

		public static SubtitleInfo Create(SubtitleInfo other) {
			return new SubtitleInfo(other);
		}
		#endregion // Create

		#region override
		public override TimelineInfo Clone() {
			return new SubtitleInfo(this);
		}

		public override void Copy(TimelineInfo other) {
			SubtitleInfo subtitleOther = other as SubtitleInfo;

			_id = subtitleOther._id;
			_timelineScope = subtitleOther._timelineScope.Clone();
			_totalFrame = subtitleOther._totalFrame;
			_sentence = (String)subtitleOther._sentence.Clone();

			OnPropertyCahnged(ID.ToString());
		}

		public override Bool Equals(System.Object obj) {
			SubtitleInfo other = obj as SubtitleInfo;

			if (base.Equals(obj) == false) {
				return false;
			}

			if (_sentence.Equals(other._sentence) == false) {
				return false;
			}

			return true;
		}

		public override Int GetHashCode() {
			return this.GetHashCode();
		}
		#endregion // override
	}
}