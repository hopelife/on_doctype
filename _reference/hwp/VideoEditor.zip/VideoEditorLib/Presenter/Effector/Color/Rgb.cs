﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Float = System.Single;
using Ratio = System.Single;
using Byte = System.Byte;
using Index = System.Int32;
using Int = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    // Rgb 값 조정
    public class Rgb {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private LookupTable RTable = LookupTable.Create();
        private LookupTable GTable = LookupTable.Create();
        private LookupTable BTable = LookupTable.Create();

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // rgb : 가감시킬 정도 -1 ~ 1
        private Rgb(Ratio r, Ratio g, Ratio b) {

            r = MathUtil.Clamp(r, -1, 1);
            g = MathUtil.Clamp(g, -1, 1);
            b = MathUtil.Clamp(b, -1, 1);

            Int temp;
            for (Index i = 0; i < 256; ++i) {

                temp = (Int)(i * (1 + r));
                RTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);

                temp = (Int)(i * (1 + g));
                GTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);

                temp = (Int)(i * (1 + b));
                BTable.Data[i] = (Byte)((255 < temp) ? 255 : temp);
            }
        }

        public static Rgb Create(Ratio r, Ratio g, Ratio b) {
            return new Rgb(r, g, b);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.R.Length; ++i) {

                pixels.R[i] = RTable.Data[pixels.R[i]];
                pixels.G[i] = GTable.Data[pixels.G[i]];
                pixels.B[i] = BTable.Data[pixels.B[i]];

            }
        }

    }

}