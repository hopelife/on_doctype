/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "Type.h"
//-------------------------------------------------------------------------------------------------
// dll ����
#define DLLEXPORT

#ifdef DLLEXPORT
#define DLLTYPE __declspec(dllexport)
#define DLLTYPE_TEMPLATE
#else
#define DLLTYPE __declspec(dllimport)
#define DLLTYPE_TEMPLATE extern
#endif

//-------------------------------------------------------------------------------------------------
// �������� Ȯ�� define
#define FAIL 0
#define SUCCESS 1
#define CANCEL 5


//-------------------------------------------------------------------------------------------------
// FFMpeg ���̺귯������ �ʿ�� �ϴ� define
#ifndef INT64_C
#define INT64_C(c) (c ## LL)
#define UINT64_C(c) (c ## ULL)
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define STREAM_DURATION 200.0
#define STREAM_FRAME_RATE 25 // 25 images/s
#define STREAM_NB_FRAMES  ((Int)(STREAM_DURATION * STREAM_FRAME_RATE))
#define STREAM_PIX_FMT PIX_FMT_YUV420P // default pix_fmt

#define MAX_FILEPATH 1024
#define MAX_FILENAME 1024
#define MAX_EXTENSION 20
#define MAX_DATE 40
#define MAX_CODEC_NAME 100

//-------------------------------------------------------------------------------------------------
// ���� frame ���忡 ���� ������ ó���ϱ� ���� ����ü
struct Frame {
	UChar** pixel;
	Int width;
	Int height;
};

struct TimeInfo {
	Int hour;
	Int minute;
	Int second;
};

struct VideoInfoStruct {
	Char filePath[MAX_FILEPATH];
	Char fileName[MAX_FILENAME];
	Int width;
	Int height;
	Double frameRate;
	Int64_t totalFrame;
	TimeInfo runningTime;
	Char modifyDate[MAX_DATE];
	Char videoCodecName[MAX_CODEC_NAME];
	Char audioCodecName[MAX_CODEC_NAME];
};

// ���� ���ڵ� ���� �ð� �� �ð� ��� �߰�
// ���� ���ڵ� �̸����� ��� �߰�
enum ExportState {
	ExportNone = 0,
	ExportStart = 1,
	ExportEncoding = 2,
	ExportFail = 3,
	ExportSuccess = 4,
	ExportCancel = 5
};

struct ExportInfo {
	Bool isCancel;
	ExportState state;
	Int64_t encodingFrameCount;
	Int64_t totalFrameCount;
};

enum Effect {
	enumOriginal = -1,
	enumGray = 0,
	enumSepia = 1,
	enumRed = 2,
	enumGreen = 3,
	enumBlue = 4,
	enumYellow = 5,
	enumOrange = 6,
	enumViolet = 7
};

enum ErrorCode {
	FileOpenFail = -1,
	NotFindAllStream = -2,
	NotFindVideoStream = -3,
	NotFindAudioStream = -4,
	VideoCodecFindFail = -5,
	AudioCodecFindFail = -6,
	VideoCodecOpenFail = -7,
	AudioCodecOpenFail = -8,
	FrameAllocFail = -9,
	FrameSeekMoveFail = -10,
	MemoryAllocFail = -11,
	GetSwsContextFail = -12,
	GetVideoFrameFail = -13,
	ToImageFail = -14,
	ExceptionCatch = -15,
	GetSizeFail = -16,
	TimelineInfoAllocFail = -17,
	NullPointInput = -18,
	EmptyTimelineInfo = -19,
	NotOutputFileInfo = -20,
	GetDecodeVideoFrameFail = -21,
	GetEncodeVideoFrameFail = -22,
	WriteFrameFail = -23,
	WriteTrailerFail = -24,
	OutputContextAllocFail = -25,
	OutputOpenVideoFail = -26,
	AvioOpenFail = -27,
	WriteHeaderFail = -28,
	OutputOpenAudioFail = -29,
};