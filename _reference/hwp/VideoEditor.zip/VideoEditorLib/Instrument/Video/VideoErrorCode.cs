﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Hnc.Instrument {
    public enum enumVideoErrorCode : int {
		UserCancel = 5,
        NotError = 1,
        FileOpenFail = -1,
        NotFindAllStream = -2,
        NotFindVideoStream = -3,
        NotFindAudioStream = -4,
        VideoCodecFindFail = -5,
        AudioCodecFindFail = -6,
        VideoCodecOpenFail = -7,
        AudioCodecOpenFail = -8,
        FrameAllocFail = -9,
        FrameSeekMoveFail = -10,
        MemoryAllocFail = -11,
        GetSwsContextFail = -12,
        GetVideoFrameFail = -13,
        ToImageFail = -14,
        ExceptionCatch = -15,
        GetSizeFail = -16,
        TimelineInfoAllocFail = -17,
        NullPointInput = -18,
        EmptyTimelineInfo = -19,
        NotOutputFileInfo = -20,
        GetDecodeVideoFrameFail = -21,
        GetEncodeVideoFrameFail = -22,
        WriteFrameFail = -23,
        WriteTrailerFail = -24,
        OutputContextAllocFail = -25,
        OutputOpenVideoFail = -26,
        AvioOpenFail = -27,
        WriteHeaderFail = -28,
    }

    public static class VideoErrorCode {
        private static enumVideoErrorCode lastErrorCode = enumVideoErrorCode.NotError;

        public static enumVideoErrorCode GetLastErrorCode() {
            return lastErrorCode;
        }

        public static String GetLastErrorMessage() {
            String message = null;

			switch (lastErrorCode) {
				case enumVideoErrorCode.UserCancel:
					message = Application.Current.Resources["IDS_VideoError_Message_01"] as String;
					break;
				case enumVideoErrorCode.NotError:
					message = Application.Current.Resources["IDS_VideoError_Message_02"] as String;
					break;
				case enumVideoErrorCode.FileOpenFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.NotFindAllStream:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.NotFindVideoStream:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.NotFindAudioStream:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.VideoCodecFindFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.AudioCodecFindFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.VideoCodecOpenFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.AudioCodecOpenFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.FrameAllocFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.FrameSeekMoveFail:
					message = Application.Current.Resources["IDS_VideoError_Message_03"] as String;
					break;
				case enumVideoErrorCode.MemoryAllocFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.GetSwsContextFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.GetVideoFrameFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.ToImageFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.ExceptionCatch:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.GetSizeFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.TimelineInfoAllocFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.NullPointInput:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.EmptyTimelineInfo:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.NotOutputFileInfo:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.GetDecodeVideoFrameFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.GetEncodeVideoFrameFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.WriteFrameFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.WriteTrailerFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.OutputContextAllocFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.OutputOpenVideoFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.AvioOpenFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
				case enumVideoErrorCode.WriteHeaderFail:
					message = Application.Current.Resources["IDS_VideoError_Message_04"] as String;
					break;
			}

			/*
            switch (lastErrorCode) {
				case enumVideoErrorCode.UserCancel:
					message = Application.Current.Resources["IDS_VideoError_Message_01"] as String;
					break;
                case enumVideoErrorCode.NotError:
                    message = "Error이 발생하지 않았습니다.";
                    break;
                case enumVideoErrorCode.FileOpenFail:
                    message = "비디오 파일을 열지 못하였습니다.";
                    break;
                case enumVideoErrorCode.NotFindAllStream:
                    message = "파일에 스트림이 존재하지 않습니다.";
                    break;
                case enumVideoErrorCode.NotFindVideoStream:
                    message = "비디오 스트림이 존재하지 않습니다.";
                    break;
                case enumVideoErrorCode.NotFindAudioStream:
                    message = "오디오 스트림이 존재하지 않습니다.";
                    break;
                case enumVideoErrorCode.VideoCodecFindFail:
                    message = "비디오 코덱을 찾지 못하였습니다.";
                    break;
                case enumVideoErrorCode.AudioCodecFindFail:
                    message = "오디오 코덱을 찾지 못하였습니다.";
                    break;
                case enumVideoErrorCode.VideoCodecOpenFail:
                    message = "비디오 코덱을 열지 못하였습니다.";
                    break;
                case enumVideoErrorCode.AudioCodecOpenFail:
                    message = "오디오 코덱을 열지 못하였습니다.";
                    break;
                case enumVideoErrorCode.FrameAllocFail:
                    message = "프레임을 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.FrameSeekMoveFail:
                    message = "프레임을 이동하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.MemoryAllocFail:
                    message = "메모리 공간을 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.GetSwsContextFail:
                    message = "Context를 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.GetVideoFrameFail:
                    message = "비디오 프레임을 가져오지 못하였습니다.";
                    break;
                case enumVideoErrorCode.ToImageFail:
                    message = "이미지를 변환하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.ExceptionCatch:
                    message = "Exception이 발생하였습니다.";
                    break;
                case enumVideoErrorCode.GetSizeFail:
                    message = "size를 가져오지 못하였습니다.";
                    break;
                case enumVideoErrorCode.TimelineInfoAllocFail:
                    message = "Timeline 정보를 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.NullPointInput:
                    message = "Null Point 입니다.";
                    break;
                case enumVideoErrorCode.EmptyTimelineInfo:
                    message = "Timeline 정보가 없습니다.";
                    break;
                case enumVideoErrorCode.NotOutputFileInfo:
                    message = "내보내기 파일을 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.GetDecodeVideoFrameFail:
                    message = "비디오 decoding에 실패하였습니다.";
                    break;
                case enumVideoErrorCode.GetEncodeVideoFrameFail:
                    message = "비디오 encoding에 실패하였습니다.";
                    break;
                case enumVideoErrorCode.WriteFrameFail:
                    message = "프레임을 쓰지 못하였습니다.";
                    break;
                case enumVideoErrorCode.WriteTrailerFail:
                    message = "Trailer를 쓰는데 문제가 발생하였습니다.";
                    break;
                case enumVideoErrorCode.OutputContextAllocFail:
                    message = "OutputContext를 생성하지 못하였습니다.";
                    break;
                case enumVideoErrorCode.OutputOpenVideoFail:
                    message = "OutputFiledmf Open하지 못하였습니다.";
                    break;
                    case enumVideoErrorCode.AvioOpenFail:
                    message = "AvioOpen을하지 못하였습니다.";
                    break;
                    case enumVideoErrorCode.WriteHeaderFail:
                    message = "Output 헤더를 쓰지 못하였습니다.";
                    break;
            }
			*/

            return message;
        }

        public static void SetLastErrorCode(enumVideoErrorCode errorCode) {
            lastErrorCode = errorCode;
        }

        public static void SetLastErrorCode(int errorCode) {
            lastErrorCode = (enumVideoErrorCode) errorCode;
        }
    }
}
