﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System;
using System.Windows.Controls;
using System.Windows.Input;

namespace Hnc.Control {

    public partial class AppDialog : Window {

        public enum ResultType {
            OK, NO, CANCEL
        }

		public enum MessageBoxType {
			DefaultType,
			MetroType
		}

		public MessageBoxType messageBoxType = MessageBoxType.DefaultType;
		private MessageBoxButton messageBoxOption;

        #region -> Constructors

        public AppDialog(string title, string message) {

            InitializeComponent();
            InitWindow();

            titleLabel.Content = title;
            messageLabel.Content = message;

            btnStack.Visibility = Visibility.Collapsed;
        }

        public AppDialog(string title, string message, string okMessage) {

            InitializeComponent();
            InitWindow();

            titleLabel.Content = title;
            messageLabel.Content = message;

            okBtn.Content = okMessage;
            noBtn.Visibility = Visibility.Collapsed;
            cancelBtn.Visibility = Visibility.Collapsed;

			messageBoxOption = MessageBoxButton.OK;
        }

        public AppDialog(string title, string message, string okMessage, string noMessage) {

            InitializeComponent();
            InitWindow();

            titleLabel.Content = title;
            messageLabel.Content = message;

            okBtn.Content = okMessage;
            noBtn.Content = noMessage;
            cancelBtn.Visibility = Visibility.Collapsed;

			messageBoxOption = MessageBoxButton.YesNo;
        }

        public AppDialog(string title, string message, string okMessage, string noMessage, string cancelMessage) {

            InitializeComponent();
            InitWindow();

            titleLabel.Content = title;
            messageLabel.Content = message;

            okBtn.Content = okMessage;
            noBtn.Content = noMessage;
            cancelBtn.Content = cancelMessage;

			messageBoxOption = MessageBoxButton.YesNoCancel;
        }

		public ResultType ShowDialog(MessageBoxType type) {

			if (messageBoxType == MessageBoxType.DefaultType) {
				MessageBoxResult result = MessageBox.Show(this.Owner, (string)messageLabel.Content, (string)titleLabel.Content, messageBoxOption, MessageBoxImage.None);

				if (result == MessageBoxResult.Yes) {
					this.Result = ResultType.OK;
					this.Close();
				} else if (result == MessageBoxResult.No) {
					this.Result = ResultType.NO;
					this.Close();
				} else if (result == MessageBoxResult.Cancel) {
					this.Result = ResultType.CANCEL;
					this.Close();
				}
			} else {
				ShowDialog();
			}

			return this.Result;
		}

        #endregion

        #region -> Properties

        public ResultType Result {
            get;
            private set;
        }

        #endregion

        #region -> Private Methods

        private void InitWindow() {

            this.PreviewKeyDown += new System.Windows.Input.KeyEventHandler(AppDialog_PreviewKeyDown);
            Keyboard.Focus(this);

            this.Owner = Application.Current.MainWindow;

            if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
                this.WindowState = WindowState.Maximized;
            } else {
                this.Width = Application.Current.MainWindow.ActualWidth;
                this.Height = Application.Current.MainWindow.ActualHeight;
            }
        }

        private void AppDialog_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e) {

            if (e.Key == Key.Escape) {
                this.DialogResult = null;
                this.Result = ResultType.CANCEL;
                this.Close();
            } else if (e.Key == Key.Enter) {
                this.DialogResult = true;
                this.Result = ResultType.OK;
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) {

            DoubleAnimation ani = new DoubleAnimation(1d, new Duration(TimeSpan.FromSeconds(0.2d)));
            ani.AccelerationRatio = 0.33;
            ani.DecelerationRatio = 0.33;
            centerGrid.BeginAnimation(Grid.OpacityProperty, ani);
        }

        private void okBtn_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = true;
            this.Result = ResultType.OK;
            this.Close();
        }

        private void noBtn_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = false;
            this.Result = ResultType.NO;
            this.Close();
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = null;
            this.Result = ResultType.CANCEL;
            this.Close();
        }



        #endregion
    }
}
