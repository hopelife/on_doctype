/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include <time.h>
#include "Type.h"

// FFMpeg Debug�� ���� Ŭ����
// �޽��� ���
// �ӵ� ����
class Debug
{
	static Char* outputFilePath;
	static Char* lastDebugMessage;
	static Char* subject;
	static clock_t start;
	static clock_t end;

public:
	Debug(void);
	Debug::Debug(const Char* subject);
	~Debug(void);

	static void Start();
	static void End();
	static clock_t Result();
	static double ResultPerSEC();
	static void Trace(Char* string);
	static const Char* GetLastdebugMessage();
	static void StartPrintTextFile();
	static void PrintTextFile(const Char* string);
};