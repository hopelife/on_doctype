﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using System.IO;
using String = System.String;
using Bool = System.Boolean;
using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Util {

    //  파일 경로 처리 유틸
    public static class PathUtil {
        // 현재의 경로명
        public static String Current {
            get { return Directory.GetCurrentDirectory(); }
        }
        public static String Combine(String pathName1, String pathName2) {
            Debug.AssertThrow(pathName1 != null && pathName1 != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(pathName2 != null && pathName2 != "", eErrorCode.InvalidPathName);

            return Path.Combine(pathName1, pathName2); // 두 경로를 이어주는 '/' 가 추가될 수 있음
        }
        public static Bool ExistsFolder(String folderName) {
            Debug.AssertThrow(folderName != null && folderName != "", eErrorCode.InvalidPathName);

            return Directory.Exists(folderName);
        }
        public static Bool ExistsFile(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            return File.Exists(pathName);
        }
        // 파일명, 확장자 명을 뺀 디렉토리 명만 반환
        public static String ParseFolderName(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);
            
            return Path.GetDirectoryName(pathName);
        }
        // 파일이름과 확장자 반환
        public static String ParseFileName(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);
            
            return Path.GetFileName(pathName);
        }
        public static String ParseFileNameWidthoutExtension(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            return Path.GetFileNameWithoutExtension(pathName);
        }
        public static String GetSafePathName(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            // 해당 pathName이 존재하지 않는다면 그대로 사용
            if (!ExistsFile(pathName)) {
                return pathName;
            }

            // 존재하는 파일이 있다면 이름을 변경한다.

            return GetSafePathName(ParseFolderName(pathName), ParseFileNameWidthoutExtension(pathName), GetExt(pathName), 1);
        }
        // 동일한 파일명이 있을 경우 num 을 증가시키며 재귀호출한다.
        private static String GetSafePathName(String folder, String file, String ext, Count num) {


            String pathName = Combine(folder, file + "(" + num.ToString() + ")" + ext);

            if (!ExistsFile(pathName)) {
                return pathName;
            }

            return GetSafePathName(folder, file, ext, ++num);
        }


        // folderName을 root를 제외한 상대경로로 만든다.
        public static String ToRelative(String root, String folderName) {
            Debug.AssertThrow(root != null && root != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(folderName != null && folderName != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(folderName.Contains(root), eErrorCode.InvalidPathName);

            Index find = folderName.IndexOf(root);
            Debug.AssertThrow(find != -1, eErrorCode.InvalidPathName);
            find += root.Length;
  
            Debug.Assert(0 <= folderName.Length - find, "IndexOf에서 검색되었다면, folderName 에서 찾았다는 뜻이므로 folderName은 find 보다 갯수가 크거나 같다.");

            return folderName.Substring(find, folderName.Length - find);
        }


        public static void Create(String folderName) {
            Debug.AssertThrow(folderName != null && folderName != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(!ExistsFolder(folderName), eErrorCode.ExistsFolder);
            
            Directory.CreateDirectory(folderName);
        }
        
        // pathName이 파일이라면 주어진 파일만 삭제
        // pathName이 폴더라면 하위 폴더 및 모든 파일 삭제
        public static void Remove(String pathName) {

            if (ExistsFile(pathName)) {
                File.Delete(pathName);
            }
            else if (ExistsFolder(pathName)) {
                Directory.Delete(pathName, true);
            }
            else {
                Debug.Assert(false, "주어진 파일, 또는 폴더가 존재하지 않음");
            }
            
        }

        public static String GetTempName() {
            return System.Guid.NewGuid().ToString();
        }

        public static void SetCreationTime(String pathName, Date date) {
            Debug.AssertThrow(ExistsFile(pathName), eErrorCode.FileNotFound);
            Debug.AssertThrow(date != null, eErrorCode.NullArgument);

            File.SetCreationTime(pathName, new System.DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second));
        }
        public static void SetModifiedTime(String pathName, Date date) {
            Debug.AssertThrow(ExistsFile(pathName), eErrorCode.FileNotFound);
            Debug.AssertThrow(date != null, eErrorCode.NullArgument);

            File.SetLastWriteTime(pathName, new System.DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second));
        }

        // ".ext" 형태로 리턴
        public static String GetExt(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            return Path.GetExtension(pathName);
        }

        /// <summary>
        /// 주어진 경로의 파일 경로명들을 수집합니다.
        /// <para>참고: 접근 권한이 없거나 시스템, 숨김 속성을 가진 디렉토리는 제외</para>
        /// </summary>
        /// <param name="folderName">탐색할 경로</param>
        /// <param name="descendant">서브 디렉토리를 포함하여 탐색할지 지정</param>
        public static List<String> Collect(String folderName, Bool descendant) {
            Debug.AssertThrow(ExistsFolder(folderName), eErrorCode.FolderNotFound);

            List<String> result = List<String>.Create();

            // 파일 추가 (권한이 없는 경로는 패스)
            try {
                String[] files = System.IO.Directory.GetFiles(folderName);
                foreach (String file in files) {
                    result.Add(file);
                }
            } 
            catch (System.UnauthorizedAccessException) { }

            // 하위 폴더의 파일 추가 (권한이 없는 경로는 패스)
            if (descendant) {

                try {
                    String[] subDirs = System.IO.Directory.GetDirectories(folderName);
                    foreach (String dir in subDirs) {

                        DirectoryInfo info = new DirectoryInfo(dir);

                        // 시스템 경로나 숨김 경로가 아닐 경우에만 탐색
                        if ((info.Attributes & FileAttributes.Hidden) == 0 &&
                            (info.Attributes & FileAttributes.System) == 0) {

                            List<String> subFiles = Collect(dir, descendant); // 재귀호출
                            result.Add(subFiles);
                        }
                    }
                } 
                catch (System.UnauthorizedAccessException) { }
            }
            return result;
        }

        // "내그림" 폴더명 반환
        public static String GetMyPicturesFolderName() {
            return System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyPictures);
        }

        public static void SetFileInfo(String pathName, Bool readOnly, Bool hidden) {
            Debug.AssertThrow(ExistsFile(pathName), eErrorCode.FileNotFound);

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(pathName);

            if (readOnly) {
                fileInfo.Attributes |= System.IO.FileAttributes.ReadOnly;
            }
            else {
                fileInfo.Attributes &= ~System.IO.FileAttributes.ReadOnly;
            }

            if (hidden) {
                fileInfo.Attributes |= System.IO.FileAttributes.Hidden;
            }
            else {
                fileInfo.Attributes &= ~System.IO.FileAttributes.Hidden;
            }
        }
    }
}

