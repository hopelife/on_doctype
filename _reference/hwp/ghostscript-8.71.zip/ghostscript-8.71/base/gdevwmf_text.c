#include "gdevwmf.h"

typedef struct wmf_text_enum_s {
    gs_text_enum_common;
    gs_text_enum_t *pte_wmf;
    gs_fixed_point origin;
} wmf_text_enum_t;

extern_st(st_gs_text_enum);
extern_st(st_gs_font_base);

int wmf_text_process(gs_text_enum_t *pte)
{
	gx_device_wmf *wdev = (gx_device_wmf*)pte->dev;
    int code = 0;

	if (!wdev || !wdev->hdc)
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
     jTRACE( "--->%s\n", __FUNCTION__ );
#endif // _DEBUG

	return code;
}

const gs_text_enum_procs_t wmf_text_procs = {
    NULL, wmf_text_process,
    NULL, NULL,
    NULL, NULL,
    gx_default_text_release
};

int wmf_text_begin(gx_device *dev, gs_imager_state *pis, const gs_text_params_t *text, gs_font *font,
				   gx_path *path, const gx_device_color *pdcolor, const gx_clip_path *pcpath,
				   gs_memory_t *memory, gs_text_enum_t **ppte)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	gs_text_enum_t *pte = NULL;
	gs_matrix scale_matrix, scale_matrix2;
	gs_fixed_point start_position;
	gs_point offset;
	gs_font *pfontvalid = NULL;
	gs_font *new_font = NULL;
	int code;
    char tempText[ 4096 ];
	uint operation = text->operation;

	if (!wdev || !wdev->hdc)
		return 0;

	if (TEXT_PARAMS_ARE_INVALID(text))
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
    jTRACE( "--->%s\n", __FUNCTION__ );

    strncpy( tempText, text->data.bytes, text->size );
    tempText[ text->size ] = '\0';
    sprintf( g_sDebugString, "\ttext:%s, font:%s\n", tempText, font->font_name.chars );
    jTRACE( g_sDebugString );
    jTRACE( "\t position(%ld, %ld)\n", path->position.x, path->position.y ); 

	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_text_begin()===============================================Text\n");
		fprintf(wdev->pFile, "operation : ");
		if (text->operation & TEXT_FROM_STRING)          fprintf(wdev->pFile, "TEXT_FROM_STRING ");
		if (text->operation & TEXT_FROM_BYTES)           fprintf(wdev->pFile, "TEXT_FROM_BYTES ");
		if (text->operation & TEXT_FROM_CHARS)           fprintf(wdev->pFile, "TEXT_FROM_CHARS ");
		if (text->operation & TEXT_FROM_GLYPHS)          fprintf(wdev->pFile, "TEXT_FROM_GLYPHS ");
		if (text->operation & TEXT_FROM_SINGLE_CHAR)     fprintf(wdev->pFile, "TEXT_FROM_SINGLE_CHAR ");
		if (text->operation & TEXT_FROM_SINGLE_GLYPH)    fprintf(wdev->pFile, "TEXT_FROM_SINGLE_GLYPH ");
		if (text->operation & TEXT_ADD_TO_ALL_WIDTHS)    fprintf(wdev->pFile, "TEXT_ADD_TO_ALL_WIDTHS ");
		if (text->operation & TEXT_ADD_TO_SPACE_WIDTH)   fprintf(wdev->pFile, "TEXT_ADD_TO_SPACE_WIDTH ");
		if (text->operation & TEXT_REPLACE_WIDTHS)       fprintf(wdev->pFile, "TEXT_REPLACE_WIDTHS ");
		if (text->operation & TEXT_DO_NONE)              fprintf(wdev->pFile, "TEXT_DO_NONE ");
		if (text->operation & TEXT_DO_DRAW)              fprintf(wdev->pFile, "TEXT_DO_DRAW ");
		if (text->operation & TEXT_DO_CHARWIDTH)         fprintf(wdev->pFile, "TEXT_DO_CHARWIDTH ");
		if (text->operation & TEXT_DO_FALSE_CHARPATH)    fprintf(wdev->pFile, "TEXT_DO_FALSE_CHARPATH ");
		if (text->operation & TEXT_DO_TRUE_CHARPATH)     fprintf(wdev->pFile, "TEXT_DO_TRUE_CHARPATH ");
		if (text->operation & TEXT_DO_FALSE_CHARBOXPATH) fprintf(wdev->pFile, "TEXT_DO_FALSE_CHARBOXPATH ");
		if (text->operation & TEXT_DO_TRUE_CHARBOXPATH)  fprintf(wdev->pFile, "TEXT_DO_TRUE_CHARBOXPATH ");
		if (text->operation & TEXT_INTERVENE)            fprintf(wdev->pFile, "TEXT_INTERVENE ");
		if (text->operation & TEXT_RETURN_WIDTH)         fprintf(wdev->pFile, "TEXT_RETURN_WIDTH ");
		fprintf(wdev->pFile, "\n");

		if (text->operation & TEXT_FROM_STRING) {
			memset(g_sDebugString, 0, sizeof(g_sDebugString));
			g_sDebugString[text->size] = 0;
			strncpy(g_sDebugString, text->data.bytes, text->size);
			fprintf(wdev->pFile, "text : %s\n", g_sDebugString);
		}
		if (pdcolor)
			fprintf(wdev->pFile, "color    : %X\n", pdcolor->colors.pure);
		fprintf(wdev->pFile, "Position : (%d, %d)\n", ftoi(path->position.x), ftoi(path->position.y));
		fprintf(wdev->pFile, "Type     : %d\n", font->FontType);
		fprintf(wdev->pFile, "\n");
	}
    
#endif // _DEBUG

	// �ʿ��� �͸� ó���� �ְ� �������� gx_default_text_begin() �� �ñ��.
	if (!(
		   (font->FontType == ft_encrypted) // ft_encrypted == 1 (Type 1 Font)
		    || (font->FontType == ft_TrueType)
		&& !(text->operation & TEXT_REPLACE_WIDTHS)
		&& (text->operation & TEXT_DO_DRAW)
		)) {

		// gx_default_text_begin() ���� �ѱ��.
		goto error;
	}

	if (font->FontType == ft_user_defined) {
		pfontvalid = font;
	}
	else
		pfontvalid = font;

	// text_enum ������ �ʱ�ȭ
	rc_alloc_struct_1(pte, gs_text_enum_t, &st_gs_text_enum, memory,
					  return_error(gs_error_VMerror), "wmf_text_begin");
	code = gs_text_enum_init(pte, &wmf_text_procs, dev, pis, text, pfontvalid,
							 path, pdcolor, pcpath, memory);
	if (code < 0)
		goto error;

	*ppte = pte;

	gs_matrix_multiply((gs_matrix*)&pis->ctm, &pfontvalid->FontMatrix, &scale_matrix);
	gx_path_current_point(path, &start_position);
	gs_distance_transform(pfontvalid->FontMatrix.tx, pfontvalid->FontMatrix.ty, (gs_matrix*)&pis->ctm, &offset);
	start_position.x += float2fixed(offset.x);
	start_position.y += float2fixed(offset.y);
	gx_path_add_point(path, start_position.x, start_position.y);
	scale_matrix.tx = fixed2float(start_position.x);
	scale_matrix.ty = fixed2float(start_position.y);
	scale_matrix2 = scale_matrix;
	scale_matrix2.tx = 0;
	scale_matrix2.ty = 0;

#if defined(_DEBUG) || defined(DEBUG)
	jTRACE( "\t scale_matrix( %f, %f )\n", scale_matrix.tx, scale_matrix.ty );
#endif

	if (text->operation & TEXT_DO_DRAW) {
		gs_char cur_char, real_char;
		bool bMultiByte = false;
		gs_glyph cur_glyph;
		gx_path *ppath;
		gx_fill_params fparams;
		gx_stroke_params sparams;

		// width �� ����ϱ� ���� ����
		int wmode = pfontvalid->WMode;
		double scale = (font->FontType == ft_TrueType ? 0.001 : 1.0);
		gs_glyph_info_t info;
		gs_point w, dpt;
		int num_spaces = 0;
		w.x = 0, w.y = 0;

		fparams.rule = pcpath->rule;
		fparams.adjust = pis->fill_adjust;
		fparams.flatness = pis->flatness;
		fparams.fill_zero_width = true;
		sparams.flatness = pis->flatness;

		ppath = gx_path_alloc_shared(NULL, wdev->memory, "wmf_text_begin");
		gx_path_add_point(ppath, start_position.x, start_position.y);

#if defined( _DEBUG )
    jTRACE( "\t start(%ld,%ld)\n", start_position.x, start_position.y );
#endif

		while (pfontvalid->procs.next_char_glyph(pte, &cur_char, &cur_glyph) == 0) {
			real_char = cur_char;

			if (cur_glyph == gs_no_glyph)
            	cur_glyph = pfontvalid->procs.encode_char( pfontvalid, real_char, GLYPH_SPACE_NAME );
            if (cur_glyph == gs_no_glyph)
				continue;

            {
                double sbw[ 4 ] = { 0.0, };
                code = pfontvalid->procs.glyph_outline( pfontvalid, pfontvalid->WMode, cur_glyph, &scale_matrix, ppath, sbw );
            }
			if (code < 0) {
				gx_path_free(ppath, "wmf_text_begin");
				goto error;
			}

			code = pfontvalid->procs.glyph_info(pfontvalid, cur_glyph, &scale_matrix2,
				GLYPH_INFO_WIDTH0 << wmode, &info);
			if (code >= 0) {
				w.x += info.width[wmode].x;
				w.y += info.width[wmode].y;
				{
					fixed temp;
					temp = float2fixed(info.width[wmode].x);
					temp = float2fixed(info.width[wmode].y);
				}
			}
			else {
				gx_path_free(ppath, "wmf_text_begin");
				goto error;
			}
			if (cur_char == text->space.s_char)
				++num_spaces;

			if (text->operation & TEXT_ADD_TO_ALL_WIDTHS) {
				if (font->FontType == ft_encrypted) {
					ppath->position.x += float2fixed(text->delta_all.x * pis->ctm.xx);
					ppath->position.y += float2fixed(text->delta_all.y * pis->ctm.yy);
				}
				else if (font->FontType == ft_TrueType) {
					scale_matrix.tx += text->delta_all.x * pis->ctm.xx;
					scale_matrix.ty += text->delta_all.y * pis->ctm.yy;
				}
			}

			if ((text->operation & TEXT_ADD_TO_SPACE_WIDTH) && (cur_char == text->space.s_char)) {
				if (font->FontType == ft_encrypted) {
					ppath->position.x += float2fixed(text->delta_space.x * pis->ctm.xx);
					ppath->position.y += float2fixed(text->delta_space.y * pis->ctm.yy);
				}
				else if (font->FontType == ft_TrueType) {
					scale_matrix.tx += text->delta_space.x * pis->ctm.xx;
					scale_matrix.ty += text->delta_space.y * pis->ctm.yy;
				}
			}

			if (font->FontType == ft_encrypted) {
				scale_matrix.tx = fixed2float(ppath->position.x);
				scale_matrix.ty = fixed2float(ppath->position.y);
			}
			else if (font->FontType == ft_TrueType) {
				scale_matrix.tx += info.width[wmode].x;
				scale_matrix.ty += info.width[wmode].y;
			}

		} // while (pfontvalid->procs.next_char_glyph(pte, &cur_char, &cur_glyph) == 0)

		dpt = w;
		if (text->operation & TEXT_ADD_TO_ALL_WIDTHS) {
			dpt.x += text->delta_all.x * text->size;
			dpt.y += text->delta_all.y * text->size;
		}
		if (text->operation & TEXT_ADD_TO_SPACE_WIDTH) {
			dpt.x += text->delta_space.x * num_spaces;
			dpt.y += text->delta_space.y * num_spaces;
		}
		pte->returned.total_width = dpt;

		if (font->FontType == ft_encrypted)
			gx_path_add_point(path, ppath->position.x, ppath->position.y);
		else if (font->FontType == ft_TrueType)
			gx_path_add_relative_point(path, float2fixed(dpt.x), float2fixed(dpt.y));

		// ���ڴ� �Ϲ������� ���� ���ñ� ������, �ܰ����� �׸��� �ϴ� ���� ���� ����.
		fparams.fill_zero_width = false;
		if (wdev->bRecord)
			wmf_fill_path(dev, pis, ppath, &fparams, pdcolor, pcpath);
		gx_path_free(ppath, "wmf_text_begin");

	} // if (text->operation & TEXT_DO_DRAW)

	pte->index = 0;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	return code;

error:
#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "=== Error!!! ===\n");
		fprintf(wdev->pFile, "Call gx_default_text_begin()...\n");
	}
#endif // _DEBUG

	if (new_font)
		gs_free_object(memory, new_font, "wmf_text_begin");
	if (pte)
		gs_free_object(memory, pte, "wmf_text_begin");

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n");
#endif // _DEBUG

	return gx_default_text_begin(dev, pis, text, font, path, pdcolor, pcpath, memory, ppte);
}
