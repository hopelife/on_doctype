﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Hnc.Type;
using Hnc.Util;
using Float = System.Single;

namespace Hnc.VEFrame.Controls
{
    /// <summary>
    /// TitleBar.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class TitleBar : UserControl
    {
        public enum FrameWindowState {
            Normal = 0,
            Minimized = 1,
            Maximized = 2
        };

        double normalLeft = SystemParameters.WorkArea.Left;
        double normalTop = SystemParameters.WorkArea.Top;
        double normalWidth = 1181;
        double normalHeight = 670;

        FrameWindowState state = FrameWindowState.Normal;
        public FrameWindowState State {
            get {
                return state;
            }
            set {
                state = value;
            }
        }

        private VideoEditor.Controls.TitleBar child = null;
        public VideoEditor.Controls.TitleBar Child {
            get {
                return child;
            }
            set {
                child = value;
            }
        }

        public TitleBar()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(TitleBar_Loaded);
        }

        public void SwitchState() {
            switch (State) {
                case FrameWindowState.Normal: {
                    State = FrameWindowState.Maximized;
                    Application.Current.MainWindow.WindowState = WindowState.Normal;

                    normalLeft = Application.Current.MainWindow.Left;
                    normalTop = Application.Current.MainWindow.Top;
                    normalWidth = Application.Current.MainWindow.Width;
                    normalHeight = Application.Current.MainWindow.Height;

                    if (normalLeft < 0) {
                        Application.Current.MainWindow.Left = SystemParameters.VirtualScreenLeft;
                        Application.Current.MainWindow.Top = SystemParameters.WorkArea.Top;
                        Application.Current.MainWindow.Width = SystemParameters.VirtualScreenWidth - SystemParameters.PrimaryScreenWidth;
                        Application.Current.MainWindow.Height = SystemParameters.PrimaryScreenHeight;
                    } else if (normalLeft > SystemParameters.PrimaryScreenWidth) {
                        Application.Current.MainWindow.Left = SystemParameters.PrimaryScreenWidth;
                        Application.Current.MainWindow.Top = SystemParameters.WorkArea.Top;
                        Application.Current.MainWindow.Width = SystemParameters.VirtualScreenWidth - SystemParameters.PrimaryScreenWidth;
                        Application.Current.MainWindow.Height = SystemParameters.PrimaryScreenHeight;
                    } else {
                        Application.Current.MainWindow.Left = SystemParameters.WorkArea.Left;
                        Application.Current.MainWindow.Top = SystemParameters.WorkArea.Top;
                        Application.Current.MainWindow.Width = SystemParameters.WorkArea.Width;
                        Application.Current.MainWindow.Height = SystemParameters.WorkArea.Height;
                    }

                    break;
                }
                case FrameWindowState.Maximized: {
                    State = FrameWindowState.Normal;

                    Application.Current.MainWindow.WindowState = WindowState.Normal;
                    Application.Current.MainWindow.Left = normalLeft;
                    Application.Current.MainWindow.Top = normalTop;
                    Application.Current.MainWindow.Width = normalWidth;
                    Application.Current.MainWindow.Height = normalHeight;
                    break;
                }
            }

            Child.UpdateRestoreButton();
        }

        private void SwitchState2() {

            Window window = Application.Current.MainWindow;

            switch (window.WindowState) {
                case WindowState.Normal: {
                        window.WindowState = WindowState.Maximized;
                        break;
                    }
                case WindowState.Maximized: {
                        window.WindowState = WindowState.Normal;
                        break;
                    }
            }
        }

        private void TitleBar_Loaded(object sender, RoutedEventArgs ea) {

            Window window = Application.Current.MainWindow;
            var restoreIfMove = false;

            this.MouseLeftButtonDown += (s, e) => {
                if (e.ClickCount == 2) {
                    if ((window.ResizeMode == ResizeMode.CanResize) ||
                        (window.ResizeMode == ResizeMode.CanResizeWithGrip)) {
                        SwitchState();
                    }
                } else {
                    if (State == FrameWindowState.Maximized) {
                        restoreIfMove = true;
                    }
                }
            };

            this.MouseLeftButtonUp += (s, e) => {
                restoreIfMove = false;
            };

            this.MouseMove += (s, e) => {

                if (restoreIfMove) {
                    restoreIfMove = false;

                    // 전체화 해제시 타이틀 바의 중간 지점이 드래그 되도록 계산
                    var x = e.GetPosition(this).X - normalWidth / 2;

                    // 주 모니터에서 해제되는지 그 이외 모니터에서 해제되는지 체크하여 좌표 지정
                    if (normalLeft + 8 > SystemParameters.PrimaryScreenWidth) {
                        x += SystemParameters.PrimaryScreenWidth - 8;
                    } else {
                        //x += SystemParameters.PrimaryScreenWidth - 8;
                    }

                    // 가상 스크린 영역을 벗어나는 경우는 보정
                    if (x < 0)
                        x = 0;

                    if (x + normalWidth > SystemParameters.VirtualScreenWidth)
                        x = SystemParameters.VirtualScreenWidth - normalWidth;

                    State = FrameWindowState.Normal;
                    window.Left = x;
                    window.Top = 0;
                    window.Width = normalWidth;
                    window.Height = normalHeight;
                    Child.UpdateRestoreButton();
                    
                }

                if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
                    window.DragMove();
                }

                
            };
        }

        
    }
}
