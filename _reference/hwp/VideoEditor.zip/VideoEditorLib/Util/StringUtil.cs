﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Bool = System.Boolean;
using String = System.String;
using Count = System.Int32;



namespace Hnc.Util {

    /// <summary>
    /// 문자열 처리 관련 유틸리티 
    /// </summary>
    public static class StringUtil {

        /// <summary>
        /// values 중에 str이 있는지 검사 
        /// </summary>
        public static Bool Contains(String str, params String[] values) {
            Debug.AssertThrow(str != null, eErrorCode.NullArgument);

            for (int i = 0; i < values.Length; ++i) {
                if (str == values[i]) {
                    return true;
                }
            }
            return false;
        }
        // str에 subStr이 있는지 검사
        public static Bool Contains(String str, String subStr) {
            Debug.AssertThrow(str != null, eErrorCode.NullArgument);
            Debug.AssertThrow(subStr != null, eErrorCode.NullArgument);

            return str.Contains(subStr);
        }

        /// <summary>
        /// 문자열의 왼쪽을 주어진 갯수만큼 제거한다. 
        /// </summary>
        public static String TrimLeft(String str, Count count) {
            Debug.AssertThrow(str != null, eErrorCode.NullArgument);
            Debug.AssertThrow(count <= str.Length, eErrorCode.InvalidArgument);

            System.Text.StringBuilder sb = new System.Text.StringBuilder(str);
            sb.Remove(0, count);
            return sb.ToString();
        }

        /// <summary>
        /// 널, 빈 문자열 또는 공백만으로 이루어진 문자열인지 체크한다.
        /// </summary>
        public static bool IsNullOrEmpty(String str) {

            if (str == null || str.Length == 0 || str.Replace(" ", "").Length == 0)
                return true;
            else
                return false;
        }
    }    
}
