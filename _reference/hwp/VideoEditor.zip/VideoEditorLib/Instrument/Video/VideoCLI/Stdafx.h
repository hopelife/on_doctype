/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "../VideoLib/Difine.h"
#include "../VideoLib/VideoLib.h"