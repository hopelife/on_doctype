/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "stdafx.h"

#define FADEINOUT_NONE -1
#define FADEINOUT_OVERFRAME 0
#define FADEINOUT_NUMBER 15


class IEffect {
public:
	virtual ~IEffect() {}
	virtual Bool Apply(AVFrame* frame) = 0;
	virtual Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) = 0;
};

class EffectUtil {
public:
	static UInt8_t GetBrightness(UInt8_t value, Int percent);
	static Int FadeInOutEffect(UInt8_t* R, UInt8_t* G, UInt8_t* B, Int64_t frameCount, Int64_t frameLengh);
};

class None : public IEffect {
public:
	None() {}
	virtual ~None() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Gray : public IEffect {
public:
	Gray() {}
	virtual ~Gray() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Sepia : public IEffect {
public:
	Sepia() {}
	virtual ~Sepia() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Red : public IEffect {
public:
	virtual ~Red() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Green : public IEffect {
public:
	virtual ~Green() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Blue : public IEffect {
public:
	virtual ~Blue() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Yellow : public IEffect {
public:
	virtual ~Yellow() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Orange : public IEffect {
public:
	virtual ~Orange() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};

class Violet : public IEffect {
public:
	virtual ~Violet() {}
	Bool Apply(AVFrame* frame);
	Bool Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh);
};