﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using LogicalRect = Hnc.Type.Rect;
using LogicalSize = Hnc.Type.Size;
using LogicalPoint = Hnc.Type.Point;
using Ratio = System.Single;
using Bool = System.Boolean;
using Float = System.Single;

namespace Hnc.Util {
    public static class TransformUtil {

        // parent + current인 total Transform을 계산하여 리턴
        // 예를 들어 다음과 같이 사용할 수 있다.
        //
        // CalcTotal(group.currentTransform, group.originRect, child.currentTransform, child.originRect)
        // group이 originRect 에서 currentTransform으로 변하고,
        // child가 originRect에서 currentTransform에서 로 변하였을때,
        // child가 최종적으로 표시되어야할 transform을 리턴함
        public static Transformation CalcTotal(
            Transformation parent,
            LogicalRect parentOrigin,
            Transformation current,
            LogicalRect currentOrigin
        ) {
            Debug.AssertThrow(parent != null, eErrorCode.NullArgument);
            Debug.AssertThrow(parent.Rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(parentOrigin != null, eErrorCode.NullArgument);
            Debug.AssertThrow(current != null, eErrorCode.NullArgument);
            Debug.AssertThrow(current.Rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(currentOrigin != null, eErrorCode.NullArgument);

            Debug.Assert(parent.Rect.Center != null);
            Debug.Assert(current.Rect.Center != null);
            Debug.Assert(parentOrigin.Center != null);

            Debug.AssertThrow(parentOrigin.Width != 0, eErrorCode.DevideZero);
            Debug.AssertThrow(parentOrigin.Height != 0, eErrorCode.DevideZero);
            Debug.AssertThrow(currentOrigin.Width != 0, eErrorCode.DevideZero);
            Debug.AssertThrow(currentOrigin.Height != 0, eErrorCode.DevideZero);

            Transformation result = current.Clone();

		    // Scale 계산
		    Ratio parentXScale = (parent.Rect.Width == parentOrigin.Width) ? 1 : (Float)parent.Rect.Width / parentOrigin.Width;
            Ratio parentYScale = (parent.Rect.Height == parentOrigin.Height) ? 1 : (Float)parent.Rect.Height / parentOrigin.Height;

            Ratio currentXScale = (current.Rect.Width == currentOrigin.Width) ? 1 : (Float)current.Rect.Width / currentOrigin.Width;
            Ratio currentYScale = (current.Rect.Height == currentOrigin.Height) ? 1 : (Float)current.Rect.Height / currentOrigin.Height;

            
		    // 현 각도가 그룹과 45 ~ 135미만, 225 ~ 315미만인 경우 그룹의 가로변경이 도형의 세로에 적용되고, 그룹의 세로변경이 도형의 가로에 적용된다.
		    Degree currentAngle = current.Angle;
            if (currentAngle == null) {
                currentAngle = Degree.Create(0);
            }
            Bool isSwap = (45 <= currentAngle.Value && currentAngle.Value < 135) || (225 <= currentAngle.Value && currentAngle.Value < 315);
            if (isSwap) {
			    result.Rect.Width = MathUtil.Round(MathUtil.Abs(parentYScale) * currentXScale * currentOrigin.Width);
                result.Rect.Height = MathUtil.Round(MathUtil.Abs(parentXScale) * currentYScale * currentOrigin.Height);
		    }
		    else {
			    result.Rect.Width = MathUtil.Round(MathUtil.Abs(parentXScale) * currentXScale * currentOrigin.Width);
                result.Rect.Height = MathUtil.Round(MathUtil.Abs(parentYScale) * currentYScale * currentOrigin.Height);
		    }

		    if (parentXScale < 0) {
			    result.Rect.FlipWidth();
		    }
		    if (parentYScale < 0) {
			    result.Rect.FlipHeight();
		    }

		    // 회전각 계산. Parent가 가로/세로 둘중 1개만 반전되었다면, 각도 Flip
		    if (parentXScale * parentYScale < 0) {

			    currentAngle = Degree.Create(360) - currentAngle;
		    }
		    Degree totalAngle = parent.Angle + currentAngle;
		    result.Angle = totalAngle;

		    // 위치 계산
		    Transform2D transform2D = Transform2D.Create(
			    parentXScale,
			    parentYScale, 
			    parent.Angle, // 0, 0 위치를 중심으로 본다.
			    parent.Rect.Center.X, 
			    parent.Rect.Center.Y
		    );
		    result.Rect = LogicalRect.CreateFromCenter(transform2D.GetTransformPoint(current.Rect.Center - parentOrigin.Center), result.Rect.Width, result.Rect.Height);

            return result;	
        }

        // current를 rotateCenter를 중심으로 angle만큼 회전시켰을 때의 transform 리턴
        public static Transformation Rotate(
            Transformation current,
            Degree angle,
            LogicalPoint rotateCenter
        ) {
            Debug.AssertThrow(current.Rect != null && current.Angle != null, eErrorCode.NullArgument);
            Debug.AssertThrow(current != null, eErrorCode.NullArgument);
            Debug.AssertThrow(current != null, eErrorCode.NullArgument);


            Transform2D transform2D = Transform2D.Create();
            transform2D.Rotate(angle, rotateCenter.X, rotateCenter.Y);

            LogicalPoint transformCenter = transform2D.GetTransformPoint(current.Rect.Center);

            return Transformation.Create(
                LogicalRect.CreateFromCenter(transformCenter, current.Rect.Width, current.Rect.Height),
                current.Angle + angle
            );
        }



        public enum eScaleOriginStyle {
            LeftTop,
            RightTop,
            RightBottom,
            LeftBottom
        }
        // angle만큼 회전된 rect를 newSize로 변경할 경우의 사각좌표 리턴
        public static RectF Resize(RectF rect, Degree angle, SizeF newSize, eScaleOriginStyle style) {
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(angle != null, eErrorCode.NullArgument);
            Debug.AssertThrow(newSize != null, eErrorCode.NullArgument);


            PointF origin = GetPoint(rect, style); // 크기조정의 기준점

            // 크기조정전의 기준점
            Transform2D oldTransform2D = Transform2D.Create(rect, rect, angle, rect.Center);
            PointF oldScaleOrigin = oldTransform2D.GetTransformPoint(origin);

            
            // 크기조정후의 기준점
            RectF newRect = RectF.CreateFromCenter(rect.Center, newSize.CX, newSize.CY);
            Transform2D newTransform2D = Transform2D.Create(rect, newRect, angle, rect.Center);
            PointF newScaleOrigin = newTransform2D.GetTransformPoint(origin);

            // 새로운 크기에서 Center점은 기준점 이동 변위만큼 이동한다.
            PointF newCenter = newRect.Center + (oldScaleOrigin - newScaleOrigin);
            return RectF.CreateFromCenter(newCenter, newRect.Width, newRect.Height);

        
        }
        // 주어진 style의 포인트 리턴
        private static PointF GetPoint(RectF rect, eScaleOriginStyle style) {
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);

            switch (style) { 
                case eScaleOriginStyle.LeftTop: return rect.LeftTop;
                case eScaleOriginStyle.RightTop: return rect.RightTop;
                case eScaleOriginStyle.RightBottom: return rect.RightBottom;
                case eScaleOriginStyle.LeftBottom: return rect.LeftBottom;
            }

            Debug.Assert(false, "알수없는 타입");
            return rect.LeftTop;
        }
    }
}
