﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using Frame = System.Double;
using String = System.String;
using Point = System.Windows.Point;
using Canvas = System.Windows.Controls.Canvas;
using Thickness = System.Windows.Thickness;
using SolidColorBrush = System.Windows.Media.SolidColorBrush;
using Brushes = System.Windows.Media.Brushes;
using Image = System.Windows.Controls.Image;
using BitmapImage = System.Windows.Media.Imaging.BitmapImage;
using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;
using System.Windows.Controls;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Base.Enum;
using System.Collections.Generic;
using Hnc.VideoEditor.Service;
using System.IO;

namespace Hnc.VideoEditor.Controls {
	// ----------------------------------------------
	// TimelineInfo 하나에 대한 View
	// ---------------------------------------------- 
	public partial class TimelineInfoView : UserControl {

		#region 상수
		// Info 테두리 두께
		static readonly double THICKNESS1 = 0.0;
		static readonly double THICKNESS2 = 1.0;
		static readonly double SIZE_CHANGER_BAR = 0.0;

		static readonly double IMAGE_WIDTH = 80.0;
		static readonly double IMAGE_HEIGHT = 60.0;

        static readonly double MAX_GAP = 28.0;
		#endregion // 상수

		#region 멤버변수
		private TimelineInfo _value;
		private TimelineInfoChangedState _state = TimelineInfoChangedState.NoChanged;
		private Point _startPosition;
		private TimelineView _timelineView = null;
		private int _zIndex;
		private List<Image> _imageList = new List<Image>();
		private Bool _select = false;

		private Thickness BorderThickness2 = new Thickness(THICKNESS2);
		private Thickness BorderThickness1 = new Thickness(THICKNESS1);

		private Brush NormalBorderBrush = null;
		private Brush NormalBackground = null;
		private Brush NormalTextColor = null;

		private Brush SelectBorderBrush = null;
		private Brush SelectBackground = null;
		private Brush SelectTextColor = null;
		#endregion // 멤버변수

		#region Property
		public TimelineInfo Value {
			get {
				return _value;
			}
			set {
				_value = value.Clone();
				if (_value.GetType() == typeof(SubtitleInfo)) {
					label.Content = (_value as SubtitleInfo).Sentence;
				}
			}
		}

		public TimelineInfoChangedState STATE {
			get {
				return _state;
			}
			set {
				_state = value;
			}
		}

		public int ID {
			get {
				return _value.ID;
			}
			set {
				_value.ID = value;
			}
		}

		public Frame TotalFrame {
			get {
				return _value.TotalFrame;
			}
			set {
				_value.TotalFrame = value;
			}
		}

		public string Path {
			get {
				if (_value.GetType() == typeof(VideoInfo)) {
					VideoInfo info = _value as VideoInfo;
					return info.FilePath;
				} else if (_value.GetType() == typeof(SoundInfo)) {
					SoundInfo info = _value as SoundInfo;
					return info.FilePath;
				} else {
#if DEBUG
					Hnc.Type.Debug.Assert(false, "속성으로 Path가 존재하지 않습니다.");
#endif
				}
				return null;
			}
			set {
				if (_value.GetType() == typeof(VideoInfo)) {
					VideoInfo info = _value as VideoInfo;
					info.FilePath = (String)value.Clone();
				} else if (_value.GetType() == typeof(SoundInfo)) {
					SoundInfo info = _value as SoundInfo;
					info.FilePath = (String)value.Clone();
				} else {
#if DEBUG
					Hnc.Type.Debug.Assert(false, "속성으로 Path가 존재하지 않습니다.");
#endif
				}
			}
		}

		public FrameScope TimelineScope {
			get {
				return _value.TimelineScope;
			}		
			set {
				_value.TimelineScope = value.Clone();
			}
		}

		public int ZIndex {
			get {
				return _zIndex;
			}
			set {
				_zIndex = value;
			}
		}

		public Bool Select {
			get {
				return _select;
			}
			set {
				_select = value;
			}
		}
		#endregion // Property

		#region 생성자
		private TimelineInfoView() {
			InitializeComponent();

			NormalBorderBrush = (SolidColorBrush)FindResource("Frame.LineColor3");
			NormalBackground = (SolidColorBrush)FindResource("Frame.BGColor2");
			NormalTextColor = (SolidColorBrush)FindResource("Frame.TextColor2");

			SelectBorderBrush = (SolidColorBrush)FindResource("Frame.LineColorB4");
			SelectBackground = (SolidColorBrush)FindResource("Frame.BGColorB4");
			SelectTextColor = (SolidColorBrush)FindResource("Frame.TextColorB1");
		}

		public TimelineInfoView(TimelineView timelineView, TimelineInfo value) {
			InitializeComponent();

			NormalBorderBrush = (SolidColorBrush)FindResource("Frame.LineColor3");
			NormalBackground = (SolidColorBrush)FindResource("Frame.BGColor2");
			NormalTextColor = (SolidColorBrush)FindResource("Frame.TextColor2");

			SelectBorderBrush = (SolidColorBrush)FindResource("Frame.LineColorB4");
			SelectBackground = (SolidColorBrush)FindResource("Frame.BGColorB4");
			SelectTextColor = (SolidColorBrush)FindResource("Frame.TextColorB1");

			InitInfoView(timelineView, value);
		}

		#endregion // 생성자

		#region 초기화 함수
		private void InitInfoView(TimelineView timelineView, TimelineInfo value) {
			try {
				_timelineView = timelineView;
				Value = value.Clone();
				_zIndex = Canvas.GetZIndex(this);

				if (Value.GetType() == typeof(VideoInfo)) {
					GetImageList();

					foreach (Image image in _imageList) {
						image.Height = IMAGE_HEIGHT;
						image.Width = IMAGE_WIDTH;
						stackPanel.Children.Add(image);
					}

					stackPanel.Visibility = Visibility.Visible;
					PathLabel.Visibility = Visibility.Visible;
					label.Visibility = Visibility.Hidden;
				} else if (Value.GetType() == typeof(SoundInfo)) {
					label.Content = Path;
					stackPanel.Visibility = Visibility.Hidden;
					PathLabel.Visibility = Visibility.Visible;
					label.Visibility = Visibility.Hidden;
				} else if (Value.GetType() == typeof(SubtitleInfo)) {
					label.Content = (Value as SubtitleInfo).Sentence;
					stackPanel.Visibility = Visibility.Hidden;
					PathLabel.Visibility = Visibility.Hidden;
					label.Visibility = Visibility.Visible;
				} else {
#if DEBUG
					Hnc.Type.Debug.Assert(false, "잘못된 TimelineInfo Type이 들어왔습니다.");
#endif
				}

				infoBorder.BorderThickness = BorderThickness1;
				// infoBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(164, 90, 232));

				// Info 선택 여부를 처리 하기 위한 마우스 다운, 마우스 업
				info.PreviewMouseDown += Event_InfoPreviewMouseDown;
				info.PreviewMouseUp += Event_InfoPreviewMouseUp;

				// LeftCurser 선택 여부를 처리 하기 위한 마우스 다운, 마우스 업
				leftCurser.PreviewMouseDown += Event_LeftCurserPreviewMouseDown;
				leftCurser.PreviewMouseUp += Event_LeftCurserPreviewMouseUp;

				// RightCurser 선택 여부를 처리 하기 위한 마우스 다운, 마우스 업
				rightCurser.PreviewMouseDown += Event_RightCurserPreviewMouseDown;
				rightCurser.PreviewMouseUp += Event_RightCurserPreviewMouseUp;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion // 초기화 함수

		// 영상에서 지정된 범위의 Frame에서 10장의 썸네일 가져오는 함수
		public void GetImageList() {
			try {
				if (_value == null) {
					return;
				}

				VideoInfo info = _value as VideoInfo;

				if (info == null) {
					return;
				}

				Image image = null;
				double frameIndex = info.VideoScope.START;
				if (frameIndex > 0) {
					image = GetVideoThumbnail(Path, (int)frameIndex);
				} else {
					image = GetVideoThumbnail(Path);
				}

				_imageList.Add(image);
				PathLabel.Text = System.IO.Path.GetFileName(Path);

				/*
				double startFrameIndex = info.VideoScope.START;
				double endFrameIndex = info.VideoScope.END;

				int gap = (int)(info.VideoScope.LENGTH / 10.0);

				int frameIndex = (int)(startFrameIndex);

				for (int i = 1; i < 2; ++i) {
					Image image = GetVideoThumbnail(Path, (int)frameIndex);
					imageList.Add(image);
					PathLabel.Content = System.IO.Path.GetFileName(Path);

					frameIndex = frameIndex + gap;
				}
				*/
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private Image GetVideoThumbnail(string path) {
			try {
				ImageSource thumbnailImage = Hnc.Instrument.VideoUtil.GetVideoAutoThumbnail(path, (int)IMAGE_WIDTH, (int)IMAGE_HEIGHT);

				if (thumbnailImage == null) {
					return null;
				}

				Image image = new Image();
				image.Source = thumbnailImage;
				image.Stretch = Stretch.UniformToFill;
				image.HorizontalAlignment = HorizontalAlignment.Center;
				image.VerticalAlignment = VerticalAlignment.Center;

				return image;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return null;
			}
		}

		private Image GetVideoThumbnail(string path, int frameIndex) {
			try {
				ImageSource thumbnailImage = Hnc.Instrument.VideoUtil.GetVideoThumbnail(path, frameIndex, (int)IMAGE_WIDTH, (int)IMAGE_HEIGHT);

				if (thumbnailImage == null) {
					return null;
				}

				Image image = new Image();
				image.Source = thumbnailImage;
				image.Stretch = Stretch.UniformToFill;
				image.HorizontalAlignment = HorizontalAlignment.Center;
				image.VerticalAlignment = VerticalAlignment.Center;

				return image;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return null;
			}
		}

		// 특정 프레임의 썸네일 한장을 가져오는 함수
		private Image GetImage(double frame, string url) {
			try {
				BitmapImage bitmap = new BitmapImage();

				bitmap.BeginInit();
				bitmap.UriSource = new Uri(url, UriKind.RelativeOrAbsolute);

				bitmap.DecodePixelWidth = 600;
				bitmap.EndInit();
				bitmap.Freeze();

				Image image = new Image();
				image.Source = bitmap;
				image.Stretch = Stretch.UniformToFill;
				image.HorizontalAlignment = HorizontalAlignment.Center;
				image.VerticalAlignment = VerticalAlignment.Center;

				return image;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return null;
			}
		}

		// 화면 갱신 함수 
		#region 화면 갱신 함수
		public void AllUpdate() {
			_timelineView.AllUpdate();
		}

		public void Update() {
			Update(_timelineView.Zoom, _timelineView.NumberUnit, _timelineView.FrameCount);
		}

		public void Update(double zoom, int numberUnit, double frameCount) {
			try {
				if (zoom == 0.0) {
#if DEBUG
					Hnc.Type.Debug.Assert(false, "zoom이 0이 될 수는 없습니다. 1로 변경합니다.");
#endif
					zoom = 1.0;
				}

				// double length = TimelineScope.LENGTH * (1.0 / frameCount);
				// double start = TimelineScope.START * (1.0 / frameCount);
				double length = TimelineScope.LENGTH;
				double start = TimelineScope.START;

				if (zoom > 0) {
					try {
						if ((length * zoom) / numberUnit < 0) {
							info.Width = 0.0;
						}
						info.Width = (length * zoom) / numberUnit;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
						info.Width = 0.0;
					}

					double position = 0.0;
					try {
						position = (start * zoom) / numberUnit - SIZE_CHANGER_BAR;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
						position = 0.0;
					}

					SetValue(Canvas.LeftProperty, position);
				} else {
					try {
						if ((length / Math.Abs(zoom)) / numberUnit < 0) {
							info.Width = 0.0;
						}
						info.Width = (length / Math.Abs(zoom)) / numberUnit;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
						info.Width = 0.0;
					}

					double position = 0.0;
					try {
						position = (start * Math.Abs(zoom)) / numberUnit - SIZE_CHANGER_BAR;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
						position = 0.0;
					}
					SetValue(Canvas.LeftProperty, position);
				}

				if (Select == true) {
					// 테두리 색 지정
					BorderLine.Width = new GridLength(0.0);
					infoBorder.BorderThickness = BorderThickness1;
					infoBorder.BorderBrush = SelectBorderBrush;
					info.Background = SelectBackground;
					PathLabel.Foreground = SelectTextColor;
					SelectBoundary.Visibility = Visibility.Visible;
					leftCurser.Visibility = Visibility.Visible;
					rightCurser.Visibility = Visibility.Visible;
					RemoveBtn.Visibility = Visibility.Visible;
				} else {
					// 테두리 색 지정 
					BorderLine.Width = new GridLength(1.0);
					infoBorder.BorderThickness = BorderThickness1;
					infoBorder.BorderBrush = NormalBorderBrush;
					info.Background = NormalBackground;
					PathLabel.Foreground =NormalTextColor;
					SelectBoundary.Visibility = Visibility.Hidden;
					leftCurser.Visibility = Visibility.Hidden;
					rightCurser.Visibility = Visibility.Hidden;
					RemoveBtn.Visibility = Visibility.Hidden;
				}

				VideoInfo value = Value as VideoInfo;

				if (value != null) {
					PathLabel.Text = System.IO.Path.GetFileName(value.FilePath);
				} else {
					PathLabel.Text = null;
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion // 화면 갱신 함수

		private void Click_VideoInfoDelete(object sender, MouseButtonEventArgs e) {
			try {
				ActionRemoveInfo action = ActionRemoveInfo.Create(ID);

				if (ActionManager.Instance.Excute(action) == true) {
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		// 타임라인 정보 충돌 체크 함수 
		#region 타임라인 정보 충돌 체크 함수
		private TimelineInfoView LeftCollision(double moveValue) {
			return LeftCollision(TimelineScope.START, moveValue);
		}

		private TimelineInfoView LeftCollision(double startPosition, double moveValue) {
			try {
				double position = startPosition + moveValue;

				TimelineInfoView clossInfo = null;

				double gap = System.Double.MaxValue;

				foreach (TimelineInfoView viewInfo in _timelineView.infoCanvas.Children) {
					if (viewInfo != this) {
						if ((startPosition - viewInfo.TimelineScope.END) >= 0) {
							if ((startPosition - viewInfo.TimelineScope.END) <= gap) {
								gap = (startPosition - viewInfo.TimelineScope.END);
								clossInfo = viewInfo;
							}
						}
					}
				}

				if (clossInfo != null) {
					if (position <= clossInfo.TimelineScope.END) {
						return clossInfo;
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return null;
		}

		private TimelineInfoView FindLeftAdjoin(List<TimelineInfoView> list, TimelineInfoView viewInfo) {
			try {
				foreach (TimelineInfoView otherViewInfo in _timelineView.infoCanvas.Children) {
					if (otherViewInfo != viewInfo) {
						if (viewInfo.TimelineScope.START == otherViewInfo.TimelineScope.END) {
							if (FindLeftAdjoin(list, otherViewInfo) == null) {
								list.Add(otherViewInfo);
							}
						}
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return null;
		}

		private TimelineInfoView FindRightAdjoin(List<TimelineInfoView> list, TimelineInfoView viewInfo) {
			try {
				foreach (TimelineInfoView otherViewInfo in _timelineView.infoCanvas.Children) {
					if (otherViewInfo != viewInfo) {
						if (viewInfo.TimelineScope.END == otherViewInfo.TimelineScope.START) {
							if (FindRightAdjoin(list, otherViewInfo) == null) {
								list.Add(otherViewInfo);
							}
						}
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return null;
		}

		public List<TimelineInfoView> FindLeftAdjoin() {
			try {
				List<TimelineInfoView> adjoinList = new List<TimelineInfoView>();

				FindLeftAdjoin(adjoinList, this);

				return adjoinList;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return null;
			}
		}

		public List<TimelineInfoView> FindRightAdjoin() {
			try {
				List<TimelineInfoView> adjoinList = new List<TimelineInfoView>();

				FindRightAdjoin(adjoinList, this);

				return adjoinList;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return null;
			}
		}

		private TimelineInfoView RightCollision(double moveValue) {
			return RightCollision(TimelineScope.END, moveValue);
		}

		private TimelineInfoView RightCollision(double endPosition, double moveValue) {
			try {
				double position = endPosition + moveValue;

				TimelineInfoView clossInfo = null;

				double gap = System.Double.MaxValue;

				foreach (TimelineInfoView viewInfo in _timelineView.infoCanvas.Children) {
					if (viewInfo != this) {
						if ((viewInfo.TimelineScope.START - endPosition) >= 0) {
							if ((viewInfo.TimelineScope.START - endPosition) <= gap) {
								gap = (viewInfo.TimelineScope.START - endPosition);
								clossInfo = viewInfo;
							}
						}
					}
				}

				if (clossInfo != null) {
					if (position >= clossInfo.TimelineScope.START) {
						return clossInfo;
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return null;
		}
		#endregion // 타임라인 정보 충돌 체크 함수

		public bool SelectInfo() {
			bool retval = false;

			try {
				int selectId = _timelineView.SelectedInfoID;
				_timelineView.ClearSelect();
				Select = true;

				VideoInfo value = Value as VideoInfo;
				if (value != null) {
					if (_imageList[0] != null) {
						value.ThumbnailImage = _imageList[0];
					}
				}

				if (selectId != ID) {
					if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayerMode(PlayerMode.PlayEditor);
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
					}
					retval = false;
				} else {
					retval = true;
				}

				_timelineView.SelectedInfoID = ID;

				_timelineView.SelectedInfo = Value;
				Canvas.SetZIndex(this, 99);

				_timelineView.AllUpdate();
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return retval;
		}

		// Info 관련 이벤트
		#region Info 관련 이벤트
		// Info 마우스 다운 이벤트
		private bool InRemoveButton(Point pt) {
			try {
				if (pt.X < 0) {
					return false;
				}

				if (pt.Y > RemoveBtn.Height) {
					return false;
				}

				if (pt.X > RemoveBtn.Width) {
					return false;
				}
				
				if (pt.Y > pt.X) {
					//return false;
					return true;
				}

				return true;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				return false;
			}
		}


		double infoLeftMoveBoundary = 0.0;
		double infoRightMoveBoundary = 0.0;
		double selectInfoStart = 0.0;
		double selectInfoEnd = 0.0;

		double leftInfoStart = 0.0;
		double leftInfoEnd = 0.0;
		double leftInfoLength = 0.0;
		TimelineInfoView selectLeftInfoView = null;

		double rightInfoStart = 0.0;
		double rightInfoEnd = 0.0;
		double rightInfoLength = 0.0;
		TimelineInfoView selectRightInfoView = null;

		public enum CheckChanging : int {
			NoChanged = 0,
			Left = 1,
			Right = 2
		};

		CheckChanging checkChanging = CheckChanging.NoChanged;

		private bool inRemoveButtonState = false;

		private void Event_InfoPreviewMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				bool retval = SelectInfo();

				if (InRemoveButton(e.GetPosition(RemoveBtn)) == true) {
					inRemoveButtonState = true;

				} else {
					// 마우스 드래그를 위한 커서 캡쳐
					info.CaptureMouse();
					
					// 드래그 시작 위치 지정
					_startPosition = e.GetPosition(_timelineView);

					int infoCount = _timelineView.GetTimelinInfoCount();

					selectInfoStart = TimelineScope.START;
					selectInfoEnd = TimelineScope.END;
					
					if (infoCount > 1) {
						// move 이벤트 추가
						checkChanging = CheckChanging.NoChanged;
						// 이동 가능 범위 찾기
						selectLeftInfoView = null;
						selectRightInfoView = null;
						infoLeftMoveBoundary = GetTimelineInfoLeftBoundary(this);
						infoRightMoveBoundary = GetTimelineInfoRightBoundary(this);

						if (infoLeftMoveBoundary != 0.0 || infoRightMoveBoundary != 0.0) {
							info.PreviewMouseMove += Event_InfoPreviewMouseMove;
						}
					}

					if (retval == false) {
						if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditOpen();
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
						}
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_InfoPreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				if (InRemoveButton(e.GetPosition(RemoveBtn))) {
					inRemoveButtonState = false;

					ActionSortRemoveInfo action = ActionSortRemoveInfo.Create(ID);
					if (ActionManager.Instance.Excute(action) == true) {
						if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.CheckTimelineInfoCount();
						}
					}
				} else {
					if (inRemoveButtonState == true) {
						inRemoveButtonState = false;
					} else {
						// 마우스 드래그를 위한 커서 캡쳐 해제
						info.ReleaseMouseCapture();

						// move 이벤트 제거
						info.PreviewMouseMove -= Event_InfoPreviewMouseMove;

						if (checkChanging == CheckChanging.Left) {
							ChangingInfo(selectLeftInfoView, this);
						} else if (checkChanging == CheckChanging.Right) {
							ChangingInfo(selectRightInfoView, this);
						} else {
							TimelineScope.START = selectInfoStart;
							TimelineScope.END = selectInfoEnd;
							STATE = TimelineInfoChangedState.NoChanged;
							Update();
						}

						checkChanging = CheckChanging.NoChanged;
						selectLeftInfoView = null;
						selectRightInfoView = null;
						infoLeftMoveBoundary = 0.0;
						infoRightMoveBoundary = 0.0;
						selectInfoStart = 0.0;
						selectInfoEnd = 0.0;

						if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();

							if (Value.GetType() == typeof(VideoInfo)) {
								Hnc.VEFrame.VEFrameManager.Instance.MainPage.VideoInfosMouseUp();
							}
						}
					}
				}

				//Canvas.SetZIndex(this, zIndex);
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_InfoPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				if (Select == true) {
					if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
						Point currentPosition = e.GetPosition(_timelineView);

						double gap = 0.0;
						if (_timelineView.Zoom > 0) {
							try {
								gap = (currentPosition.X - _startPosition.X) / _timelineView.Zoom;
							} catch (DivideByZeroException) {
								Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
								gap = 0.0;
							}
						} else {
							gap = (currentPosition.X - _startPosition.X) * Math.Abs(_timelineView.Zoom);
						}

						if (TimelineScope.START + gap < 0.0) {
							gap = 0.0 - TimelineScope.START;
						}

						// 왼쪽으로 이동
						if (gap < 0) {
							if (infoLeftMoveBoundary == 0.0) {
								if ((TimelineScope.START + gap) < selectInfoStart) {
									gap = selectInfoStart - TimelineScope.START;
								}
								// gap = 0.0;
							} else if ((TimelineScope.START + gap) < infoLeftMoveBoundary) {
								gap = infoLeftMoveBoundary - TimelineScope.START;
							}
						}
						else {
							if (infoRightMoveBoundary == 0.0) {
								if ((TimelineScope.END + gap) > selectInfoEnd) {
									gap = selectInfoEnd - TimelineScope.END;
								}
							} else if ((TimelineScope.END + gap) > infoRightMoveBoundary) {
								gap = infoRightMoveBoundary - TimelineScope.END;
							}
						}

						// 바꿀지 여부 체크
						if ((TimelineScope.START + gap) == infoLeftMoveBoundary) {
							checkChanging = CheckChanging.Left;

							if (selectLeftInfoView != null) {
								selectLeftInfoView.TimelineScope.END = selectInfoEnd;
								selectLeftInfoView.TimelineScope.START = selectLeftInfoView.TimelineScope.END - leftInfoLength;
							}
						} else if ((TimelineScope.END + gap) == infoRightMoveBoundary) {
							checkChanging = CheckChanging.Right;

							if (selectRightInfoView != null) {
								selectRightInfoView.TimelineScope.START = selectInfoStart;
								selectRightInfoView.TimelineScope.END = selectRightInfoView.TimelineScope.START + rightInfoLength;
							}
						} else {
							checkChanging = CheckChanging.NoChanged;
							//infoBorder.BorderBrush = (SolidColorBrush)FindResource("Base_Brush");
							if (selectLeftInfoView != null) {
								selectLeftInfoView.TimelineScope.START = leftInfoStart;
								selectLeftInfoView.TimelineScope.END = leftInfoEnd;
							}

							if (selectRightInfoView != null) {
								selectRightInfoView.TimelineScope.START = rightInfoStart;
								selectRightInfoView.TimelineScope.END = rightInfoEnd;
							}
						}

						TimelineScope.START = TimelineScope.START + gap;
						TimelineScope.END = TimelineScope.END + gap;

						if (gap != 0.0) {
							AllUpdate();
						}

						_startPosition = currentPosition;
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_InfoPreviewMouseMove2(object sender, MouseEventArgs e) {
			try {
				if (Select == true) {
					if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
						Point currentPosition = e.GetPosition(_timelineView);

						double gap = 0.0;

						if (_timelineView.Zoom > 0) {
							try {
								gap = (currentPosition.X - _startPosition.X) / _timelineView.Zoom;
							} catch (DivideByZeroException) {
								Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
								gap = 0.0;
							}
						} else {
							gap = (currentPosition.X - _startPosition.X) * Math.Abs(_timelineView.Zoom);
						}

						// 왼쪽으로 이동
						if (gap < 0) {
							List<TimelineInfoView> leftAdjoinList = FindLeftAdjoin();
							TimelineInfoView leftInfo = null;

							if (leftAdjoinList.Count > 0) {
								double position = TimelineScope.START;

								TimelineInfoView selectInfo = null;
								foreach (TimelineInfoView viewInfo in leftAdjoinList) {
									if (viewInfo.TimelineScope.START < position) {
										position = viewInfo.TimelineScope.START;
										selectInfo = viewInfo;
									}
								}

								leftInfo = LeftCollision(position, gap);


								if (leftInfo != null) {
									gap = leftInfo.TimelineScope.END - selectInfo.TimelineScope.START;
								}

								if (selectInfo.TimelineScope.START + gap < 0.0) {
									gap = 0.0 - selectInfo.TimelineScope.START;
								}


								foreach (TimelineInfoView viewInfo in leftAdjoinList) {
									viewInfo.STATE = TimelineInfoChangedState.Move;
									viewInfo.TimelineScope.START = viewInfo.TimelineScope.START + gap;
									viewInfo.TimelineScope.END = viewInfo.TimelineScope.END + gap;
								}
							} else {
								leftInfo = LeftCollision(gap);

								if (leftInfo != null) {
									gap = leftInfo.TimelineScope.END - TimelineScope.START;
								}

								if (TimelineScope.START + gap < 0.0) {
									gap = 0.0 - TimelineScope.START;
								}
							}
						}
							// 오른쪽으로 이동
						else {
							List<TimelineInfoView> rightAdjoinList = FindRightAdjoin();

							TimelineInfoView rightInfo = null;

							if (rightAdjoinList.Count > 0) {
								double position = TimelineScope.END;

								TimelineInfoView selectInfo = null;
								foreach (TimelineInfoView viewInfo in rightAdjoinList) {
									if (viewInfo.TimelineScope.END > position) {
										position = viewInfo.TimelineScope.END;
										selectInfo = viewInfo;
									}
								}

								rightInfo = RightCollision(position, gap);


								if (rightInfo != null) {
									gap = rightInfo.TimelineScope.START - selectInfo.TimelineScope.END;
								}


								foreach (TimelineInfoView viewInfo in rightAdjoinList) {
									viewInfo.STATE = TimelineInfoChangedState.Move;
									viewInfo.TimelineScope.START = viewInfo.TimelineScope.START + gap;
									viewInfo.TimelineScope.END = viewInfo.TimelineScope.END + gap;
								}
							} else {
								rightInfo = RightCollision(gap);

								if (rightInfo != null) {
									gap = rightInfo.TimelineScope.START - TimelineScope.END;
								}
							}
						}

						TimelineScope.START = TimelineScope.START + gap;
						TimelineScope.END = TimelineScope.END + gap;

						if (gap != 0.0) {
							STATE = TimelineInfoChangedState.Move;
							AllUpdate();
						}
					}
				}

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion // Info 관련 이벤트

		double startPosition;
		// leftCurser 관련 이벤트
		#region leftCurser 관련 이벤트
		private void Event_LeftCurserPreviewMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				// 마우스 드래그를 위한 커서 캡쳐
				leftCurser.CaptureMouse();
				// 드래그 시작 위치 지정
				_startPosition = e.GetPosition(_timelineView);
				startPosition = TimelineScope.START;

				// move 이벤트 추가
				leftCurser.PreviewMouseMove += Event_LeftCurserPreviewMouseMove;

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditOpen();
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		public void ChangedImageThumnail() {
			if (Value.GetType() == typeof(VideoInfo)) {
				_imageList.Clear();
				

				GetImageList();

				if (_imageList.Count > 0) {
					stackPanel.Children.Clear();

					foreach (Image image in _imageList) {
                        image.Stretch = Stretch.Fill;
						image.Height = IMAGE_HEIGHT;
						image.Width = IMAGE_WIDTH;
						stackPanel.Children.Add(image);
					}
				}
			}
		}

		private void Event_LeftCurserPreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				// 마우스 드래그를 위한 커서 캡쳐 해제
				leftCurser.ReleaseMouseCapture();

				// move 이벤트 추가
				leftCurser.PreviewMouseMove -= Event_LeftCurserPreviewMouseMove;

				if (startPosition < TimelineScope.START) {
					double gap = startPosition - TimelineScope.START;
					TimelineScope.START += gap;
					TimelineScope.END += gap;

					MoveOtherInfo(gap);
				}

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();

					if (Value.GetType() == typeof(VideoInfo)) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.VideoInfosMouseUp();
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_LeftCurserPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				if (Select == true) {
					if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
						Point currentPosition = e.GetPosition(_timelineView);

                        
                        double left = (double) this.GetValue(Canvas.LeftProperty);
                        double width = leftCurser.ActualWidth;
                        /*
                        if (currentPosition.X < left || currentPosition.X > left + width) {
                            return;
                        }
                        */

						double gap = 0.0;

						if (_timelineView.Zoom > 0) {
							try {
								gap = (currentPosition.X - _startPosition.X) / _timelineView.Zoom;
							} catch (DivideByZeroException) {
								Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
								gap = 0.0;
							}
						} else {
							gap = (currentPosition.X - _startPosition.X) * Math.Abs(_timelineView.Zoom);
						}

						// 왼쪽으로 이동
						if (gap < 0) {
							/*
							TimelineInfoView leftInfo = null;

							leftInfo = LeftCollision(gap);

							if (leftInfo != null) {
								gap = leftInfo.TimelineScope.END - TimelineScope.START;
							}

							if (TimelineScope.START + gap < 0.0) {
								gap = 0.0 - TimelineScope.START;
							}

							if ((TimelineScope.LENGTH + Math.Abs(gap)) >= TotalFrame) {
								gap = 0.0;// TimelineScope.LENGTH - TotalFrame;
							}
							*/

							gap = gap * _timelineView.NumberUnit;

							if (Value.GetType() == typeof(VideoInfo)) {
								VideoInfo videoInfo = Value as VideoInfo;
								if (videoInfo.VideoScope.START + gap >= TotalFrame) {
									gap = 0.0;
                                    return;
								}

								if (videoInfo.VideoScope.START + gap <= 0.0) {
									gap = 0.0 - videoInfo.VideoScope.START;
								}

								videoInfo.VideoScope.START = videoInfo.VideoScope.START + gap;
							}

                            if (startPosition == TimelineScope.START) {
                                MoveOtherInfo(-gap);
                                TimelineScope.END = TimelineScope.END - gap;
                            } else if (startPosition == TimelineScope.START - gap) {
                                MoveOtherInfo(-gap);
                                TimelineScope.START = startPosition;
                            } else if (startPosition < TimelineScope.START - gap) {
                                TimelineScope.START = TimelineScope.START + gap;
                            } else if (startPosition > TimelineScope.START - gap) {
                                MoveOtherInfo(-gap);
                                double gap2 = TimelineScope.START - startPosition;

                                gap = gap2 - gap;
                                TimelineScope.START = startPosition;
                                TimelineScope.END = TimelineScope.END - gap;
                            } else {
                                MoveOtherInfo(-gap);
                            }
						}
						// 오른쪽으로 이동
						else {
                            double xGap = (currentPosition.X - _startPosition.X);
                            if (info.Width - xGap <= MAX_GAP) {
                                return;
                            }

							if (TimelineScope.START > TimelineScope.END) {
								return;
							}

							if (TimelineScope.LENGTH < 0) {
								return;
							}

							double tempGap = gap;
							gap = gap * _timelineView.NumberUnit;

							if ((TimelineScope.START + gap) >= TimelineScope.END) {
								gap = 0.0;
							}

							if (Value.GetType() == typeof(VideoInfo)) {
								VideoInfo videoInfo = Value as VideoInfo;
								videoInfo.VideoScope.START = videoInfo.VideoScope.START + gap;
							}

							//MoveOtherInfo(-gap);

							if (TimelineScope.START > TimelineScope.END) {
								return;
							}

							if (TimelineScope.LENGTH < 0) {
								return;
							}

							if ((TimelineScope.START + gap) >= TimelineScope.END) {
								gap = 0.0;
							}

							TimelineScope.START = TimelineScope.START + gap;
						}

						//TimelineScope.START = TimelineScope.START + gap;

						if (TimelineScope.START > TimelineScope.END) {
							return;
						}

						if (TimelineScope.LENGTH < 0) {
							return;
						}

						ChangedImageThumnail();

						if (gap != 0.0) {
							STATE = TimelineInfoChangedState.Move;
							AllUpdate();

                            _startPosition = currentPosition;
						}
					}
				}

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion // leftCurser 관련 이벤트

		public double GetTimelineInfoRightBoundary(TimelineInfoView infoView) {
			try {
				if (infoView == null) {
					return 0.0;
				}

				TimelineInfoView rightInfoView = null;

				try {
					foreach (TimelineInfoView otherViewInfo in _timelineView.infoCanvas.Children) {
						if (infoView != otherViewInfo) {
							double end = Math.Floor(1000.0 * TimelineScope.END)/1000;
							double start = Math.Floor(1000.0 * otherViewInfo.TimelineScope.START)/1000;

							if (end == start) {
								rightInfoView = otherViewInfo;
							}
						}
					}

					if (rightInfoView == null) {
						selectRightInfoView = null;
						return 0.0;
					}

					selectRightInfoView = rightInfoView;
					rightInfoStart = rightInfoView.TimelineScope.START;
					rightInfoEnd = rightInfoView.TimelineScope.END;
					rightInfoLength = rightInfoView.TimelineScope.LENGTH;
					return rightInfoView.TimelineScope.END - (rightInfoView.TimelineScope.LENGTH / 2);
				} catch {
					Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return 0.0;
		}

		public double GetTimelineInfoLeftBoundary(TimelineInfoView infoView) {
			try {
				if (infoView == null) {
					return 0.0;
				}

				TimelineInfoView leftInfoView = null;

				try {
					foreach (TimelineInfoView otherViewInfo in _timelineView.infoCanvas.Children) {
						if (infoView != otherViewInfo) {
							double end = Math.Floor(1000.0 * otherViewInfo.TimelineScope.END) / 1000;
							double start = Math.Floor(1000.0 * TimelineScope.START) / 1000;

							if (start == end) {
								leftInfoView = otherViewInfo;
							}
						}
					}

					if (leftInfoView == null) {
						selectLeftInfoView = null;
						return 0.0;
					}

					selectLeftInfoView = leftInfoView;
					leftInfoStart = leftInfoView.TimelineScope.START;
					leftInfoEnd = leftInfoView.TimelineScope.END;
					leftInfoLength = leftInfoView.TimelineScope.LENGTH;

					return leftInfoView.TimelineScope.END - (leftInfoView.TimelineScope.LENGTH / 2);
				} catch {
					Hnc.Type.Debug.Assert(false, "TimelineView Exception");
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			return 0.0;
		}

		private void ChangingInfo(TimelineInfoView selectInfoView, TimelineInfoView infoView) {

			double infoViewLength = infoView.TimelineScope.LENGTH;
			double selectInfoViewLength = 0.0;

			if (checkChanging == CheckChanging.Left) {
				selectInfoViewLength = leftInfoLength;

				infoView.TimelineScope.START = leftInfoStart;
				infoView.TimelineScope.END = infoView.TimelineScope.START + infoViewLength;

				selectInfoView.TimelineScope.START = infoView.TimelineScope.END;
				selectInfoView.TimelineScope.END = selectInfoView.TimelineScope.START + selectInfoViewLength;
			} else if (checkChanging == CheckChanging.Right) {
				selectInfoViewLength = rightInfoLength;

				selectInfoView.TimelineScope.START = selectInfoStart;
				selectInfoView.TimelineScope.END = selectInfoView.TimelineScope.START + selectInfoViewLength;

				infoView.TimelineScope.START = selectInfoView.TimelineScope.END;
				infoView.TimelineScope.END = infoView.TimelineScope.START + infoViewLength; 
			}

			VideoInfo videoInfo = infoView.Value as VideoInfo;
			VideoInfo selectVideoInfo = selectInfoView.Value as VideoInfo;

			if (videoInfo != null && selectVideoInfo != null) {
				double start = 0.0;
				double end = 0.0;

				start = videoInfo.VideoScope.START;
				end = videoInfo.VideoScope.END;

				videoInfo.VideoScope.START = selectVideoInfo.VideoScope.START;
				videoInfo.VideoScope.END = selectVideoInfo.VideoScope.END;

				selectVideoInfo.VideoScope.START = start;
				selectVideoInfo.VideoScope.END = end;
			}

			infoView.STATE = TimelineInfoChangedState.Move;
			selectInfoView.STATE = TimelineInfoChangedState.Move;
		}

		private void MoveOtherInfo(double gap) {
			if (gap == 0.0) {
				return;
			}

			List<TimelineInfoView> rightInfoList = new List<TimelineInfoView>();

			// 현재 선택된 TimelineInfoView 오른편에 있는 TimelineInfoView를 모두 찾기
			try {
				foreach (TimelineInfoView otherViewInfo in _timelineView.infoCanvas.Children) {
					if (this != otherViewInfo) {
						if (TimelineScope.END < otherViewInfo.TimelineScope.END) {
							rightInfoList.Add(otherViewInfo);
						}
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}

			foreach (TimelineInfoView viewInfo in rightInfoList) {
				viewInfo.STATE = TimelineInfoChangedState.Move;
				viewInfo.TimelineScope.START = viewInfo.TimelineScope.START + gap;
				viewInfo.TimelineScope.END = viewInfo.TimelineScope.END + gap;
			}
		}

		// rightCurser 관련 이벤트
		#region rightCurser 관련 이벤트
		private void Event_RightCurserPreviewMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				// 마우스 드래그를 위한 커서 캡쳐
				rightCurser.CaptureMouse();
				// 드래그 시작 위치 지정
				_startPosition = e.GetPosition(_timelineView);

				// move 이벤트 추가
				rightCurser.PreviewMouseMove += Event_RightCurserPreviewMouseMove;

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditOpen();
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_RightCurserPreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				// 마우스 드래그를 위한 커서 캡쳐 해제
				rightCurser.ReleaseMouseCapture();

				// move 이벤트 추가
				rightCurser.PreviewMouseMove -= Event_RightCurserPreviewMouseMove;

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();

					if (Value.GetType() == typeof(VideoInfo)) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.VideoInfosMouseUp();
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		private void Event_RightCurserPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				if (Select == true) {
					if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
						Point currentPosition = e.GetPosition(_timelineView);

						double gap = 0.0;

						if (_timelineView.Zoom > 0) {
							try {
								gap = (currentPosition.X - _startPosition.X) / _timelineView.Zoom;
							} catch (DivideByZeroException) {
								Hnc.Type.Debug.Assert(false, "Update 0으로 나누려고 했습니다.");
								gap = 0.0;
							}
						} else {
							gap = (currentPosition.X - _startPosition.X) * Math.Abs(_timelineView.Zoom);
						}

						// 왼쪽으로 이동
						if (gap < 0) {
                            double xGap = (currentPosition.X - _startPosition.X);
                            if (info.Width + xGap <= MAX_GAP) {
                                gap = 0.0;
                            }

                            if ((TimelineScope.END + gap) <= TimelineScope.START) {
								gap = 0.0;
							}
						}
						// 오른쪽으로 이동
						else {
							//TimelineInfoView rightInfo = null;

							//rightInfo = RightCollision(gap);

							//if (rightInfo != null) {
							//	gap = rightInfo.TimelineScope.START - TimelineScope.END;
							//}

							double videoScopeStart = 0.0;

							if (Value.GetType() == typeof(VideoInfo)) {
								VideoInfo videoInfo = Value as VideoInfo;

								videoScopeStart = videoInfo.VideoScope.START;
							}

							if ((videoScopeStart + TimelineScope.LENGTH + Math.Abs(gap)) >= TotalFrame) {
								gap = 0.0;
							}
						}

						gap = gap * _timelineView.NumberUnit;
						if (Value.GetType() == typeof(VideoInfo)) {
							VideoInfo videoInfo = Value as VideoInfo;

							videoInfo.VideoScope.END = videoInfo.VideoScope.END + gap;
						}

						MoveOtherInfo(gap);

						TimelineScope.END = TimelineScope.END + gap;

						if (gap != 0.0) {
							STATE = TimelineInfoChangedState.Move;
							AllUpdate();

                            _startPosition = currentPosition;
						}
					}
				}

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion // rightCurser 관련 이벤트

		private new void Loaded(object sender, RoutedEventArgs e) {
			double curserTop = (ActualHeight - leftCurser.ActualHeight) / 2;
			leftCurser.SetValue(Canvas.TopProperty, curserTop);
			rightCurser.SetValue(Canvas.TopProperty, curserTop);
		}
	}
}