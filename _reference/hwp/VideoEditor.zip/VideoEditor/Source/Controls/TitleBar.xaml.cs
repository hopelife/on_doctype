﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using Hnc.VideoEditor.Service;
using Grid = System.Windows.Controls.Grid;
using Hnc.VEFrame;
using System;
using Hnc.Control;
using System.Windows.Input;
using Hnc.Type;
using Float = System.Single;
using Hnc.Util;
using System.Windows.Media.Imaging;
using Hnc.VideoEditor.Util;

using Hnc.DataLogic;

namespace Hnc.VideoEditor.Controls {

    // ----------------------------------------------
    // 타이틀바 설정 창
    // 최대 최소 종료 버튼
    // 타이틀바 처럼 이동 기능
    // ----------------------------------------------
    public partial class TitleBar : Grid {

        Hnc.VEFrame.Controls.TitleBar parent = null;
        public Hnc.VEFrame.Controls.TitleBar Parent {
            get {
                return parent;
            }
            set {
                parent = value;
            }
        }

        #region -> Constructor
        public TitleBar() {
            InitializeComponent();

            Application.Current.MainWindow.Loaded += new RoutedEventHandler(MainWindow_Loaded);
            Application.Current.MainWindow.StateChanged += new System.EventHandler(MainWindow_StateChanged);

			UpdateToolbarState();
        }        

        #endregion
                
        #region -> Private Methods

		private void ClickMinBtn(object sender, System.Windows.RoutedEventArgs e) {
			ActionChangeWindowModeMin action = ActionChangeWindowModeMin.Create();
			if (ActionManager.Instance.Excute(action) == true) {
				// 최소화 버튼 클릭시 재생 정지
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
				}
			}
		}

		private void ImageToggleButton_Click(object sender, System.Windows.RoutedEventArgs e) {

            /*
            if (state == 0) {
                Application.Current.MainWindow.WindowState = WindowState.Normal;
                Application.Current.MainWindow.Left = normalLeft;
                Application.Current.MainWindow.Top = normalTop;
                Application.Current.MainWindow.Width = normalWidth;
                Application.Current.MainWindow.Height = normalHeight;

                state = 1;

            } else if (state == 1) {
                normalLeft   = Application.Current.MainWindow.Left;
                normalTop    = Application.Current.MainWindow.Top; 
                normalWidth  = Application.Current.MainWindow.Width;
                normalHeight = Application.Current.MainWindow.Height;

                Application.Current.MainWindow.Left = SystemParameters.WorkArea.Left;
                Application.Current.MainWindow.Top = SystemParameters.WorkArea.Top;
                Application.Current.MainWindow.Width = SystemParameters.WorkArea.Width;
                Application.Current.MainWindow.Height = SystemParameters.WorkArea.Height;

                state = 0;
            }
            */
            /*
			if (Application.Current.MainWindow.WindowState == WindowState.Maximized)
				Application.Current.MainWindow.WindowState = WindowState.Normal;
            else if (Application.Current.MainWindow.WindowState == WindowState.Normal) {
                Application.Current.MainWindow.WindowState = WindowState.Maximized;
            }
            */

            Parent.SwitchState();
            
		}

        private void ClickCloseBtn(object sender, System.Windows.RoutedEventArgs e) {
			// 창이 뜨면 재생 정지
			int timelineInfoCount = 0;
			// bool undoCount = 0;
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);

				timelineInfoCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoCount();
			}

			if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {
                CustomDialog dialog = new CustomDialog();
                string message = Application.Current.Resources["IDS_Message_29"] as String + "\n" +
                                 Application.Current.Resources["IDS_Message_30"] as String;

                dialog.ChangeMessageBoxType("", message, 315.0,
                    Application.Current.Resources["IDS_Save"] as String,
                Application.Current.Resources["IDS_NoSave"] as String,
                Application.Current.Resources["IDS_Cancel"] as String);
                dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

                if (dialog.Result != Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                    if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.CANCEL) {
                        return;
                    }
                }

                if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
					if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
						if (Hnc.VEFrame.VEFrameManager.Instance.MainPage.ProjectSave(0) < 1) {
							return;
						}
					}


					/*
					string[] HvwExtension = { ".hvw", ".xml" };
					
					FileDialog filePage = new FileDialog(FileDialog.Mode.Save, HvwExtension, SetupManager.Instance.LastOpendDirectory, ".xml");

					if (filePage == null) {
						System.Diagnostics.Debug.Assert(false, "FileDialogPage가 생성되지 않았습니다.");
						return;
					}

					if (filePage.ShowDialog() == false)  {
						return;
					}

					System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);

					String saveFileName = null;
					if (filePage.DialogResult == true) {
						SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;
						saveFileName = filePage.SaveFilePath;
						ActionSave saveAction = ActionSave.Create(saveFileName);

						ActionManager.Instance.Excute(saveAction);
					} else {
						return;
					}
					*/
				}
			}

            ActionClose action = ActionClose.Create();
            ActionManager.Instance.Excute(action);
        }

        public void UpdateRestoreButton() {
            if (Parent.State == VEFrame.Controls.TitleBar.FrameWindowState.Maximized) {
                windowStateBtn.ImageSource = Application.Current.Resources["BitmapImage.Title_restore3"] as BitmapImage;
                windowStateBtn.HoverImage = Application.Current.Resources["BitmapImage.Title_restore3"] as BitmapImage;
                windowStateBtn.PressedImage = Application.Current.Resources["BitmapImage.Title_restore3"] as BitmapImage;
            } else if (Parent.State == VEFrame.Controls.TitleBar.FrameWindowState.Normal) {
                windowStateBtn.ImageSource = Application.Current.Resources["BitmapImage.Title_max3"] as BitmapImage;
                windowStateBtn.HoverImage = Application.Current.Resources["BitmapImage.Title_max3"] as BitmapImage;
                windowStateBtn.PressedImage = Application.Current.Resources["BitmapImage.Title_max3"] as BitmapImage;
            }
        }
        void MainWindow_StateChanged(object sender, System.EventArgs e) {
            if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
                if (Parent.State == VEFrame.Controls.TitleBar.FrameWindowState.Normal) {
                    Parent.SwitchState();
                }
            }
        }

        #endregion        

        private void MainWindow_Loaded(object sender, RoutedEventArgs e) {
            UpdateRestoreButton();
        }

		private void Titlebar_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e) {
			if (e.ButtonState == MouseButtonState.Pressed) {

				if (Application.Current.MainWindow.WindowState == System.Windows.WindowState.Maximized) {
					Application.Current.MainWindow.WindowState = System.Windows.WindowState.Normal;
				}

				this.Cursor = Cursors.ScrollAll;
				Application.Current.MainWindow.DragMove();
			}
		}

		private static System.Windows.Point ButtonDownPos {
			get;
			set;
		}
		private static System.Windows.Point WindowDefaultPos {
			get;
			set;
		}

		private void Titlebar_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) {
			if (e.LeftButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed) {
				if (Cursor == Cursors.ScrollAll) {
					System.Windows.Point curPos = e.GetPosition(Application.Current.MainWindow);

					SizeF delta = SizeF.Create(
					   (Float)(curPos.X - ButtonDownPos.X),
					   (Float)(curPos.Y - ButtonDownPos.Y)
					);

					// tracking 영역보다 많이 움직였으면 flicking이다.
					if (!((MathUtil.Abs(delta.CX) < SystemParameters.MinimumHorizontalDragDistance) &&
						(MathUtil.Abs(delta.CY) < SystemParameters.MinimumVerticalDragDistance))) {
						this.Cursor = Cursors.Arrow;
					}
				}
			}
		}

		private void Titlebar_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
			if (this.Cursor == Cursors.Arrow &&
				Application.Current.MainWindow.Left == WindowDefaultPos.X &&
				Application.Current.MainWindow.Top == WindowDefaultPos.Y &&
				e.OriginalSource is Hnc.VEFrame.Controls.Layout.MainWindowDockPanel) {

				if (VEFrameManager.Instance.IsExistOpenedAppBar()) {
					VEFrameManager.Instance.SwitchAppBarState(false);
				} else {
					VEFrameManager.Instance.SwitchAppBarState(true);
				}
			}

			this.Cursor = Cursors.Arrow;
		}

		public void UpdateToolbarState() {
			StateUndo.IsEnabled = UndoManager.Instance.IsEnableUndo;
			StateRedo.IsEnabled = UndoManager.Instance.IsEnableRedo;

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				int timelineInfoCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoCount();

				if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {
					//if (timelineInfoCount > 0) {
					StateSave.IsEnabled = true;
					Export.IsEnabled = true;
				} else {
					StateSave.IsEnabled = false;
					Export.IsEnabled = false;
				}
			}
		}

		private void ClickUndo(object sender, RoutedEventArgs e) {
			Undo();
		}

		private void ClickRedo(object sender, RoutedEventArgs e) {
			Redo();
		}

		public void Undo() {
			ActionUndo action = ActionUndo.Create();
			ActionManager.Instance.Excute(action);
			//Page.videoTimeline.AllUpdate();
			UpdateToolbarState();
		}

		public void Redo() {
			ActionRedo action = ActionRedo.Create();
			ActionManager.Instance.Excute(action);
			//Page.videoTimeline.AllUpdate();
			UpdateToolbarState();
		}


		private void ClickAddSource(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
			}

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.AddSourceFile();
			}
		}

		private void ClickExport(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ExportTimeline();
			}
		}

		private void ClickProjectLoad(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ProjectLoad();
			}
		}

		private void ClickProjectSave(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ProjectSave(1);
			}
		}
    }
}
