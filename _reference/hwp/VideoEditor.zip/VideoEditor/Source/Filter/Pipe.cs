﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Filter {
	using Bool = System.Boolean;
	using String = System.String;
	using Hnc.VideoEditor.Base.Type;
	using Hnc.VideoEditor.Engine;
	using System.Collections.ObjectModel;
	using Hnc.VideoEditor.Base.Enum;

	public class Pipe {
		public Bool Save(String filePath, Collection<TimelineInfo> infoCollection) {
			IParser parser = ParserUtil.Create(ParserOption.XML);

			if (parser == null) {
				return false;
			}

			return parser.Save(filePath, infoCollection);
		}

		public Bool Load(String filePath) {
			IParser parser = ParserUtil.Create(ParserOption.XML);

			if (parser == null) {
				return false;
			}

			return parser.Load(filePath);
		}
	}
}