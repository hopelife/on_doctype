﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Controls.Primitives;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Media;

namespace Hnc.Control {
    public class TextBox : System.Windows.Controls.TextBox {

        private DispatcherTimer toolTipTimer = new DispatcherTimer();
        private System.Windows.Controls.ToolTip errorToolTip = new System.Windows.Controls.ToolTip();

        #region -> Constructor

        static TextBox() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TextBox), new FrameworkPropertyMetadata(typeof(TextBox)));
        }

        #endregion

        #region -> Dependency Properties

        /// <summary>
        /// 숫자만 입력가능한지 설정합니다.
        /// </summary>
        public bool IsNumeric {
            get { return (bool)GetValue(IsNumericProperty); }
            set { SetValue(IsNumericProperty, value); }
        }

        public static readonly DependencyProperty IsNumericProperty =
            DependencyProperty.Register("IsNumeric", typeof(bool), typeof(TextBox), new PropertyMetadata(false));

        /// <summary>
        /// IsNumeric 속성이 true일 경우 입력가능한 최소값을 지정합니다.
        /// </summary>
        public double Minimum {
            get { return (double)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }

        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(double), typeof(TextBox), new PropertyMetadata(0d));

        /// <summary>
        /// IsNumeric 속성이 true일 경우 입력가능한 최대값을 지정합니다.
        /// </summary>
        public double Maximum {
            get { return (double)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(double), typeof(TextBox), new PropertyMetadata(100d));

        #endregion

        #region -> Private Methods

        private void ShowErrorToolTip(string message) {

            toolTipTimer.IsEnabled = false;
            errorToolTip.Visibility = Visibility.Visible;
            errorToolTip.Content = message;
            errorToolTip.IsOpen = true;
            toolTipTimer.IsEnabled = true;
        }

        #endregion

        #region -> Overrided Methods

        protected override void OnInitialized(System.EventArgs e) {

            if (IsNumeric) {
                errorToolTip.Placement = PlacementMode.Top;
                errorToolTip.VerticalOffset = -4;
                errorToolTip.PlacementTarget = this;
                ToolTipService.SetShowDuration(errorToolTip, 2000);
                errorToolTip.Visibility = Visibility.Hidden;
                this.ToolTip = errorToolTip;

                toolTipTimer.Interval = System.TimeSpan.FromSeconds(2);
                toolTipTimer.IsEnabled = true;
                // 타이머로 툴팁 숨김
                toolTipTimer.Tick += new System.EventHandler(delegate(object timerSender, System.EventArgs args) {
                    errorToolTip.IsOpen = false;
                    errorToolTip.Visibility = Visibility.Hidden;
                });
            }

            base.OnInitialized(e);
        }

        protected override void OnKeyDown(KeyEventArgs e) {

            if (e.Key == Key.Enter) {
                FrameworkElement parent = (FrameworkElement)this.Parent;
                while (parent != null && parent is IInputElement && !((IInputElement)parent).Focusable) {
                    parent = (FrameworkElement)parent.Parent;
                }
                DependencyObject scope = FocusManager.GetFocusScope(this);
                FocusManager.SetFocusedElement(scope, parent as IInputElement);
            }

            base.OnKeyDown(e);
        }

        protected override void OnPreviewTextInput(TextCompositionEventArgs e) {

            if (IsNumeric) {
                // 입력한 문자열중 하나라도 숫자가 아니라면 입력 불가
                // 소수점이라던지 기타 형식의 숫자처리는 추후에 구현
                for (int i = 0; i < e.Text.Length; i++) {
                    if (!char.IsDigit(e.Text[i])) {
                        e.Handled = true;
                        ShowErrorToolTip(Application.Current.Resources["IDS_Message01"] as string);
                    }
                }
            }

            base.OnPreviewTextInput(e);
        }

        //??
        //protected override void OnTextChanged(System.Windows.Controls.TextChangedEventArgs e) {            
        //    // 숫자 입력모드일 경우 최대/최소값 보정
        //    if (IsNumeric && !string.IsNullOrEmpty(this.Text)) {

        //        double value = double.Parse(this.Text);

        //        if (value > Maximum) {
        //            this.Text = Maximum.ToString();
        //            ShowErrorToolTip(Minimum + "~" + Maximum + Application.Current.Resources["IDS_Message02"] as string);
        //        } else if (value < Minimum) {
        //            this.Text = Minimum.ToString();
        //            ShowErrorToolTip(Minimum + "~" + Maximum + Application.Current.Resources["IDS_Message02"] as string);
        //        }
        //    }

        //    base.OnTextChanged(e);
        //}

        #endregion
    }
}
