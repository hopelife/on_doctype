﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Base.Enum {
	public enum TimelineInfoChangedState : int {
		NoChanged = 0,
		Move = 1,
		ChangedWidthLeft = 2,
		ChangedWidthRight = 2
	};

	// 줄자의 단위 종류
	// 비디오를 위해 Frame을 추가 - Frame은 pixel과 같은 단위
	public enum Unit {
		Cm,
		Inch,
		Frame
	};

	public enum MarksLocation {
		Up,
		Down
	}

	public enum InfoType : int {
		Video = 0,
		Sound = 1,
		Subtitle = 2
	};

	public enum SUBAPPBAR_STATE {
		Closed = -1,
		Video = 0,
		Sound = 1,
		Subtitle = 2,
		Export = 3,
		Info = 4
	};

	public enum ParserOption {
		XML = 0
	}

	public enum ResourcesState : int {
		Success = 2,
		LoadBase = 1,
		Failed = 0
	};

	public enum PageState : int {
		None = 0,
		StartPage = 1,
		MainPage = 2
	};
}