﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using String = System.String;
using Bool = System.Boolean;
using Index = System.Int32;
using Int = System.Int32;
using Hnc.Type;
using Hnc.VideoEditor.Base.Type;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Collections;

namespace Hnc.VideoEditor.Engine {
	//////////////////////////////////////////////////////////////////////////////////////////
	// 메시지 큐 - TimelineInfo가 변화 되었다는 것을 기억해 알려주기 위한 클래스
	//////////////////////////////////////////////////////////////////////////////////////////
	public static class ChangedTimeline {
		// 큐로 구현
		// 안에 내용은 Pair로 어떠한 변화인지를 확인하기 위한 메시지(string)과 변환된 TimelineInfo를
		// 가지고 있음
		private static Queue<KeyValuePair<String, TimelineInfo>> ChangedInfoQueue = new Queue<KeyValuePair<String, TimelineInfo>>();

		// 큐에 Push
		public static void Push(String key, TimelineInfo info) {
			KeyValuePair<String, TimelineInfo> item = new KeyValuePair<string, TimelineInfo>(key, info);

			ChangedInfoQueue.Enqueue(item);
		}

		// 큐에서 Pop
		public static KeyValuePair<String, TimelineInfo> Pop() {
			if (ChangedInfoQueue.Count == 0) {
#if DEBUG
				Debug.Assert(false, "큐가 비어있어 아이템을 가져오지 못하였습니다.");
#endif
				KeyValuePair<String, TimelineInfo> item = new KeyValuePair<string, TimelineInfo>("Error", null);
				return item;
			}

			return ChangedInfoQueue.Dequeue();
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////
	// TimelineInfo를 관리하는 클래스
	// INotifyPropertyChanged : 변화 감지를 위해 사용
	//////////////////////////////////////////////////////////////////////////////////////////
	public class Timeline : INotifyPropertyChanged {

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnTimelineInfoPropertyChanged(String propertyName) {
			var Handler = PropertyChanged;

			if (Handler != null) {
				Handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		private Collection<TimelineInfo> _infoList = new Collection<TimelineInfo>();
		public Collection<TimelineInfo> InfoList {
			get {
				return _infoList;
			}
		}

		private Index _newID = 0;
		public Index NewID {
			get {
				++_newID;
				return _newID - 1;
			}
		}

		private void TimelineInfo_PropertyChanged(object sender, PropertyChangedEventArgs e) {
			Int id = Int.Parse(e.PropertyName);

			int index = -1;


			for (int i = 0; i < InfoList.Count; ++i) {
				if (InfoList[i].ID == id) {
					index = i;
				}
			}

			if (index == -1) {
				Debug.Assert(false, "잘못된 TimelineInfo Index가 들어왔습니다.");
				return;
			}

			ChangedTimeline.Push("Changed_Property", InfoList[index]);
			OnTimelineInfoPropertyChanged("Changed_Property");
		}

		public Timeline() {
		}

		public Collection<TimelineInfo> GetTimelineInfoCollection() {
			Collection<TimelineInfo> infoCollection = new Collection<TimelineInfo>();

			foreach (TimelineInfo info in InfoList) {
				infoCollection.Add(info);
			}

			return infoCollection;
		}

		public Bool IsVideoInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			VideoInfo videoInfo = info as VideoInfo;

			if (videoInfo == null) {
				return false;
			}

			return true;
		}

		public Bool IsSoundInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			SoundInfo soundInfo = info as SoundInfo;

			if (soundInfo == null) {
				return false;
			}

			return true;
		}

		public Bool IsSubtitleInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			SubtitleInfo subtitleInfo = info as SubtitleInfo;

			if (subtitleInfo == null) {
				return false;
			}

			return true;
		}

		public Collection<TimelineInfo> FindVideoInfo() {
			Collection<TimelineInfo> videoInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(videoInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in InfoList) {
				if (IsVideoInfo(info) == true) {
					videoInfoCollection.Add(info);
				}
			}

			return videoInfoCollection;
		}

		public Collection<TimelineInfo> FindCloneVideoInfo() {
			Collection<TimelineInfo> videoInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(videoInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in InfoList) {
				if (IsVideoInfo(info) == true) {
					videoInfoCollection.Add(info.Clone());
				}
			}

			return videoInfoCollection;
		}

		public Collection<TimelineInfo> FindSoundInfo() {
			Collection<TimelineInfo> soundInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(soundInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in InfoList) {
				if (IsSoundInfo(info) == true) {
					soundInfoCollection.Add(info);
				}
			}

			return soundInfoCollection;
		}

		public Collection<TimelineInfo> FindSubtitleInfo() {
			Collection<TimelineInfo> subtitleInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(subtitleInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in InfoList) {
				if (IsSubtitleInfo(info) == true) {
					subtitleInfoCollection.Add(info);
				}
			}

			return subtitleInfoCollection;
		}

		public void SetNewID() {
			int id = -1;

			foreach (TimelineInfo info in InfoList) {
				if (id < info.ID) {
					id = info.ID;
				}
			}

			_newID = id + 1;
		}

		public int GetNewInfoID() {
			return NewID;
		}

		public double GetNewVideoInfoStartFrame() {
			double startFrame = 0.0;

			foreach (TimelineInfo info in InfoList) {
				if (IsVideoInfo(info) == true) {
					if (startFrame < info.TimelineScope.END) {
						startFrame = info.TimelineScope.END;
					}
				}
			}

			return startFrame;
		}

		public double GetNewSoundInfoStartFrame() {
			double startFrame = 0.0;

			foreach (TimelineInfo info in InfoList) {
				if (IsSoundInfo(info) == true) {
					if (startFrame < info.TimelineScope.END) {
						startFrame = info.TimelineScope.END;
					}
				}
			}

			return startFrame;
		}

		public double GetNewSubtitleInfoStartFrame() {
			double startFrame = 0.0;

			foreach (TimelineInfo info in InfoList) {
				if (IsSubtitleInfo(info) == true) {
					if (startFrame < info.TimelineScope.END) {
						startFrame = info.TimelineScope.END;
					}
				}
			}

			return startFrame;
		}

		public Bool AddInfo(TimelineInfo info) {
			if (info == null) {
				Debug.Assert(false, "AddInfo TimelineInfo가 Null 입니다.");
				return false;
			}

			if (info.GetType() == typeof(VideoInfo)) {
				VideoInfo videoInfo = info as VideoInfo;
				if (System.IO.File.Exists(videoInfo.FilePath) == false) {
					Debug.Assert(false, "AddInfo VideoInfo의 동영상 소스를 가져오는데 실패하였습니다.");
					return false;
				}
			} else if (info.GetType() == typeof(SoundInfo)) {
				SoundInfo soundInfo = info as SoundInfo;
				if (System.IO.File.Exists(soundInfo.FilePath) == false) {
					Debug.Assert(false, "AddInfo SoundInfo의 사운드 소스를 가져오는데 실패하였습니다.");
					return false;
				}
			}

			info.PropertyChanged += new PropertyChangedEventHandler(TimelineInfo_PropertyChanged);

			ChangedTimeline.Push("AddTimelineInfo", info);
			OnTimelineInfoPropertyChanged("AddTimelineInfo");

			InfoList.Add(info);

			return true;
		}

		public Bool AddVideoInfo(VideoInfo info) {
#if DEBUG
			Debug.Assert(info != null, "VideoInfo가 Null 입니다.");
#endif
			if (info == null) {
				return false;
			}

			AddInfo(info);

			return true;
		}

		public Bool AddVideoInfo(String filePath, FrameScope videoScope, FrameScope timelineScope) {
			int id = GetNewInfoID();
			VideoInfo info = VideoInfo.Create(id, timelineScope, 0.0, filePath, videoScope);
#if DEBUG
			Debug.Assert(info != null, "VideoInfo를 생성하지 못하였습니다.");
#endif
			return AddVideoInfo(info);
		}



		public Bool RemoveVideoInfo(String filePath, FrameScope videoScope, FrameScope timelineScope) {

			Collection<TimelineInfo> videoInfoCollection = FindVideoInfo();

			foreach (VideoInfo info in videoInfoCollection) {
				if (info.FilePath == filePath && info.VideoScope == videoScope && info.TimelineScope == timelineScope) {
					if (InfoList.Remove(info) == true) {
						return true;
					} else {
						return false;
					}
				}
			}

			return false;
		}

		public Bool RemoveVideoInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif
			Collection<TimelineInfo> videoInfoCollection = FindVideoInfo();

			foreach (VideoInfo info in videoInfoCollection) {
				if (info.ID == id) {
					if (InfoList.Remove(info) == true) {
						return true;
					} else {
						return false;
					}
				}
			}

			return false;
		}

		public System.Collections.Generic.List<TimelineInfo> SortInfo() {
			Collection<TimelineInfo> videoInfoCollection = FindCloneVideoInfo();

			System.Collections.Generic.List<TimelineInfo> infoList = new System.Collections.Generic.List<TimelineInfo>();
			
			// 정렬
			int count = videoInfoCollection.Count;
			for (int i = 0; i < count; ++i) {
				for (int j = i + 1; j < count; ++j) {
					if (videoInfoCollection[i].TimelineScope.START > videoInfoCollection[j].TimelineScope.START) {
						TimelineInfo temp = videoInfoCollection[i];
						videoInfoCollection[i] = videoInfoCollection[j];
						videoInfoCollection[j] = temp;
					}
				}
			}

			double positionFrame = 0.0;
			for (int i = 0; i < count; ++i) {
				double length = videoInfoCollection[i].TimelineScope.LENGTH;

				if (videoInfoCollection[i].TimelineScope.START != positionFrame) {

					videoInfoCollection[i].TimelineScope.START = positionFrame;
					videoInfoCollection[i].TimelineScope.END = positionFrame + length;


					//TimelineInfo newInfo = videoInfoCollection[i].Clone();
					/*
					FrameScope scope = FrameScope.Create();
					scope.START = positionFrame;
					scope.END = scope.START + length;

					newInfo.TimelineScope = scope;

					videoInfoCollection[i].Copy(newInfo);
					*/

					infoList.Add(videoInfoCollection[i]);
				}
				positionFrame = videoInfoCollection[i].TimelineScope.END;
			}

			return infoList;
		}

		public Bool RemoveInfo(int id) {
#if DEBUG
			Debug.Assert(id >= 0, "잘못된 ID 값이 들어왔습니다.");
#endif

			foreach (TimelineInfo info in InfoList) {
				if (info.ID == id) {
					if (InfoList.Remove(info) == true) {
						ChangedTimeline.Push("RemoveTimelineInfo", info);
						OnTimelineInfoPropertyChanged("RemoveTimelineInfo");
						return true;
					} else {
						return false;
					}
				}
			}

			return false;
		}

		public Bool AddSoundInfo(SoundInfo info) {
#if DEBUG
			Debug.Assert(info != null, "SoundInfo가 Null 입니다.");
#endif
			if (info == null) {
				return false;
			}

			AddInfo(info);

			return true;
		}

		public Bool AddSoundInfo(String filePath, FrameScope soundScope, FrameScope timelineScope) {
			int id = GetNewInfoID();

			SoundInfo info = SoundInfo.Create(id, timelineScope, 0.0, filePath, soundScope);
#if DEBUG
			Debug.Assert(info != null, "SoundInfo를 생성하지 못하였습니다.");
#endif
			return AddSoundInfo(info);
		}

		public Bool AddSubtitleInfo(SubtitleInfo info) {
#if DEBUG
			Debug.Assert(info != null, "SubtitleInfo가 Null 입니다.");
#endif
			if (info == null) {
				return false;
			}

			AddInfo(info);

			return true;
		}

		public Bool AddSubtitleInfo(String sentence, FrameScope timelineScope) {
			int id = GetNewInfoID();
			SubtitleInfo info = SubtitleInfo.Create(id, timelineScope, 0.0, sentence);
#if DEBUG
			Debug.Assert(info != null, "SubtitleInfo를 생성하지 못하였습니다.");
#endif
			return AddSubtitleInfo(info);
		}
	}
}