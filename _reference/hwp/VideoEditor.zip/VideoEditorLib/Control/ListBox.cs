﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Hnc.Control
{
    // ListBox에 들어가는 Content의 기본 형태를 구성하는 클래스
    public class ListItem : ContentControl {
        
        #region -> Properties

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register(
                "Text",
                typeof(string),
                typeof(ListItem),
                new PropertyMetadata("")
            );

        public string Text {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        public static readonly DependencyProperty GroupNameProperty =
            DependencyProperty.Register(
                "GroupName",
                typeof(string),
                typeof(ListItem),
                new PropertyMetadata("")
            );

        public string GroupName {
            get { return (string)GetValue(GroupNameProperty); }
            set { SetValue(GroupNameProperty, value); }
        }

		// ContentWidth와 ContentHeight는 itemWidth와 itemHeight에 따라가는 것이 맞으므로 제거
		//public static readonly DependencyProperty ContentWidthProperty =
		//    DependencyProperty.Register(
		//        "ContentWidth",
		//        typeof(double),
		//        typeof(ListItem),
		//        new PropertyMetadata(double.NaN)
		//    );

		//public double ContentWidth {
		//    get { return (double)GetValue(ContentWidthProperty); }
		//    set { SetValue(ContentWidthProperty, value); }
		//}

		//public static readonly DependencyProperty ContentHeightProperty =
		//    DependencyProperty.Register(
		//        "ContentHeight",
		//        typeof(double),
		//        typeof(ListItem),
		//        new PropertyMetadata(double.NaN)
		//    );

		//public double ContentHeight {
		//    get { return (double)GetValue(ContentHeightProperty); }
		//    set { SetValue(ContentHeightProperty, value); }
		//}

        #endregion

        #region -> Contructors

        public ListItem(string text, string imageSource, string groupName) {
            Text = text;
            GroupName = groupName;

            BitmapImage bitmap = new BitmapImage(new Uri(imageSource));
            Image image = new Image();
            image.Source = bitmap;
            image.Stretch = Stretch.Uniform;
            Content = image as object;

            //!! 확인!! 현재 Content 사이즈를 지정해주지 않고 Item 사이즈에 맞도록 해놓은 상태!!
            //ContentWidth = bitmap.Width;
            //ContentHeight = bitmap.Height;
        }

        public ListItem(string text, string imageSource, string groupName, Size imageSize) {
            Text = text;
            GroupName = groupName;

            Image image = new Image();
            image.Source = new BitmapImage(new Uri(imageSource));
            image.Stretch = Stretch.Uniform;
            Content = image as object;

			// itemWidth, itemHeight에 따라가는 것이 맞으므로 제거해야 맞다.
			// 사이드 이펙트가 발생한다면 연락주세요~ (마형주)
			//ContentWidth = imageSize.Width;
			//ContentHeight = imageSize.Height;
        }

        public ListItem(object content, string text, string groupName, Size contentSize) {
            Content = content;
            Text = text;
            GroupName = groupName;

			// itemWidth, itemHeight에 따라가는 것이 맞으므로 제거해야 맞다.
			// 사이드 이펙트가 발생한다면 연락주세요~ (마형주)
			//ContentWidth = contentSize.Width;
			//ContentHeight = contentSize.Height;
        }

        #endregion
    }

    /// <summary>
    /// ListBox의 아이템에 기능을 추가하기 위한 확장클래스입니다.
    /// - IsPressed 속성 추가
    /// - 더블 클릭 시 Select/Unselect 이벤트를 멈추는 기능 추가
    /// </summary>
    public sealed class ListBoxItem : System.Windows.Controls.ListBoxItem {

        private bool isEnableUnselection = true;
        private Point startPos = new Point();
        private DispatcherTimer doubleClickChecker = new DispatcherTimer();

        #region -> Constructors

        public ListBoxItem() {
            this.isEnableUnselection = false;

            doubleClickChecker.Interval = TimeSpan.FromMilliseconds(180);
            doubleClickChecker.Tick += new EventHandler(doubleClickChecker_Tick);
        }

        public ListBoxItem(bool isEnableUnselection) {
            this.isEnableUnselection = isEnableUnselection;

            doubleClickChecker.Interval = TimeSpan.FromMilliseconds(180);
            doubleClickChecker.Tick += new EventHandler(doubleClickChecker_Tick);
        }

        #endregion

        #region -> Properties

        public bool IsPressed {
            get { return (bool)GetValue(IsPressedProperty); }
            set { SetValue(IsPressedProperty, value); }
        }

        public static readonly DependencyProperty IsPressedProperty = 
            DependencyProperty.Register("IsPressed", typeof(bool), typeof(ListBoxItem), new PropertyMetadata(false));

        #endregion

        #region -> Overrided Methods

        protected override void OnMouseDown(MouseButtonEventArgs e) {

            IsPressed = true;
            startPos = e.GetPosition(Application.Current.MainWindow);
            e.Handled = true;

            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseButtonEventArgs e) {

            // 5px 이내의 범위에서 움직인건 아이템을 선택 중인걸로 판단
            Point endPos = e.GetPosition(Application.Current.MainWindow);
            double offsetX = Math.Abs(startPos.X - endPos.X);
            double offsetY = Math.Abs(startPos.Y - endPos.Y);

            if (IsPressed && offsetX < 100 && offsetY < 100) {

                // 더블클릭인지 아닌지 첫번째 클릭시 시작된 타이머로 체크
                if (doubleClickChecker.IsEnabled) {

                    // 더블클릭에 진입하면 타이머를 종료하고 선택상태로 강제
                    doubleClickChecker.Stop();
                    IsSelected = true;                    

                } else {

                    // 더블클릭 중이 아니라면 더블클릭 체크 타이머 시작
                    doubleClickChecker.Start();
                }
            }

            base.OnMouseUp(e);
        }

        private void doubleClickChecker_Tick(object sender, EventArgs e) {

            // 더블클릭이 아닌 상태일 때 타이머에 진입
            doubleClickChecker.Stop();

            if (isEnableUnselection)
                IsSelected = !IsSelected;
            else
                IsSelected = true;
        }

        protected override void OnMouseEnter(MouseEventArgs e) {

            if (!IsPressed) {
                if (Mouse.LeftButton == MouseButtonState.Pressed || Mouse.RightButton == MouseButtonState.Pressed) {
                    IsPressed = true;
                } else
                    IsPressed = false;
            }

            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            if (IsPressed && !IsSelected) {
                IsPressed = false;
            }

            base.OnMouseLeave(e);
        }

        protected override void OnUnselected(RoutedEventArgs e) {

            IsPressed = false;

            base.OnUnselected(e);
        }

        #endregion
    }

	public class ListBox : System.Windows.Controls.ListBox
	{
		static ListBox()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata(typeof(ListBox)));
		}
    
        public ListBox(ObservableCollection<ListItem> source) {
            // 생성 시 source가 null이면 업데이터를 통해 반드시 source를 설정해야 함
            if (source == null)
                return;

            SetItemsSource(source);
        }

        #region -> Properties

        private static readonly DependencyProperty IsSelectableProperty =
            DependencyProperty.Register(
                "IsSelectable",
                typeof(bool),
                typeof(ListBox),
                new PropertyMetadata(false)
            );

        private bool IsSelectable {
            get { return (bool)GetValue(IsSelectableProperty); }
            set { SetValue(IsSelectableProperty, value); }
        }

        private static readonly DependencyProperty GroupingProperty =
            DependencyProperty.Register(
                "Grouping",
                typeof(GroupingStyle),
                typeof(ListBox),
                new PropertyMetadata(GroupingStyle.Hidden)
            );

        private GroupingStyle Grouping {
            get { return (GroupingStyle)GetValue(GroupingProperty); }
            set { SetValue(GroupingProperty, value); }
        }

        public static readonly DependencyProperty IsFlickableProperty =
            DependencyProperty.Register(
                "IsFlickable",
                typeof(bool),
                typeof(ListBox),
                new PropertyMetadata(false)
            );

        public bool IsFlickable {
            get { return (bool)GetValue(IsFlickableProperty); }
            set { SetValue(IsFlickableProperty, value); }
        }

        public static readonly DependencyProperty IsImageListProperty =
            DependencyProperty.Register(
                "IsImageList",
                typeof(bool),
                typeof(ListBox),
                new PropertyMetadata(false)
            );

        public bool IsImageList {
            get { return (bool)GetValue(IsImageListProperty); }
            set { SetValue(IsImageListProperty, value); }
        }

        public static readonly DependencyProperty ImageVisibilityProperty =
            DependencyProperty.Register(
                "ImageVisibility",
                typeof(Visibility),
                typeof(ListBox),
                new PropertyMetadata(Visibility.Visible)
            );

        public Visibility ImageVisibility {
            get { return (Visibility)GetValue(ImageVisibilityProperty); }
            set { SetValue(ImageVisibilityProperty, value); }
        }

        public static readonly DependencyProperty TextVisibilityProperty =
            DependencyProperty.Register(
                "TextVisibility",
                typeof(Visibility),
                typeof(ListBox),
                new PropertyMetadata(Visibility.Visible)
            );

        public Visibility TextVisibility {
            get { return (Visibility)GetValue(TextVisibilityProperty); }
            set { SetValue(TextVisibilityProperty, value); }
        }

        public static readonly DependencyProperty ItemWidthProperty =
            DependencyProperty.Register(
                "ItemWidth",
                typeof(double),
                typeof(ListBox),
                new FrameworkPropertyMetadata(double.NaN, FrameworkPropertyMetadataOptions.AffectsRender)
            );

        public double ItemWidth {
            get { return (double)GetValue(ItemWidthProperty); }
            set { SetValue(ItemWidthProperty, value); }
        }

        public static readonly DependencyProperty ItemHeightProperty =
            DependencyProperty.Register(
                "ItemHeight",
                typeof(double),
                typeof(ListBox),
                new FrameworkPropertyMetadata(double.NaN, FrameworkPropertyMetadataOptions.AffectsRender)
            );

        public double ItemHeight {
            get { return (double)GetValue(ItemHeightProperty); }
            set { SetValue(ItemHeightProperty, value); }
        }

        public static readonly DependencyProperty OrientationProperty =
            DependencyProperty.Register(
                "Orientation",
                typeof(Orientation),
                typeof(ListBox),
                new PropertyMetadata(Orientation.Vertical)
            );

        public Orientation Orientation {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }

        #endregion

		#region -> Methods

		public void SetItemsSource(ObservableCollection<ListItem> source)
		{
			if (source == null)
			{
				System.Diagnostics.Debug.Assert(false, "null인 source를 넣고 있습니다.");
				return;
			}

			if (source is ObservableCollection<ListItem>)
			{
				ItemsSource = source;
			}
			else
			{
				System.Diagnostics.Debug.Assert(false, "source는 ObservableCollection<ListItem> 형식이어야 합니다.");
			}

			if (!IsSelectable)
				UnselectAll();
		}

		public ObservableCollection<ListItem> GetItemsSource()
		{
			return ItemsSource as ObservableCollection<ListItem>;
		}

		public void AddItem(ListItem item)
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			if (item == null)
			{
				System.Diagnostics.Debug.Assert(false, "null인 item을 넣고 있습니다.");
				return;
			}

			if (item is ListItem)
			{
				(ItemsSource as ObservableCollection<ListItem>).Add(item);
			}
			else
			{
				System.Diagnostics.Debug.Assert(false, "item은 ListItem 형식이어야 합니다.");
			}
		}

		public void RemoveItem(ListItem item)
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			if ((ItemsSource as ObservableCollection<ListItem>).Contains(item))
				(ItemsSource as ObservableCollection<ListItem>).Remove(item);
			else
				System.Diagnostics.Debug.Assert(false, "포함되지 않는 item을 제거하고 있습니다.");
		}

		public void RemoveItemAt(int index)
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			//!! 없는 index를 지우려 하는 상황을 미리 예방해야 함!! 확인!!
			(ItemsSource as ObservableCollection<ListItem>).RemoveAt(index);
		}

		public void RemoveAll()
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			(ItemsSource as ObservableCollection<ListItem>).Clear();
		}

		public void AddGroupStyle(GroupingStyle groupingStyle)
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			RemoveGrouping();

			Grouping = groupingStyle;

			if (Grouping == GroupingStyle.Foldable)
				GroupStyle.Add(FindResource("GroupingStyle.Foldable") as GroupStyle);
			else if (Grouping == GroupingStyle.Foldless)
				GroupStyle.Add(FindResource("GroupingStyle.Foldless") as GroupStyle);
			else
				return;

			PropertyGroupDescription groupDescription = new PropertyGroupDescription();
			groupDescription.PropertyName = "GroupName";
			Items.GroupDescriptions.Add(groupDescription);
		}

		public void RemoveGrouping()
		{
			if (ItemsSource == null)
			{
				System.Diagnostics.Debug.Assert(false, "ItemsSource를 먼저 설정하셔야 합니다. (SetItemsSource 사용)");
				return;
			}

			Items.GroupDescriptions.Clear();
			GroupStyle.Clear();
		}

		public void SetSelectable(bool isSelectable)
		{
			IsSelectable = isSelectable;

			if (!IsSelectable)
				UnselectAll();
		}

		public bool GetSelectable()
		{
			return IsSelectable;
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			AddGroupStyle(Grouping);
		}

		protected override void OnMouseUp(MouseButtonEventArgs e)
		{
			base.OnMouseUp(e);

			if (!IsSelectable)
				UnselectAll();
		}

		protected override DependencyObject GetContainerForItemOverride()
		{
			// 상속 받아 재정의한 Hnc.Control.ListBoxItem을 리턴
            return new Hnc.Control.ListBoxItem();
		}

		//private void OnItemsMouseDown(object source, RoutedEventArgs args)
		//{
		//    //ListBoxItem item = args.Source as ListBoxItem;
		//    //if (item != null)
		//    //    item.IsSelected = false;
		//}

		//private void OnItemsMouseUp(object source, RoutedEventArgs args)
		//{
		//    //ListBoxItem item = args.Source as ListBoxItem;
		//    //if (item != null)
		//    //    item.IsSelected = true;
		//}

		#endregion		
	}	
}
