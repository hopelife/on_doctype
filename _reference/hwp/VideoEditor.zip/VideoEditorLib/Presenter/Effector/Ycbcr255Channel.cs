﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Ratio = System.Single;
using Index = System.Int32;
using Byte = System.Byte;
using Count = System.Int32;
using Pixel = System.UInt32;
using Int = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    public class Ycbcr255Channel {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Byte[] A;
        public Byte[] Y; // 0 ~ 255
        public Byte[] Cb; // 0 ~ 255
        public Byte[] Cr; // 0 ~ 255

        public Count Width { get; private set; }
        public Count Height { get; private set; }

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Ycbcr255Channel(Count width, Count height) {
            A = new Byte[width * height];
            Y = new Byte[width * height];
            Cb = new Byte[width * height];
            Cr = new Byte[width * height];

            Width = width;
            Height = height;

        }

        public static Ycbcr255Channel Create(Pixels pixels) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(pixels.Data.Length != 0, eErrorCode.NullArgument);

            Ycbcr255Channel result = new Ycbcr255Channel(pixels.Width, pixels.Height);

            Byte r = 0;
            Byte g = 0;
            Byte b = 0;


            Int y = 0;
            Int cb = 0;
            Int cr = 0;

            for (Index i = 0; i < pixels.Data.Length; ++i) {

                r = (Byte)((pixels.Data[i] >> 16) & 0xFF);
                g = (Byte)((pixels.Data[i] >> 8) & 0xFF);
                b = (Byte)((pixels.Data[i]) & 0xFF);
             
                result.A[i] = (Byte)((pixels.Data[i] >> 24) & 0xFF);

                y = (Int)(0.299F * r + 0.587F * g + 0.114F * b);
                if (255 < y) y = 255;

                cb = (Int)(-0.169F * r  -0.332F * g + 0.5F * b) + 128;
                //if (cb < 0) cb = 0; 
                if (255 < cb) cb = 255;
                Debug.Assert(0 <= cb);
                

                cr = (Int)(0.5F * r - 0.419F * g - 0.0813F * b) + 128;
                //if (cr < 0) cr = 0; 
                if (255 < cr) cr = 255;
                Debug.Assert(0 <= cr);
                

                result.Y[i] = (Byte)y;
                result.Cb[i] = (Byte)cb;
                result.Cr[i] = (Byte)cr;
            }

            return result;
        }

        public static Ycbcr255Channel Create(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Ycbcr255Channel result = new Ycbcr255Channel(pixels.Width, pixels.Height);

            Byte r = 0;
            Byte g = 0;
            Byte b = 0;

            Int y = 0;
            Int cb = 0;
            Int cr = 0;

            for (Index i = 0; i < pixels.R.Length; ++i) {

                r = pixels.R[i];
                g = pixels.G[i];
                b = pixels.B[i];

                result.A[i] = pixels.A[i];

                y = (Int)(0.299F * r + 0.587F * g + 0.114F * b);
                if (255 < y) y = 255;

                cb = (Int)(-0.169F * r - 0.332F * g + 0.5F * b) + 128;
                //if (cb < 0) cb = 0; 
                if (255 < cb) cb = 255;
                Debug.Assert(0 <= cb);


                cr = (Int)(0.5F * r - 0.419F * g - 0.0813F * b) + 128;
                //if (cr < 0) cr = 0; 
                if (255 < cr) cr = 255;
                Debug.Assert(0 <= cr);


                result.Y[i] = (Byte)y;
                result.Cb[i] = (Byte)cb;
                result.Cr[i] = (Byte)cr;
            }

            return result;
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public ArgbChannel ToArgb() {
            ArgbChannel result = ArgbChannel.Create(Width, Height);

            Int r = 0;
            Int g = 0;
            Int b = 0;
          
            for (Index i = 0; i < Y.Length; ++i) {

                
                r = (Int)(Y[i] + (1.4075F * (Cr[i] - 128)));
                if (r < 0) r = 0;
                if (255 < r) r = 255;

                g = (Int)(Y[i] - 0.3455F * (Cb[i] - 128) - (0.7169F * (Cr[i] - 128)));
                if (g < 0) g = 0;
                if (255 < g) g = 255;

                b = (Int)(Y[i] + (1.779F * (Cb[i] - 128)));
                if (b < 0) b = 0;
                if (255 < b) b = 255;

                result.A[i] = A[i]; 
                result.R[i] = (Byte)r;
                result.G[i] = (Byte)g;
                result.B[i] = (Byte)b;
            }

            return result;
        }
        public Pixel[] ToPixels() {
            Pixel[] result = new Pixel[A.Length];

            Int r = 0;
            Int g = 0;
            Int b = 0;

            for (Index i = 0; i < Y.Length; ++i) {

                r = (Int)(Y[i] + (1.4075F * (Cr[i] - 128)));
                if (r < 0) r = 0;
                if (255 < r) r = 255;
                
                g = (Int)(Y[i] - 0.3455F * (Cb[i] - 128) - (0.7169F * (Cr[i] - 128)));
                if (g < 0) g = 0;
                if (255 < g) g = 255;

                b = (Int)(Y[i] + (1.779F * (Cb[i] - 128)));
                if (b < 0) b = 0;
                if (255 < b) b = 255;
                        
                result[i] = (Pixel)((A[i] << 24) | (r << 16) | (g << 8) | b);
            }

            return result;
        }
    }



}
