﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Grid = System.Windows.Controls.Grid;
using RoutedEventArgs = System.Windows.RoutedEventArgs;
using Hnc.Type;
using Hnc.Control;
using Hnc.DataLogic;
using Hnc.VideoEditor.Pages;
using Hnc.VideoEditor.Service;
using System.Windows;
using System;
using Hnc.VideoEditor.Base.Enum;
using System.IO;
using Hnc.VideoEditor.Util;
using Hnc.VideoEditor.Controls;

namespace Hnc.VideoEditor.Appbar {
	public partial class MainMenu : Grid {
		private static readonly String[] HvwExtension = { ".hvw", ".xml" };
		// ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private MainPage page;
		#endregion

		// ----------------------------------------------
		// 프로퍼티
		// ----------------------------------------------
		#region 프로퍼티
		public MainPage Page {
			get {
				return page;
			}
			set {
				page = value;
			}
		}
		#endregion

		// ----------------------------------------------
		// 생성자
		// ----------------------------------------------
		#region 생성자
		public MainMenu() {
			InitializeComponent();

			UpdateMenuState();
		}
		#endregion

		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		#region 메소드
		public void UpdateMenuState() {
			StateUndo.IsEnabled = UndoManager.Instance.IsEnableUndo;
			StateRedo.IsEnabled = UndoManager.Instance.IsEnableRedo;

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				int timelineInfoCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoCount();

				if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {
					//if (timelineInfoCount > 0) {
					StateSave.IsEnabled = true;
				} else {
					StateSave.IsEnabled = false;
				}

				if (Hnc.VEFrame.VEFrameManager.Instance.MainPage.IsLoadBarSelectedItem() == true) {
					StateInfomation.IsEnabled = true;
				} else {
					StateInfomation.IsEnabled = false;
				}

				if (Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoCount() > 0) {
					StateExport.IsEnabled = true;
				} else {
					StateSave.IsEnabled = false;
					StateExport.IsEnabled = false;
				}
			} else {
				StateInfomation.IsEnabled = false;
				StateExport.IsEnabled = false;
			}
		}

		private void ShowExportAppbar(object sender, RoutedEventArgs e) {
			if (subAppbar.ShowPanel(SUBAPPBAR_STATE.Export, null, null) == true) {
				subPanel.IsOpen = true;

				// 내보내기시 재생 정지
				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
				}
			} else {
				subPanel.IsOpen = false;
			}

			UpdateMenuState();
		}

		private void ShowInfoAppbar(object sender, RoutedEventArgs e) {
			String filePath = page.LoadBarSelectedItemFilePath();
			if (subAppbar.ShowPanel(SUBAPPBAR_STATE.Info, filePath, page.videoTimeline.SelectedInfo) == true) {
				subPanel.IsOpen = true;
			} else {
				subPanel.IsOpen = false;
			}

			UpdateMenuState();
		}

		private void ShowSubtitleAppbar(object sender, RoutedEventArgs e) {
			if (subAppbar.ShowPanel(SUBAPPBAR_STATE.Subtitle, null, page.subtitleTimeline.SelectedInfo) == true) {
				subPanel.IsOpen = true;
			} else {
				subPanel.IsOpen = false;
			}

			UpdateMenuState();
		}

		private void ShowSoundAppbar(object sender, RoutedEventArgs e) {
			if (subAppbar.ShowPanel(SUBAPPBAR_STATE.Sound, null, page.soundTimeline.SelectedInfo) == true) {
				subPanel.IsOpen = true;
			} else {
				subPanel.IsOpen = false;
			}

			UpdateMenuState();
		}

		private void ShowVideoAppbar(object sender, RoutedEventArgs e) {
			if (subAppbar.ShowPanel(SUBAPPBAR_STATE.Video, null, page.videoTimeline.SelectedInfo) == true) {
				subPanel.IsOpen = true;
			} else {
				subPanel.IsOpen = false;
			}

			UpdateMenuState();
		}

		public void HideSubAppbar() {
			subAppbar.ShowPanel(SUBAPPBAR_STATE.Closed, null, null);
			subPanel.IsOpen = false;
			UpdateMenuState();
		}

		private void ClickSave(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
			}

			FileDialog filePage = new FileDialog(FileDialog.Mode.Save, HvwExtension, SetupManager.Instance.LastOpendDirectory, ".xml");

			if (filePage == null) {
				System.Diagnostics.Debug.Assert(false, "FileDialogPage가 생성되지 않았습니다.");
				return;
			}

			filePage.ShowDialog();

			System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);

			String saveFileName = null;
			if (filePage.DialogResult == true) {
				SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;

				saveFileName = filePage.SaveFilePath;

				ActionSave action = ActionSave.Create(saveFileName);
				AppDialog dlg = null;

				if (ActionManager.Instance.Excute(action) != true) {
					dlg = new AppDialog(Application.Current.Resources["IDS_XMLSave"] as String,
					Application.Current.Resources["IDS_XMLSaveResultSucess"] as String,
					Application.Current.Resources["IDS_Confirm"] as String);
				}

				if (dlg != null) {
					try {
						dlg.ShowDialog();
					} catch (Exception ex) {
						Debug.Assert(false, ex.Message);
					}
				}
			}
		}

		private void ClickLoad(object sender, RoutedEventArgs e) {
			// 창이 뜨면 재생 정지
			int timelineInfoCount = 0;
			// bool undoCount = 0;
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
				timelineInfoCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoCount();
			}

			if (Hnc.DataLogic.UndoManager.Instance.IsEnableUndo == true && timelineInfoCount > 0) {
                CustomDialog dialog = new CustomDialog();
                string message = Application.Current.Resources["IDS_Message_29"] as String + "\n" +
                                 Application.Current.Resources["IDS_Message_30"] as String;

                dialog.ChangeMessageBoxType("", message, 315.0,
                    Application.Current.Resources["IDS_Save"] as String,
                Application.Current.Resources["IDS_NoSave"] as String,
                Application.Current.Resources["IDS_Cancel"] as String);
                dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);

                if (dialog.Result != Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                    if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.CANCEL) {
                        return;
                    }
                }

                if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
					string[] HvwExtensionSave = { ".hvw", ".xml" };
					FileDialog filePageSave = new FileDialog(FileDialog.Mode.Save, HvwExtensionSave, SetupManager.Instance.LastOpendDirectory, ".xml");

					if (filePageSave == null) {
						System.Diagnostics.Debug.Assert(false, "FileDialogPage가 생성되지 않았습니다.");
						return;
					}

					if (filePageSave.ShowDialog() == false) {
						return;
					}

					System.IO.Directory.SetCurrentDirectory(filePageSave.CurrentPath);

					String saveFileName = null;
					if (filePageSave.DialogResult == true) {
						SetupManager.Instance.LastOpendDirectory = filePageSave.CurrentPath;
						saveFileName = filePageSave.SaveFilePath;
						ActionSave saveAction = ActionSave.Create(saveFileName);

						ActionManager.Instance.Excute(saveAction);
					} else {
						return;
					}
				}
			}

			String[] HvwExtension = { ".hvw", ".xml" };

			FileDialog filePage = new FileDialog(FileDialog.Mode.SingleOpen, HvwExtension, SetupManager.Instance.LastOpendDirectory);
			System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);

			Debug.Assert(filePage != null, "FileDialogPage를 생성하지 못하였습니다.");
			filePage.ShowDialog();

			// 파일 다이얼로그에서 확인을 눌렀을 경우
			if (filePage.DialogResult == true) {
				SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;

				if (filePage.SelectedPaths.Count != 0) {
					if (filePage.SelectedPaths[0] != null) {
						ActionLoad action = ActionLoad.Create(filePage.SelectedPaths[0]);

						if (ActionManager.Instance.Excute(action) == true) {
							if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
								Hnc.VEFrame.VEFrameManager.Instance.MainPage.ClearSourceFileList();
								Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetSourceFileList();

								Hnc.VEFrame.VEFrameManager.Instance.MainPage.videoTimeline.SelectFirstTimeline();

								Hnc.VEFrame.VEFrameManager.Instance.MainPage.MediaEditOpen();
								Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetMediaEditSlider();
								Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
							}
						} else {
							AppDialog appDlg = null;

							appDlg = new AppDialog(Application.Current.Resources["IDS_LoadFail"] as String,
												Application.Current.Resources["IDS_Message_22"] as String,
												Application.Current.Resources["IDS_Confirm"] as String);

							if (appDlg != null) {
								try {
									appDlg.ShowDialog();
								} catch (Exception ex) {
									Hnc.Type.Debug.Assert(false, ex.Message);
								}
							}
						}

						if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
							Hnc.VEFrame.VEFrameManager.Instance.MainPage.SwitchAppBarState(false);
						}
					}
				}
			}
		}

		private void ClickUndo(object sender, RoutedEventArgs e) {
			ActionUndo action = ActionUndo.Create();
			ActionManager.Instance.Excute(action);
			UpdateMenuState();
		}

		private void ClickRedo(object sender, RoutedEventArgs e) {
			ActionRedo action = ActionRedo.Create();
			ActionManager.Instance.Excute(action);
			UpdateMenuState();
		}

		private void ClickAddSource(object sender, RoutedEventArgs e) {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangePlayState(false);
			}

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				Hnc.VEFrame.VEFrameManager.Instance.MainPage.AddSourceFile();
			}
		}
		#endregion

		#region -> Public Methods
		public void SwitchAppBarSubPanelState(Bool isOpen) {
			UpdateMenuState();
			subPanel.IsOpen = isOpen;
			subAppbar.PanelID = SUBAPPBAR_STATE.Closed;
		}

		public void ChangeSelectFile(String filePath) {
			if (subPanel.IsOpen == true) {
				if (subAppbar.PanelID == SUBAPPBAR_STATE.Info) {
					subAppbar.ChangeSelectFile(filePath);
				}
			}

			UpdateMenuState();
		}
		#endregion
	}
}