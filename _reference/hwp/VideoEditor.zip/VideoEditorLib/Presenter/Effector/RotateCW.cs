﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;


using Int = System.Int32;
using Bool = System.Boolean;
using Pixel = System.UInt32;
using Count = System.Int32;


namespace Hnc.Presenter.ImageEffect {
    public static class RotateCW {

        // 90도 회전, -90도 회전
        public static Pixels Create(Pixels pixels, Bool clockwise) {
            Debug.AssertThrow(pixels.Data != null, eErrorCode.NullArgument);

            Pixel[] target = new Pixel[pixels.Data.Length];

            Count width = pixels.Width;
            Count height = pixels.Height;

            if (clockwise) {
                for (Int y = 0; y < height; ++y) {
                    for (Int x = 0; x < width; ++x) {
                        target[x * height + (height - 1 - y)] = pixels.Data[y * width + x];
                    }
                }
            }
            else {
                for (Int y = 0; y < height; ++y) {
                    for (Int x = 0; x < width; ++x) {
                        target[(width - 1 - x) * height + y] = pixels.Data[y * width + x];
                    }
                }
            }

            return Pixels.Create(target, pixels.Height, pixels.Width, pixels.HeightDpi, pixels.WidthDpi);
        }
    }
}
