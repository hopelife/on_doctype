﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Hnc.Type;
using Hnc.VideoEditor.Base.Type;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Hnc.VideoEditor.Engine {
	//////////////////////////////////////////////////////////////////////////////////////////
	// Document에는 Maker를 통해서만 접근을 허용하고 있다.
	// 하지만 저장 및 불러오기를 하는 Filter 부분에서 필요한 
	// 몇가지 정보가 있어서 따로 DocumentUtil로 빼두었다.
	// 이후 Maker에서 이 역할을 하도록 수정하거나 하는 작업
	// 이 필요하다.
	//////////////////////////////////////////////////////////////////////////////////////////
	public static class DocumentUtil {
		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		#region 메소드

		// TimelineInfo가 VideoInfo인지 확인
		public static Bool IsVideoInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			VideoInfo videoInfo = info as VideoInfo;

			if (videoInfo == null) {
				return false;
			}

			return true;
		}

		// TimelineInfo가 SoundInfo인지 확인
		public static Bool IsSoundInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			SoundInfo soundInfo = info as SoundInfo;

			if (soundInfo == null) {
				return false;
			}

			return true;
		}

		// TimelineInfo가 SubtitleInfo인지 확인
		public static Bool IsSubtitleInfo(TimelineInfo info) {
#if DEBUG
			Debug.Assert(info != null, "TimelineInfo가 Null 입니다.");
#endif
			SubtitleInfo subtitleInfo = info as SubtitleInfo;

			if (subtitleInfo == null) {
				return false;
			}

			return true;
		}

		// 인자로 들어온 Collection에서 VideoInfo만 검색
		public static Collection<TimelineInfo> FindVideoInfo(Collection<TimelineInfo> infoCollection) {
#if DEBUG
			Debug.Assert(infoCollection != null, "TimelineInfoList가 Null 입니다.");
#endif
			Collection<TimelineInfo> videoInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(videoInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in infoCollection) {
				if (IsVideoInfo(info) == true) {
					videoInfoCollection.Add(info);
				}
			}

			return videoInfoCollection;
		}

		// 인자로 들어온 Collection에서 SoundInfo만 검색
		public static Collection<TimelineInfo> FindSoundInfo(Collection<TimelineInfo> infoCollection) {
#if DEBUG
			Debug.Assert(infoCollection != null, "TimelineInfoList가 Null 입니다.");
#endif
			Collection<TimelineInfo> soundInfoCollection = new Collection<TimelineInfo>();

#if DEBUG
			Debug.Assert(soundInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in infoCollection) {
				if (IsSoundInfo(info) == true) {
					soundInfoCollection.Add(info);
				}
			}

			return soundInfoCollection;
		}

		// 인자로 들어온 Collection에서 SubtitleInfo만 검색
		public static Collection<TimelineInfo> FindSubtitleInfo(Collection<TimelineInfo> infoCollection) {
#if DEBUG
			Debug.Assert(infoCollection != null, "TimelineInfoList가 Null 입니다.");
#endif
			Collection<TimelineInfo> subtitleInfoCollection = new Collection<TimelineInfo>();
#if DEBUG
			Debug.Assert(subtitleInfoCollection != null, "TimelineInfo List를 생성하지 못하였습니다.");
#endif
			foreach (TimelineInfo info in infoCollection) {
				if (IsSubtitleInfo(info) == true) {
					subtitleInfoCollection.Add(info);
				}
			}

			return subtitleInfoCollection;
		}
		#endregion
	}
}