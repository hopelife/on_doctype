#include "gdevwmf.h"
#include "gdevwmf_.h"

#define DWORD_ALIGN_WIDTH(width, bits) (((((width) * (bits) + 7) / 8) + 3) / 4 * 4)

extern int g_nBitsPerPixel;

int wmf_fill_rectangle(gx_device *dev, int x, int y, int width, int height, gx_color_index color)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	COLORREF crColor;
	RECT rect;

	if (!wdev || !wdev->hdc)
		return 0;

	// PDF 1.4 �� �̹��� ������ ����
	if (wdev->bpdf14 && wdev->pbmi) {
		BITMAPINFOHEADER *pBmih = (BITMAPINFOHEADER*)wdev->pbmi;
		BYTE *pBits = (BYTE*)pBmih + pBmih->biSize + sizeof(RGBQUAD) * pBmih->biClrUsed;
		BYTE *pLine, *pPixel;
		int nImageByteWidth = DWORD_ALIGN_WIDTH(pBmih->biWidth, pBmih->biBitCount);
		int nImageHeight = pBmih->biHeight;
		BYTE r = (color >> 16) & 255;
		BYTE g = (color >> 8) & 255;
		BYTE b = color & 255;
		int xx, yy;
		for (yy = y; yy < y + height; yy++) {
			pLine = pBits + nImageByteWidth * (nImageHeight - yy - 1);
			for (xx = x; xx < x + width; xx++) {
				pPixel = pLine + xx * g_nBitsPerPixel / 8;
				pPixel[0] = b;
				pPixel[1] = g;
				pPixel[2] = r;
			}
		}
		wdev->nItems++;
		wdev->bRecord = TRUE;
		if (x == 0 && y == 0 && width == dev->width && height == dev->height) {

#if defined(_DEBUG) || defined(DEBUG)
			if (wdev->pFile) {
				fprintf(wdev->pFile, "wmf_fill_rectangle()\n");
				fprintf(wdev->pFile, "Clear all at %d items\n", wdev->nItems);
			}
#endif // _DEBUG
		}
		return 0;
	}

	// ����̽� �ʱ�ȭ�� ȭ���� ������� ����� ���� ����
	if (!wdev->bRecord) {
		wdev->bRecord = TRUE;
		return 0;
	}

	if (!wdev->bRecord)
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_fill_rectangle()\n");
		fprintf(wdev->pFile, "x      : %d\n", x);
		fprintf(wdev->pFile, "y      : %d\n", y);
		fprintf(wdev->pFile, "width  : %d\n", width);
		fprintf(wdev->pFile, "height : %d\n", height);
		fprintf(wdev->pFile, "color  : %08X\n", color);
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	crColor = MakeColorRef(color);
	wmf_change_pen(dev, 1, crColor);
	wmf_change_brush(dev, BS_SOLID, crColor, HS_CROSS);
	rect.left = x;
	rect.top = y;
	rect.right = x + width;
	rect.bottom = y + height;

	MoveToEx(wdev->hdc, rect.left, rect.top, NULL);
	BeginPath(wdev->hdc);
	LineTo(wdev->hdc, rect.right, rect.top);
	LineTo(wdev->hdc, rect.right, rect.bottom);
	LineTo(wdev->hdc, rect.left, rect.bottom);
	LineTo(wdev->hdc, rect.left, rect.top);
	EndPath(wdev->hdc);
	StrokeAndFillPath(wdev->hdc); // �ּ� Ǯ��.

	if (!(x == 0 && y == 0 && width == dev->width && height == dev->height))
		wdev->nItems++;
	return 0;
}

int wmf_copy_mono(gx_device *dev, const byte *data, int data_x, int raster, gx_bitmap_id id,
				  int x, int y, int width, int height, gx_color_index color0, gx_color_index color1)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	BITMAPINFO *pBmpInfo = NULL;
	int nSize;
	COLORREF crTrans;
	BOOL bTransImage = FALSE;

	if (width == 0 || height == 0)
		return 0;
	if (!wdev || !wdev->hdc)
		return 0;
	if (!wdev->bRecord)
		return 0;

	// Alpha ���� �ִ��� Ȯ��
	if (color0 == gx_no_color_index) {
		crTrans = MakeColorRef(color0);
		bTransImage = TRUE;
	}
	if (color1 == gx_no_color_index) {
		crTrans = MakeColorRef(color1);
		bTransImage = TRUE;
	}

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_copy_mono()========Bitmap\n");
		fprintf(wdev->pFile, "Position X : %d\n", x);
		fprintf(wdev->pFile, "Position Y : %d\n", y);
		fprintf(wdev->pFile, "Width      : %d\n", width - data_x);
		fprintf(wdev->pFile, "Height     : %d\n", height);
		fprintf(wdev->pFile, "Color0     : %08X\n", color0);
		fprintf(wdev->pFile, "Color1     : %08X\n", color1);
		if (bTransImage)
			fprintf(wdev->pFile, "Alpha      : %08X\n", crTrans);
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	WmfSetClipPath(dev, NULL, 0);

	// ������ �����͸� ������ �޸� �Ҵ�
	{
		unsigned long long total = sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 2 + ((unsigned long long)(width - data_x + 7) / 8 + 3) / 4 * 4 * (unsigned long long)height;
		if (total > UINT_MAX) { 
			_ASSERTE(false&&"UINT ���� ���� ��ġ");
			return 0;
		}

	}
	nSize = sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 2 + ((width - data_x + 7) / 8 + 3) / 4 * 4 * height;
	pBmpInfo = (BITMAPINFO*)malloc(nSize);
	memset(pBmpInfo, 0, nSize);

	if (pBmpInfo) {
		MonoImageToDIB(data, data_x, raster, width, height, color0, color1, pBmpInfo);
		if (bTransImage) {
			HDC hdcTemp = CreateCompatibleDC(wdev->hdc);
			HBITMAP hBitmap = CreateCompatibleBitmap(wdev->hdc, width - data_x, height);
			HBITMAP hBitmapOld = SelectObject(hdcTemp, hBitmap);
			SetDIBitsToDevice(hdcTemp, 0, 0, width - data_x, height, 0, 0, 0, height,
							  (BYTE*)pBmpInfo + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 2,
							  pBmpInfo, DIB_RGB_COLORS);
			TransparentBlt(wdev->hdc, x, y, width - data_x, height, hdcTemp, 0, 0, width - data_x, height, crTrans);
			SelectObject(hdcTemp, hBitmapOld);
			DeleteObject(hBitmap);
			DeleteDC(hdcTemp);
		}
		else {
			SetDIBitsToDevice(wdev->hdc, x, y, width - data_x, height, 0, 0, 0, height,
							  (BYTE*)pBmpInfo + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 2,
							  pBmpInfo, DIB_RGB_COLORS);
		}
	}

	if (pBmpInfo)
		free(pBmpInfo);

	wdev->nItems++;
	return 0;
}

int wmf_copy_color(gx_device *dev, const byte *data, int data_x, int raster, gx_bitmap_id id,
				   int x, int y, int width, int height)
{

	gx_device_wmf *wdev = (gx_device_wmf*)dev;

	if (!wdev || !wdev->hdc)
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_copy_color()=======Bitmap  check\n");
		fprintf(wdev->pFile, "Position X : %d\n", x);
		fprintf(wdev->pFile, "Position Y : %d\n", y);
		fprintf(wdev->pFile, "Width      : %d\n", width - data_x);
		fprintf(wdev->pFile, "Height     : %d\n", height);
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	if (width == 0 || height == 0)
		return 0;
	if (!wdev->bRecord)
		return 0;

	wdev->nItems++;
	return 0;
}

int wmf_copy_alpha(gx_device *dev, const byte *data, int data_x, int raster, gx_bitmap_id id,
				   int x, int y, int width, int height, gx_color_index color, int depth)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;

	if (!wdev || !wdev->hdc)
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_copy_alpha()=======Bitmap  chec\n");
		fprintf(wdev->pFile, "Position X : %d\n", x);
		fprintf(wdev->pFile, "Position Y : %d\n", y);
		fprintf(wdev->pFile, "Width      : %d\n", width - data_x);
		fprintf(wdev->pFile, "Height     : %d\n", height);
		fprintf(wdev->pFile, "color      : %08X\n", color);
		fprintf(wdev->pFile, "depth      : %d\n", depth);
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	if (width == 0 || height == 0)
		return 0;
	if (!wdev->bRecord)
		return 0;

	wdev->nItems++;
	return 0;
}

int wmf_create_compositor(gx_device * dev, gx_device ** pcdev, const gs_composite_t * pcte,
						  gs_imager_state * pis, gs_memory_t * memory)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	*pcdev = dev;

	if (!wdev || !wdev->hdc)
		return 0;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_create_compositor()=======Bitmap  chec\n");
		fprintf(wdev->pFile, "\n");
	}
#endif // _DEBUG

	return 0;
}
