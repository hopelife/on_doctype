/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include "Type.h"
#include "Difine.h"
using namespace std;

// FFMpeg ��� ���� ����
extern "C" {
	#include "./FFMpeg/libavutil/opt.h"
	#include "./FFMpeg/libavcodec/avcodec.h"
	#include "./FFMpeg/libavutil/audioconvert.h"
	#include "./FFMpeg/libavutil/common.h"
	#include "./FFMpeg/libavutil/imgutils.h"
	#include "./FFMpeg/libavutil/mathematics.h"
	#include "./FFMpeg/libswscale/swscale.h"
	#include "./FFMpeg/libavformat/avformat.h"
	#include "./FFMpeg/libavutil/samplefmt.h"
	//#include "./FFMpeg/libavutil/fifo.h"
}

Int Round(Double d);