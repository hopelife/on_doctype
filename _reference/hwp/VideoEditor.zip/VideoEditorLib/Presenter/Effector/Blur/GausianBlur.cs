﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {
    public class GaussianBlur {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Kernel1D Kernel { get; set; } // 가로 세로로 적용

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private GaussianBlur(Count radius) {
            Debug.AssertThrow(0 < radius, eErrorCode.OutOfBoundary);

            // 가우시안 블러를 위한 Kernel 생성
            //
            //                 1                           -x * x  
            // G = --------------------------- * exp(-------------------)
            //      sigma * Sqrt(2 * PI)              2 * sigma * sigma      
            // 

            radius = (radius < 1) ? 1 : radius;
            Count count = radius * 2 + 1; // 항상 홀수임
            Float[] m = new Float[count];
            Float sigma = radius / 3;
            Float sigmaSqrt2Pi = sigma * MathUtil.Sqrt(2 * MathUtil.PI);
            Debug.Assert(sigmaSqrt2Pi != 0);

            Index index = 0;
            Float total = 0;

            for (Int x = -radius; x <= radius; ++x) {
                if (radius * radius < x * x) {
                    m[index] = 0;
                }
                else {
                    m[index] = (MathUtil.Exp(-(x * x) / (2 * sigma * sigma))) / sigmaSqrt2Pi;
                }
                total = total + m[index];

                ++index;
            }


            Kernel = Kernel1D.Create(m);

        }
        public static GaussianBlur Create(Count radius) {

            return new GaussianBlur(radius);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel source) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.Assert(Kernel != null);

            ArgbChannel target = ArgbChannel.Create(source.Width, source.Height);

            // 가로 적용
            ApplyCol(source, target);

            // 세로 적용
            ApplyRow(target, source);

        }

        private void ApplyCol(ArgbChannel source, ArgbChannel target) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.AssertThrow(target != null, eErrorCode.NullArgument);
            Debug.AssertThrow(Kernel != null, eErrorCode.InvalidArgument);

            Count width = source.Width;
            Count height = source.Height;

            Index targetPixelPos = 0;
            Index pos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index pixelPos = 0;

            Float total = 0;
            Float aTotal = 0;
            Float rTotal = 0;
            Float gTotal = 0;
            Float bTotal = 0;
            Count kernelCount = Kernel.M.Length;
            Count halfKernelCount = kernelCount / 2;
            Index startPos = 0;

            for (Index y = 0; y < height; ++y) {
                startPos = y * width;
                for (Index x = 0; x < width; ++x) {
                    total = 0;
                    aTotal = 0;
                    rTotal = 0;
                    gTotal = 0;
                    bTotal = 0;

                    targetPixelPos = startPos + x;

                    for (Index k = 0; k < kernelCount; ++k) {
                        pos = x + k - halfKernelCount; // 적용할 픽셀의 가로 위치

                        if (0 <= pos && pos < width) {
                            pixelPos = startPos + pos;

                            total = total + Kernel.M[k];

                            aTotal += source.A[pixelPos] * Kernel.M[k];
                            rTotal += source.R[pixelPos] * Kernel.M[k];
                            gTotal += source.G[pixelPos] * Kernel.M[k];
                            bTotal += source.B[pixelPos] * Kernel.M[k];

                        }
                    }

                    aTotal /= total;
                    rTotal /= total;
                    gTotal /= total;
                    bTotal /= total;

                    //aTotal = (aTotal < 0) ? 0 : ((255 < aTotal) ? 255 : aTotal);
                    //rTotal = (rTotal < 0) ? 0 : ((255 < rTotal) ? 255 : rTotal);
                    //gTotal = (gTotal < 0) ? 0 : ((255 < gTotal) ? 255 : gTotal);
                    //bTotal = (bTotal < 0) ? 0 : ((255 < bTotal) ? 255 : bTotal);

                    target.A[targetPixelPos] = (Byte)aTotal;
                    target.R[targetPixelPos] = (Byte)rTotal;
                    target.G[targetPixelPos] = (Byte)gTotal;
                    target.B[targetPixelPos] = (Byte)bTotal;

                }
            }
        }
        private void ApplyRow(ArgbChannel source, ArgbChannel target) {
            Debug.AssertThrow(source != null, eErrorCode.NullArgument);
            Debug.AssertThrow(target != null, eErrorCode.NullArgument);
            Debug.AssertThrow(Kernel != null, eErrorCode.InvalidArgument);

            Count width = source.Width;
            Count height = source.Height;

            Index targetPixelPos = 0;
            Index pos = 0; // 수정하려는 픽셀 주변에 kernel을 적용할 픽셀위치
            Index pixelPos = 0;

            Float total = 0;
            Float aTotal = 0;
            Float rTotal = 0;
            Float gTotal = 0;
            Float bTotal = 0;
            Count kernelCount = Kernel.M.Length;
            Count halfKernelCount = kernelCount / 2;
            Index startPos = 0;

            for (Index x = 0; x < width; ++x) {
                for (Index y = 0; y < height; ++y) {
                    total = 0;
                    aTotal = 0;
                    rTotal = 0;
                    gTotal = 0;
                    bTotal = 0;

                    startPos = y * width;
                    targetPixelPos = startPos + x;

                    for (Index k = 0; k < kernelCount; ++k) {
                        pos = y + k - halfKernelCount; // 적용할 픽셀의 세로 위치

                        if (0 <= pos && pos < height) {
                            pixelPos = pos * width + x;

                            total = total + Kernel.M[k];

                            aTotal += source.A[pixelPos] * Kernel.M[k];
                            rTotal += source.R[pixelPos] * Kernel.M[k];
                            gTotal += source.G[pixelPos] * Kernel.M[k];
                            bTotal += source.B[pixelPos] * Kernel.M[k];

                        }
                    }

                    aTotal /= total;
                    rTotal /= total;
                    gTotal /= total;
                    bTotal /= total;

                    //aTotal = (aTotal < 0) ? 0 : ((255 < aTotal) ? 255 : aTotal);
                    //rTotal = (rTotal < 0) ? 0 : ((255 < rTotal) ? 255 : rTotal);
                    //gTotal = (gTotal < 0) ? 0 : ((255 < gTotal) ? 255 : gTotal);
                    //bTotal = (bTotal < 0) ? 0 : ((255 < bTotal) ? 255 : bTotal);

                    target.A[targetPixelPos] = (Byte)aTotal;
                    target.R[targetPixelPos] = (Byte)rTotal;
                    target.G[targetPixelPos] = (Byte)gTotal;
                    target.B[targetPixelPos] = (Byte)bTotal;

                }
            }
        }
    }

}
