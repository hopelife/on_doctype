﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Hnc.Control
{
	public class ImageToggleButton : ToggleButton
	{
		static ImageToggleButton()
		{

			DefaultStyleKeyProperty.OverrideMetadata(typeof(ImageToggleButton), new FrameworkPropertyMetadata(typeof(ImageToggleButton)));
		}

		public ImageToggleButton()
		{
		}

		// 속성 정의
		#region Properties

		public string ImageSource
		{
			get { return (string)GetValue(ImageSourceProperty); }
			set { SetValue(ImageSourceProperty, value); }
		}

		public string DisabledImage
		{
			get { return (string)GetValue(DisabledImageProperty); }
			set { SetValue(DisabledImageProperty, value); }
		}

		public string CheckedImage
		{
			get { return (string)GetValue(CheckedImageProperty); }
			set { SetValue(CheckedImageProperty, value); }
		}

		public Visibility ImageVisibility
		{
			get { return (Visibility)GetValue(ImageVisibilityProperty); }
			set { SetValue(ImageVisibilityProperty, value); }
		}

		public string Text
		{
			get { return (string)GetValue(TextProperty); }
			set { SetValue(TextProperty, value); }
		}

		public Visibility TextVisibility
		{
			get { return (Visibility)GetValue(TextVisibilityProperty); }
			set { SetValue(TextVisibilityProperty, value); }
		}


		public string InputGestureText
		{
			get { return (string)GetValue(InputGestureTextProperty); }
			set { SetValue(InputGestureTextProperty, value); }
		}

		public double ImageMargin
		{
			get { return (double)GetValue(ImageMarginProperty); }
			set { SetValue(ImageMarginProperty, value); }
		}

		public Orientation Orientation
		{
			get { return (Orientation)GetValue(OrientationProperty); }
			set { SetValue(OrientationProperty, value); }
		}

	   public static readonly DependencyProperty ImageMarginProperty =
	   DependencyProperty.Register("ImageMargin", typeof(double), typeof(ImageToggleButton),
	   new FrameworkPropertyMetadata(2.0));

       public static readonly DependencyProperty ImageHeightProperty = DependencyProperty.Register("ImageHeight", typeof(double), typeof(ImageToggleButton), new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));
       public double ImageHeight
       {
           get { return (double)GetValue(ImageHeightProperty); }
           set { SetValue(ImageHeightProperty, value); }
       }

       public static readonly DependencyProperty ImageWidthProperty = DependencyProperty.Register("ImageWidth", typeof(double), typeof(ImageToggleButton), new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));
       public double ImageWidth
       {
           get { return (double)GetValue(ImageWidthProperty); }
           set { SetValue(ImageWidthProperty, value); }
       }

		public Visibility InputGestureTextVisibility
		{
			get { return (Visibility)GetValue(InputGestureTextVisibilityProperty); }
			set { SetValue(InputGestureTextVisibilityProperty, value); }
		}

		public static readonly DependencyProperty ImageSourceProperty =
			DependencyProperty.Register(
				"ImageSource",
				typeof(string),
				typeof(ImageToggleButton),
				new PropertyMetadata("")
			);

		public static readonly DependencyProperty DisabledImageProperty =
		  DependencyProperty.Register(
			  "DisabledImage",
			  typeof(string),
			  typeof(ImageToggleButton),
			  new PropertyMetadata("")
		  );

		public static readonly DependencyProperty CheckedImageProperty =
		 DependencyProperty.Register(
			 "CheckedImage",
			 typeof(string),
			 typeof(ImageToggleButton),
			 new PropertyMetadata("")
		 );

		public static readonly DependencyProperty ImageVisibilityProperty =
			DependencyProperty.Register(
				"ImageVisibility",
				typeof(Visibility),
				typeof(ImageToggleButton),
				new PropertyMetadata(Visibility.Visible)
			);

		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register(
				"Text",
				typeof(string),
				typeof(ImageToggleButton),
				new PropertyMetadata("")
			);

		public static readonly DependencyProperty TextVisibilityProperty =
			DependencyProperty.Register(
				"TextVisibility",
				typeof(Visibility),
				typeof(ImageToggleButton),
				new PropertyMetadata(Visibility.Visible)
			);

		public static readonly DependencyProperty InputGestureTextProperty =
		   DependencyProperty.Register(
			   "InputGestureText",
			   typeof(string),
			   typeof(ImageToggleButton),
			   new PropertyMetadata("")
		   );

		public static readonly DependencyProperty InputGestureTextVisibilityProperty =
			DependencyProperty.Register(
				"InputGestureTextVisibility",
				typeof(Visibility),
				typeof(ImageToggleButton),
				new PropertyMetadata(Visibility.Visible)
			);

		public static readonly DependencyProperty OrientationProperty =
			DependencyProperty.Register(
				"Orientation",
				typeof(Orientation),
				typeof(ImageToggleButton),
				new PropertyMetadata(Orientation.Horizontal)
			);
		
		#endregion
	}
}
