﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Ratio = System.Single;
using Index = System.Int32;
using Count = System.Int32;
using Byte = System.Byte;
using Float = System.Single;


namespace Hnc.Presenter.ImageEffect {
   

    class Histogram {

        // ----------------------------------------------
        // 내부 클래스
        // ----------------------------------------------
        public class Item {
            // 히스토그램 레벨 단계
            private static Count LevelCount = 256;

            // 주어진 명암의 갯수들의 집합
            private Count[] data = new Count[LevelCount]; 
            public Count[] Data {
                get { return data; }
            }

            public Count PixelCount { get; set; }

            // Level값이 0이 아닌 곳
            public Index Low {
                get {

                    for (Index i = 0; i < LevelCount; ++i) {
                        if (Data[i] != 0) {
                            return i;
                        }
                    }
                    return LevelCount - 1;
                }
            }

            // Level값이 0이 아닌 곳
            public Index High {
                get {

                    for (Index i = LevelCount; 0 < i; --i) {
                        if (Data[i - 1] != 0) {
                            return i - 1;
                        }
                    }

                    return 0;
                }
            }

            // ----------------------------------------------
            // 생성자
            // ----------------------------------------------
            private Item() { 
            }
            public static Item Create() {
                return new Item();
            }
            public static Item Create(Ratio[] data) {
                Item result = Create();

                result.PixelCount = data.Length;
                for (Index i = 0; i < result.PixelCount; ++i) {
                    Debug.Assert(0 <= (Index)(MathUtil.Round(data[i] * 255)) && (Index)(MathUtil.Round(data[i] * 255)) < 256);
                    ++result.Data[(Index)(MathUtil.Round(data[i] * 255))];
                }
        
                return result;
            }
            public static Item Create(Byte[] data) {
                Item result = Create();

                result.PixelCount = data.Length;
                for (Index i = 0; i < result.PixelCount; ++i) {
                    ++result.Data[data[i]];
                }

                return result;
            }
            
            // ----------------------------------------------
            // 메서드
            // ----------------------------------------------
            // 누적 픽셀갯수가 val 인 위치(히스토그램 왼쪽에서 찾는다.)
            public Index Left(Ratio val) {

                Count limit = MathUtil.Round(val * PixelCount);

                Count total = 0;
                for (Index i = 0; i < LevelCount; ++i) {
                    total = total + Data[i];
                    if (limit <= total) {
                        return i;
                    }
                }
                return 0;
            }
            // 누적 픽셀갯수가 val 인 위치(히스토그램 오른쪽에서 찾는다.)
            public Index Right(Ratio val) {

                Count limit = MathUtil.Round(val * PixelCount);

                Count total = 0;
                for (Index i = LevelCount; 0 < i; --i) {
                    total = total + Data[i - 1];
                    if (limit <= total) {
                        return i - 1;
                    }
                }
                return LevelCount - 1;
            }

            public LookupTable Stretch(Index low, Index high) {
                Debug.AssertThrow(0 <= low && low < LevelCount, eErrorCode.OutOfRange);
                Debug.AssertThrow(0 <= high && high < LevelCount, eErrorCode.OutOfRange);

                if (high < low) {
                    Index temp = low;
                    low = high;
                    high = temp;
                }

                LookupTable result = LookupTable.Create();

                if (high == low) {
                    for (Index i = 0; i < result.Count; ++i) {
                        result.Data[i] = (Byte)low;
                    }

                }
                else {

                    Float delta = high - low;
                    Index maxIndex = result.Count - 1;
                    Ratio temp = 0;
                    
                    for (Index i = 0; i < result.Count; ++i) {

                        temp = (i - low) / delta;
                        result.Data[i] = (Byte)MathUtil.Clamp(temp * maxIndex, 0, 255);
                    }
                }

                return result;
            }

            // 히스토그램 평활화 - 한쪽으로 치우친 명암분포를 재분배 과정을 거쳐 일정한 부포를 갖게 함
            public LookupTable Equalization() {
                Count[] sum = new Count[LevelCount];
                LookupTable result = LookupTable.Create();

                // 누적 빈도수 계산
                sum[0] = Data[0];
                for (Index i = 1; i < LevelCount; ++i) {
                    sum[i] = sum[i - 1] + Data[i];
                }

                // 정규화된 누적합
                for (Index i = 0; i < LevelCount; ++i) {
                    Float temp = (Float)sum[i] / PixelCount * (LevelCount - 1);
                    result.Data[i] = (Byte)MathUtil.Clamp(temp, 0, 255);
                }

                return result;

            }

        }

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Item red = Item.Create();
        public Item Red { get { return red; } }

        private Item green = Item.Create();
        public Item Green { get { return green; } }

        private Item blue = Item.Create();
        public Item Blue { get { return blue; } }

  
        // 히스토그램 분석에 사용한 총 픽셀 갯수
        public Count PixelCount { get; set; }

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Histogram() {
        }


        public static Histogram Create(Pixels pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            
            Histogram result = new Histogram();

            result.PixelCount = pixels.Data.Length;

            result.Red.PixelCount = result.PixelCount;
            result.Green.PixelCount = result.PixelCount;
            result.Blue.PixelCount = result.PixelCount;

            for (Index i = 0; i < result.PixelCount; ++i) {
                ++result.Red.Data[((pixels.Data[i] >> 16) & 0xFF)];
                ++result.Green.Data[((pixels.Data[i] >> 8) & 0xFF)];
                ++result.Blue.Data[((pixels.Data[i]) & 0xFF)];
            }

            return result;
        }
        public static Histogram Create(ArgbChannel pixels) {
           
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Histogram result = new Histogram();

            result.PixelCount = pixels.R.Length;

            result.Red.PixelCount = result.PixelCount;
            result.Green.PixelCount = result.PixelCount;
            result.Blue.PixelCount = result.PixelCount;

            for (Index i = 0; i < result.PixelCount; ++i) {
                ++result.Red.Data[pixels.R[i]];
                ++result.Green.Data[pixels.G[i]];
                ++result.Blue.Data[pixels.B[i]];
            }

            return result;
        }

    }
}
