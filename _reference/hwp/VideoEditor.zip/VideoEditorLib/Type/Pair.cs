﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.Type {


    // 쌍으로 관리되어야 하는 데이터
    public sealed class Pair<TValue1, TValue2> {
        public TValue1 Value1 { get; set; }

        public TValue2 Value2 { get; set; }


        private Pair(TValue1 value1, TValue2 value2) {

            Value1 = value1;
            Value2 = value2;
        }
        public static Pair<TValue1, TValue2> Create(TValue1 value1, TValue2 value2) {
            return new Pair<TValue1, TValue2>(value1, value2);
        }
    }

}
