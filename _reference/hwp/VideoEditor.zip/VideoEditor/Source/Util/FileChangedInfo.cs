﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.IO;
using System.Collections.Generic;

namespace Hnc.VideoEditor.Util {

	class FileChangedInfo {
		public FileStream stream = null;
		public string path = null;
	}

	internal sealed class FileChangedManager {
		static List<FileChangedInfo> fileList = new List<FileChangedInfo>();

		public static void AddFile(string path) {
			FileChangedInfo info = new FileChangedInfo();

			info.stream = new FileStream(path, FileMode.Open, FileAccess.Read);
			info.path = path;
			fileList.Add(info);
		}

		public static void RemoveFile(string path) {
			FileChangedInfo info = null;

			for (int i = 0; i < fileList.Count; ++i) {
				if (path == fileList[i].path) {
					info = fileList[i];
					break;
				}
			}

			if (info != null) {
				info.stream.Close();
				fileList.Remove(info);
			}
		}
	}
}
