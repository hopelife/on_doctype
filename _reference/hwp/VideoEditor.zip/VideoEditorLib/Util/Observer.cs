﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using String = System.String;
using Index = System.Int32;

namespace Hnc.Util {

    // 구분할수 있는 이름만 제공
    public class ObserverArg {
        public String Name { get; set; }
        public Index Index { get; set; }
        private ObserverArg(String name, Index index) {
            Name = name;
            Index = index;
        }
        public static ObserverArg Create(String name, Index index) {
            return new ObserverArg(name, index);
        }
    }
    public interface Observer {
        void Update(ObserverArg arg);
    }

    // 옵저버들
    public class Observers {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private List<Observer> collection = List<Observer>.Create();
        private List<Observer> Collection {
            get {
                Debug.Assert(collection != null);
                return collection;
            }
        }
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Observers() { 
        }
        public static Observers Create() {
            return new Observers();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        public void Add(Observer observer) {
            Debug.Assert(observer != null);
            if (observer == null) {
                return;
            }

            // 이미 존재하면 리턴
            if (Collection.IndexOf(observer) != -1) {
                return;
            }

            Collection.Add(observer);
        }
        public void Remove(Observer observer) {
            Debug.Assert(observer != null);
            if (observer == null) {
                return;
            }
            Collection.Remove(observer);
        }

        public void Update(ObserverArg arg) {
            foreach (var item in Collection) {
                Debug.Assert(item != null);
                item.Update(arg);
            }
        }
    }

    // 옵저버들을 등록하고 통지할 수 있는 개체
    public class Publisher {
        private Observers observers = Observers.Create();
        private Observers Observers {
            get {
                Debug.Assert(observers != null);
                return observers;
            }
        }
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        protected Publisher() { // 상속해서만 쓰도록 protected로 구현
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void AddObserver(Observer observer) {
            Observers.Add(observer);
        }
        public void RemoveObserver(Observer observer) {
            Observers.Remove(observer);
        }
        public void NotifyChanged(String name) {
            Observers.Update(ObserverArg.Create(name, -1));
        }
        public void NotifyChanged(String name, Index index) {
            Observers.Update(ObserverArg.Create(name, index));
        }

    }
}
