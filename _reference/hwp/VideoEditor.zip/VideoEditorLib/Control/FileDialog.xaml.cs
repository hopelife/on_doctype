﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Hnc.Type;
using Hnc.Util;

using Bool = System.Boolean;
using Int = System.Int32;
using String = System.String;
using System.Windows.Interop;
using Hnc.Instrument;
using System.Windows.Input;

namespace Hnc.Control {

    public partial class FileDialog : Window {

        #region -> Enumeration

        public enum Mode {
            /// <summary>
            /// 복수 파일을 선택
            /// </summary>
            Open,
            /// <summary>
            /// 단일 파일을 선택
            /// </summary>
            SingleOpen,
            /// <summary>
            /// 저장할 파일을 선택
            /// </summary>
            Save,
            /// <summary>
            /// 저장할 디렉터리를 선택
            /// </summary>
            SaveDir
        };

        #endregion

        #region -> Fields

        public readonly static String[] ImageExtentions = { ".png", ".gif", ".bmp", ".jpeg", ".jpg", ".tiff" };
        public readonly static String[] VideoExtentions = { ".mp4", ".avi", ".wmv", ".mkv", ".ts" };

        private String[] FilteringExtensions = null;

        private Mode mode;
        private ObservableCollection<PhotoListBoxItem> listItems = new ObservableCollection<PhotoListBoxItem>();
        private ObservableCollection<PhotoListBoxItem> selectedItems = new ObservableCollection<PhotoListBoxItem>();
		private RoutedEventHandler eventClickedOK = null;
        /// <summary>
        /// listItems를 수동으로 편집할 경우에는 반드시 isMovingDirectory 플래그를 셋팅해야함
        /// 그렇지 않으면 selectedItems(선택 아이템 리스트)에 영향을 미침
        /// </summary>
        private Bool isMovingDirectory = false;

        private SolidColorBrush fileBackground = Application.Current.Resources["Show.b2"] as SolidColorBrush;

        #endregion

        #region -> Constructors

        private FileDialog() { }

        public FileDialog(Mode dialogMode, String[] filteringExtention) {

            InitializeComponent();
            selectedItems.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(selectedItems_CollectionChanged);
			okButton.Click += GetClickedOKEvent();

            this.mode = dialogMode;
            this.FilteringExtensions = filteringExtention;
            photoListBox.ItemsSource = listItems;
            selectedListBox.ItemsSource = selectedItems;
            InitWindow();

            CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_PERSONAL);
        }
        
        public FileDialog(Mode dialogMode, String[] filteringExtention, String startPath) {                        

            InitializeComponent();
            selectedItems.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(selectedItems_CollectionChanged);
			okButton.Click += GetClickedOKEvent();

            this.mode = dialogMode;
            this.FilteringExtensions = filteringExtention;
            photoListBox.ItemsSource = listItems;
            selectedListBox.ItemsSource = selectedItems;
            InitWindow();

            CurrentPath = startPath;
        }       

        public FileDialog(Mode dialogMode, String[] filteringExtention, String startPath, String exportExtension) {            

            InitializeComponent();
            selectedItems.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(selectedItems_CollectionChanged);
			okButton.Click += GetClickedOKEvent();

            this.mode = dialogMode;
            this.FilteringExtensions = filteringExtention;
            photoListBox.ItemsSource = listItems;
            selectedListBox.ItemsSource = selectedItems;
            InitWindow();

            CurrentPath = startPath;
            ExportExtension = exportExtension;
        }

        #endregion

        #region -> Properties

        private String ExportExtension {
            get;
            set;
        }

        private String currentPath;
        /// <summary>
        /// 현재 탐색중인 경로이며 속성을 설정하면 해당 경로로 이동하고 관련된 정보를 갱신합니다.
        /// </summary>
        public String CurrentPath {

            get { return currentPath; }
            set {

                if (!Directory.Exists(value)) {
                    currentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO);
                } else {
                    currentPath = value;
                }

                if (value.Equals(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYPICTURES)))
                    titleLabel.Text = Application.Current.Resources["IDS_MyPictures"] as String;
                else if (value.Equals(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO)))
                    titleLabel.Text = Application.Current.Resources["IDS_MyVideos"] as String;
                else if (value.Equals(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_PERSONAL)))
                    titleLabel.Text = Application.Current.Resources["IDS_MyDocuments"] as String;
                else if (value.Equals(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_DESKTOP)))
                    titleLabel.Text = Application.Current.Resources["IDS_Desktop"] as String;
                else
                    titleLabel.Text = currentPath;

				// 내 동영상 폴더라면 공용 동영상부터 로드도 추가
				if (value.Equals(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO))) {
					LoadDirectory(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_COMMON_VIDEO), true);
					LoadDirectory(currentPath, false);
				} else {
					LoadDirectory(currentPath, true);
				}
            }
        }

        /// <summary>
        /// 파일 다이얼로그에서 선택된 파일들의 경로입니다.
        /// </summary>
        public System.Collections.Generic.List<String> SelectedPaths {
            get {

                System.Collections.Generic.List<String> selectedfileNames = new System.Collections.Generic.List<String>(selectedItems.Count);

                foreach (PhotoListBoxItem item in selectedItems) {
                    selectedfileNames.Add(item.Path);
                }

                return selectedfileNames;
            }
            set {

                foreach (String path in value) {
                    if (FindByPath(selectedItems, path) == -1) {
                        PhotoListBoxItem item = CreateItem(path, path);

                        if (item != null) {
                            selectedItems.Add(item);
                            selectedListBox.ScrollToEnd();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Save모드에서 입력된 출력 경로입니다.
        /// </summary>
        public String SaveFilePath {
            get {
                return saveFileName.Text;
            }
            set {
                saveFileName.Text = value;
            }
        }

        #endregion

        #region -> Event Handlers

        private void OnClickedUp(object sender, RoutedEventArgs e) {

            // 드라이브 루트에서 한 수준 위로 이동하고자 할 경우 내 컴퓨터 경로로 이동
            if (CurrentPath.Length == 3) {
                OnClickedMyComputer(sender, e);
                return;
            }

            String path = CurrentPath;

            Int index = path.LastIndexOf('\\');
            if (index == -1) {
                return;
            }

            // 상위 경로로 변환
            path = path.Substring(0, index);

            // 드라이브 루트 경로로 이동했을 경우 C:와 같은 형태가 되므로 C:\로 수정
            if (!path.Contains(@"\"))
                path += @"\";

            // 상위 경로로 이동
            CurrentPath = path;
        }

        private void OnClickedMyPictures(object sender, RoutedEventArgs e) {

            // 내 사진으로 이동
            CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYPICTURES);
        }

        private void OnClickedMyVideos(object sender, RoutedEventArgs e) {

            // 내 동영상으로 이동
            CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO);
        }

        private void OnClickedMyDocument(object sender, RoutedEventArgs e) {

            // 내 문서로 이동
            CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_PERSONAL);
        }

        private void OnClickedDesktop(object sender, RoutedEventArgs e) {

            // 바탕화면으로 이동
            CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_DESKTOP);
        }

        private void OnClickedMyComputer(object sender, RoutedEventArgs e) {

            titleLabel.Text = Application.Current.Resources["IDS_MyComputer"] as String;

            LoadDrive();
        }

		private RoutedEventHandler GetClickedOKEvent() {
			if (eventClickedOK == null) {
				eventClickedOK = new RoutedEventHandler(OnClickedOK);
			}

			return eventClickedOK;
		}

		public void SetClickedOK(RoutedEventHandler handler) {
			okButton.Click -= GetClickedOKEvent();
			okButton.Click += handler;
		}

		public void ClickedOKBack() {
			okButton.Click += GetClickedOKEvent();
		}

		public String GetFullPath() {
			String fullPath = null;
			if (!String.IsNullOrEmpty(ExportExtension)) {
				fullPath = CurrentPath.TrimEnd('\\') + @"\" + saveFileName.Text.Replace(ExportExtension, "") + ExportExtension;
			} else {
				fullPath = CurrentPath.TrimEnd('\\') + @"\" + saveFileName.Text;
			}

			return fullPath;
		}

		public void BaseClickedOKFunction() {
			if (mode == Mode.Save) {

				// 사용할 수 없는 문자가 포함되었는지 체크
				if (!IsValidName(saveFileName.Text)) {

					AppDialog dlg = new AppDialog(Application.Current.Resources["IDS_SaveFile"] as String,
					Application.Current.Resources["IDS_Message04"] as String,
					Application.Current.Resources["IDS_Confirm"] as String);
					dlg.ShowDialog();
					return;
				}				

				// 내보낼 확장자가 셋팅되어 있는 경우에는 확장자를 붙여서 체크하고 아닐 경우에는 확장자가 직접 입력되었다고 간주하고 체크
				String fullPath = null;
				if (!String.IsNullOrEmpty(ExportExtension))
					fullPath = CurrentPath.TrimEnd('\\') + @"\" + saveFileName.Text.Replace(ExportExtension, "") + ExportExtension;
				else
					fullPath = CurrentPath.TrimEnd('\\') + @"\" + saveFileName.Text;

                // 이미 존재하는 파일인지 체크
				if (File.Exists(fullPath)) {

					AppDialog dlg = new AppDialog(Application.Current.Resources["IDS_SaveFile"] as String,
						"\'" + fullPath + "\'" + Application.Current.Resources["IDS_Message03"] as String,
						Application.Current.Resources["IDS_Overwrite"] as String,
						Application.Current.Resources["IDS_Cancel"] as String);

					if (dlg.ShowDialog(dlg.messageBoxType) != Hnc.Control.AppDialog.ResultType.OK)
						return;
				}

				/*
				foreach (char c in fullPath) {
					if (char.GetUnicodeCategory(c) == System.Globalization.UnicodeCategory.OtherLetter) {
						AppDialog dlg = new AppDialog(Application.Current.Resources["IDS_SaveFile"] as String,
						Application.Current.Resources["IDS_Message05"] as String,
						Application.Current.Resources["IDS_Confirm"] as String);
						dlg.ShowDialog();
						return;
					}
				}
				*/

				saveFileName.Text = fullPath;
				this.DialogResult = true;
				this.Close();

			} else if (mode == Mode.SaveDir) {

                if (!IsValidName(saveFileName.Text)) {
                    AppDialog dlg = new AppDialog(Application.Current.Resources["IDS_SaveFile"] as String,
                    Application.Current.Resources["IDS_Message04"] as String,
                    Application.Current.Resources["IDS_Confirm"] as String);
                    dlg.ShowDialog();
                    return;
                }

                String fullPath = CurrentPath.TrimEnd('\\') + @"\" + saveFileName.Text;

                if (Directory.Exists(fullPath)) {
                    AppDialog dlg = new AppDialog(Application.Current.Resources["IDS_SaveFile"] as String,
                        fullPath + Application.Current.Resources["IDS_Message06"] as String,
                        Application.Current.Resources["IDS_Confirm"] as String);
                    dlg.ShowDialog();
                    return;
                }

                saveFileName.Text = fullPath;
                this.DialogResult = true;
                this.Close();
            } else {
				this.DialogResult = true;
				this.Close();
			}

		}

		private void OnClickedOK(object sender, RoutedEventArgs e) {
			BaseClickedOKFunction();
		}

        private void OnClickedCancel(object sender, RoutedEventArgs e) {

            //this.DialogResult = false;
            this.Close();
        }

        private void photoListBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {

            // 저장 모드일 경우 경로 이동만 수행
            if (mode == Mode.Save || mode == Mode.SaveDir) {

                if (e.AddedItems.Count > 0) {
                    PhotoListBoxItem selectedItem = e.AddedItems[0] as PhotoListBoxItem;

                    if (Directory.Exists(selectedItem.Path)) {
                        CurrentPath = selectedItem.Path;
                    } else {
                        string selectedItemExt = Path.GetExtension(selectedItem.Path);
                        saveFileName.Text = Path.GetFileName(selectedItem.Path);
                        saveFileName.Text = saveFileName.Text.Replace(selectedItemExt, "");
                    }
                }
            } else {
                // 파일을 선택했을 경우
                if (e.AddedItems.Count > 0) {

                    PhotoListBoxItem selectedItem = e.AddedItems[0] as PhotoListBoxItem;

                    // 선택된 아이템이 폴더인 경우
                    if (Directory.Exists(selectedItem.Path)) {
                  
                        // 폴더는 선택되지 않도록 강제
                        if (photoListBox.SelectionMode == SelectionMode.Single) {
                            photoListBox.SelectedItem = null;
                        } else {
                            photoListBox.SelectedItems.Remove(selectedItem);
                        }

                        CurrentPath = selectedItem.Path;                       
                    }
                    // 선택된 아이템이 파일인 경우
                    else {

                        // 이미 선택된 이미지인지 확인한 후 새롭게 선택한 이미지라면 추가
                        if (FindByPath(selectedItems, selectedItem.Path) == -1) {
                            PhotoListBoxItem item = CreateItem(selectedItem.Id, selectedItem.Path);

                            if (item != null) {

                                if (mode == Mode.SingleOpen) {
                                    if (selectedItems.Count == 0)
                                        selectedItems.Add(item);
                                    else
                                        selectedItems[0] = item;
                                } else {
                                    selectedItems.Add(item);                                    
                                }
                                selectedListBox.ScrollToEnd();
                            }
                        }
                    }
                }
                    // 파일 선택을 해제했을 경우
                else if (e.RemovedItems.Count > 0) {

                    // isMovingDirectory가 True이면 코드에 의해 선택해제가 발생한 경우이므로 처리하지 않음
                    if (!isMovingDirectory) {

                        PhotoListBoxItem removedItem = e.RemovedItems[0] as PhotoListBoxItem;

                        Int index = FindByPath(selectedItems, removedItem.Path);
                        if (index != -1)
                            selectedItems.RemoveAt(index);
                    }
                }           
            }
        }

        private void selectedItems_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e) {

            okButton.IsEnabled = true;

            if (selectedItems.Count == 0) {
                selCountLabel.Content = String.Empty;
                photoLabel.Content = String.Empty;
                okButton.IsEnabled = false;
            } else if (selectedItems.Count == 1) {
                selCountLabel.Content = selectedItems.Count;
                photoLabel.Content = " File";
            } else {
                selCountLabel.Content = selectedItems.Count;
                photoLabel.Content = " Files";
            }
        }

        private void selectedListBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {

            // 선택된 아이템을 리스트에서 삭제
            if (e.AddedItems.Count > 0) {

                PhotoListBoxItem selectedItem = e.AddedItems[0] as PhotoListBoxItem;

                Int index = FindByPath(selectedItems, selectedItem.Path);
                if (index != -1) {

                    selectedItems.RemoveAt(index);

                    if (photoListBox.SelectionMode == SelectionMode.Single) {
                        if (selectedItem.Path.Equals((photoListBox.SelectedItem as PhotoListBoxItem).Path))
                            photoListBox.SelectedItem = null;
                    } else {
                        Int photoListBoxIndex = FindByPath(photoListBox.SelectedItems, selectedItem.Path);
                        if (photoListBoxIndex != -1) {
                            photoListBox.SelectedItems.RemoveAt(photoListBoxIndex);
                        }
                    } 
                }
            }
        }

        private void sortListBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {

            if (listItems == null || listItems.Count == 0)
                return;

            SortList();
        }

        private void selectAllBtn_Click(object sender, RoutedEventArgs e) {

            if (mode == Mode.SingleOpen || mode == Mode.Save || mode == Mode.SaveDir)
                return;

            // 디렉토리를 제외한 모든 아이템 선택
            foreach (PhotoListBoxItem item in photoListBox.Items) {

                if (!Directory.Exists(item.Path))
                    photoListBox.SelectedItems.Add(item);
            }
        }

        private void clearSelectionBtn_Click(object sender, RoutedEventArgs e) {

            if (mode == Mode.SingleOpen || mode == Mode.Save || mode == Mode.SaveDir)
                return;

            foreach (PhotoListBoxItem item in photoListBox.SelectedItems) {

                Int index = FindByPath(selectedItems, item.Path);
                if (index != -1)
                    selectedItems.RemoveAt(index);
            }

            photoListBox.SelectedItems.Clear();
        }

        private void saveFileName_TextChanged(object sender, TextChangedEventArgs e) {

            // 공백 입력 시에는 확인 버튼 비활성화 
            if (StringUtil.IsNullOrEmpty(saveFileName.Text))
                okButton.IsEnabled = false;
            else
                okButton.IsEnabled = true;
        }

        private void Grid_MouseMove(object sender, MouseEventArgs e) {

            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
        }

        #endregion

        #region -> Private Methods

        private void InitWindow() {
  
            this.Owner = Application.Current.MainWindow;

            if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
                this.WindowState = WindowState.Maximized;
            } else {
                this.Width = Application.Current.MainWindow.ActualWidth;
                this.Height = Application.Current.MainWindow.ActualHeight;
            }

            DropDownListItem item1 = new DropDownListItem();
            DropDownListItem item2 = new DropDownListItem();

            item1.Text = Application.Current.Resources["IDS_ByDateDesc"] as String;
            item1.Tag = PhotoListBox.SortType.Date_Desc;
            item2.Text = Application.Current.Resources["IDS_ByNameAsc"] as String;
            item2.Tag = PhotoListBox.SortType.Name_Acs;

            sortListBox.Items.Add(item1);
            sortListBox.Items.Add(item2);
            sortListBox.SelectedIndex = 0;

            titleLabel.Width = Application.Current.MainWindow.ActualWidth - 250d;    // DropDownMenu 만큼만 제외

            ChangeMode(this.mode);

            // 존재하지 않는 폴더의 바로 가기 버튼 숨기기
            if (!Directory.Exists(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYVIDEO)))
                myVideoBtn.Visibility = Visibility.Collapsed;

            if (!Directory.Exists(SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_DESKTOP)))
                desktopBtn.Visibility = Visibility.Collapsed;
        }
    
        /// <summary>
        /// 각 모드에 맞게 UI 요소를 셋팅합니다.
        /// </summary>
        private void ChangeMode(Mode mode) {
            Debug.Assert(openModeGrid != null);
            Debug.Assert(saveModeGrid != null);
            Debug.Assert(photoListBox != null);
            Debug.Assert(titleLabel != null);

            this.mode = mode;
            okButton.IsEnabled = false;

            // 파일 복수 선택 모드
            if (mode == Mode.Open) {

                selectAllBtn.Visibility = Visibility.Visible;
                clearSelectionBtn.Visibility = Visibility.Visible;
                openModeGrid.Visibility = Visibility.Visible;
                selectedListBox.Visibility = Visibility.Visible;
                selCountLabel.Visibility = Visibility.Visible;
                photoLabel.Visibility = Visibility.Visible;
                saveModeGrid.Visibility = Visibility.Hidden;

                photoListBox.SelectionMode = SelectionMode.Multiple;

                // 현재 검색중인 디렉토리가 없다면 내 그림 폴더로 이동
                if (StringUtil.IsNullOrEmpty(CurrentPath))
                    CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYPICTURES);
            }
            // 파일 단일 선택 모드
            else if (mode == Mode.SingleOpen) {

                selectAllBtn.Visibility = Visibility.Hidden;
                clearSelectionBtn.Visibility = Visibility.Hidden;
                openModeGrid.Visibility = Visibility.Visible;
                selectedListBox.Visibility = Visibility.Hidden;
                selCountLabel.Visibility = Visibility.Hidden;
                photoLabel.Visibility = Visibility.Hidden;
                saveModeGrid.Visibility = Visibility.Hidden;

                photoListBox.SelectionMode = SelectionMode.Single;

                // 현재 검색중인 디렉토리가 없다면 내 그림 폴더로 이동
                if (StringUtil.IsNullOrEmpty(CurrentPath))
                    CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_MYPICTURES);
            }
            // 파일 저장 모드
            else if (mode == Mode.Save || mode == Mode.SaveDir) {
                selectAllBtn.Visibility = Visibility.Hidden;
                clearSelectionBtn.Visibility = Visibility.Hidden;
                openModeGrid.Visibility = Visibility.Hidden;
                saveModeGrid.Visibility = Visibility.Visible;                
                photoListBox.SelectionMode = SelectionMode.Single;

                // 바탕화면 폴더로 이동
                CurrentPath = SpecialFolder.GetSpecialFolder(SpecialFolderCSIDL.CSIDL_DESKTOP);

                if (mode == Mode.SaveDir) {
                    pathLabel.Content = Application.Current.Resources["IDS_DirectoryName"] as String;
                }
            }
        }

		// saveFileName TextBox 컨트롤에 포커스가 가도록 설정
		private void SaveFileName_Loaded(object sender, RoutedEventArgs e) {
			if (mode == Mode.Save) {
				saveFileName.Focusable = true;
				saveFileName.Focus();
			}
		}

        /// <summary>
        /// 내컴퓨터의 드라이브를 로드합니다.
        /// </summary>
        private void LoadDrive() {

            if (mode == Mode.SingleOpen)
                selectedItems.Clear();

            sourceMenu.IsOpen = false;

            isMovingDirectory = true;
            {
                // 목록 클리어            
                listItems.Clear();

                ImageSource driveImage = Application.Current.Resources["FileDialog.DriveImage"] as ImageSource;

                // 내 컴퓨터의 디스크 목록 검색
                foreach (DriveInfo info in DriveInfo.GetDrives()) {

                    // 고정식 디스크만 사용
                    if (info.DriveType == DriveType.Fixed) {
                        PhotoListBoxItem item = CreateItem(info.Name, info.Name, driveImage);

                        if (item != null)
                            listItems.Add(item);
                    }
                }
            }
            isMovingDirectory = false;
        }

        /// <summary>
        /// 입력한 경로의 폴더와 파일들을 로드합니다.
        /// </summary>
		private void LoadDirectory(String path, bool reset) {
            Debug.AssertThrow(!StringUtil.IsNullOrEmpty(path), eErrorCode.NullArgument);

            if (mode == Mode.SingleOpen)
                selectedItems.Clear();

            sourceMenu.IsOpen = false;

            isMovingDirectory = true;
            {
				if (reset == true) {
					// 목록 클리어
					photoListBox.ItemsSource = null;
					listItems.Clear();
				}

                // 폴더 검색
                System.Collections.Generic.List<String> folderPaths = new System.Collections.Generic.List<String>();
                try {
                    System.IO.DirectoryInfo legacyInfo;
                    foreach (String directoryPath in System.IO.Directory.GetDirectories(path)) {
                        try {
                            legacyInfo = new System.IO.DirectoryInfo(directoryPath);

                            // 숨김 폴더는 제외
                            if ((legacyInfo.Attributes & System.IO.FileAttributes.Hidden) != System.IO.FileAttributes.Hidden)
                                folderPaths.Add(directoryPath);
                        } catch (PathTooLongException) {
                            // 경로가 너무 길면 파일 검색 창에 출력되지 않도록 임시 처리
                            // 후에 경로를 넘는 디렉토리나 파일도 처리할 수 있도록 수정해야함
                            continue;
                        }
                    }

                } catch (UnauthorizedAccessException) {
                    return;
                }

                // 파일 검색 (저장 모드일 경우에는 파일은 표시할 필요 없음)
                Hnc.Type.List<String> filePaths = null;          
                try {
                    filePaths = PathUtil.Collect(path, false);
                } catch (UnauthorizedAccessException) {
                    return;
                }

                // 폴더 아이템 추가
                foreach (String folderPath in folderPaths) {
                    PhotoListBoxItem item = CreateItem(folderPath, folderPath, GetDirectoryImage(folderPath));

                    if (item != null) {
                        listItems.Add(item);
                    }
                }

                // 파일 아이템 추가
                if (filePaths != null) {
                    foreach (String filePath in filePaths) {

                        if (!File.Exists(filePath))
                            continue;

                        if (".lnk".Equals(Path.GetExtension(filePath).ToLower())) {

                            String targetPath = GetLnkTarget(filePath);
                            if (StringUtil.IsNullOrEmpty(targetPath) || (!File.Exists(targetPath) && !Directory.Exists(targetPath)))
                                continue;

                            // 디렉터리 선택 모드(Mode.SaveDir)이면 바로가기 파일은 표시하지 않음
                            if (mode == Mode.SaveDir && File.Exists(targetPath))
                                continue;

                            if ((File.Exists(targetPath) && FilteringExtensions.Contains(Path.GetExtension(targetPath).ToLower()))
                                || Directory.Exists(targetPath)) {

                                PhotoListBoxItem item = CreateItem(filePath, targetPath, GetLnkFileImage(filePath, targetPath));

                                if (item != null) {
                                    listItems.Add(item);

                                    // 이미 선택중인 이미지의 경우 선택체크
                                    if (photoListBox.SelectionMode != SelectionMode.Single && FindByPath(selectedListBox.Items, targetPath) != -1)
                                        photoListBox.SelectedItems.Add(item);
                                }
                            }
                        } else if (FilteringExtensions.Contains(Path.GetExtension(filePath).ToLower())) {

                            PhotoListBoxItem item = CreateItem(filePath, filePath);

                            if (item != null) {
                                listItems.Add(item);

                                // 이미 선택중인 이미지의 경우 선택체크
                                if (photoListBox.SelectionMode != SelectionMode.Single && FindByPath(selectedListBox.Items, filePath) != -1)
                                    photoListBox.SelectedItems.Add(item);
                            }
                        }
                    }
                }

                SortList();
                photoListBox.ItemsSource = listItems;
            }
            isMovingDirectory = false;

            if (listItems.Count != 0)
                photoListBox.ScrollToIndex(0);
        }

        private PhotoListBoxItem CreateItem(String id, String path) {

            return CreateItem(id, path, GetFileImage(path, (int)photoListBox.ItemWidth));
        }

        private PhotoListBoxItem CreateItem(String id, String path, ImageSource source) {

            if (source == null) {
                return null;
            } else {                
                PhotoListBoxItem item = new PhotoListBoxItem(id, CreateImageControl(source));

                item.ItemName = Path.GetFileName(path);
                item.Path = path;

                if (VideoExtentions.Contains(PathUtil.GetExt(path))){
                    VideoContentInfo info = VideoUtil.GetVideoContentInfo(path);

					String information = "";
					FileInfo fileInfo = new FileInfo(path);
                    information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                    information += Application.Current.Resources["IDS_Size"] as String + ": " + Math.Round(fileInfo.Length / 1024.0, 2) + "KB" + Environment.NewLine;
                    information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                    information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                    information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
					item.Information = information;
                }

                String extention = Path.GetExtension(path).ToLower();

                // 디렉토리이거나 이미지, 동영상이 아닌 경우 파일명으로 라벨 설정
                if (Directory.Exists(path)) {
                    item.Label = new DirectoryInfo(path).Name;
                    item.LabelHeight = 23d;
                    item.LabelMargin = new Thickness(10, 0, 10, 0);
                    item.LabelColor = Brushes.Transparent;

                    item.DateImageTaken = new DirectoryInfo(path).LastWriteTime;
                } else if (!VideoExtentions.Contains(extention) && !ImageExtentions.Contains(extention)) {
                    item.Label = new FileInfo(path).Name;
                    item.LabelHeight = 23d;
                    item.LabelMargin = new Thickness(10, 0, 10, 0);
                    item.LabelColor = Brushes.Transparent;

                    item.DateImageTaken = new FileInfo(path).LastWriteTime;

                } else {
                    item.DateImageTaken = new FileInfo(path).LastWriteTime;
                }

                return item;
            }
        }

        /// <summary>
        /// 기본 속성이 초기화된 Image 컨트롤을 생성합니다.
        /// </summary>
        private Image CreateImageControl(String path, int decodedPixel) {
            return CreateImageControl(GetFileImage(path, decodedPixel));
        }

        private Image CreateImageControl(ImageSource source) {

            Image image = new Image();
            image.Source = source;
            image.Stretch = Stretch.UniformToFill;
            image.HorizontalAlignment = HorizontalAlignment.Center;
            image.VerticalAlignment = VerticalAlignment.Center;

            return image;
        }

        /// <summary>
        /// 파일 아이템의 썸네일 이미지를 가져옵니다.
        /// </summary>
        private ImageSource GetFileImage(String path, int decodedPixel) {

            // 파일의 특성에 맞게 썸네일 추출
            String extention = Path.GetExtension(path).ToLower();

            if (ImageExtentions.Contains(extention)) {
                // 이미지
                return GetImageSource(path, decodedPixel);

            } else if (VideoExtentions.Contains(extention)) {
                // 비디오 썸네일 추출
                return VideoUtil.GetVideoAutoThumbnail(path, 190, 130);

            } else {
                // 파일 아이콘 리턴
                return GetFileImageIncludeIcon(path);
            }
        }

        /// <summary>
        /// 미리보기를 제공할 수 없는 파일 아이템의 경우 빈 사각형에 아이콘을 그린 썸네일 이미지를 가져옵니다.
        /// </summary>
        private ImageSource GetFileImageIncludeIcon(String path) {

            if (File.Exists(path)) {

                System.Drawing.Icon sysIcon = System.Drawing.Icon.ExtractAssociatedIcon(path);
                BitmapSource iconImage = Imaging.CreateBitmapSourceFromHIcon(sysIcon.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());

                DrawingVisual dv = new DrawingVisual();
                DrawingContext dc = dv.RenderOpen();

                ImageBrush ib = new ImageBrush(iconImage);
                ib.Stretch = Stretch.UniformToFill;

                dc.DrawRectangle(fileBackground, null, new System.Windows.Rect(0, 0, 190, 130));
                dc.DrawRectangle(ib, null, new System.Windows.Rect(12, 15, 32, 32));

                dc.Close();

                RenderTargetBitmap bitmap = new RenderTargetBitmap(190, 130, 96, 96, PixelFormats.Default);
                bitmap.Render(dv);
                bitmap.Freeze();

                return bitmap;
            } else
                return null;
        }

        /// <summary>
        /// 디렉토리 아이템의 썸네일 이미지를 가져옵니다.
        /// </summary>
        private ImageSource GetDirectoryImage(String path) {

            ImageSource emptyDirImage = Application.Current.Resources["FileDialog.EmptyDirectory"] as ImageSource;
            ImageSource dirImage = Application.Current.Resources["FileDialog.Directory"] as ImageSource;                        

            if (!Directory.Exists(path))
                return emptyDirImage;

            System.Collections.Generic.List<String> filteringFilePaths = new System.Collections.Generic.List<String>();
            try {
                // 필터링 될 파일의 경로만 수집
                foreach (String filePath in Directory.GetFiles(path, "*.*")) {

                    if (FilteringExtensions.Contains(Path.GetExtension(filePath).ToLower()))
                        filteringFilePaths.Add(filePath);
                }

            } catch (UnauthorizedAccessException) {
            }

            // 디렉토리에 필터링 대상 파일이 있을 경우에는 해당 파일의 썸네일 혹은 아이콘을 반환
            if (filteringFilePaths.Count == 0) {
                return emptyDirImage;
            } else {

                try {
                    DrawingVisual dv = new DrawingVisual();
                    DrawingContext dc = dv.RenderOpen();

                    ImageBrush ib1 = new ImageBrush(GetFileImage(filteringFilePaths[0], 190));
					if (ib1.ImageSource == null) {
						return emptyDirImage;
					}

                    ImageBrush ib2 = new ImageBrush(dirImage);
                    ib1.Stretch = Stretch.UniformToFill;
                    ib2.Stretch = Stretch.UniformToFill;

                    dc.PushTransform(new RotateTransform(5.0));
                    dc.DrawRectangle(ib1, null, new System.Windows.Rect(20, 0, 180, 120));
                    dc.Pop();
                    dc.DrawRectangle(ib2, null, new System.Windows.Rect(0, 0, 190, 130));

                    dc.Close();

                    RenderTargetBitmap bitmap = new RenderTargetBitmap(190, 130, 96, 96, PixelFormats.Default);
                    bitmap.Render(dv);
                    bitmap.Freeze();

                    return bitmap;
                } catch {
                    // 디렉토리 미리보기 이미지 생성 실패
                    return emptyDirImage;
                }
            }
        }

        /// <summary>
        /// 바로 가기 아이템의 썸네일 이미지를 가져옵니다.
        /// </summary>
        private ImageSource GetLnkFileImage(String path, String targetPath) {

            ImageSource baseImage = null;

            if (File.Exists(targetPath)) {
                baseImage = GetFileImage(targetPath, 190);
            } else if (Directory.Exists(targetPath)) {
                baseImage = GetDirectoryImage(targetPath);
            }

            DrawingVisual dv = new DrawingVisual();
            DrawingContext dc = dv.RenderOpen();

            // 기본 이미지 그리기
            ImageBrush ib = new ImageBrush(baseImage);
            ib.Stretch = Stretch.UniformToFill;
            dc.DrawRectangle(ib, null, new System.Windows.Rect(0, 0, 190, 130));

            // 파일일 경우 아이콘 그리기            
            System.Drawing.Icon sysIcon = System.Drawing.Icon.ExtractAssociatedIcon(path);
            BitmapSource iconImage = Imaging.CreateBitmapSourceFromHIcon(sysIcon.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            ImageBrush iconBrush = new ImageBrush(iconImage);
            ib.Stretch = Stretch.UniformToFill;
            dc.DrawRectangle(iconBrush, null, new System.Windows.Rect(12, 15, 32, 32));

            dc.Close();

            RenderTargetBitmap bitmap = new RenderTargetBitmap(190, 130, 96, 96, PixelFormats.Default);
            bitmap.Render(dv);
            bitmap.Freeze();

            return bitmap;
        }

        /// <summary>
        /// 그림 파일로부터 ImageSource를 추출합니다.
        /// </summary>
        private ImageSource GetImageSource(String path, int decodePixelWidth) {

            Debug.AssertThrow(!StringUtil.IsNullOrEmpty(path), eErrorCode.NullArgument);

            try {
                Uri uri = new Uri(path, UriKind.RelativeOrAbsolute);

                // 정상적인 이미지인지 체크
                BitmapFrame.Create(uri);

                BitmapImage bitmap = new BitmapImage();
                RenderOptions.SetCachingHint(bitmap, CachingHint.Cache);
                RenderOptions.SetBitmapScalingMode(bitmap, BitmapScalingMode.LowQuality);
                bitmap.BeginInit();
                {
                    bitmap.UriSource = new Uri(path, UriKind.RelativeOrAbsolute);
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.CreateOptions = BitmapCreateOptions.DelayCreation;
                    RenderOptions.SetEdgeMode(bitmap, EdgeMode.Aliased);

                    if (decodePixelWidth != 0)
                        bitmap.DecodePixelWidth = decodePixelWidth;
                }
                bitmap.EndInit();
                bitmap.Freeze();

                Debug.Assert(bitmap.Width != 0 && bitmap.Height != 0);

                return bitmap;

            } catch {

                // 디코딩할 수 없는 이미지
                return null;
            }
        }

        /// <summary>
        /// .lnk 파일이 연결된 파일 또는 디렉토리의 경로를 가져옵니다.
        /// </summary>        
        private String GetLnkTarget(String lnkPath) {

            Debug.Assert(".lnk".Equals(Path.GetExtension(lnkPath).ToLower()));

            try {
                Shell32.IShellDispatch shl = new Shell32.Shell();
                lnkPath = System.IO.Path.GetFullPath(lnkPath);
                Shell32.Folder dir = shl.NameSpace(System.IO.Path.GetDirectoryName(lnkPath));
                Shell32.FolderItem item = dir.Items().Item(System.IO.Path.GetFileName(lnkPath));
                Shell32.ShellLinkObject lnk = (Shell32.ShellLinkObject)item.GetLink;

                return lnk.Path;
            } catch (Exception e) {
                Debug.Assert(false, e.Message);
                return null;
            }            
        }

        private void SortList() {

            // 정렬시킬 아이템이 없을 경우 통과
            if (listItems.Count == 0)
                return;

            System.Collections.Generic.List<PhotoListBoxItem> sortedItems = null;

            // 아이템을 정렬하여 별도로 저장
            // - 날짜순 정렬
            if (sortListBox.SelectedIndex == 0) {
                sortedItems = new System.Collections.Generic.List<PhotoListBoxItem>(listItems.OrderByDescending(listItem => listItem.DateImageTaken));
            }
            // - 이름순 정렬
            else if (sortListBox.SelectedIndex == 1) {
                sortedItems = new System.Collections.Generic.List<PhotoListBoxItem>(listItems.OrderBy(listItem => listItem.ItemName));
            } 
            else {
                return;
            }

            bool isMoving = isMovingDirectory;
            isMovingDirectory = true;
            {
                // 디렉터리 > 파일순으로 구분하여 재배치
                listItems.Clear();
                foreach (PhotoListBoxItem item in sortedItems) {
                    if (Directory.Exists(item.Path)) {
                        listItems.Add(item);
                    }
                }

                foreach (PhotoListBoxItem item in sortedItems) {
                    if (!Directory.Exists(item.Path)) {
                        listItems.Add(item);

                        // 이미 선택중인 이미지의 경우 선택체크
                        if (FindByPath(selectedListBox.Items, item.Path) != -1) {

                            if (photoListBox.SelectionMode == SelectionMode.Single)
                                photoListBox.SelectedItem = item;
                            else
                                photoListBox.SelectedItems.Add(item);
                        }
                    }
                }
            }
            if (!isMoving) isMovingDirectory = false;            
        }

        /// <summary>
        /// List에 같은 경로를 가진 아이템이 있는지 검색하고 있다면 인덱스를 반환합니다.
        /// </summary>
        private int FindByPath(IList items, String path) {

            if (StringUtil.IsNullOrEmpty(path) || !File.Exists(path))
                return -1;

            if (items == null || items.Count == 0)
                return -1;

            int index = 0;
            foreach (PhotoListBoxItem item in items) {
                Debug.Assert(item != null);
                Debug.Assert(item.Path != null);

                if (item.Path.Equals(path))
                    return index;

                index++;
            }

            return -1;
        }

        private Bool IsValidName(String name) {

            Debug.Assert(!StringUtil.IsNullOrEmpty(name));

            foreach (char c in name) {
                foreach (char ic in Path.GetInvalidFileNameChars()) {
                    if (c == ic) {
                        return false;
                    }
                }
            }
            return true;
        }

        #endregion
    }

    // 특수 폴더 csidl
    public enum SpecialFolderCSIDL : int {
        CSIDL_DESKTOP = 0x0000,                 // <desktop>
        CSIDL_INTERNET = 0x0001,                // Internet Explorer (icon on desktop)
        CSIDL_PROGRAMS = 0x0002,                // Start Menu\Programs
        CSIDL_CONTROLS = 0x0003,                // My Computer\Control Panel
        CSIDL_PRINTERS = 0x0004,                // My Computer\Printers
        CSIDL_PERSONAL = 0x0005,                // My Documents
        CSIDL_FAVORITES = 0x0006,               // <user name>\Favorites
        CSIDL_STARTUP = 0x0007,                 // Start Menu\Programs\Startup
        CSIDL_RECENT = 0x0008,                  // <user name>\Recent
        CSIDL_SENDTO = 0x0009,                  // <user name>\SendTo
        CSIDL_BITBUCKET = 0x000a,               // <desktop>\Recycle Bin
        CSIDL_STARTMENU = 0x000b,               // <user name>\Start Menu
        CSIDL_MYMUSIC = 0x000d,                 // <user name>\MYMUSIC
        CSIDL_MYVIDEO = 0x000e,                 // <user name>\MYVIDEO
        CSIDL_DESKTOPDIRECTORY = 0x0010,        // <user name>\Desktop
        CSIDL_DRIVES = 0x0011,                  // My Computer
        CSIDL_NETWORK = 0x0012,                 // Network Neighborhood
        CSIDL_NETHOOD = 0x0013,                 // <user name>\nethood
        CSIDL_FONTS = 0x0014,                   // windows\fonts
        CSIDL_TEMPLATES = 0x0015,
        CSIDL_COMMON_STARTMENU = 0x0016,        // All Users\Start Menu
        CSIDL_COMMON_PROGRAMS = 0x0017,         // All Users\Programs
        CSIDL_COMMON_STARTUP = 0x0018,          // All Users\Startup
        CSIDL_COMMON_DESKTOPDIRECTORY = 0x0019, // All Users\Desktop
        CSIDL_APPDATA = 0x001a,                 // <user name>\Application Data
        CSIDL_PRINTHOOD = 0x001b,               // <user name>\PrintHood
        CSIDL_LOCAL_APPDATA = 0x001c,           // <user name>\Local Settings\Applicaiton Data (non roaming)
        CSIDL_ALTSTARTUP = 0x001d,              // non localized startup
        CSIDL_COMMON_ALTSTARTUP = 0x001e,       // non localized common startup
        CSIDL_COMMON_FAVORITES = 0x001f,
        CSIDL_INTERNET_CACHE = 0x0020,
        CSIDL_COOKIES = 0x0021,
        CSIDL_HISTORY = 0x0022,
        CSIDL_COMMON_APPDATA = 0x0023,          // All Users\Application Data
        CSIDL_WINDOWS = 0x0024,                 // GetWindowsDirectory()
        CSIDL_SYSTEM = 0x0025,                  // GetSystemDirectory()
        CSIDL_PROGRAM_FILES = 0x0026,           // C:\Program Files
        CSIDL_MYPICTURES = 0x0027,              // C:\Program Files\My Pictures
        CSIDL_PROFILE = 0x0028,                 // USERPROFILE
        CSIDL_SYSTEMX86 = 0x0029,               // x86 system directory on RISC
        CSIDL_PROGRAM_FILESX86 = 0x002a,        // x86 C:\Program Files on RISC
        CSIDL_PROGRAM_FILES_COMMON = 0x002b,    // C:\Program Files\Common
        CSIDL_PROGRAM_FILES_COMMONX86 = 0x002c, // x86 Program Files\Common on RISC
		CSIDL_COMMON_PICTURES = 0x0036,			// All Users\My Pictures
		CSIDL_COMMON_VIDEO = 0x0037,			// All Users\My Video
        CSIDL_COMMON_TEMPLATES = 0x002d,        // All Users\Templates
        CSIDL_COMMON_DOCUMENTS = 0x002e,        // All Users\Documents
        CSIDL_COMMON_ADMINTOOLS = 0x002f,       // All Users\Start Menu\Programs\Administrative Tools
        CSIDL_ADMINTOOLS = 0x0030,              // <user name>\Start Menu\Programs\Administrative Tools
        CSIDL_CONNECTIONS = 0x0031,             // Network and Dial-up Connections
    };

    // 특수 폴더 가져오기를 위한 클래스
    public static class SpecialFolder {

        [DllImport("shfolder.dll", CharSet = CharSet.Unicode)]
        private static extern int SHGetFolderPath(IntPtr owner, Int folder, IntPtr token, Int flags, StringBuilder path);

        // Environment.GetFolderPath(Environment.SpecialFolder.MyPictures); 등의 방법으로 폴더를 가져 올 수 있지만
        // Environment.SpecialFolder 에 MyVideo 등에 대한 폴더가 정의되어 있지 않아 다른 방법을 찾음
        public static string GetSpecialFolder(SpecialFolderCSIDL csidl) {
            StringBuilder path = new StringBuilder(260);
            int retval = SHGetFolderPath(IntPtr.Zero, (Int)csidl, IntPtr.Zero, 0, path);
            if (retval != 0) {
                return null;
            }
            return path.ToString();
        }
    }
}
