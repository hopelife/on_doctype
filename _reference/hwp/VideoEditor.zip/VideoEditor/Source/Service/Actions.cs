﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Service {
	using Bool = System.Boolean;
	using Int = System.Int32;
	using String = System.String;
	using Index = System.Int32;
	using Frame = System.Double;
	using Hnc.DataLogic;
	using Hnc.Type;
	using Hnc.VideoEditor.Engine;
	using Hnc.VideoEditor.Base.Type;

	public sealed class ActionChangeWindowModeMin : IAction {
		private ActionChangeWindowModeMin() {
		}

		public static ActionChangeWindowModeMin Create() {
			return new ActionChangeWindowModeMin();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			TransactionUtil.GetTransaction().ChangeWindowStateMin();
			return true;
		}
	}

	public sealed class ActionChangeWindowModeMax : IAction {
		private ActionChangeWindowModeMax() {
		}

		public static ActionChangeWindowModeMax Create() {
			return new ActionChangeWindowModeMax();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			TransactionUtil.GetTransaction().ChangeWindowStateMax();
			return true;
		}
	}

	public sealed class ActionChangeWindowModeNomal : IAction {
		private ActionChangeWindowModeNomal() {
		}

		public static ActionChangeWindowModeNomal Create() {
			return new ActionChangeWindowModeNomal();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			TransactionUtil.GetTransaction().ChangeWindowStateNomal();
			return true;
		}
	}

	public sealed class ActionClose : IAction {
		private ActionClose() {
		}

		public static ActionClose Create() {
			return new ActionClose();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			TransactionUtil.GetTransaction().Close();

			return true;
		}
	}

	public sealed class ActionUndo : IAction {
		private ActionUndo() {
		}

		public static ActionUndo Create() {
			return new ActionUndo();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			if (!UndoManager.Instance.IsEnableUndo) {
				return true;
			}

			UndoManager.Instance.Undo();

			return true;
		}
	}

	public sealed class ActionRedo : IAction {
		private ActionRedo() {
		}

		public static ActionRedo Create() {
			return new ActionRedo();
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			if (!UndoManager.Instance.IsEnableRedo) {
				return true;
			}

			UndoManager.Instance.Redo();

			return true;
		}
	}

	public sealed class ActionSave : IAction {
		String _filePath;

		private ActionSave() {
			_filePath = null;
		}

		private ActionSave(String filePath) {
			_filePath = filePath;
		}

		private static String CheckFilePath(String filePath) {
			String ext = ".xml";

			Int indexDot = filePath.LastIndexOf('.');

			if (indexDot != -1) {
				filePath = filePath.Remove(indexDot);
			}

			filePath += ext;
			return filePath;
		}

		public static ActionSave Create(String filePath) {
			filePath = ActionSave.CheckFilePath(filePath);
			return new ActionSave(filePath);
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			TransactionUtil.GetTransaction().SetSaveFileName(_filePath);
			return TransactionUtil.GetTransaction().Save();
		}
	}

	public sealed class ActionExportCancel : IAction {
		private ActionExportCancel() {
		}

		public static ActionExportCancel Create() {
			return new ActionExportCancel();
		}

		public Bool Execute() {
			int errorCode = TransactionUtil.GetTransaction().ExportCancel();

			if (errorCode == 1) {
				return true;
			}

			return false;
		}
	}

	public sealed class ActionExport : IAction {
		String _filePath;
		Int _width;
		Int _height;
		Int _frameRate;
		Int _videoCodec;
		Int _audioCodec;
		Int _errorCode = 1;

		private ActionExport() {
			_filePath = null;
			_width = 0;
			_height = 0;
			_frameRate = 0;
			_videoCodec = 0;
			_audioCodec = 0;
			_errorCode = 1;
		}

		private ActionExport(String filePath, Int width, Int height, Int frameRate, Int videoCodec, Int audioCodec) {
			_filePath = filePath;
			_width = width;
			_height = height;
			_frameRate = frameRate;
			_videoCodec = videoCodec;
			_audioCodec = audioCodec;
			_errorCode = 1;
		}

		public static ActionExport Create(String filePath, Int width, Int height, Int frameRate, Int videoCodec, Int audioCodec) {
			return new ActionExport(filePath, width, height, frameRate, videoCodec, audioCodec);
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			_errorCode = TransactionUtil.GetTransaction().Export(_filePath, _width, _height, _frameRate, _videoCodec, _audioCodec);

			if (_errorCode == 1) {
				return true;
			}

			Hnc.Instrument.VideoErrorCode.SetLastErrorCode(_errorCode);

			return false;
		}
	}

	public sealed class ActionCompareFilePath : IAction {
		String _filePath;

		private ActionCompareFilePath() {
			_filePath = null;
		}

		private ActionCompareFilePath(String filePath) {
			_filePath = filePath;
		}

		public static ActionCompareFilePath Create(String filePath) {
			return new ActionCompareFilePath(filePath);
		}

		public Bool Execute() {
			return TransactionUtil.GetTransaction().CompareFilePath(_filePath);
		}
	}

	public sealed class ActionLoad : IAction {
		String _filePath;

		private ActionLoad() {
			_filePath = null;
		}

		private ActionLoad(String filePath) {
			_filePath = filePath;
		}

		public static ActionLoad Create() {
			return new ActionLoad();
		}

		public static ActionLoad Create(String filePath) {
			return new ActionLoad(filePath);
		}

		public Bool Execute() {
#if DEBUG
			Debug.Assert(UndoManager.Instance != null);
#endif
			return TransactionUtil.GetTransaction().Load(_filePath);
		}
	}

	public sealed class ActionAddSubtitleInfo : IAction {
		private String _sentence;
		private Frame _frame;

		public ActionAddSubtitleInfo(String sentence, Frame frame) {
			_sentence = sentence;
			_frame = frame;
		}

		public Bool Execute() {
			UndoItem item = TransactionUtil.GetTransaction().AddSubtitleInfo(_sentence, _frame);
			UndoManager.Instance.Record(item, false);

			return true;
		}
	}

	public sealed class ActionAddVideoInfo : IAction {
		private String _filePath;
		private Frame _totalFrame;
		private FrameScope _videoScope;

		public ActionAddVideoInfo(String filePath, Frame totalFrame, FrameScope videoScope) {
			this._filePath = filePath;
			this._totalFrame = totalFrame;
			this._videoScope = videoScope;
		}

		public Bool CheckField() {
			if (_filePath == null) {
				return false;
			}

			if (_videoScope.CheckFrame() == false) {
				return false;
			}

			return true;
		}

		public Bool Execute() {
			if (CheckField() == false) {
				return false;
			}

			UndoItem item = TransactionUtil.GetTransaction().AddVideoInfo(_filePath, _totalFrame, _videoScope);
			if (item == null) {
				Debug.Assert(false, "AddVideoInfo Action AddVideoInfo가 실패하였습니다.");
				return false;
			}

			UndoManager.Instance.Record(item, false);

			return true;
		}
	}

	public sealed class ActionPropertyChangedInfo : IAction {
		System.Collections.Generic.List<TimelineInfo> _infoList = null;

		public ActionPropertyChangedInfo(System.Collections.Generic.List<TimelineInfo> infoList) {
			_infoList = infoList;
		}

		public ActionPropertyChangedInfo(TimelineInfo info) {
			_infoList = new System.Collections.Generic.List<TimelineInfo>();
			_infoList.Add(info);
		}

		public Bool Execute() {
			if (_infoList.Count != 0) {
				GroupUndoItem groupUndoItem = GroupUndoItem.Create();
				foreach (TimelineInfo info in _infoList) {
					UndoItem item = TransactionUtil.GetTransaction().PropertyChangedInfo(info);

					if (item != null) {
						groupUndoItem.Collection.Add(item);
					}
				}
				UndoManager.Instance.Record(groupUndoItem, false);
			}
			return true;
		}
	}

	public sealed class ActionSortInfo : IAction {
		public System.Collections.Generic.List<TimelineInfo> _infoList = null;

		private ActionSortInfo() {
		}

		public static ActionSortInfo Create() {
			return new ActionSortInfo();
		}

		public Bool Execute() {
			_infoList = TransactionUtil.GetTransaction().SortInfo();
			return true;
		}
	}

	public sealed class ActionRenameInfo : IAction {
		String _oldFilePath = null;
		String _newFilePath = null;

		private ActionRenameInfo(String oldFilePath, String newFilePath) {
			_oldFilePath = oldFilePath;
			_newFilePath = newFilePath;
		}

		public static ActionRenameInfo Create(String oldFilePath, String newFilePath) {
			return new ActionRenameInfo(oldFilePath, newFilePath);
		}

		public Bool Execute() {
			TransactionUtil.GetTransaction().ChangingFilePathInfo(_oldFilePath, _newFilePath);
			return true;
		}
	}

	public sealed class ActionRemoveInfo : IAction {
		private static readonly Index NON_SELECTED_INFO = -1;
		Index _id = NON_SELECTED_INFO;
		String _filePath = null;

		private ActionRemoveInfo(Index id) {
			_id = id;
			_filePath = null;
		}

		private ActionRemoveInfo(String filePath) {
			_id = NON_SELECTED_INFO;
			_filePath = filePath;
		}

		public static ActionRemoveInfo Create(Index id) {
			return new ActionRemoveInfo(id);
		}

		public static ActionRemoveInfo Create(String filePath) {
			return new ActionRemoveInfo(filePath);
		}

		public Bool Execute() {
			if (_id <= NON_SELECTED_INFO && _filePath == null) {
				Hnc.Type.Debug.Assert(false, "ActionRemoveInfo 멤버 변수가 이상합니다.\n");
				return false;
			}

			if (_id > NON_SELECTED_INFO) {
				UndoItem item = TransactionUtil.GetTransaction().RemoveInfo(_id);
				UndoManager.Instance.Record(item, false);
			} else if (_filePath != null) {
				UndoItem item = TransactionUtil.GetTransaction().RemoveInfo(_filePath);
				UndoManager.Instance.Record(item, false);
			} else {
				Hnc.Type.Debug.Assert(false, "ActionRemoveInfo 멤버 변수가 이상합니다.\n");
				return false;
			}

			return true;
		}
	}

	public sealed class ActionSortRemoveInfo : IAction {
		private static readonly Index NON_SELECTED_INFO = -1;
		private System.Collections.Generic.List<TimelineInfo> _infoList = null;
		Index _id = NON_SELECTED_INFO;
		String _filePath = null;

		private ActionSortRemoveInfo(Index id) {
			_id = id;
			_filePath = null;
		}

		private ActionSortRemoveInfo(String filePath) {
			_id = NON_SELECTED_INFO;
			_filePath = filePath;
		}

		public static ActionSortRemoveInfo Create(Index id) {
			return new ActionSortRemoveInfo(id);
		}

		public static ActionSortRemoveInfo Create(String filePath) {
			return new ActionSortRemoveInfo(filePath);
		}

		public Bool Execute() {
			if (_id <= NON_SELECTED_INFO && _filePath == null) {
				Hnc.Type.Debug.Assert(false, "ActionRemoveInfo 멤버 변수가 이상합니다.\n");
				return false;
			}

			if (_id > NON_SELECTED_INFO) {
				GroupUndoItem groupUndoItem = GroupUndoItem.Create();

				UndoItem itemRemove = TransactionUtil.GetTransaction().RemoveInfo(_id);

				if (itemRemove != null) {
					groupUndoItem.Collection.Add(itemRemove);

					_infoList = TransactionUtil.GetTransaction().SortInfo();
					if (_infoList.Count != 0) {
						foreach (TimelineInfo info in _infoList) {

							UndoItem itemSort = TransactionUtil.GetTransaction().PropertyChangedInfo(info);

							if (itemSort != null) {
								groupUndoItem.Collection.Add(itemSort);
							}
						}
					}
					UndoManager.Instance.Record(groupUndoItem, false);
				}
			} else {
				Hnc.Type.Debug.Assert(false, "ActionRemoveInfo 멤버 변수가 이상합니다.\n");
				return false;
			}

			return true;
		}
	}
}