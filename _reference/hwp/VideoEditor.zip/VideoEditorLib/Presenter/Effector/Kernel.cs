﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;

using Float = System.Single;
using Count = System.Int32;

namespace Hnc.Presenter.ImageEffect {
    public class Kernel {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Count RowCount { get; private set; }
        public Count ColCount { get; private set; }
        
        public Float[] M; // 참조 속도 향상을 위해 직접 액세스
        //public Float[] M {
        //    get {
        //        Debug.Assert(m != null);
        //        return m;
        //    }
        //    private set {
        //        Debug.AssertThrow(value != null, eErrorCode.NullArgument);
        //        m = value;
        //    }
        //}
        
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Kernel(Count row, Count col, Float[] m) {
            Debug.AssertThrow(row * col == m.Length, eErrorCode.InvalidArgument);

            RowCount = row;
            ColCount = col;
            M = m;
        }
        public static Kernel Create(Count row, Count col, Float[] m) {
            return new Kernel(row, col, m);
        }
    }

    // 1차원 커널
    public class Kernel1D {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Float[] M; // 참조 속도 향상을 위해 직접 액세스
        //public Float[] M {
        //    get {
        //        Debug.Assert(m != null);
        //        return m;
        //    }
        //    private set {
        //        Debug.AssertThrow(value != null, eErrorCode.NullArgument);
        //        m = value;
        //    }
        //}

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Kernel1D(Float[] m) {
            Debug.Assert(m != null);

              M = m;
        }
        public static Kernel1D Create(Float[] m) {
            return new Kernel1D(m);
        }
    }
}
