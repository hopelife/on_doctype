﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;


namespace Hnc.Presenter.ImageEffect {

    // 물속에 있는듯 하게 왜곡한다.
    public class Swim : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Ratio scale = 200; // 변경의 조밀 정도
        private Ratio stretch = 1;
        private Ratio amount = 20; // 변위 정도
        private Float turbulence = 1;
        private Float time = 0; // turbulence가 1인 경우 perlin3D 노이즈 사용
        private Float m00 = 1;
        private Float m01 = 0;
        private Float m10 = 0;
        private Float m11 = 1;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Swim(Ratio scale, Ratio stretch, Ratio amount, Float turbulence, Float time, Float degree)
            : base() {

            this.scale = MathUtil.Clamp(scale, 1, 300);
            this.stretch = MathUtil.Clamp(stretch, 1, 50);
            this.amount = MathUtil.Clamp(amount, 0, 100);
            this.turbulence = MathUtil.Clamp(turbulence, 0, 1);
            this.time = time;

            this.m00 = MathUtil.Cos(MathUtil.ToRadian(degree));
            this.m01 = MathUtil.Sin(MathUtil.ToRadian(degree));
            this.m10 = -MathUtil.Sin(MathUtil.ToRadian(degree));
            this.m11 = MathUtil.Cos(MathUtil.ToRadian(degree));


        }
        public static Swim Create(Ratio scale, Ratio stretch, Ratio amount, Float turbulence, Float time, Float degree) {
            return new Swim(scale, stretch, amount, turbulence, time, degree);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {

		    Float nx = m00 * targetX + m01 * targetY;
		    Float ny = m10 * targetX + m11 * targetY;
		    nx /= scale;
		    ny /= scale * stretch;

		    if (turbulence == 1) {
			    originX = targetX + amount * Noise.Perlin3D(nx, ny, time);
                originY = targetY + amount * Noise.Perlin3D(nx, ny, time);
		    } else {
			    originX = targetX + amount * Noise.Turbulence3(nx, ny, turbulence, time);
                originY = targetY + amount * Noise.Turbulence3(nx, ny, turbulence, time);
		    }


        }
        #endregion

 
    }
}
