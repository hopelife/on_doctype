﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Bool = System.Boolean;
using String = System.String;


namespace Hnc.DataLogic {
    // Pixels의 크기를 바꾼다. 
    // System 의존적이므로 Service 레이어에서 구현한다.
    public interface PixelsResizer {
        // source를 targetSize 크기로 변경함
        // View관련 처리에 대한 종속성을 없애기위해 interface화함. 
        // Action 단에서 실제로 구현하여 전달할 것
        // 변경하려는 크기와 source가 동일하면 source를 리턴
        // 오류발생시 null이 리턴될 수 있음
        Pixels Resize(Pixels source, Size targetSize);
    }

    // 픽셀의 주어진 영역을 Crop한다.
    public interface PixelsCropper {
        // source가 angle 만큼 회전된 상태에서 rect 영역을 crop한다.
        // rect는 sourceRect의 inset 영역임
        Pixels Crop(Pixels source, OffsetRect rect, Degree angle);
    }

    // 주어진 stream으로부터 pixels를 로딩
    public interface PixelsLoader {
        // stream이 null 이면 null 이 리턴될 수 있다.
        Pixels Load(Stream stream);
    }

    // 주어진 Pixels으로부터 저장
    public interface PixelsSaver {
        
        // pixels가 null이거나 저장에 실패하면 false
        Bool Save(Pixels pixels, String metaTag);
    }
}
