﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using Float = System.Single;
using Pixel = System.UInt32;
using Byte = System.Byte;

namespace Hnc.Type {

    // 픽셀당 32비트 brga(WPF에 맞춤) 로 데이터를 관리하는 자료구조체
    public sealed class Pixels : System.IDisposable {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        // AARRGGBB 의 배열
        public Pixel[] Data; // 참조 속도 향상을 위해 직접 액세스
        //public Pixel[] Data {
        //    get {
        //        Debug.Assert(data != null);
        //        return data;
        //    }
        //    private set { data = value; }
        //}

        private Int width;
        public Int Width { 
            get { return width; }
            private set { width = value; }
        }

        private Int height;
        public Int Height {
            get { return height; }
            private set { height = value; }
        }

        private Float widthDpi;
        public Float WidthDpi { 
            get { return widthDpi; }
            private set { widthDpi = value; }
        }

        private Float heightDpi;
        public Float HeightDpi { 
            get { return heightDpi; }
            private set { heightDpi = value; }

        }

        // width의 byte 수
        public Int Stride {
            get {
                return Width * 4;
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Pixels(Pixel[] data, Int width, Int height, Float widthDpi, Float heightDpi) {
            Assign(data, width, height, widthDpi, heightDpi);
        }
        private Pixels(Pixels other) {
            Debug.AssertThrow(other != null, eErrorCode.NullArgument);
            Debug.Assert(other.Data != null);

            Data = new Pixel[other.Data.Length];
            other.Data.CopyTo(this.Data, 0);
            
            Width = other.width;
            Height = other.height;
            WidthDpi = other.widthDpi;
            HeightDpi = other.heightDpi;
        }

        public static Pixels Create(Pixel[] data, Int width, Int height, Float widthDpi, Float heightDpi) {
            return new Pixels(data, width, height, widthDpi, heightDpi);
        }

        public Pixels Clone() {
            return new Pixels(this);
        }
        private void Assign(Pixel[] data, Int width, Int height, Float widthDpi, Float heightDpi) {
            Debug.AssertThrow(data != null, eErrorCode.NullArgument);
            Debug.AssertThrow(data.Length == width * height, eErrorCode.InvalidArgument);
            Debug.AssertThrow(0 < width, eErrorCode.InvalidArgument);
            Debug.AssertThrow(0 < height, eErrorCode.InvalidArgument);
            Debug.AssertThrow(0 <= widthDpi, eErrorCode.InvalidArgument);
            Debug.AssertThrow(0 <= heightDpi, eErrorCode.InvalidArgument);

            Data = data;
            Width = width;
            Height = height;
            WidthDpi = widthDpi;
            HeightDpi = heightDpi;
        }
        
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region IDisposable 구현
        void System.IDisposable.Dispose() {
            if (Data != null) {

                Data = null; //!! 더이상 참조하지 않으면 소멸한다고 해서 null 대입. 정말 소멸되나 확인해야 함
            }
        }
        #endregion


        // AARRGGBB
        public static Byte GetA(Pixel pixel) {
            return (Byte)((pixel >> 24) & 0xFF);
        }
        public static Byte GetR(Pixel pixel) {
            return (Byte)((pixel >> 16) & 0xFF);
        }
        public static Byte GetG(Pixel pixel) {
            return (Byte)((pixel >> 8) & 0xFF);
        }
        public static Byte GetB(Pixel pixel) {
            return (Byte)((pixel) & 0xFF);
        }
        public static Pixel ToPixel(Byte a, Byte r, Byte g, Byte b) {
            return (Pixel)((a << 24) | (r << 16) | (g << 8) | b);
        }

    }
}
        
        
 