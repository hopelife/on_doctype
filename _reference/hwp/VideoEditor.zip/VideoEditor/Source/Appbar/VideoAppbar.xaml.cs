﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Index = System.Int32;
using Grid = System.Windows.Controls.Grid;
using Image = System.Windows.Controls.Image;
using BitmapSource = System.Windows.Media.Imaging.BitmapSource;

using Hnc.Type;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Service;

namespace Hnc.VideoEditor.Appbar {
    // ----------------------------------------------
    // 비디오 설정 창
    // ----------------------------------------------
    public partial class VideoAppbar : Grid {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        #region 속성
        private static readonly Index NonSelectedInfo = -1;
        private Index _selectedInfoID = NonSelectedInfo;
        private TimelineInfo _selectedInfo = null;
        #endregion

        // ----------------------------------------------
        // 프로퍼티
        // ----------------------------------------------
        #region 프로퍼티        
        public Index SelectedInfoID {
            get { return _selectedInfoID; }
            set {_selectedInfoID = value;}
        }
  
        public TimelineInfo SelectedInfo {
            get { return _selectedInfo; }
            set {
                if (value != null) {
                    _selectedInfo = value.Clone();
                } else {
                    _selectedInfo = null;
                }
                ChangeCotrolState();
            }
        }
        #endregion

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        #region 생성자
        public VideoAppbar() {
            InitializeComponent();

            _selectedInfoID = NonSelectedInfo;
            _selectedInfo = null;
            /*
            // gray
            {
                Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(grayImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Grayscale.Create().Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                grayImage.Source = source;
            }

            // sepia
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(sepiaImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0xF5, 0xE5, 0xD0)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                sepiaImage.Source = source;
            }

            // red
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(redImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0xFF, 0x00, 0x00)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                redImage.Source = source;   
            }
            
            // green
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(greenImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0xFF, 0x00)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                greenImage.Source = source;
            }

            // blue
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(blueImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0xFF)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                blueImage.Source = source;
            }

            // yellow
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(yellowImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0xFF, 0xFF, 0x00)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                yellowImage.Source = source;
            }

            // orange
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(orangeImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.Duotone.Create(
                        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
                        Hnc.Type.Pixels.ToPixel(255, 0xFF, 0x80, 0x00)
                ).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                orangeImage.Source = source;
            }
            */

            /*
            // violet
            {
                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(violetImage.Source as BitmapSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.BrightnessContrast.Create
                    (Hnc.Util.MathUtil.Clamp(0.0F, -1.0F, 1.0F), 
                    Hnc.Util.MathUtil.Clamp(-1.0F, -1.0F, 1.0F)).Apply(channel);



                pixels.Data = channel.ToPixels();
                BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                violetImage.Source = source;
            }
            */

            /*
Hnc.Presenter.ImageEffect.Duotone.Create(
        Hnc.Type.Pixels.ToPixel(255, 0x00, 0x00, 0x00),
        Hnc.Type.Pixels.ToPixel(255, 0xFF, 0x00, 0xFF)
).Apply(channel);
*/

        }
        #endregion

        // ----------------------------------------------
        // 메소드
        // ----------------------------------------------
        #region 메소드

        private void ApplyEffectGrayscale(Image originalImage, Image effectImage) {
            Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(originalImage.Source as BitmapSource);
            Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

            Hnc.Presenter.ImageEffect.Grayscale.Create().Apply(channel);

            pixels.Data = channel.ToPixels();
            BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
            effectImage.Source = source;
        }

        private void ApplyEffectDuotone(Image originalImage, Image effectImage, 
                                            byte darkA, byte darkR, byte darkG, byte darkB, 
                                            byte brightA, byte brightR, byte brightG, byte brightB) {
            Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(originalImage.Source as BitmapSource);
            Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

            Hnc.Presenter.ImageEffect.Duotone.Create(
                    Hnc.Type.Pixels.ToPixel(darkA, darkR, darkG, darkB),
                    Hnc.Type.Pixels.ToPixel(brightA, brightR, brightG, brightB)
            ).Apply(channel);

            pixels.Data = channel.ToPixels();
            BitmapSource source = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
            effectImage.Source = source;
        }
        

        private void ChangeCotrolState() {

            if (_selectedInfo == null) {
                /*
                originalImage.IsEnabled = false;
                grayImage.IsEnabled = false;
                sepiaImage.IsEnabled = false; 
                redImage.IsEnabled = false;
                greenImage.IsEnabled = false;
                blueImage.IsEnabled = false;
                yellowImage.IsEnabled = false;
                violetImage.IsEnabled = false;
                orangeImage.IsEnabled = false;
                violet2Image.IsEnabled = false;

                Brightness.IsEnabled = false;
                Contrast.IsEnabled = false;
                */
                originalImage.Visibility = System.Windows.Visibility.Hidden;
                grayImage.Visibility = System.Windows.Visibility.Hidden;
                sepiaImage.Visibility = System.Windows.Visibility.Hidden;
                redImage.Visibility = System.Windows.Visibility.Hidden;
                greenImage.Visibility = System.Windows.Visibility.Hidden;
                blueImage.Visibility = System.Windows.Visibility.Hidden;
                yellowImage.Visibility = System.Windows.Visibility.Hidden;
                violetImage.Visibility = System.Windows.Visibility.Hidden;
                orangeImage.Visibility = System.Windows.Visibility.Hidden;

                Brightness.Visibility = System.Windows.Visibility.Hidden;
                Contrast.Visibility = System.Windows.Visibility.Hidden;

                BackButton.Visibility = System.Windows.Visibility.Hidden;
            } else {
                /*
                originalImage.IsEnabled = true;
                grayImage.IsEnabled = true;
                sepiaImage.IsEnabled = true;
                redImage.IsEnabled = true;
                greenImage.IsEnabled = true;
                blueImage.IsEnabled = true;
                yellowImage.IsEnabled = true;
                violetImage.IsEnabled = true;
                orangeImage.IsEnabled = true;
                violet2Image.IsEnabled = true;

                Brightness.IsEnabled = true;
                Contrast.IsEnabled = true;
                */

                VideoInfo info = _selectedInfo as VideoInfo;

                if (info != null) {

                    Image image = info.ThumbnailImage;

                    if (image != null) {
                        originalImage.Source = image.Source;
                        ApplyEffectGrayscale(image, grayImage);
                        ApplyEffectDuotone(image, sepiaImage, 255, 0x00, 0x00, 0x00, 255, 0xF5, 0xE5, 0xD0);
                        ApplyEffectDuotone(image, redImage, 255, 0x00, 0x00, 0x00, 255, 0xFF, 0x00, 0x00);
                        ApplyEffectDuotone(image, greenImage, 255, 0x00, 0x00, 0x00, 255, 0x00, 0xFF, 0x00);
                        ApplyEffectDuotone(image, blueImage, 255, 0x00, 0x00, 0x00, 255, 0x00, 0x00, 0xFF);
                        ApplyEffectDuotone(image, yellowImage, 255, 0x00, 0x00, 0x00, 255, 0xFF, 0xFF, 0x00);
                        ApplyEffectDuotone(image, orangeImage, 255, 0x00, 0x00, 0x00, 255, 0xFF, 0x80, 0x00);                        
                    }

                    originalImage.Visibility = System.Windows.Visibility.Visible;
                    grayImage.Visibility = System.Windows.Visibility.Visible;
                    sepiaImage.Visibility = System.Windows.Visibility.Visible;
                    redImage.Visibility = System.Windows.Visibility.Visible;
                    greenImage.Visibility = System.Windows.Visibility.Visible;
                    blueImage.Visibility = System.Windows.Visibility.Visible;
                    yellowImage.Visibility = System.Windows.Visibility.Visible;
                    violetImage.Visibility = System.Windows.Visibility.Visible;
                    orangeImage.Visibility = System.Windows.Visibility.Visible;

                    Brightness.Visibility = System.Windows.Visibility.Visible;
                    Contrast.Visibility = System.Windows.Visibility.Visible;

                    BackButton.Visibility = System.Windows.Visibility.Visible;
                }
            }
        }

        private void Click_VideoInfoDelete(object sender, System.Windows.RoutedEventArgs e) {
            if (_selectedInfo != null) {
                ActionRemoveInfo action = ActionRemoveInfo.Create(_selectedInfo.ID);

                if (ActionManager.Instance.Excute(action) == true) {
                }
            }
        }
        #endregion

        private void BrightnessValueChanged(object sender, System.Windows.RoutedPropertyChangedEventArgs<double> e) {
            double newValue = e.NewValue;
            double brightnessValue = newValue / 100.0;
            double contrastValue = Contrast.Value / 100.0;

            // violet
            {
                BitmapSource originalSource = (originalImage.Source as BitmapSource).Clone();

                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(originalSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.BrightnessContrast.Create
                    (Hnc.Util.MathUtil.Clamp((float)contrastValue, -1.0F, 1.0F),
                    Hnc.Util.MathUtil.Clamp((float)brightnessValue, -1.0F, 1.0F)).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource resultSource = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                violetImage.Source = resultSource;
            }
        }

        private void ContrastValueChanged(object sender, System.Windows.RoutedPropertyChangedEventArgs<double> e) {
            double newValue = e.NewValue;

            double contrastValue = newValue / 100.0;

            double brightnessValue = Brightness.Value / 100.0;

            {
                BitmapSource originalSource = (originalImage.Source as BitmapSource).Clone();

                Hnc.Type.Pixels pixels = Hnc.Presenter.PixelsUtil.BitmapSourceToPixels(originalSource);
                Hnc.Presenter.ImageEffect.ArgbChannel channel = Hnc.Presenter.ImageEffect.ArgbChannel.Create(pixels);

                Hnc.Presenter.ImageEffect.BrightnessContrast.Create
                    (Hnc.Util.MathUtil.Clamp((float)contrastValue, -1.0F, 1.0F),
                    Hnc.Util.MathUtil.Clamp((float)brightnessValue, -1.0F, 1.0F)).Apply(channel);

                pixels.Data = channel.ToPixels();
                BitmapSource resultSource = Hnc.Presenter.PixelsUtil.PixelsToBitmapSource(pixels);
                violetImage.Source = resultSource;
            }
        }
    }
}
