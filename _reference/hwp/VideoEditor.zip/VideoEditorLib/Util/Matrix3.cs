﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Float = System.Single;
using Int = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Util {
    public sealed class Matrix3 {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Float[,] a = new Float[,] { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };
        public Float[,] A { 
            get {
                Debug.Assert(a != null);
                return a;
            }
        }

        // 단위행렬인지의 여부
        public Bool Identity {
            get {
                Debug.Assert(A != null);

                return
                    (A[0, 0] == 1 && A[0, 1] == 0 && A[0, 2] == 0) &&
                    (A[1, 0] == 0 && A[1, 1] == 1 && A[1, 2] == 0) &&
                    (A[2, 0] == 0 && A[2, 1] == 0 && A[2, 2] == 1);
            }
        }
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Matrix3() { 
        }
        public static Matrix3 Create() {
            return new Matrix3();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
	    // this = left  * this
	    public void PreMultiply(Matrix3 left)
	    {
		    Float[,] t = new Float[,] { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };
		    Int i;

		    for (i = 0; i < 3; i++) {
			    t[i, 0] = left.A[i, 0] * A[0, 0] + left.A[i, 1] * A[1, 0] + left.A[i, 2] * A[2, 0];
			    t[i, 1] = left.A[i, 0] * A[0, 1] + left.A[i, 1] * A[1, 1] + left.A[i, 2] * A[2, 1];
			    t[i, 2] = left.A[i, 0] * A[0, 2] + left.A[i, 1] * A[1, 2] + left.A[i, 2] * A[2, 2];
		    }

		    for (i = 0; i < 3; i++) {
			    A[i, 0] = t[i, 0];
			    A[i, 1] = t[i, 1];
			    A[i, 2] = t[i, 2];
		    }
	    }
        // 3열짜리 데이터를 곱한 xyz를 구한다. this * (a, b, c)
        public void Mutiply (ref Float x, ref Float y, ref Float z, Float a, Float b, Float c) {

            x = A[0, 0] * a + A[0, 1] * b + A[0, 2] * c;
            y = A[1, 0] * a + A[1, 1] * b + A[1, 2] * c;
            z = A[2, 0] * a + A[2, 1] * b + A[2, 2] * c;

        }







    }
}
