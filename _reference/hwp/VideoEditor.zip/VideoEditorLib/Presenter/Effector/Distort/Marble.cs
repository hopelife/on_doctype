﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;


namespace Hnc.Presenter.ImageEffect {

    // 마블링 효과를 준다. 그림위에 랜덤으로 픽셀을 이동시켜 마치 울퉁불퉁한 유리를 통해 보는 듯한 느낌을 준다.
    public class Marble : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        // 난류. 난기류
        private Ratio Turbulence { get; set; }
        private Count Offset { get; set; }

        Float[] SinTable = new Float[256];
        Float[] CosTable = new Float[256];


        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // Turbulence : 난기류 정도. 1이 적절 0 ~ 1
        // offset 15 정도가 적절. 픽셀 왜곡의 노이즈 변위
        private Marble(Ratio turbulance, Count offset)
            : base() {
            Turbulence = MathUtil.Clamp(turbulance, 0, 1);
            Offset = offset;

            Float angle;

            for (Int i = 0; i < 256; ++i) {
                angle = MathUtil.TWO_PI * i / 256F * Turbulence;
                SinTable[i] = (Float)(-Offset * MathUtil.Sin(angle));
                CosTable[i] = (Float)(Offset * MathUtil.Cos(angle));
            }
        }
        public static Marble Create(Ratio turbulance, Count offset) {
            return new Marble(turbulance, offset);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {
            Int displacement = DisplacementMap(targetX, targetY);

            originX = targetX + SinTable[displacement];
            originY = targetY + CosTable[displacement];
        }
        #endregion


        private Int DisplacementMap(Int x, Int y) {
            Debug.Assert(Offset != 0);

            return MathUtil.Clamp((Int)(127 * (1 + Noise.Perlin2D((Float)x / Offset, (Float)y / Offset))), 0, 255);
            //return MathUtil.Clamp((Int)(127 * (1 + random2.Next(0, 127) / 127.0F)), 0, 255);
            //  return random2.Next(0, 255);
            //return (Int)MathUtil.Clamp(noise2(x / Offset, y / Offset) * 255, 0, 255);
        }
    }
}
