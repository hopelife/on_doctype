﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Int = System.Int32;
using Byte = System.Byte;

namespace Hnc.Presenter.ImageEffect {

    // 히스토그램에서 상위 5%, 하위 5% low - high 을 strectch하여 level을 재구성한다.
    public class AutoWhiteBalance {

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private AutoWhiteBalance() {

        }

        public static AutoWhiteBalance Create() {
            return new AutoWhiteBalance();
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Histogram histogram = Histogram.Create(pixels);

            // 상위/하위 5% 를 제외한 후 Stretch하여 많이 사용하지 않는 부분은 제거하여 색보정을 한다.
            LookupTable rTable = histogram.Red.Stretch(histogram.Red.Left(0.005F), histogram.Red.Right(0.005F));
            LookupTable gTable = histogram.Green.Stretch(histogram.Green.Left(0.005F), histogram.Green.Right(0.005F));
            LookupTable bTable = histogram.Blue.Stretch(histogram.Blue.Left(0.005F), histogram.Blue.Right(0.005F));

            for (Index i = 0; i < pixels.R.Length; ++i) {

                pixels.R[i] = rTable.Data[pixels.R[i]];
                pixels.G[i] = gTable.Data[pixels.G[i]];
                pixels.B[i] = bTable.Data[pixels.B[i]];

            }
        }

    }
}