#include "gdevwmf.h"
#include "gdevwmf_.h"

extern const gx_device_color_type_t gx_dc_pattern2;

int wmf_fill_path(gx_device *dev, const gs_imager_state *pis, gx_path *ppath, const gx_fill_params *params,
				  const gx_drawing_color *pdcolor, const gx_clip_path *pcpath)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	COLORREF crColor;
	int nPenWidth;
    gs_path_enum penum, pcenum;
	BOOL bClosed = FALSE;
	BOOL bOverflow = FALSE;
	int nThickness = (int)floor(fixed2float((params->adjust.x + params->adjust.y) / 2));

#if defined(_DEBUG) || defined(DEBUG)
	jTRACE( "---> %s %d \n", __FUNCTION__, wdev->nItems );

	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_fill_path()======================================high\n");
		if (pdcolor) {
			if (pdcolor->type == gx_dc_type_pure)
				fprintf(wdev->pFile, "pure color : %08X\n", pdcolor->colors.pure);
			else if (pdcolor->type == gx_dc_type_ht_binary)
				fprintf(wdev->pFile, "ht binary : check\n");
			else if (pdcolor->type == gx_dc_type_ht_colored)
				fprintf(wdev->pFile, "ht colored : check\n");
			else if (pdcolor->type == gx_dc_type_pattern)
				fprintf(wdev->pFile, "pattern colored : check\n");
			else if (pdcolor->type == &gx_dc_pattern2) {
				gs_pattern2_instance_t *pinst = (gs_pattern2_instance_t *)pdcolor->ccolor.pattern;
				fprintf(wdev->pFile, "pattern2 colored : %d   check\n", pinst->template.Shading->head.type);
			}
			else
				fprintf(wdev->pFile, "none color : check\n");
		}
		if (params->rule == gx_rule_winding_number)
			fprintf(wdev->pFile, "rule : winding number\n");
		else
			fprintf(wdev->pFile, "rule : even odd\n");
		fprintf(wdev->pFile, "flatness : %10.3f\n", params->flatness);
		fprintf(wdev->pFile, "fill adjust : (%d, %d)\n", params->adjust.x, params->adjust.y);
		//!!!
		fprintf(wdev->pFile, "fill zero width : %d\n", params->fill_zero_width);
		//!!!
		fprintf(wdev->pFile, "line width : %d\n", (int)(pis->line_params.half_width * 2));
	}
#endif // _DEBUG

	if (!wdev || !wdev->hdc)
		return 0;
	if (!wdev->bRecord)
		return 0;

	// Shading �� ���� ����Ʈ ó�� �Լ��� ȣ���Ѵ�.
	if (gx_dc_is_pattern2_color(pdcolor)) {
		int code;
		WmfSetClipPathFromPath(dev, ppath, RGN_COPY);
		WmfSetClipPath(dev, pcpath, RGN_AND);
		wdev->bShading = TRUE;

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "Shading Start ======================\n");
#endif // _DEBUG

		code = gx_default_fill_path(dev, pis, ppath, params, pdcolor, pcpath);

#if defined(_DEBUG) || defined(DEBUG)
		if (wdev->pFile)
			fprintf(wdev->pFile, "Shading End ======================\n");
#endif // _DEBUG

		wdev->bShading = FALSE;
		return code;
	}

	// ��, �귯�� ����
	crColor = MakeColorRef(pdcolor->colors.pure);

	if (params->fill_zero_width && nThickness >= 1)
		wmf_change_pen(dev, nThickness, crColor);
	else
		wmf_change_pen(dev, (int)(pis->line_params.half_width * 2), crColor);
	
	wmf_change_brush(dev, BS_SOLID, crColor, HS_CROSS);
	
	// Ŭ���� ���� ����
	if (!wdev->bShading)
		WmfSetClipPath(dev, pcpath, RGN_COPY);

	// �н��� Iterating �ϸ鼭 ������ ��ҵ��� ��ȯ
    gx_path_enum_init(&penum, ppath);

#ifdef _USE_POLYGON
	// Curve �� ������, Polygon ���� �����ؼ� ũ�⸦ ���δ�.
	if (ppath->curve_count == 0) {
		gs_fixed_point pts[3];
		POINT pt[256];
		int nCount = 0;
	    gx_path_enum_init(&penum, ppath);

		for (;;) {
			// ����Ʈ�� ������ ���۸� �ʰ��ϸ� Path �� ó���Ѵ�.
			if (nCount > 255) {
				bOverflow = TRUE;

#if defined(_DEBUG) || defined(DEBUG)
//                jTRACE( "\tPoints overflow!!!\n" );
#endif // _DEBUG
				break;
			}
			switch (gx_path_enum_next(&penum, pts)) {
				case gs_pe_moveto:
					if (nCount > 0) {
						Polygon(wdev->hdc, pt, nCount);

#if defined(_DEBUG) || defined(DEBUG)
//                        jTRACE( "\t polygon( %d )\n", nCount ); 
#endif // _DEBUG
						nCount = 0;
					}
					pt[nCount].x = ftoi(pts[0].x);
					pt[nCount].y = ftoi(pts[0].y);
					nCount++;

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t moveto( %d, %d )\n",  pt[ nCount ].x, pt[ nCount ].y );
#endif // _DEBUG
					continue;
				case gs_pe_lineto:
					pt[nCount].x = ftoi(pts[0].x);
					pt[nCount].y = ftoi(pts[0].y);
					nCount++;

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t lineto( %d, %d )\n",  pt[ nCount ].x, pt[ nCount ].y );
#endif // _DEBUG
					continue;
				case gs_pe_curveto:

#if defined(_DEBUG) || defined(DEBUG)
                    jTRACE( "\t gs_pe_curveto\n" );
#endif // _DEBUG
					continue;
				case gs_pe_closepath:
					pt[nCount].x = ftoi(pts[0].x);
					pt[nCount].y = ftoi(pts[0].y);
					nCount++;

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t closepath( %d, %d )\n",  pt[ nCount ].x, pt[ nCount ].y );
#endif // _DEBUG
					SetPolyFillMode(wdev->hdc, WINDING);
					Polygon( wdev->hdc, pt, nCount );

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t polygon( %d )\n", nCount ); 
#endif // _DEBUG
					nCount = 0;
					continue;
				default:
					break;
			}
			break;
		}
		if (!bOverflow && nCount > 1) {
			Polygon(wdev->hdc, pt, nCount);

#if defined(_DEBUG) || defined(DEBUG)
//            jTRACE( "\t polygon( %d )\n", nCount ); 
#endif // _DEBUG
			nCount = 0;
		}
	}
	// Curve �� �ְų� Polygon ���� �����÷ο찡 ����� �н��� �����Ѵ�.
	if (bOverflow || ppath->curve_count > 0) {
#endif // _USE_POLYGON

		gx_path_enum_init(&penum, ppath);
		BeginPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
//        jTRACE( "\t BeginPath()\n" ); 
#endif // _DEBUG

		for (;;) {
			gs_fixed_point pts[3];
			POINT pt[3];

			switch (gx_path_enum_next(&penum, pts)) {
				case gs_pe_moveto:
					MoveToEx(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y), NULL);
					bClosed = FALSE;

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t moveto( %d, %d )\n", ftoi( pts[ 0 ].x ), ftoi( pts[ 0 ].y ) ); 
#endif // _DEBUG

					continue;
				case gs_pe_lineto:
					LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));

#if defined(_DEBUG) || defined(DEBUG)
//                    jTRACE( "\t lineto( %d, %d )\n", ftoi( pts[ 0 ].x ), ftoi( pts[ 0 ].y ) ); 
#endif // _DEBUG

					continue;
				case gs_pe_curveto:
					pt[0].x = ftoi(pts[0].x); pt[0].y = ftoi(pts[0].y); // control point1
					pt[1].x = ftoi(pts[1].x); pt[1].y = ftoi(pts[1].y); // control point2
					pt[2].x = ftoi(pts[2].x); pt[2].y = ftoi(pts[2].y); // end point
					PolyBezierTo(wdev->hdc, pt, 3);

					if (pt[0].x < 0) {
						int stop = 1;
					}

#if defined(_DEBUG) || defined(DEBUG)
//                            jTRACE( "\t polyBezierTo(%d, %d %d, %d %d, %d)\n", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y);
#endif // _DEBUG

					continue;
				case gs_pe_closepath:
					LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));
					bClosed = TRUE;

#if defined(_DEBUG) || defined(DEBUG)
//                            jTRACE( "\t ClosePath(%d, %d)\n", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

					continue;
				default:
					break;
			}
				break;
		}

		if (!bClosed) {
			CloseFigure(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
//            jTRACE( "\t closeFigure()" );
#endif // _DEBUG
		}
		EndPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
//        jTRACE( "\t endPath()\n" );
#endif // _DEBUG

		if (params->fill_zero_width && nThickness < 1) {
			FillPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
//            jTRACE( "\t fillPath()\n" );
#endif // _DEBUG
		} else {
			StrokeAndFillPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
//            jTRACE( "\t strokeAndFillPath()\n" );
#endif // _DEBUG
		}

#ifdef _USE_POLYGON
	}
#endif // _USE_POLYGON
	wdev->nItems++;

	return 0;
}

int wmf_stroke_path(gx_device *dev, const gs_imager_state *pis, gx_path *ppath,
					const gx_stroke_params *params, const gx_drawing_color *pdcolor, const gx_clip_path *pcpath)
{
	gx_device_wmf *wdev = (gx_device_wmf*)dev;
	gx_line_params line_params = pis->line_params;
	int code;
    gs_path_enum penum, pcenum;
	gx_path *spath, fpath, dpath;

#if defined(_DEBUG) || defined(DEBUG)
	int nCount = 0;

	if (wdev->pFile) {
		fprintf(wdev->pFile, "wmf_stroke_path()====================================high\n");
		if (pdcolor) {
			if (pdcolor->type == gx_dc_type_pure)
				fprintf(wdev->pFile, "pure color : %08X\n", pdcolor->colors.pure);
			else if (pdcolor->type == gx_dc_type_ht_binary)
				fprintf(wdev->pFile, "ht binary : \n");
			else if (pdcolor->type == gx_dc_type_ht_colored)
				fprintf(wdev->pFile, "ht colored : \n");
		}
	}
#endif // _DEBUG

	if (!wdev || !wdev->hdc)
		return 0;
	if (!wdev->bRecord)
		return 0;

	// �뽬 ������ ���� ���, ���Ͽ� ���� �ɰ� �ش�.
	if (line_params.dash.pattern_size != 0 && !gx_path_has_curves(ppath)) {
		if (!gx_path_has_curves(ppath)) {
			if (!ppath->first_subpath)
				return 0;
			spath = ppath;
		// Ŀ�갡 ���� ��� �������� �ٲپ� �ش�.
		} else {
			gx_path_init_local(&fpath, ppath->memory);
			if ((code = gx_path_add_flattened_for_stroke(ppath, &fpath, params->flatness, pis)) < 0) {
				gx_path_free(&fpath, "wmf_stroke_path(flattened path)");
				return code;
			}
			spath = &fpath;
		}

		gx_path_init_local(&dpath, ppath->memory);
		if ((code = gx_path_add_dash_expansion(spath, &dpath, pis)) < 0) {
			if (ppath->curve_count)
				gx_path_free(&fpath, "wmf_stroke_path(flattened path)");
			gx_path_free(&dpath, "gx_stroke_path exit(dash path)");
			return code;
		}
		spath = &dpath;
	} else {
		spath = ppath;
	}

	{ // �� �Ӽ� ����
	DWORD dwPenStyle = PS_GEOMETRIC | PS_SOLID;
	COLORREF crColor = MakeColorRef(pdcolor->colors.pure);
	int nPenWidth = (int)(line_params.half_width * 2 * pis->ctm.xx);
	nPenWidth = (nPenWidth > 1) ? nPenWidth : 1;

	//!!!
	if (line_params.start_cap == gs_cap_butt)
		dwPenStyle |= PS_ENDCAP_FLAT;
	if (line_params.start_cap == gs_cap_round)
		dwPenStyle |= PS_ENDCAP_ROUND;
	if (line_params.start_cap == gs_cap_square)
		dwPenStyle |= PS_ENDCAP_SQUARE;
	if (line_params.start_cap == gs_cap_triangle)
		dwPenStyle |= PS_ENDCAP_ROUND;

	if (line_params.join == gs_join_miter) {
		dwPenStyle |= PS_JOIN_MITER;
		SetMiterLimit(wdev->hdc, (FLOAT)(line_params.miter_limit), NULL);
	}
	if (line_params.join == gs_join_round)
		dwPenStyle |= PS_JOIN_ROUND;
	if (line_params.join == gs_join_bevel)
		dwPenStyle |= PS_JOIN_BEVEL;
	if (line_params.join == gs_join_none)
		dwPenStyle |= PS_JOIN_ROUND;
	if (line_params.join == gs_join_triangle)
		dwPenStyle |= PS_JOIN_ROUND;
	if (line_params.curve_join >= 0);

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile) {
		fprintf(wdev->pFile, "width             : %f(%d)\n", line_params.half_width * 2, nPenWidth);
		if (pis->line_params.dash.pattern_size)
			fprintf(wdev->pFile, "dash pattern size : %f\n", line_params.dash.pattern_size);
	}
#endif // _DEBUG

	wmf_change_pen_ex(dev, nPenWidth, crColor, dwPenStyle, 0, NULL);
	}

	// Ŭ���� ���� ����
	WmfSetClipPath(dev, pcpath, RGN_COPY);

    // �н��� Iterating �ϸ鼭 ������ ��ҵ��� ��ȯ
	BeginPath(wdev->hdc);
    gx_path_enum_init(&penum, spath);

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "BeginPath - wmf_stroke_path\n");
#endif // _DEBUG

	for (;;) {
		gs_fixed_point pts[3];
		POINT pt[3];

		switch (gx_path_enum_next(&penum, pts)) {
			case gs_pe_moveto:
				MoveToEx(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y), NULL);

#if defined(_DEBUG) || defined(DEBUG)
				if (wdev->pFile)
					fprintf(wdev->pFile, "MoveTo(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			case gs_pe_lineto:
				LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));

#if defined(_DEBUG) || defined(DEBUG)
				nCount++;
					if (wdev->pFile)
				fprintf(wdev->pFile, "LineTo(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			case gs_pe_curveto:
				pt[0].x = ftoi(pts[0].x); pt[0].y = ftoi(pts[0].y); // control point1
				pt[1].x = ftoi(pts[1].x); pt[1].y = ftoi(pts[1].y); // control point2
				pt[2].x = ftoi(pts[2].x); pt[2].y = ftoi(pts[2].y); // end point
				PolyBezierTo(wdev->hdc, pt, 3);

#if defined(_DEBUG) || defined(DEBUG)
				nCount++;
				if (wdev->pFile)
					fprintf(wdev->pFile, "CurveTo(%d, %d)(%d, %d)(%d, %d)\t", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y);
#endif // _DEBUG

				continue;
			case gs_pe_closepath:
				LineTo(wdev->hdc, ftoi(pts[0].x), ftoi(pts[0].y));

#if defined(_DEBUG) || defined(DEBUG)
				nCount++;
				if (wdev->pFile)
					fprintf(wdev->pFile, "ClosePath(%d, %d)\t", ftoi(pts[0].x), ftoi(pts[0].y));
#endif // _DEBUG

				continue;
			default:
				break;
			}
			break;
    }

	EndPath(wdev->hdc);

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "EndPath - wmf_stroke_path\n");
#endif // _DEBUG

	StrokePath(wdev->hdc); // �׽�Ʈ��, �ּ�ó�� �� ��

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "StrokePath - wmf_stroke_path\n");
#endif // _DEBUG

	wdev->nItems++;

#if defined(_DEBUG) || defined(DEBUG)
	if (wdev->pFile)
		fprintf(wdev->pFile, "\n\n");
#endif // _DEBUG

	return 0;
}
