﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Hnc.Type;

namespace Hnc.Control
{
    public class AppBar : ContentControl
    {
        #region -> Fields

        /// <summary>
        /// AppBar가 열리거나 닫힐 때 영향을 받는 프레임의 영역으로서
        /// CenterGrid에 셋팅된 상하좌우의 Workspace 그리드 중 하나를 설정합니다.
        /// </summary>
        private FrameworkElement relatedArea;
        private bool isOverlapped = true;
        private TranslateTransform slideTransform = new TranslateTransform();
        private DoubleAnimation sizeAnimation = new DoubleAnimation();
        private DoubleAnimation slideAnimation = new DoubleAnimation();
        private DoubleAnimation transparentAnimation = new DoubleAnimation();
        
        private static Duration openDuration = new Duration(TimeSpan.FromSeconds(0.2));
        private static Duration closeDuration = new Duration(TimeSpan.FromSeconds(0.1));

        #endregion

        #region -> Constructor

        static AppBar() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AppBar), new FrameworkPropertyMetadata(typeof(AppBar)));
        }

        public AppBar() {
        }

        public AppBar(FrameworkElement relatedArea) {
            this.relatedArea = relatedArea;
        }

        #endregion

        #region -> Events

        /// <summary>
        /// AppBar가 열릴 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Opened;

        /// <summary>
        /// AppBar가 닫힐 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Closed;

        #endregion

        #region -> Properties

        /// <summary>
        /// AppBar가 프레임에 오버랩되어 나올지 프레임의 레이아웃에 영향을 주도록 연동될지 여부입니다.
        /// </summary>
        public bool IsOverlapped {
            get { return isOverlapped; }
            set {

                if (!isOverlapped)
                    Debug.Assert(relatedArea != null, "프레임과 연동되어 움직이기 위해선 연관 영역이 설정되야 합니다");

                isOverlapped = value; 
            }
        }

        /// <summary>
        /// AppBar의 위치가 상단인지 하단인지 설정하거나 가져옵니다.
        /// </summary>
        public Dock DockType {
            get { return (Dock)GetValue(DockTypeProperty); }
            set { SetValue(DockTypeProperty, value); }
        }

        public static readonly DependencyProperty DockTypeProperty =
            DependencyProperty.Register("DockType", typeof(Dock), typeof(AppBar), new PropertyMetadata(Dock.Bottom));

        /// <summary>
        /// AppBar의 표시 상태를 설정하거나 가져옵니다.
        /// </summary>
        public bool IsOpen {
            get { return (bool)GetValue(IsOpenProperty); }
            set {
                if (IsOpen == value)
                    return;

                SetValue(IsOpenProperty, value);

                if (value) {
                    PlayOpenAnimation();
                    OnOpened();
                }
                else {
                    PlayCloseAnimation();
                    OnClosed();
                }
            }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(AppBar), new PropertyMetadata(false));

        #endregion

        #region -> Private Methods

        private void OnOpened() {
            if (Opened != null)
                Opened(this, null);
        }

        private void OnClosed() {
            if (Closed != null)
                Closed(this, null);
        }

        private void PlayOpenAnimation() {
            slideAnimation.To = 0d;            
            transparentAnimation.To = 1d;
            slideAnimation.Duration = openDuration;
            sizeAnimation.Duration = openDuration;

            if (DockType == Dock.Top || DockType == Dock.Bottom) {
                slideTransform.BeginAnimation(TranslateTransform.YProperty, slideAnimation);

                if (!IsOverlapped) {
                    sizeAnimation.From = 0d;
                    sizeAnimation.To = this.Height;
                    relatedArea.BeginAnimation(FrameworkElement.HeightProperty, sizeAnimation);
                }

            } else if (DockType == Dock.Left || DockType == Dock.Right) {
                slideTransform.BeginAnimation(TranslateTransform.XProperty, slideAnimation);

                if (!IsOverlapped) {
                    sizeAnimation.From = 0d;
                    sizeAnimation.To = this.Width;
                    relatedArea.BeginAnimation(FrameworkElement.WidthProperty, sizeAnimation);
                }
            }

            this.BeginAnimation(OpacityProperty, transparentAnimation);
        }

        private void PlayCloseAnimation() {

            slideAnimation.Duration = closeDuration;
            sizeAnimation.Duration = closeDuration;

            if (DockType == Dock.Top)
                slideAnimation.To = -this.Height;
            else if (DockType == Dock.Bottom)
                slideAnimation.To = this.Height;
            else if (DockType == Dock.Left)
                slideAnimation.To = -this.Width;
            else if (DockType == Dock.Right)
                slideAnimation.To = this.Width;
            
            transparentAnimation.To = 0d;

            if (DockType == Dock.Top || DockType == Dock.Bottom) {
                slideTransform.BeginAnimation(TranslateTransform.YProperty, slideAnimation);

                if (!isOverlapped) {
                    sizeAnimation.From = this.Height;
                    sizeAnimation.To = 0d;
                    relatedArea.BeginAnimation(FrameworkElement.HeightProperty, sizeAnimation);
                }

            } else if (DockType == Dock.Left || DockType == Dock.Right) {
                slideTransform.BeginAnimation(TranslateTransform.XProperty, slideAnimation);

                if (!isOverlapped) {
                    sizeAnimation.From = this.Width;
                    sizeAnimation.To = 0d;
                    relatedArea.BeginAnimation(FrameworkElement.WidthProperty, sizeAnimation);
                }
            }

            this.BeginAnimation(OpacityProperty, transparentAnimation);            
        }

        private void transparentAnimation_Completed(object sender, EventArgs e) {

            // 열림, 닫힘 상태에 따라 다른 컨트롤을 가리지 않도록 상태 설정
            if (IsOpen)
                this.Visibility = Visibility.Visible;
            else
                this.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region -> Overrided Methods

        protected override void OnInitialized(EventArgs e) {
            base.OnInitialized(e);

            // 부모 컨트롤 내의 AppBar 위치 지정
            if (this.DockType == Dock.Top) {
                this.VerticalAlignment = VerticalAlignment.Top;
            } else if (this.DockType == Dock.Bottom) {
                this.VerticalAlignment = VerticalAlignment.Bottom;
            } else if (this.DockType == Dock.Left) {
                this.HorizontalAlignment = HorizontalAlignment.Left;
            } else if (this.DockType == Dock.Right) {
                this.HorizontalAlignment = HorizontalAlignment.Right;
            }

            // 열림/닫힘 상태에 따른 초기 위치 이동
            this.Opacity = 0.0;
            if (IsOpen) {
                slideTransform.X = 0.0;
                slideTransform.Y = 0.0;
                this.Opacity = 255.0;
            } else if (DockType == Dock.Top) {
                slideTransform.Y = -this.Height;
            } else if (DockType == Dock.Bottom) {
                slideTransform.Y = this.Height;
            } else if (DockType == Dock.Left) {
                slideTransform.X = -this.Width;
            } else if (DockType == Dock.Right) {
                slideTransform.X = this.Width;
            }

            this.RenderTransform = slideTransform;
            
            sizeAnimation.AccelerationRatio = 0.3;
            sizeAnimation.DecelerationRatio = 0.35;

            slideAnimation.AccelerationRatio = 0.3;
            slideAnimation.DecelerationRatio = 0.35;

            transparentAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.15));
            transparentAnimation.DecelerationRatio = 0.6;
            transparentAnimation.Completed += new EventHandler(transparentAnimation_Completed);
        }

        #endregion
    }
}
