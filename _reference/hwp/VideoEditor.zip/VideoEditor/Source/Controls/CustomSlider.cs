﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Controls {
	using Bool = System.Boolean;
	using System;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Input;

	class CustomSlider : Slider {
		// 이전 IsMoveToPointEnabled 값으로 되돌리기 위한 플래그
		private Bool _defaultIsMoveToPointEnabled;

		public static readonly DependencyProperty AutoMoveProperty =
													DependencyProperty.Register("AutoMove",
													typeof(Bool),
													typeof(CustomSlider),
													new FrameworkPropertyMetadata(false, ChangeAutoMoveProperty));

		public Bool AutoMove {
			get {
				return (Bool)GetValue(AutoMoveProperty);
			}
			set {
				SetValue(AutoMoveProperty, value);
			}
		}

		private static void ChangeAutoMoveProperty(DependencyObject d, DependencyPropertyChangedEventArgs e) {
			CustomSlider slider = d as CustomSlider;

			if (slider != null) {
				if ((Bool)e.NewValue) {
					slider._defaultIsMoveToPointEnabled = slider.IsMoveToPointEnabled;
					slider.IsMoveToPointEnabled = true;
					slider.PreviewMouseMove += CustomSlider_PreviewMouseMove;
				} else {
					slider.IsMoveToPointEnabled = slider._defaultIsMoveToPointEnabled;
					slider.PreviewMouseMove -= CustomSlider_PreviewMouseMove;
				}
			}
		}

		private static void CustomSlider_PreviewMouseMove(object sender, MouseEventArgs e) {
			if (e.LeftButton == MouseButtonState.Pressed) {
				CustomSlider slider = sender as CustomSlider;
				Point point = e.GetPosition(slider);

				// 현재 Slider 내 마우스 좌표 값을 Value 값으로 계산.
				try {
					slider.Value = point.X / (slider.ActualWidth / slider.Maximum);
				} catch (DivideByZeroException) {
					Hnc.Type.Debug.Assert(false, "CustomSlider_PreviewMouseMove 0으로 나누려고 했습니다.");
					slider.Value = 0.0;
				}
			}
		}
	}
}