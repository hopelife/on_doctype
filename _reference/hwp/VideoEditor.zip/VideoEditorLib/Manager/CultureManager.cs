﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using Hnc.Type;
using System.Threading;

using System.Runtime.InteropServices;

namespace Hnc.Manager {
    

	public sealed class CultureManager {
        [DllImport("Kernel32.dll", CharSet = CharSet.Auto)]
        private static extern ushort SetThreadUILanguage(ushort _languageId);


		public static CultureInfo CurrentCultureInfo {
			get {
				return CultureInfo.GetCultureInfo(CurrentCultureName);
			}
		}

        public static void SetCurrentCulture(String culture) {
            CultureInfo cultureInfo = null; 

            if (culture == "ko-KR") {
                cultureInfo = new CultureInfo("ko-KR");
            } else {
                cultureInfo = new CultureInfo("en-US");
            }
					
			Thread.CurrentThread.CurrentCulture = cultureInfo;
			Thread.CurrentThread.CurrentUICulture = cultureInfo;

            SetThreadUILanguage((ushort)cultureInfo.LCID);
		}
			
		public static String CurrentCultureName {
			get {
				if (CultureInfo.CurrentCulture.Name != "ko-KR" && CultureInfo.CurrentCulture.Name != "en-US") {
					CultureInfo cultureInfo = new CultureInfo("en-US");
					Thread.CurrentThread.CurrentCulture = cultureInfo;
					Thread.CurrentThread.CurrentUICulture = cultureInfo;
                    

					Debug.Assert(false, "지원하는 문화권이 아니므로 영문(en-US)으로 대체됩니다.");
				}

				return CultureInfo.CurrentCulture.Name;
			}
		}
	}
}
