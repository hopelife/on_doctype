﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using Float = System.Single;
using Bool = System.Boolean;

namespace Hnc.Type {

    // cx, cy 영역관리
    // value Compare
    public sealed class Size {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Int CX { get; set; }
        public Int CY { get; set; }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Size(Int cx, Int cy) {
            CX = cx;
            CY = cy;
        }

        public static Size Create(Int cx, Int cy) {
            return new Size(cx, cy);
        }
        public Size Clone() {
            return Size.Create(CX, CY);
        }

        #region 비교연산

        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }
            Size other = obj as Size;
            Debug.Assert(other != null);

            return (CX == other.CX) && (CY == other.CY);
        }
        public static Bool operator ==(Size left, Size right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Size left, Size right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }

    }
    public sealed class SizeF {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public Float CX { get; set; }
        public Float CY { get; set; }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private SizeF(Float cx, Float cy) {
            CX = cx;
            CY = cy;
        }

        public static SizeF Create(Float cx, Float cy) {
            return new SizeF(cx, cy);
        }

        public SizeF Clone() {
            return SizeF.Create(CX, CY);
        }

        #region 비교연산

        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }
            Size other = obj as Size;
            Debug.Assert(other != null);

            return (CX == other.CX) && (CY == other.CY);
        }
        public static Bool operator ==(SizeF left, SizeF right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(SizeF left, SizeF right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }

    }
}
