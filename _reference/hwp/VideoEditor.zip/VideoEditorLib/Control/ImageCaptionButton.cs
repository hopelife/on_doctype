﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace Hnc.Control
{
	public class ImageCaptionButton : Button
	{
        static ImageCaptionButton()
		{
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ImageCaptionButton), new FrameworkPropertyMetadata(typeof(ImageCaptionButton)));		   
		}	   
		
		#region -> Properties

		public System.Windows.Media.ImageSource ImageSource
		{
            get { return (System.Windows.Media.ImageSource)GetValue(ImageSourceProperty); }
			set { SetValue(ImageSourceProperty, value); }
		}

        public static readonly DependencyProperty ImageSourceProperty =
            DependencyProperty.Register(
                "ImageSource",
                typeof(System.Windows.Media.ImageSource),
                typeof(ImageCaptionButton),
                new PropertyMetadata(null)
            );

        public System.Windows.Media.ImageSource HoverImage {
            get { return (System.Windows.Media.ImageSource)GetValue(HoverImageProperty); }
            set { SetValue(HoverImageProperty, value); }
        }

        public static readonly DependencyProperty HoverImageProperty =
           DependencyProperty.Register(
               "HoverImage",
               typeof(System.Windows.Media.ImageSource),
               typeof(ImageCaptionButton),
               new PropertyMetadata(null)
               );

		public System.Windows.Media.ImageSource PressedImage {
			get {
				return (System.Windows.Media.ImageSource)GetValue(PressedImageProperty);
			}
			set {
				SetValue(PressedImageProperty, value);
			}
		}

		public static readonly DependencyProperty PressedImageProperty =
		   DependencyProperty.Register(
			   "PressedImage",
			   typeof(System.Windows.Media.ImageSource),
               typeof(ImageCaptionButton),
			   new PropertyMetadata(null)
			   );

        public System.Windows.Media.ImageSource DisabledImage
		{
            get { return (System.Windows.Media.ImageSource)GetValue(DisabledImageProperty); }
			set { SetValue(DisabledImageProperty, value); }
		}

        public static readonly DependencyProperty DisabledImageProperty =
           DependencyProperty.Register(
               "DisabledImage",
               typeof(System.Windows.Media.ImageSource),
               typeof(ImageCaptionButton),
               new PropertyMetadata(null)
           );

        public bool UseBorder {
            get { return (bool)GetValue(UseBorderProperty); }
            set { SetValue(UseBorderProperty, value); }
        }

        public static readonly DependencyProperty UseBorderProperty =
            DependencyProperty.Register(
                "UseBorder",
                typeof(bool),
                typeof(ImageCaptionButton),
                new PropertyMetadata(true)
            );

		public Visibility ImageVisibility
		{
			get { return (Visibility)GetValue(ImageVisibilityProperty); }
			set { SetValue(ImageVisibilityProperty, value); }
		}

        public static readonly DependencyProperty ImageVisibilityProperty =
            DependencyProperty.Register(
                "ImageVisibility",
                typeof(Visibility),
                typeof(ImageCaptionButton),
                new PropertyMetadata(Visibility.Visible)
            );

		public string Text
		{
			get { return (string)GetValue(TextProperty); }
			set { SetValue(TextProperty, value); }
		}

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register(
                "Text",
                typeof(string),
                typeof(ImageCaptionButton),
                new PropertyMetadata("")
            );

		public Visibility TextVisibility
		{
			get { return (Visibility)GetValue(TextVisibilityProperty); }
			set { SetValue(TextVisibilityProperty, value); }
		}

        public static readonly DependencyProperty TextVisibilityProperty =
            DependencyProperty.Register(
                "TextVisibility",
                typeof(Visibility),
                typeof(ImageCaptionButton),
                new PropertyMetadata(Visibility.Visible)
            );


		public string InputGestureText
		{
			get { return (string)GetValue(InputGestureTextProperty); }
			set { SetValue(InputGestureTextProperty, value); }
		}

        public static readonly DependencyProperty InputGestureTextProperty =
           DependencyProperty.Register(
               "InputGestureText",
               typeof(string),
               typeof(ImageCaptionButton),
               new PropertyMetadata("")
           );

		public double ImageMargin
		{
			get { return (double)GetValue(ImageMarginProperty); }
			set { SetValue(ImageMarginProperty, value); }
		}
	  

	   public static readonly DependencyProperty ImageMarginProperty =
	          DependencyProperty.Register(
                        "ImageMargin", 
                        typeof(double),
                        typeof(ImageCaptionButton),
	                    new FrameworkPropertyMetadata(0.0));


       public double ImageHeight
       {
           get { return (double)GetValue(ImageHeightProperty); }
           set { SetValue(ImageHeightProperty, value); }
       }


       public static readonly DependencyProperty ImageHeightProperty = 
           DependencyProperty.Register(
                    "ImageHeight", 
                    typeof(double),
                    typeof(ImageCaptionButton), 
                    new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));

       public double ImageWidth
       {
           get { return (double)GetValue(ImageWidthProperty); }
           set { SetValue(ImageWidthProperty, value); }
       }

        public static readonly DependencyProperty ImageWidthProperty = 
            DependencyProperty.Register(
                     "ImageWidth", 
                     typeof(double),
                     typeof(ImageCaptionButton), 
                     new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));

      

		public Visibility InputGestureTextVisibility
		{
			get { return (Visibility)GetValue(InputGestureTextVisibilityProperty); }
			set { SetValue(InputGestureTextVisibilityProperty, value); }
		}

        public static readonly DependencyProperty InputGestureTextVisibilityProperty =
            DependencyProperty.Register(
                "InputGestureTextVisibility",
                typeof(Visibility),
                typeof(ImageCaptionButton),
                new PropertyMetadata(Visibility.Visible)
            );

		public Orientation Orientation
		{
			get { return (Orientation)GetValue(OrientationProperty); }
			set { SetValue(OrientationProperty, value); }
		}

        public static readonly DependencyProperty OrientationProperty =
            DependencyProperty.Register(
                "Orientation",
                typeof(Orientation),
                typeof(ImageCaptionButton),
                new PropertyMetadata(Orientation.Horizontal)
            );
        
        public Visibility SubMenuVisibility
		{
			get { return (Visibility)GetValue(SubMenuVisibilityProperty); }
			set { SetValue(SubMenuVisibilityProperty, value); }
		}

        public static readonly DependencyProperty SubMenuVisibilityProperty =
           DependencyProperty.Register(
               "SubMenuVisibility",
               typeof(Visibility),
               typeof(ImageCaptionButton),
               new PropertyMetadata(Visibility.Visible)
           );

		#endregion

        protected override void OnMouseEnter(System.Windows.Input.MouseEventArgs e) {
			
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(System.Windows.Input.MouseEventArgs e) {
            base.OnMouseLeave(e);
        }

        //protected override System.Windows.Media.HitTestResult HitTestCore(System.Windows.Media.PointHitTestParameters hitTestParameters) {

        //    BitmapSource source = (BitmapSource)ImageSource;

        //    int x = (int)(hitTestParameters.HitPoint.X / this.ActualWidth * source.PixelWidth);
        //    int y = (int)(hitTestParameters.HitPoint.Y / this.ActualHeight * source.PixelHeight);

        //    if (x > 0 && x < source.PixelWidth && y > 0 && y < source.PixelHeight) {

        //        var pixels = new byte[4];
        //        source.CopyPixels(new Int32Rect(x, y, 1, 1), pixels, 4, 0);

        //        if (pixels[3] < 10)
        //            return null;
        //    }

        //    return base.HitTestCore(hitTestParameters);
        //}
	}
}
