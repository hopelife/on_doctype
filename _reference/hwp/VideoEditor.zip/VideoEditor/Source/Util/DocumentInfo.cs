﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Xml;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Hnc.Type;

namespace Hnc.VideoEditor.Util {

    internal sealed class DocumentInfo {

        public static readonly String SavePath =
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\HNC\Utils\VideoEditor";

        public static readonly String SetupPath = SavePath + @"\Setup.xml";        

        static DocumentInfo() {
            CheckSavePath();
        }

        private static XmlWriterSettings settings = new XmlWriterSettings();
        public static XmlWriterSettings WriterSettings {
            get {
                settings.Indent = true;
                settings.NewLineChars = Environment.NewLine;
                return settings;
            }
        }      

        public static bool CheckSavePath() {

            // 저장할 디렉토리가 존재하지 않는다면 디렉토리 생성
            if (!Directory.Exists(SavePath)) {
                try {                    
                    Directory.CreateDirectory(SavePath);
                } catch (Exception e) {
                    Debug.Assert(false, e.Message);
                    return false;
                }
            }

            return true;
        }
    }
}
