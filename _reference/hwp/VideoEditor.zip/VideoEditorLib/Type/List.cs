﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Type {

    // 목록 저장. Null은 저장할 수 없다.
    public sealed class List<T> : System.Collections.Generic.IEnumerable<T>, System.IDisposable {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private System.Collections.Generic.List<T> collection = new System.Collections.Generic.List<T>();
        private System.Collections.Generic.List<T> Collection {
            get {
                Debug.Assert(collection != null);
                return collection;
            }
        }

        public T this[Index index] {
            get {
                Debug.Assert(Collection != null);
                return Collection[index];
            }
            set {
                Debug.Assert(Collection != null);
                Debug.AssertThrow(value != null, eErrorCode.NullArgument);
                
                if (Count < index) { // 범위를 벗어나면 뒤에 추가
                    Add(value);
                }
                else {
                    Collection[index] = value;
                }
            }
        }
        public Count Count {
            get {
                Debug.Assert(Collection != null);
                return Collection.Count;
            }
        }
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------

        private List() {

        }
        
        private List(List<T> other) {
            Debug.Assert(other.Collection != null);

            foreach (var item in other.Collection) {
                Add(item);
            }
        }
        public static List<T> Create() {
            return new List<T>();
        }

        public List<T> Clone() {
            return new List<T>(this);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region IDispose
        public void Dispose() {
            Debug.Assert(Collection != null);

            foreach (var item in Collection) {
                if (item != null && item is System.IDisposable) {
                    (item as System.IDisposable).Dispose();
                }
            }
            Collection.Clear();
        }
        #endregion
        
        #region IEnumerable 구현 - foreach 지원
        public System.Collections.Generic.IEnumerator<T> GetEnumerator() {
            Debug.Assert(Collection != null);

            return Collection.GetEnumerator();
        }
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
            return GetEnumerator();
        }
        #endregion



        public void Add(T item) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(item != null, eErrorCode.NullArgument);
 
            Collection.Add(item);
        }
        public void Add(List<T> items) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(items != null, eErrorCode.NullArgument);

            foreach (var item in items) {
                Add(item);
            }
        }
        public void Insert(Index index, T item) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(item != null, eErrorCode.NullArgument);
            Debug.AssertThrow(0<= index && index <= Collection.Count, eErrorCode.OutOfRange);

            Collection.Insert(index, item);
        }

        public void Remove(T item) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(item != null, eErrorCode.NullArgument);

            Collection.Remove(item);
        }
        public void RemoveAt(Index index) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(0 <= index && index < Collection.Count, eErrorCode.OutOfRange);
          
            Collection.RemoveAt(index);
        }
        // List의 pos 위치에서부터 count개를 삭제한다.
        public void Remove(Index pos, Count count) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(0 <= pos && pos < Collection.Count, eErrorCode.OutOfRange);
            Debug.AssertThrow((pos + count) <= Collection.Count, eErrorCode.OutOfRange);
            Debug.AssertThrow(0 < count, eErrorCode.OutOfRange);


            Collection.RemoveRange(pos, count);
        }
        public void Clear() {
            Debug.Assert(Collection != null);

            Collection.Clear();
        }
        // item 인 아이템의 위치. 없으면 -1
        public Index IndexOf(T item) {
            Debug.Assert(Collection != null);

            return Collection.IndexOf(item);
        }
        public void Copy(List<T> other) {
            Debug.Assert(Collection != null); 
            Debug.AssertThrow(other != null, eErrorCode.NullArgument);

            Clear();
            foreach (T item in other.Collection) {
                Collection.Add(item);
            }
        }
        public void Sort() {
            Debug.Assert(Collection != null);
            Collection.Sort();
        }
        
    }
}
