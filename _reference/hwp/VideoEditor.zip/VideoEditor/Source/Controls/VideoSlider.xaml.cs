﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;
using System;
using Hnc.VEFrame;
using System.Windows.Media;

namespace Hnc.VideoEditor.Controls {
	public partial class VideoSlider : UserControl {
		static readonly double SliderGap = 15.0;

		static readonly double PositionGap = 7.5;
		//static readonly double ThumbGap = 30.0;
		static readonly double PlayPositionGap = 7.5;
		static readonly double BarPositionGap = 7.5;

		private double thumbPositionValue = 0.0;

		private double startPositionValue = 0.0;
		private double endPositionValue = 0.0;

		private double startSecondsValue = 0.0;
		private double endSecondsValue = 0.0;

		private double valueSeconds = 0.0;

		// 슬라이더바에서 실제 프레임 위치를 계산하기 위한 슬라이더바의 크기
		private double sliderWidth = 0.0;
		// 현재 선택된 동영상의 전체 시간
		private double totalSeconds = 0.0;

		public VideoPlayer videoPlayer;
		private bool isMoved = true;

		private String filePath = null;

		// ----------------------------------------------
		// 프로퍼티
		// ----------------------------------------------
		#region 프로퍼티
		public double SliderWidth {
			get {
				return sliderWidth;
			}
			set {
				if (sliderWidth != value) {
					sliderWidth = value;
					StartPosition.SliderWidth = sliderWidth;
					EndPosition.SliderWidth = sliderWidth;
				}
			}
		}

		public double TotalSeconds {
			get {
				return totalSeconds;
			}
			set {
				if (totalSeconds != value) {
					totalSeconds = value;
					StartPosition.TotalSeconds = totalSeconds;
					endSecondsValue = totalSeconds;
					EndPosition.TotalSeconds = totalSeconds;
				}
			}
		}

		public double ValueSeconds {
			get {
				return valueSeconds;
			}
			set {
				valueSeconds = value;
				UpdateSlider();
			}
		}

		public double StartSecondsValue {
			get {
				return startSecondsValue;
			}
			set {
				startSecondsValue = value;
			}
		}

		public double EndSecondsValue {
			get {
				return endSecondsValue;
			}
			set {
				if (endSecondsValue != value) {
					endSecondsValue = value;
					EndPosition.SecondsValue = endSecondsValue;
				}
			}
		}

		public bool IsMoved {
			get {
				return isMoved;
			}
			set {
				isMoved = value;
			}
		}

		public String FilePath {
			get {
				return filePath;
			}
			set {
				filePath = value;
			}
		}
		#endregion

		public VideoSlider() {
			InitializeComponent();

			Thumb.MouseDown += new MouseButtonEventHandler(Event_ThumbPreviewMouseDown);
			Thumb.MouseUp += new MouseButtonEventHandler(Event_ThumbPreviewMouseUp);

			this.MouseDown += new MouseButtonEventHandler(Event_SliderPreviewMouseDown);
			this.MouseUp += new MouseButtonEventHandler(Event_SliderPreviewMouseUp);

			StartPosition.PreviewMouseDown += new MouseButtonEventHandler(Event_StartPositionPreviewMouseDown);
			StartPosition.PreviewMouseUp += new MouseButtonEventHandler(Event_StartPositionPreviewMouseUp);

			EndPosition.PreviewMouseDown += new MouseButtonEventHandler(Event_EndPositionPreviewMouseDown);
			EndPosition.PreviewMouseUp += new MouseButtonEventHandler(Event_EndPositionPreviewMouseUp);
		}

		private void OnLoaded(object sender, System.Windows.RoutedEventArgs e) {
			InitVideoPlayer();
		}

		private void ResizeFrame(object sender, SizeChangedEventArgs e) {
			try {
				SliderWidth = this.ActualWidth - SliderGap;//-(SliderGap * 2);
				UpdateSlider();

				startPositionValue = SecondsValueToSliderValue(startSecondsValue);
				endPositionValue = SecondsValueToSliderValue(endSecondsValue);

				StartPosition.SetValue(Canvas.LeftProperty, startPositionValue);
				EndPosition.SetValue(Canvas.LeftProperty, endPositionValue);


                if (startPositionValue == 0 && endPositionValue == 0) {
                    return;
                }

				MiddleLineUp.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
                MiddleLineUp.Width = endPositionValue - startPositionValue - SliderGap;

				MiddleLineDown.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineDown.Width = endPositionValue - startPositionValue - SliderGap;
				
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		public void InitVideoPlayer() {
			try {
				startPositionValue = 0.0;
				startSecondsValue = 0.0;

				endPositionValue = this.ActualWidth - SliderGap;//-PositionGap;

				StartPosition.SetValue(Canvas.LeftProperty, startPositionValue);
				EndPosition.SetValue(Canvas.LeftProperty, endPositionValue);
				Thumb.SetValue(Canvas.LeftProperty, 0.0);

				EndSecondsValue = SliderValueToSecondsValue(endPositionValue);

				SliderWidth = this.ActualWidth - SliderGap;//-(SliderGap * 2);

				valueSeconds = 0.0;
				CurrentTime.Text = System.TimeSpan.FromSeconds(valueSeconds).ToString().Substring(0, 8);

				MiddleLineUp.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineUp.Width = endPositionValue - startPositionValue - SliderGap;

				MiddleLineDown.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineDown.Width = endPositionValue - startPositionValue - SliderGap;

				StartPosition.LeftBarCanvas.Visibility = Visibility.Visible;
				EndPosition.RightBarCanvas.Visibility = Visibility.Visible;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		double SecondsValueToSliderValue(double value) {
			if ((SliderWidth * value) == 0.0) {
				return 0.0;
			} else if (TotalSeconds == 0.0) {
				return 0.0;
			}

			double result = 0.0;
			try {
				result = (SliderWidth * value) / TotalSeconds;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "SecondsValueToSliderValue 0으로 나누려고 했습니다.");
				result = 0.0;
			}

			return result;
		}

		double SliderValueToSecondsValue(double value) {
			if ((TotalSeconds * value) == 0.0) {
				return 0.0;
			} else if (SliderWidth == 0.0) {
				return 0.0;
			}

			double result = 0.0;
			try {
				result = (TotalSeconds * value) / SliderWidth;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "SliderValueToSecondsValue 0으로 나누려고 했습니다.");
				result = 0.0;
			}

			return result;
		}

		/*
		private void UpdateSlider() {
			try {
				double sliderValue = SecondsValueToSliderValue(valueSeconds);

				if (sliderValue + ThumbGap > (endPositionValue - ThumbGap + PositionGap)) {
					sliderValue = endPositionValue - ThumbGap + PositionGap;
				} else if (sliderValue < (startPositionValue + PositionGap)) {
					sliderValue = startPositionValue + PositionGap;
				}

				thumbPositionValue = sliderValue;
				Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		*/

		private void UpdateSlider() {
			try {
				double sliderValue = SecondsValueToSliderValue(valueSeconds);

				if (sliderValue > endPositionValue) {
					sliderValue = endPositionValue;
				} else if (sliderValue < startPositionValue) {
					sliderValue = startPositionValue;
				}

				thumbPositionValue = sliderValue;
				Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_StartPositionPreviewMouseDown(object sender, MouseEventArgs e) {
			try {
				StartPosition.CaptureMouse();
				StartPosition.PreviewMouseMove += Event_StartPositionPreviewMouseMove;
				//e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_StartPositionPreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				StartPosition.ReleaseMouseCapture();
				StartPosition.PreviewMouseMove -= Event_StartPositionPreviewMouseMove;

				if (StartBarCanvas.Visibility == Visibility.Visible) {
					StartBarCanvas.Visibility = Visibility.Hidden;
				}

				e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		/*
		private void Event_StartPositionPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);

				//            currentPosition.X -= PlayPositionGap;

				// 스타트바가 처음 위치로 이동 했을 경우
				if (currentPosition.X <= 0.0) {
					startPositionValue = -PositionGap;
					startSecondsValue = 0.0;
				}
				// 스타트바가 앤드바 보다 뒤로 이동 했을 경우
				else if ((currentPosition.X + ThumbGap) > endPositionValue) {
					startPositionValue = endPositionValue - ThumbGap - 15;
					startSecondsValue = SliderValueToSecondsValue(startPositionValue + 15);
				}
				// 그 외 경우
				else {
					startPositionValue = currentPosition.X;
					startSecondsValue = SliderValueToSecondsValue(startPositionValue + 15);
				}

				StartPosition.SetValue(Canvas.LeftProperty, startPositionValue);

				if (thumbPositionValue <= (startPositionValue + 15)) {
					thumbPositionValue = startPositionValue + 15;
					valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
					videoPlayer.ScreenMove(valueSeconds);
					Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
				}

				if (filePath != null) {
					if (startPositionValue < 0.0) {
						startPositionValue = 0.0;
					}
					Image image = GetVideoThumbnail(filePath, (int)(startSecondsValue * 30.0));
					StartBarImage.Source = image.Source;

					StartBarCurrentTime.Text = System.TimeSpan.FromSeconds(startSecondsValue).ToString().Substring(0, 8);

					if (startPositionValue < 40.0) {
						StartBarCanvas.SetValue(Canvas.LeftProperty, 0.0);
					} else {
						StartBarCanvas.SetValue(Canvas.LeftProperty, startPositionValue - 40.0);
					}

					StartBarCanvas.Visibility = Visibility.Visible;
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		*/

		private void Event_StartPositionPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				currentPosition.X -= BarPositionGap;

				// 스타트바가 처음 위치로 이동 했을 경우
				if (currentPosition.X <= 0.0) {
					startPositionValue = 0.0;
				}
				// 스타트바가 앤드바 보다 뒤로 이동 했을 경우
				else if (currentPosition.X > endPositionValue) {
					startPositionValue = endPositionValue;
				}
				// 그 외 경우
				else {
					startPositionValue = currentPosition.X;
				}

				if (startPositionValue == endPositionValue) {
					if (VEFrameManager.IsLoaded == true) {
						if (VEFrameManager.Instance.MainPage != null) {
							VEFrameManager.Instance.MainPage.IsEnabledAddVideoBtn(false);
						}
					}
				} else {
					if (VEFrameManager.IsLoaded == true) {
						if (VEFrameManager.Instance.MainPage != null) {
							VEFrameManager.Instance.MainPage.IsEnabledAddVideoBtn(true);
						}
					}
				}

				StartPosition.SetValue(Canvas.LeftProperty, startPositionValue);

				if (thumbPositionValue <= startPositionValue) {
					thumbPositionValue = startPositionValue;
					valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
					videoPlayer.ScreenMove(valueSeconds);
					Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
				}

				if (filePath != null) {
					startSecondsValue = SliderValueToSecondsValue(startPositionValue);

					Image image = GetVideoThumbnail(filePath, (int)(startSecondsValue * 30.0));
					if (image != null) {
						StartBarImage.Source = image.Source;
					}

					StartBarCurrentTime.Text = System.TimeSpan.FromSeconds(startSecondsValue).ToString().Substring(0, 8);

					if (startPositionValue < 40.0) {
						StartBarCanvas.SetValue(Canvas.LeftProperty, 0.0);
					} else {
						StartBarCanvas.SetValue(Canvas.LeftProperty, startPositionValue - 40.0);
					}

					StartBarCanvas.Visibility = Visibility.Visible;
				}

				MiddleLineUp.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineUp.Width = endPositionValue - startPositionValue - SliderGap;

				MiddleLineDown.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineDown.Width = endPositionValue - startPositionValue - SliderGap;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private Image GetVideoThumbnail(string path, int frameIndex) {
			System.Windows.Media.ImageSource thumbnailImage = null;
			Image image = null;

			try {
				if (frameIndex < 0) {
					frameIndex = 0;
				}

				thumbnailImage = Hnc.Instrument.VideoUtil.GetVideoThumbnail(path, frameIndex, 80, 60);

				if (thumbnailImage == null) {
					return null;
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}

			image = new Image();
			if (image == null) {
				return null;
			}

			try {
				image.Source = thumbnailImage;
				image.Stretch = System.Windows.Media.Stretch.UniformToFill;
				image.HorizontalAlignment = HorizontalAlignment.Center;
				image.VerticalAlignment = VerticalAlignment.Center;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}

			return image;
		}

		private void Event_EndPositionPreviewMouseDown(object sender, MouseEventArgs e) {
			try {
				EndPosition.CaptureMouse();
				EndPosition.PreviewMouseMove += Event_EndPositionPreviewMouseMove;
				e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_EndPositionPreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				EndPosition.ReleaseMouseCapture();
				EndPosition.PreviewMouseMove -= Event_EndPositionPreviewMouseMove;

				if (EndBarCanvas.Visibility == Visibility.Visible) {
					EndBarCanvas.Visibility = Visibility.Hidden;
				}

				e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		/*
		private void Event_EndPositionPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				//    currentPosition.X -= PlayPositionGap;
				// 최대 넓이 보다 이상으로 넘어 갔을 경우
				if (currentPosition.X > this.ActualWidth) {
					endPositionValue = this.ActualWidth - PositionGap;
					endSecondsValue = SliderValueToSecondsValue(endPositionValue - 30);
				} 
				// 스타드바 보다 앞으로 갔을 경우
				else if ((currentPosition.X - ThumbGap) < startPositionValue) {
					endPositionValue = startPositionValue + ThumbGap;
					endSecondsValue = SliderValueToSecondsValue(endPositionValue - 30);
				} else {
					endPositionValue = currentPosition.X;
					endSecondsValue = SliderValueToSecondsValue(endPositionValue - 30);
				}
				EndPosition.SetValue(Canvas.LeftProperty, endPositionValue);

				if (thumbPositionValue > (endPositionValue - 30)) {
					thumbPositionValue = endPositionValue - 30;
					valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
					videoPlayer.ScreenMove(valueSeconds);
					Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
				}

				if (filePath != null) {
					if (endSecondsValue < 0.0) {
						endSecondsValue = 0.0;
					}

					Image image = GetVideoThumbnail(filePath, (int)(endSecondsValue * 30.0));
					EndBarImage.Source = image.Source;

					EndBarCurrentTime.Text = System.TimeSpan.FromSeconds(endSecondsValue).ToString().Substring(0, 8);

					if (endPositionValue + 40.0 > this.ActualWidth) {
						EndBarCanvas.SetValue(Canvas.LeftProperty, this.ActualWidth - 80.0);
					} else {
						EndBarCanvas.SetValue(Canvas.LeftProperty, endPositionValue - 40.0 + PositionGap);
					}

					EndBarCanvas.Visibility = Visibility.Visible;
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		*/

		private void Event_EndPositionPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				currentPosition.X -= BarPositionGap;
				//    currentPosition.X -= PlayPositionGap;
				// 최대 넓이 보다 이상으로 넘어 갔을 경우
				if (currentPosition.X > this.ActualWidth - SliderGap) {
					endPositionValue = this.ActualWidth - SliderGap;
					endSecondsValue = SliderValueToSecondsValue(endPositionValue);
				}
				// 스타드바 보다 앞으로 갔을 경우
				else if (currentPosition.X < startPositionValue) {
					endPositionValue = startPositionValue;
				} else {
					endPositionValue = currentPosition.X;
				}
				endSecondsValue = SliderValueToSecondsValue(endPositionValue);
				EndPosition.SetValue(Canvas.LeftProperty, endPositionValue);

				if (startPositionValue == endPositionValue) {
					if (VEFrameManager.IsLoaded == true) {
						if (VEFrameManager.Instance.MainPage != null) {
							VEFrameManager.Instance.MainPage.IsEnabledAddVideoBtn(false);
						}
					}
				} else {
					if (VEFrameManager.IsLoaded == true) {
						if (VEFrameManager.Instance.MainPage != null) {
							VEFrameManager.Instance.MainPage.IsEnabledAddVideoBtn(true);
						}
					}
				}

				if (thumbPositionValue > endPositionValue) {
					thumbPositionValue = endPositionValue;
					valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
					videoPlayer.ScreenMove(valueSeconds);
					Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
				}

				if (filePath != null) {
					if (endSecondsValue < 0.0) {
						endSecondsValue = 0.0;
					}

					Image image = GetVideoThumbnail(filePath, (int)(endSecondsValue * 30.0));
					if (image != null) {
						EndBarImage.Source = image.Source;
					}

					EndBarCurrentTime.Text = System.TimeSpan.FromSeconds(endSecondsValue).ToString().Substring(0, 8);

					if (endPositionValue + 40.0 > this.ActualWidth) {
						EndBarCanvas.SetValue(Canvas.LeftProperty, this.ActualWidth - 80.0);
					} else {
						EndBarCanvas.SetValue(Canvas.LeftProperty, endPositionValue - 40.0 + PositionGap);
					}

					EndBarCanvas.Visibility = Visibility.Visible;
				}

				MiddleLineUp.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineUp.Width = endPositionValue - startPositionValue - SliderGap;

				MiddleLineDown.Margin = new Thickness(startPositionValue + SliderGap, 0, 0, 0);
				MiddleLineDown.Width = endPositionValue - startPositionValue - SliderGap;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_SliderPreviewMouseUp(object sender, MouseEventArgs e) {
			try {
				Thumb.PreviewMouseMove -= Event_ThumbPreviewMouseMove;
				Thumb.MouseMove -= videoPlayer.Event_ThumbMouseMove;

				//e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_SliderPreviewMouseDown(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				currentPosition.X -= PlayPositionGap;

				if (currentPosition.X < 0.0) {
					currentPosition.X = 0.0;
				}

				if (currentPosition.X >= (endPositionValue + PositionGap)) {
					//    thumbPositionValue = endPositionValue - ThumbGap + PositionGap;
					IsMoved = false;
					return;
				} else if (currentPosition.X <= (startPositionValue + PositionGap)) {
					//    thumbPositionValue = startPositionValue + PositionGap;
					IsMoved = false;
					return;
				}

				thumbPositionValue = currentPosition.X;

				valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
				videoPlayer.ScreenMove(valueSeconds);
				Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);

				Thumb.PreviewMouseMove += Event_ThumbPreviewMouseMove;
				Thumb.MouseMove += videoPlayer.Event_ThumbMouseMove;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_ThumbPreviewMouseDown(object sender, MouseEventArgs e) {
			try {
				Thumb.CaptureMouse();
				Thumb.PreviewMouseMove += Event_ThumbPreviewMouseMove;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void Event_ThumbPreviewMouseUp(object sender, MouseEventArgs e) {
			try {
				Thumb.ReleaseMouseCapture();
				Thumb.PreviewMouseMove -= Event_ThumbPreviewMouseMove;
				//Thumb.MouseMove -= videoPlayer.Event_ThumbMouseMove;

				//e.Handled = true;
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		/*
		private void Event_ThumbPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				currentPosition.X -= PlayPositionGap;

				if (currentPosition.X + ThumbGap > (endPositionValue)) {
					thumbPositionValue = endPositionValue - 30;
				} else if (currentPosition.X < (startPositionValue + PositionGap)) {
					thumbPositionValue = startPositionValue + 15;
				} else {
					thumbPositionValue = currentPosition.X;
				}

				valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
				videoPlayer.ScreenMove(valueSeconds);
				Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}
		*/

		private void Event_ThumbPreviewMouseMove(object sender, MouseEventArgs e) {
			try {
				Point currentPosition = e.GetPosition(this);
				currentPosition.X -= PlayPositionGap;

				if (currentPosition.X > endPositionValue) {
					thumbPositionValue = endPositionValue;
				} else if (currentPosition.X < startPositionValue) {
					thumbPositionValue = startPositionValue;
				} else {
					thumbPositionValue = currentPosition.X;
				}

				valueSeconds = SliderValueToSecondsValue(thumbPositionValue);
				videoPlayer.ScreenMove(valueSeconds);
				Thumb.SetValue(Canvas.LeftProperty, thumbPositionValue);
			} catch {
				Hnc.Type.Debug.Assert(false, "VideoSlider Exception");
			}
		}

		private void UserControl_MouseUp(object sender, MouseButtonEventArgs e) {
			Thumb.PreviewMouseMove -= Event_ThumbPreviewMouseMove;
			Thumb.MouseMove -= videoPlayer.Event_ThumbMouseMove;
			e.Handled = true;
		}

		System.Windows.Shapes.Rectangle recta;
		DrawingVisual dv;

		protected override void OnRender(System.Windows.Media.DrawingContext drawingContext) {

		}
	}
}