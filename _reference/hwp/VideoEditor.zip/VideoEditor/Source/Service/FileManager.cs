﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Service {
	using String = System.String;
	using Object = System.Object;
	using System.IO;
	using Hnc.Type;
	using Hnc.VEFrame;

	public class FileManager {
		private static readonly Object _thisLock = new Object();
		private List<FileSystemWatcher> _watcherList = List<FileSystemWatcher>.Create();
		static FileManager _instance;

		public static FileManager Instance {
			get {
				lock (_thisLock) {
					if (_instance == null) {
						_instance = new FileManager();
					}
				}
				return _instance;
			}
		}

		public bool AddWatcherFile(String filePath) {
			filePath = null;

			try {
				if (filePath == null) {
					return false;
				}

				DirectoryInfo info = System.IO.Directory.GetParent(filePath);
				if (info.Exists == false) {
					return false;
				}

				String directoryPath = info.FullName;

				foreach (FileSystemWatcher tempWatcher in _watcherList) {
					if (tempWatcher.Path == directoryPath) {
						return false;
					}
				}

				FileSystemWatcher watcher = new FileSystemWatcher(directoryPath);
				watcher.Deleted += new FileSystemEventHandler(Watcher_Deleted);
				watcher.Renamed += new RenamedEventHandler(Watcher_Renamed);
				watcher.IncludeSubdirectories = false;
				watcher.EnableRaisingEvents = true;
				_watcherList.Add(watcher);
			} catch (System.Exception) {
				return false;
			}

			return true;
		}

		private void Watcher_Deleted(object sender, FileSystemEventArgs e) {
			if (e.ChangeType == WatcherChangeTypes.Deleted) {
				// 이 파일을 사용하는 리스트박스가 있는지 확인 및 삭제
				VEFrameManager.Instance.MainPage.Dispatcher.Invoke(VEFrameManager.Instance.MainPage.DelegateDeleteLoadBarItemInstance, new object[] { e.FullPath });

				// 이 파일을 사용하는 타임라인인포가 있는지 확인 및 삭제
				// Undo Redo에서 문제가 발생할 수 있음
				// 하지만 여기서만 문제가 아니라 다른 곳에서도 문제 발생 여지가 있음
				// 다른 부분도 addInfo 등에서 실제 파일이 존재 하는지 여부에 대한 확인이 꼭 필요함

				//   e.FullPath;
			}
		}

		private void Watcher_Renamed(object sender, RenamedEventArgs e) {
			if (e.ChangeType == WatcherChangeTypes.Renamed) {
				VEFrameManager.Instance.MainPage.RenameLoadBarItem(e.OldFullPath, e.FullPath);
				//   e.OldFullPath, e.FullPath;

				ActionRenameInfo action = ActionRenameInfo.Create(e.OldFullPath, e.FullPath);
				ActionManager.Instance.Excute(action);
			}
		}
	}
}