﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {

    // 회색조로 만든뒤 blur를 주어 blur 굵기만큼만 추출하여 렌더링하여 펜으로 그린듯한 느낌을 줌
    // Color 속성일때는 color 이미지와 Overlay하여 약간의 color가 표시되도록 처리
    public class Sketch {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Bool Color = false; // ColorSketch인지의 여부
        private Count Radius = 5; // 선 굵기 반경 1 ~ 
        private Ratio GammaVal = 0.25F; // 진하기. 0 ~ 3
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Sketch(Bool color, Count radius, Ratio gammaVal) {
            Color = color;
            Radius = radius < 1 ? 1 : radius;
          
            GammaVal = MathUtil.Clamp(gammaVal, 0, 3);

        }
        public static Sketch Create(Bool color, Count radius, Ratio gammaVal) {

            return new Sketch(color, radius, gammaVal);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);


            // 감마값을 위한 Table 생성. 
            LookupTable table = LookupTable.Create();
            Int temp;
            for (Index i = 0; i < 256; ++i) {

                temp = (Int)((255F * MathUtil.Pow(i / 255F, 1F / GammaVal)) + 0.5F);
                table.Data[i] = (Byte)((255 < temp) ? 255 : temp);
            }


            // Color 인경우 원본을 저장해 둠
            ArgbChannel color = null;

            if (Color) {

                HslChannel hsl = HslChannel.Create(pixels);
                Hsl.Create(Degree.Create(0), 0.5F, 0).Apply(hsl);
                color = hsl.ToArgb();
            }


            // 원본을 회색조로 만듬
            Grayscale.Create().Apply(pixels);

            // 회색조로 만들었으므로 R만 대상으로 효과를 적용한뒤 G, B 에 대입
            Byte[] clone = new Byte[pixels.R.Length];
            pixels.R.CopyTo(clone, 0);

            Invert.Apply(clone);
            BoxBlur.Apply(clone, pixels.Width, pixels.Height, Radius);



            // blur것이 background로 사용됨
            for (Index i = 0; i < pixels.R.Length; ++i) {

                pixels.R[i] = Blend.ColorDodgeForSketch(clone[i], pixels.R[i]);
                pixels.R[i] = pixels.G[i] = pixels.B[i] = table.Data[pixels.R[i]]; // Gamma 조정
            }

            if (color != null) {
                // Color 버전이 Background로 사용됨
                for (Index i = 0; i < pixels.R.Length; ++i) {

                    Blend.Overlay(
                        ref color.A[i], ref color.R[i], ref color.G[i], ref color.B[i],
                        pixels.A[i], pixels.R[i], pixels.G[i], pixels.B[i],
                        1
                    );

                    pixels.A[i] = color.A[i];
                    pixels.R[i] = color.R[i];
                    pixels.G[i] = color.G[i];
                    pixels.B[i] = color.B[i];
                }
            }

        }
    }
}