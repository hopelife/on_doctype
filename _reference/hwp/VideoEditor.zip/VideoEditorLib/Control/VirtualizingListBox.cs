﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Hnc.Control
{
    public class VirtualizingListBox : System.Windows.Controls.ListBox {

        private Size itemSize = new Size(100, 100);

        public VirtualizingListBox() {
            this.ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingWrapPanel)));

            /*FontEditor 때문에 임시로 작업해놓은 코드,, 추후 UX-XML로 빼야함. */
            this.Background = Brushes.Transparent;
            this.BorderBrush = Brushes.Transparent;

            SetItemSize(itemSize);
        }

        public VirtualizingListBox(Size size) {
            this.ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingWrapPanel)));

            SetItemSize(size);
        }

        public Size GetItemSize() {
            return new Size(itemSize.Width, itemSize.Height);
        }

        public void SetItemSize(Size size) {
            Size newSize = new Size(size.Width, size.Height);
            if (newSize.Width == 0.0)
                newSize.Width = itemSize.Width;
            if (newSize.Height == 0.0)
                newSize.Height = itemSize.Height;
            itemSize = newSize;

            this.ItemsPanel.VisualTree.SetValue(VirtualizingWrapPanel.ItemWidthProperty, newSize.Width);
            this.ItemsPanel.VisualTree.SetValue(VirtualizingWrapPanel.ItemHeightProperty, newSize.Height);
            // FontEditor에 적용했던 버전을 사용할 경우
            //this.ItemsPanel.VisualTree.SetValue(VirtualizingWrapPanel.ChildSizeProperty, newSize);
        }
    }
}
