﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Float = System.Single;
using Ratio = System.Single;
using Byte = System.Byte;
using Index = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    // Hsl 수정 효과
    public class Hsl {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Float Hue { get; set; }
        private Ratio Sat { get; set; }
        private Ratio Lum { get; set; }

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Hsl(Degree h, Ratio s, Ratio l) {

            Debug.AssertThrow(h != null, eErrorCode.NullArgument);

            Hue = h.Value;
            Sat = MathUtil.Clamp(s, -1, 1);
            Lum = MathUtil.Clamp(l, -1, 1);
        }

        public static Hsl Create(Degree h, Ratio s, Ratio l) {
            return new Hsl(h, s, l);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(HslChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.H.Length; ++i) {

                pixels.H[i] += Hue;
                pixels.S[i] += Sat;
                pixels.L[i] += Lum;

                pixels.H[i] = (pixels.H[i] < 0) ? 0 : ((360 < pixels.H[i]) ? 360 : pixels.H[i]); // Degree.Contraint가 더 좋으나 속도가 느려 단순화하여 계산
                pixels.S[i] = (pixels.S[i] < 0) ? 0 : ((1 < pixels.S[i]) ? 1 : pixels.S[i]);
                pixels.L[i] = (pixels.L[i] < 0) ? 0 : ((1 < pixels.L[i]) ? 1 : pixels.L[i]);

            }
        }

    }

}