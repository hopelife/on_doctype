﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Collections.Generic;

using Index = System.Int32;
using Bool = System.Boolean;
using Int = System.Int32;
using String = System.String;

namespace Hnc.Type {

    // flag 관리. 해당 key가 없다면 false
    // value Compare
    public sealed class Flag<T> {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Dictionary<T, Bool> collection = new Dictionary<T, Bool>();
        private Dictionary<T, Bool> Collection {
            get {
                Debug.Assert(collection != null);
                return collection; 
            }
        }

        // 존재하지 않으면 false
        public Bool this[T key] {
            get {
                Debug.Assert(collection != null);
                Debug.AssertThrow(key != null, eErrorCode.NullArgument);
                return IsOn(key);
            }
            set {

                Debug.Assert(Collection != null);
                Debug.AssertThrow(key != null, eErrorCode.NullArgument);

                if (value) {
                    On(key, value);
                }
                else {
                    Off(key, value);
                }
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Flag() {

        }

        public static Flag<T> Create() {
            return new Flag<T>();
        }

        #region 비교연산
        public override Bool Equals(System.Object obj) {
            Debug.Assert(Collection != null);

            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }


            Flag<T> other = obj as Flag<T>;
            Debug.Assert(other != null);

            if (Collection.Count != other.Collection.Count) {
                return false;
            }

            foreach (var value in collection) {

                if (value.Value != other.Collection[value.Key]) {
                    return false;
                }
            }

            return true;
        }
        public static Bool operator ==(Flag<T> left, Flag<T> right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Flag<T> left, Flag<T> right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public Bool IsOn(T key) {
            Debug.Assert(key != null);

            if (!Collection.ContainsKey(key)) {
                return false;
            }

            return Collection[key];
        }
        public void On(T key, Bool val) {
            Debug.Assert(Collection != null);
            Debug.Assert(key != null);
            
            Collection[key] = val;
        }
        public void Off(T key, Bool val) {
            Debug.Assert(Collection != null);
            Debug.Assert(key != null);

            Collection[key] = val;
        }
    }
}
