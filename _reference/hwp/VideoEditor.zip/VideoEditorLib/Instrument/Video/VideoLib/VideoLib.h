/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once


#include "stdafx.h"
#include "TimelineInfo.h"
#include "OutputFileInfo.h"

//-------------------------------------------------------------------------------------------------
// FFMpeg ���� Ŭ����

#pragma warning(disable: 4251)
// warning C4251 ����
// ����� �ߴ� ������ DLL���� STL�� ����Ͽ��� �� �߻��ϴ� �����
// DLL ���ο����� ��� �� ��� �ƹ��� ������ ����. 
// ���� ��� ���� ������ �Ͽ���.
// ���� ���� : http://msdn.microsoft.com/ko-kr/library/esew7y1w.aspx

struct OutputVideoInfo {
	AVFrame* frame;
	AVPicture srcPicture;
	AVPicture dstPicture;
	Int frameCount;
	int64_t videoPts;
};

struct OutputAudioInfo {
	Float t;
	Float tincr;
	Float tincr2;
	Int16_t* samples;
	Int audioInputFrameSize;
};

struct OutputInfo {
	AVFrame* frame;
	Int frameCount;
	Int64_t videoPts;
	Int64_t audioPts;
	Int streamIndex;

	Bool isVideoOpen;
	Bool isAudioOpen;
};

struct OutputFrame {
	int streamIndex;
	AVFrame* frame;
};

class DLLTYPE VideoLib {
	vector<TimelineInfo*> timelineInfoList;
	OutputFileInfo* outputFileInfo;
	ExportInfo exportInfo;

public:
	// ������ & �Ҹ���
	VideoLib(void);
	~VideoLib(void);

	// ��� �Լ�
public:
	Int Add(Int a, Int b);
	ExportInfo GetExportInfo();
	Int GetExportState();
	void SetExportState(Int state);
	Int GetExportProgress();

	bool GetExportIsCancel();
	void SetExportIsCancel(bool isCancel);

	void ClearImage(Frame* image);

	Int FindFrame(AVFrame* frame, Int width, Int height, Int threshold);
	Int GetFrame(const Char* inputFilePath, Frame* output, Int width = 320, Int height = 240);
	Int GetFrame(const Char* inputFilePath, Int frameIndex, Frame* output, Int width=-1, Int height=-1);
	Int GetVideoInfo(const Char* inputFilePath, VideoInfoStruct* info);
	Double GetEstimateTime(const Char* inputFilePath, Int width, Int height);

	void NewTimeline();
	void DeleteTimeline();
	Int AddTimelineInfo(Char* filePath, Effect enumEffect, Int startFrame, Int endFrame);
	Int64_t GetTotalFrame(AVStream* videoStream);

	// ����
	Int CreateOutputfileInfo(const Char* outputFilePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID);
	Int DeleteOutputfileInfo();

	// ������ �ӵ� ����
	Int SetFrameRate(AVCodecContext* outputCodecContext, Int frameRate);

	// ���� ���� �ϳ��� �ٸ� ������ ���Ϸ� ���ڵ�
	Int Export(const Char* inputFilePath, const Char* outputFilePath);
	// ������ ���� ������ �ٸ� ���������� ��������
	Int Export(const Char* outputFilePath);
	Int Export();
	
	Int SaveFrame(const Char* outputFileName, AVFrame* frame, enum PixelFormat fmt, Int width, Int height, Int64_t index);

	Int PrevFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame);
	Int MoveFrame(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex);
	Int MoveFrame2(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex);
	Int MoveFrame3(AVFormatContext* formatContext, Int streamIndex, Int64_t frameIndex);

	Int64_t FrameCountToMS(AVFormatContext* formatContext, Int64_t frameNumber);
	Int64_t SeekMs(AVFormatContext* formatContext, Int streamIndex, Int tsms);
	Int ExportEx();

private:
	Int AddTimelineInfo(TimelineInfo* info);
	Int GetVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame);
	Int AVFrameToImage(AVFrame* frame, Int width, Int height, Frame* output);
	Int NewAVFrameToImage(AVFrame* frame, Int width, Int height, Frame* output);
	Bool GetDecodeVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* outputFrame);
	Bool GetEncodeVideoFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet, int streamIndex);
	Int64_t  SeekMs(Int tsms, AVStream* videoStream);
	//Bool SeekFrame(Int64_t frame);
	Bool SetVideoFrame(Int64_t dts, AVFormatContext* formatContext, AVStream* stream, AVCodecContext* codecContext, Int videoStreamIndex, AVFrame* inputFrame);
	Bool ResizeFrame(AVFrame** dstFrame, Int dstWidth, Int dstHeight, enum PixelFormat dstFmt, AVFrame* srcFrame, Int srcWidth, Int srcHeight, enum PixelFormat srcFmt);
	Bool ApplyEffect(AVFrame* dstFrame);
	Int sws_flags;

	Int GetNextFrame(AVFormatContext* formatContext, AVCodecContext* codecVideoContext, AVCodecContext* codecAudioContext, 
						   Int videoStreamIndex, Int audioStreamIndex);

	Int GetDecodeFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* videoStream, AVStream* audioStream, int64_t audioPts);

	// �Ҹ�
	//Bool GetDecodeAudioFrame(int16_t* samples, AVCodecContext* codecContext, AudioStruct* audioStruct);
	//Bool GetEncodeAudioFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet, int streamIndex);
	/*
	float t;
	float tincr;
	float tincr2;

	int16_t* samples;
	int audio_input_frame_size;
	*/

	Int InitExportEx(AVStream* videoStream, AVStream* audioStream);

	Bool CloseVideo(AVFormatContext* formatContext, AVStream* stream);
	Bool CloseAudio(AVFormatContext* formatContext, AVStream* stream);

	Int FillYuvImage(AVPicture *pict, int frame_index, int width, int height);
	//Bool GetDecodeAudioFrame(int16_t* samples, AVCodecContext* codecContext);
	Bool GetDecodeAudioFrame(int16_t* samples, int frame_size, int nb_channels);

	Int WriteVideoFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* videoStream, AVFrame* decodeFrame);
	Int WriteVideoFrame2(AVFormatContext* formatContext, AVStream* videoStream, AVStream* audioStream, int64_t audioPts);
	Int WriteAudioFrame(Int timelineInfoIndex, AVFormatContext* formatContext, AVStream* audioStream, int64_t audioPts, AVFrame* decodeFrame);
	Int WriteAudioFrame(AVFormatContext* formatContext, AVStream* stream);

	//OutputVideoInfo* outputVideoInfo;
	//OutputAudioInfo* outputAudioInfo;

	OutputInfo* outputInfo;

	Int GetBothFrame(AVFormatContext* formatContext, AVCodecContext* codecVideoContext, AVCodecContext* codecAudioContext, 
						   Int videoStreamIndex, Int audioStreamIndex, OutputFrame* outputFrame);
	
};
