﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Index = System.Int32;
using Grid = System.Windows.Controls.Grid;
using RoutedEventArgs = System.Windows.RoutedEventArgs;
using Frame = System.Double;
using Canvas = System.Windows.Controls.Canvas;

using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Base.Enum;
using System;
using System.Collections.Generic;

namespace Hnc.VideoEditor.Controls {
	public delegate void DelegateChangedTimelineInfo(TimelineInfo info);
	// ----------------------------------------------
	// Timeline 한줄에 대한 View
	// ---------------------------------------------- 
	public partial class TimelineView : Grid {
		// ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private static readonly Index NonSelectedInfo = -1;
		private double zoom = 2.0;
		private int numberUnit = 1;
		private int frameCount = 30;
		private Index _selectedInfoID = NonSelectedInfo;
		private TimelineInfo _selectedInfo = null;
		private double _endTimelinePosition = 0.0;
		public DelegateChangedTimelineInfo DelegateChangedTimelineInfoInstance = null;
		#endregion

		// ----------------------------------------------
		// 프로퍼티
		// ----------------------------------------------
		#region 프로퍼티
		public double Zoom {
			get {
				return zoom;
			}
			set {
				zoom = value * 2;
				//zoom = value;
				AllUpdate();
			}
		}

		public int NumberUnit {
			get {
				return numberUnit;
			}
			set {
				numberUnit = value;
			}
		}

		public int FrameCount {
			get {
				return frameCount;
			}
			set {
				frameCount = value;
				AllUpdate();
			}
		}

		public Index SelectedInfoID {
			get {
				return _selectedInfoID;
			}
			set {
				_selectedInfoID = value;
			}
		}

		public TimelineInfo SelectedInfo {
			get {
				return _selectedInfo;
			}
			set {
				_selectedInfo = value.Clone();
			}
		}
		#endregion

		// ----------------------------------------------
		// 생성자
		// ----------------------------------------------
		#region 생성자
		public TimelineView() {
			try {
				DelegateChangedTimelineInfoInstance = new DelegateChangedTimelineInfo(this.ChangedTimelineInfo);
				InitializeComponent();

				_selectedInfo = null;
				Zoom = 1.0;

				AllUpdate();
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}
		#endregion

		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		#region 메소드
		// TimelineView의 Info 정보 변경
		public void ChangedTimelineInfo(TimelineInfo info) {
			try {
				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					if (viewInfo.ID == info.ID) {
						viewInfo.Value = info.Clone();
						viewInfo.STATE = TimelineInfoChangedState.NoChanged;
					}
				}
				AllUpdate();
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		public void GetSourceFileList(List<String> addSourceFileList) {
			if (addSourceFileList == null) {
				return;
			}

			foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
				if (viewInfo.Path != null) {
					addSourceFileList.Add(viewInfo.Path);
				}
			}
		}

		// 새로운 TimelineInfo 추가
		public void AddTimelineInfo(TimelineInfo value) {
			try {
				TimelineInfoView viewInfo = new TimelineInfoView(this, value);
				viewInfo.info.Height = this.Height;
				infoCanvas.Children.Add(viewInfo);
				AllUpdate();

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					/*
					if (_endTimelinePosition - 200.0 > 0) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.ScrollViewerPosition(_endTimelinePosition);
					} else {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.ScrollViewerPosition(0.0);
					}
					*/
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		public double GetTimelineFrameCount() {
			double frameCount = 0.0;
			try {
				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					frameCount += viewInfo.Value.TimelineScope.LENGTH;
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
			return frameCount;
		}

		public double GetTimelineLength() {
			double length = 0.0;
			try {
				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					if (viewInfo.TimelineScope.END > length) {
						length = viewInfo.TimelineScope.END;
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
			return length;
		}

		public int GetTimelinInfoCount() {
			try {
				return infoCanvas.Children.Count;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
			return 0;
		}

		// id에 해당하는 TimelineInfo 삭제
		public void RemoveTimelineInfo(int id) {
			try {
				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					if (viewInfo.ID == id) {
						infoCanvas.Children.Remove(viewInfo);
						break;
					}
				}

				if (infoCanvas.Children.Count != 0) {
					TimelineInfoView viewInfo = infoCanvas.Children[0] as TimelineInfoView;

					if (viewInfo != null) {
						viewInfo.Select = true;
					}
				} else {
					ClearSelect();
				}

				AllUpdate();

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					/*
					if (_endTimelinePosition - 200.0 > 0) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.ScrollViewerPosition(_endTimelinePosition);
					} else {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.ScrollViewerPosition(0.0);
					}
					*/
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		// 모든 TimelineInfo 삭제
		public void RemoveAll() {
			try {
				infoCanvas.Children.Clear();
				SelectedInfoID = NonSelectedInfo;
				AllUpdate();
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		public int SelectFirstTimeline() {
			ClearSelect();

			TimelineInfoView selectInfo = null;

			int count = 0;
			foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
				if (count == 0) {
					selectInfo = viewInfo;
				} else {
					if (selectInfo.TimelineScope.START > viewInfo.TimelineScope.START) {
						selectInfo = viewInfo;
					}
				}
				++count;
			}

			if (selectInfo != null) {
				selectInfo.SelectInfo();
			}

			return infoCanvas.Children.Count;
		}

		// 선택된 TimelineInfo 선택 해제
		public void ClearSelect() {
			try {
				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					Canvas.SetZIndex(viewInfo, viewInfo.ZIndex);
					viewInfo.Select = false;
				}

				SelectedInfoID = NonSelectedInfo;
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		// 모든 TimelineInfo 상태 업데이트
		public void AllUpdate() {
			try {
				double endTime = 0.0;

				foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
					viewInfo.Update(zoom, numberUnit, frameCount);
					if (endTime < viewInfo.TimelineScope.END) {
						endTime = viewInfo.TimelineScope.END;
					}
				}

				int totalSec = 0;
				try {
					totalSec = (int)(endTime / frameCount);
				} catch (DivideByZeroException) {
					Hnc.Type.Debug.Assert(false, "AllUpdate 0으로 나누려고 했습니다.");
					totalSec = 0;
				}

				int min = totalSec / 60;
				int sec = totalSec % 60;

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.SetStatusbar(min, sec);
					Hnc.VEFrame.VEFrameManager.Instance.MainPage.ChangeMeinMenuState();
				}

				if (zoom > 0) {
					try {
						endTime = (endTime * zoom) / numberUnit;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "AllUpdate 0으로 나누려고 했습니다.");
						endTime = 0.0;
					}
				} else if (zoom == 0.0) {
					zoom = 1.0;
					try {
						endTime = (endTime / System.Math.Abs(zoom)) / numberUnit;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "AllUpdate 0으로 나누려고 했습니다.");
						endTime = 0.0;
					}
				} else {
					try {
						endTime = (endTime / System.Math.Abs(zoom)) / numberUnit;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "AllUpdate 0으로 나누려고 했습니다.");
						endTime = 0.0;
					}
				}

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					_endTimelinePosition = endTime;
					if ((int)endTime > 2000) {
						Hnc.VEFrame.VEFrameManager.Instance.MainPage.TimelineControl.Width = endTime + 200.0;
					}
				}
			} catch {
				Hnc.Type.Debug.Assert(false, "TimelineView Exception");
			}
		}

		/*
		public Frame GetTotalFrame() {
			Frame totalFrame = 0.0;

			foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
				if (viewInfo.TimelineScope.END > totalFrame) {
					totalFrame = viewInfo.TimelineScope.END;
				}
			}

			return totalFrame;
		}
 
		 public int GetNewTimelineInfoID() {
			 return infoCanvas.Children.Count + 1;
		 }


		 public Frame GetNewStartFrame() {
			 Frame lastFrame = 0.0;

			 foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
				 if (viewInfo.TimelineScope.END > lastFrame) {
					 lastFrame = viewInfo.TimelineScope.END;
				 }
			 }

			 return lastFrame;
		 }
         
		 public void ChangedTimelineInfo(int id, string path, FrameScope scope, Frame totalFrame) {
			foreach (TimelineInfoView viewInfo in infoCanvas.Children) {
				if (viewInfo.ID == id) {
					viewInfo.Path = path;
					viewInfo.TimelineScope = scope;
					viewInfo.TotalFrame = totalFrame;
					viewInfo.STATE = TimelineInfoChangedState.NoChanged;
				}
			}

			AllUpdate();
		}
		 */
		#endregion
	}
}