﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using Hnc.VEFrame.Controls;
using Hnc.VEFrame.Controls.Layout;
using System.Windows.Media.Animation;
using System.Collections.Generic;
using System.Threading;
using System.Globalization;
using Grid = System.Windows.Controls.Grid;
using System.IO;
using Debug = Hnc.Type.Debug;
using Hnc.VideoEditor.Pages;
using System.Windows.Media;
using Hnc.VideoEditor.Base.Enum;

namespace Hnc.VEFrame {

	public class VEFrameManager {
		#region 생성자
		private VEFrameManager() {
			InitWindow();
			isLoaded = true;
		}
		#endregion // 생성자

		#region 싱글톤
		private static VEFrameManager instance;

		public static VEFrameManager Instance {
			get {
				if (instance == null)
					instance = new VEFrameManager();

				return instance;
			}
		}
		#endregion // 싱글톤

		#region 멤버변수
		private static bool isLoaded = false;
		// VEFrameManager에서 관리되는 주 윈도우.
		private Window rootWindow;
		private MainWindowDockPanel dockPanel;
		private TitleBar titleBar;
		private Hnc.VideoEditor.Controls.TitleBar titleBarGrid;
		private StatusBar statusBar;
		private MainWindow mainWindow;
		private StartPage startPage;
		private MainPage mainPage;
		private Hnc.VEFrame.Controls.ToolBar topToolBar;
		private Hnc.VEFrame.Controls.ToolBar bottomToolBar;
		private PageState pageState = PageState.None;
		#endregion // 멤버변수

		#region 프로퍼티
		public static bool IsLoaded {
			get {
				return isLoaded;
			}
		}

		public Window RootWindow {
			get {
				return rootWindow;
			}
			set {
				rootWindow = value;
			}
		}
		public TitleBar TitleBar {
			get {
				return titleBar;
			}
			set {
				titleBar = value;
			}
		}
		public Hnc.VideoEditor.Controls.TitleBar TitleBarGrid {
			get {
				return titleBarGrid;
			}
			set {
				titleBarGrid = value;
			}
		}

		public StatusBar StatusBar {
			get {
				return statusBar;
			}
			set {
				statusBar = value;
			}
		}
		public ToolBar TopToolBar {
			get {
				return topToolBar;
			}
			set {
				topToolBar = value;
			}
		}
		public ToolBar BottomToolBar {
			get {
				return bottomToolBar;
			}
			set {
				bottomToolBar = value;
			}
		}
		public MainWindow MainWindow {
			get {
				return mainWindow;
			}
			set {
				mainWindow = value;
			}
		}
		public MainPage MainPage {
			get {
				return mainPage;
			}
		}
		#endregion // 프로퍼티

		#region 숨김 멤버변수
		// 윈도우 생성 및 구조 초기화
		private void InitWindow() {
			// rootWindow 생성
			rootWindow = new Window();

			// rootWindow 설정
			rootWindow.Title = Application.Current.Resources["IDS_VideoEditor"] as String;
			rootWindow.Width = 1366;
			rootWindow.Height = 768;
			rootWindow.MinWidth = 800;
			rootWindow.MinHeight = 600;
			rootWindow.SnapsToDevicePixels = true;
			rootWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			rootWindow.WindowStyle = WindowStyle.None;
			rootWindow.AllowsTransparency = true;

			System.Windows.Controls.ControlTemplate template =
				Application.Current.FindResource("WindowTemplate") as System.Windows.Controls.ControlTemplate;
			Debug.Assert(template != null);
			rootWindow.Template = template;

			// 프레임 구조를 위한 dockpanel 생성
			dockPanel = new MainWindowDockPanel();
			rootWindow.Content = dockPanel;
			dockPanel.Background = Application.Current.Resources["ImageBrush.Background"] as ImageBrush;
			//rootWindow.Background = Application.Current.Resources["ImageBrush.Background"] as ImageBrush;

			// 멤버변수 연결
			titleBar = dockPanel.TitleBar;
			statusBar = dockPanel.StatusBar;
			mainWindow = dockPanel.MainWindow;

			topToolBar = mainWindow.topToolBar;
			bottomToolBar = mainWindow.bottomToolBar;

			startPage = new StartPage();
			mainPage = new MainPage();
		}
		#endregion // 멤버변수

		#region 공개 멤버변수
		public void GoStartPage() {
			mainWindow.Workspace.Children.Clear();
			mainWindow.Workspace.Children.Add(startPage);
			pageState = PageState.StartPage;
		}

		public void GoMainPage() {
			mainWindow.Workspace.Children.Clear();
			mainWindow.Workspace.Children.Add(mainPage);
			pageState = PageState.MainPage;
		}

		public bool IsExistOpenedAppBar() {
			if (pageState == PageState.MainPage) {
				return mainPage.IsExistOpenedAppBar();
			}

			return false;
		}

		public void SwitchAppBarState(bool isOpen) {
			if (pageState == PageState.MainPage) {
				mainPage.SwitchAppBarState(isOpen);
			}
		}

		public void SetTitleBar(Grid grid) {
			titleBar.Content = grid;
		}

		public void SetTitleBar(Hnc.VideoEditor.Controls.TitleBar grid) {
			titleBarGrid = grid;
			titleBar.Content = grid;
            grid.Parent = titleBar;

            titleBar.Child = grid;
		}

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 이하 titleBar, statusBar, toolBar show/hide/isShow 함수
		// toolBar show 함수에는 해당 애니메이션 부분이 추가 되어 있음.
		public void ShowTitleBar() {
			titleBar.Visibility = Visibility.Visible;
		}
		public void ShowStatusBar() {
			statusBar.Visibility = Visibility.Visible;
		}

		public void ShowTopToolBar() {
			topToolBar.Visibility = Visibility.Visible;

			// show 애니메이션
			ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
			Thickness thickness = new Thickness();
			thickness.Top = -topToolBar.Height;
			thicknessAnimation.From = thickness;
			thickness.Top = 0;
			thicknessAnimation.To = thickness;
			thicknessAnimation.Duration = TimeSpan.FromSeconds(0.1);
			topToolBar.BeginAnimation(ToolBar.MarginProperty, thicknessAnimation);
		}
		public void ShowBottomToolBar() {
			bottomToolBar.Visibility = Visibility.Visible;

			// show 애니메이션
			ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
			Thickness thickness = new Thickness();
			thickness.Bottom = -bottomToolBar.Height;
			thicknessAnimation.From = thickness;
			thickness.Bottom = 0;
			thicknessAnimation.To = thickness;
			thicknessAnimation.Duration = TimeSpan.FromSeconds(0.1);
			bottomToolBar.BeginAnimation(ToolBar.MarginProperty, thicknessAnimation);
		}

		public void HideTitleBar() {
			titleBar.Visibility = Visibility.Collapsed;
		}
		public void HideStatusBar() {
			statusBar.Visibility = Visibility.Collapsed;
		}
		public void HideTopToolBar() {
			topToolBar.Visibility = Visibility.Collapsed;
		}
		public void HideBottomToolBar() {
			bottomToolBar.Visibility = Visibility.Collapsed;
		}
		public bool IsShowTitleBar() {
			if (titleBar.Visibility == Visibility.Visible) {
				return true;
			}
			return false;
		}
		public bool IsShowStatusBar() {
			if (statusBar.Visibility == Visibility.Visible) {
				return true;
			}
			return false;
		}
		public bool IsShowTopToolBar() {
			if (topToolBar.Visibility == Visibility.Visible) {
				return true;
			}
			return false;
		}
		public bool IsShowBottomToolBar() {
			if (bottomToolBar.Visibility == Visibility.Visible) {
				return true;
			}
			return false;
		}
		#endregion // 공개 멤버변수
	}
}