﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace Hnc.Control
{
	public class FlexibleTab : System.Windows.Controls.TabControl
	{
		static FlexibleTab()
		{
			DefaultStyleKeyProperty.OverrideMetadata(typeof(FlexibleTab), new FrameworkPropertyMetadata(typeof(FlexibleTab)));
		}

		private Button addButton;
		private TabPanel tabPanel;

		public static readonly RoutedEvent AddTabEvent =
			EventManager.RegisterRoutedEvent(
				"AddTab",
				RoutingStrategy.Bubble,
				typeof(RoutedEventHandler),
				typeof(FlexibleTab)
			);

        public static readonly DependencyProperty ImageSourceProperty =
            DependencyProperty.Register(
                "ImageSource",
                typeof(string),
                typeof(FlexibleTab),
                new PropertyMetadata("")
            );
        public string ImageSource
        {
            get { return (string)GetValue(ImageSourceProperty); }
            set { SetValue(ImageSourceProperty, value); }
        }

        public static readonly DependencyProperty ImageHeightProperty = 
            DependencyProperty.Register("ImageHeight",
                typeof(double),
                typeof(FlexibleTab), 
                new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));
        public double ImageHeight
        {
            get { return (double)GetValue(ImageHeightProperty); }
            set { SetValue(ImageHeightProperty, value); }
        }

        public static readonly DependencyProperty ImageWidthProperty = 
                DependencyProperty.Register("ImageWidth", 
                typeof(double),
                typeof(FlexibleTab), 
                new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));
        public double ImageWidth
        {
            get { return (double)GetValue(ImageWidthProperty); }
            set { SetValue(ImageWidthProperty, value); }
        }

        public static readonly DependencyProperty ImageMarginProperty =
                DependencyProperty.Register("ImageMargin", 
                typeof(double),
                typeof(FlexibleTab),
                new FrameworkPropertyMetadata(2.0));
        public double ImageMargin
        {
            get { return (double)GetValue(ImageMarginProperty); }
            set { SetValue(ImageMarginProperty, value); }
        }

        public static readonly DependencyProperty ImageVisibilityProperty =
            DependencyProperty.Register(
                "ImageVisibility",
                typeof(Visibility),
                typeof(FlexibleTab),
                new PropertyMetadata(Visibility.Visible)
            );
        public Visibility ImageVisibility
        {
            get { return (Visibility)GetValue(ImageVisibilityProperty); }
            set { SetValue(ImageVisibilityProperty, value); }
        }
        


		public event RoutedEventHandler AddTab
		{
			add { AddHandler(AddTabEvent, value); }
			remove { RemoveHandler(AddTabEvent, value); }
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			addButton = GetTemplateChild("AddButton") as Button;
			tabPanel = GetTemplateChild("HeaderPanel") as TabPanel;

			if (addButton == null)
			{
				System.Diagnostics.Debug.Assert(false, "Skin에서 AddButton을 찾을 수 없어서 이벤트를 설정할 수 없습니다.");
			}
			else
			{
				addButton.Click += new RoutedEventHandler(addButton_Click);
			}

			if (tabPanel == null)
			{
				System.Diagnostics.Debug.Assert(false, "Skin에서 HeaderPanel을 찾을 수 없어서 크기를 구할 수 없습니다.");
			}
		}

		// TabPanel 크기를 구하기 위한 코드로 TabControl 자체 Measure에 관여하지 않음
		protected override Size MeasureOverride(Size constraint)
		{
			if (addButton == null || tabPanel == null)
				return base.MeasureOverride(constraint);

			if (this.ActualHeight > 0.0)
			{
				if (addButton.Width.CompareTo(double.NaN) == 0)
					addButton.Width = addButton.ActualWidth;

				Size idealSize = new Size(0, 0);
				Size size = new Size(Double.PositiveInfinity, Double.PositiveInfinity);
				foreach (UIElement child in Items)
				{
					child.Measure(size);
					idealSize.Width += child.DesiredSize.Width;
					idealSize.Height = Math.Max(idealSize.Height, child.DesiredSize.Height);
				}

				if (idealSize.Width < this.ActualWidth - addButton.ActualWidth - addButton.Margin.Left - tabPanel.Margin.Right)
				{
					tabPanel.Width = double.NaN;
				}
				else
				{
					tabPanel.Width = this.ActualWidth - addButton.ActualWidth - addButton.Margin.Left - tabPanel.Margin.Right;
				}
			}
			return base.MeasureOverride(constraint);
		}

		void addButton_Click(object sender, RoutedEventArgs e)
		{
			RaiseEvent(new RoutedEventArgs(AddTabEvent, this));
		}

		// 아래 부분은 FlexibleTabItem의 사용 예제입니다.
		// 앱에서 아래 부분을 구현해서 Tab Close 시 필요한 액션을 구현하시면 됩니다.
		// 테스트로 FlexibleTab을 사용할 경우 닫기 버튼 클릭 시 바로 Close 됩니다.
		//public FlexibleTab()
		//{
		//    AddHandler(FlexibleTabItem.CloseTabEvent, new RoutedEventHandler(CloseTab));
		//}

		//private void CloseTab(object source, RoutedEventArgs args)
		//{
		//    // 변경사항 있을 때 저장 후 닫기 등의 처리는 앱에서 구현해야 합니다.
		//    FlexibleTabItem item = args.Source as FlexibleTabItem;
		//    if (item != null)
		//        Items.Remove(item);
		//}
	}

	public class FlexibleTabItem : System.Windows.Controls.TabItem
	{
		private Button closeButton;

		public static readonly DependencyProperty IsCloseableProperty =
			DependencyProperty.Register(
				"IsCloseable",
				typeof(bool),
				typeof(TabItem),
				new PropertyMetadata(true)
			);

		public bool IsCloseable
		{
			get { return (bool)GetValue(IsCloseableProperty); }
			set
			{
				SetValue(IsCloseableProperty, value);

				if (closeButton != null)
					CloseableChanged();
			}
		}

		public static readonly RoutedEvent CloseTabEvent =
			EventManager.RegisterRoutedEvent(
				"CloseTab",
				RoutingStrategy.Bubble,
				typeof(RoutedEventHandler),
				typeof(FlexibleTabItem)
			);

		public event RoutedEventHandler CloseTab
		{
			add { AddHandler(CloseTabEvent, value); }
			remove { RemoveHandler(CloseTabEvent, value); }
		}

		protected override void OnSelected(RoutedEventArgs e)
		{
			base.OnSelected(e);

			if (closeButton != null)
				closeButton.Visibility = Visibility.Visible;
		}

		protected override void OnUnselected(RoutedEventArgs e)
		{
			base.OnUnselected(e);

			if (closeButton != null)
				closeButton.Visibility = Visibility.Hidden;
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			closeButton = GetTemplateChild("CloseButton") as Button;

			if (closeButton == null)
			{
				System.Diagnostics.Debug.Assert(false, "Skin에서 CloseButton을 찾을 수 없어서 Closeable을 설정할 수 없습니다.");
				IsCloseable = false;
			}
			else
			{
				CloseableChanged();
			}
		}

		private void CloseableChanged()
		{
			if (IsCloseable)
			{
				if (IsSelected)
					closeButton.Visibility = Visibility.Visible;
				else
					closeButton.Visibility = Visibility.Hidden;

				closeButton.Click += new RoutedEventHandler(button_Click);
			}
			else
			{
				closeButton.Click -= button_Click;
				closeButton.Visibility = Visibility.Collapsed;
			}
		}

		void button_Click(object sender, RoutedEventArgs e)
		{
			RaiseEvent(new RoutedEventArgs(CloseTabEvent, this));
		}
	}
}
