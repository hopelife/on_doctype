﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows.Controls;
using System.Collections.Generic;
using Hnc.Control;
using Hnc.Instrument;
using System.IO;
using System.Windows;
using System.Collections.ObjectModel;
using Hnc.VideoEditor.Service;
using Hnc.VideoEditor.Util;
using Microsoft.Win32;

namespace Hnc.VideoEditor.Pages {
	// ----------------------------------------------
	// 위에 뜨는 Appbar에 표시될 불러온 비디오 파일 목록
	// ----------------------------------------------
	public partial class LoadStatusBar : Grid {
		// ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private MainPage mainPage = null;
		private static readonly int imageWidth = 96;
		private static readonly int imageHeight = 72;
		private static readonly int imageMargin = 5;
		private int nextID = 0;
		#endregion

		// ----------------------------------------------
		// 생성자
		// ----------------------------------------------
		#region 생성자
		private LoadStatusBar() {
			InitializeComponent();
		}

		public LoadStatusBar(MainPage mainPage) {
			InitializeComponent();

			this.mainPage = mainPage;
			//LoadPhotoListBox.ItemsSource = listItems;
		}
		#endregion

		// ----------------------------------------------
		// 메소드
		// ----------------------------------------------
		#region 메소드
		private void SelectedListBoxChanged(object sender, SelectionChangedEventArgs e) {
			if (e.AddedItems.Count > 0) {
				PhotoListBoxItem selectedItem = e.AddedItems[0] as PhotoListBoxItem;

				if (selectedItem != null) {
					if (mainPage != null) {
						mainPage.ChangeSelectFile(selectedItem.Path);
						mainPage.OpenVideoFile(selectedItem.Path);
						mainPage.TimelineClearSelect();

						mainPage.ChangePlayState(false);
					}
				}
			}
		}
		#endregion

		public void ClearSourceFileList() {
			if (LoadPhotoListBox.Items.Count <= 0) {
				return;
			}

			LoadPhotoListBox.Items.Clear();
		}

		public String GetFileSize(long size) {
			List<String> fileUints = new List<string>();
			fileUints.Add(" KB");
			fileUints.Add(" MB");
			fileUints.Add(" GB");

			double step = 1.0;
			String selectFileUint = " BYTE";
			if (Math.Round(size / step, 2) > 1.0) {
				step *= 1024;

				foreach (String fileUint in fileUints) {
					if (Math.Round(size / step, 2) > 1.0) {
						step *= 1024.0;
						selectFileUint = fileUint;
					} else {
						break;
					}
				}

				step /= 1024.0;
			}

			return Math.Round(size / step, 2) + selectFileUint;
		}

		List<FileStream> fileList = new List<FileStream>();
		public void AddSourceFile(List<String> addSourcePaths, bool load) {
			if (addSourcePaths.Count != 0) {
				int addItemCount = 0;

				foreach (String path in addSourcePaths) {
					bool check = false;

					foreach (PhotoListBoxItem oldItem in LoadPhotoListBox.Items) {
						if (oldItem.Path == path) {
							check = true;
							break;
						}
					}

					if (check != true) {
						Image newImage = ControlUtil.CreateImageControl(VideoUtil.GetVideoAutoThumbnail(path, imageWidth, imageHeight));
						PhotoListBoxItem newItem = new PhotoListBoxItem(nextID.ToString(), path, newImage);
						++nextID;

						VideoContentInfo info = VideoUtil.GetVideoContentInfo(path);

						String information = "";
						FileInfo fileInfo = new FileInfo(path);
                        information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                        information += Application.Current.Resources["IDS_Size"] as String + ": " + GetFileSize(fileInfo.Length) + Environment.NewLine;

                        information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                        information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                        information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
						newItem.Information = information;
						
						LoadPhotoListBox.Items.Add(newItem);
						++addItemCount;
					}
				}

				if (addItemCount > 0 && load == true) {
					//LoadPhotoListBox.SelectedItem = LoadPhotoListBox.Items[LoadPhotoListBox.Items.Count - 1];
				}
			}
		}

		public void AddSourceFile(List<String> addSourcePaths) {
			AddSourceFile(addSourcePaths, true);
		}

		public void AddSourceFile(String[] addSourcePaths) {
			List<String> listPaths = new List<String>(addSourcePaths);
			AddSourceFile(listPaths, true);
		}

		public void AddSourceFile() {
			/*
            FileDialog filePage = new FileDialog(FileDialog.Mode.Open, FileDialog.VideoExtentions, SetupManager.Instance.LastOpendDirectory);

			if (filePage.ShowDialog() == true) {
				SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;
				AddSourceFile(filePage.SelectedPaths);
			}

			System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);
			*/
			// OpenFileDialog dlgOpen = new OpenFileDialog();

			System.Windows.Forms.OpenFileDialog dlgOpen = new System.Windows.Forms.OpenFileDialog();

            string mediaFiles = Application.Current.Resources["IDS_MediaFiles"] as String;
            mediaFiles += "|*.mp4;*.avi;*.wmv;*.mkv;*.ts|AllFile(*.*)|*.*";

            dlgOpen.Filter = mediaFiles;
            dlgOpen.Title = Application.Current.Resources["IDS_VideoLoad"] as String;
			dlgOpen.Multiselect = true;

			if (dlgOpen.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
				AddSourceFile(dlgOpen.FileNames);
			}
		}

		private void AddFile(object sender, System.Windows.RoutedEventArgs e) {
			AddSourceFile();
		}

		public bool IsSelectedItem() {
			if (LoadPhotoListBox.SelectedItem == null) {
				return false;
			}

			return true;
		}

		public int RenameItem(String oldFilePath, String newFilePath) {
			int count = 0;
			foreach (PhotoListBoxItem item in LoadPhotoListBox.Items) {
				if (item.Path == oldFilePath) {
					item.Path = newFilePath;
					item.ItemName = System.IO.Path.GetFileName(newFilePath);

					VideoContentInfo info = VideoUtil.GetVideoContentInfo(newFilePath);
					String information = "";
					FileInfo fileInfo = new FileInfo(newFilePath);
                    information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                    information += Application.Current.Resources["IDS_Size"] as String + ": " + GetFileSize(fileInfo.Length) + Environment.NewLine;
                    information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                    information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                    information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
					item.Information = information;

					++count;
				}
			}
			return count;
		}

		public void SetSelectedItems(IList<string> paths) {
			foreach (String path in paths) {
				//PhotoListBoxItem newItem = new PhotoListBoxItem(path, ControlUtil.CreateImageControl(VideoUtil.GetVideoAutoThumbnail(path, 96, 72)));

				Image newImage = ControlUtil.CreateImageControl(VideoUtil.GetVideoAutoThumbnail(path, imageWidth, imageHeight));
				PhotoListBoxItem newItem = new PhotoListBoxItem(nextID.ToString(), path, newImage);
				++nextID;

				VideoContentInfo info = VideoUtil.GetVideoContentInfo(path);

				String information = "";
				FileInfo fileInfo = new FileInfo(path);
                information += Environment.NewLine + Application.Current.Resources["IDS_Path"] as String + ": " + fileInfo.DirectoryName + Environment.NewLine;
                information += Application.Current.Resources["IDS_Size"] as String + ": " + GetFileSize(fileInfo.Length) + Environment.NewLine;
                information += Application.Current.Resources["IDS_ModifiedTime"] as String + ": " + info.ModifyDate + Environment.NewLine;
                information += Application.Current.Resources["IDS_RunningTime"] as String + ": " + info.RunningTime + Environment.NewLine;
                information += Application.Current.Resources["IDS_FrameRate"] as String + ": " + info.FrameRate.ToString("F02") + Environment.NewLine;
				newItem.Information = information;

				FileManager.Instance.AddWatcherFile(newItem.Path);
				FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read);
				fileList.Add(stream);
				LoadPhotoListBox.Items.Add(newItem);
			}

			//LoadPhotoListBox.Sort(PhotoListBox.SortType.Id_Asc);

			if (LoadPhotoListBox.Items.Count > 0) {
				PhotoListBoxItem item = LoadPhotoListBox.Items[0] as PhotoListBoxItem;
				if (item != null) {
					LoadPhotoListBox.SelectedItem = item;
				} else {
					LoadPhotoListBox.SelectedItem = null;
				}
			} else {
				LoadPhotoListBox.SelectedItem = null;
			}
		}

		void Content_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
			e.Handled = true;
		}

		private void Grid_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {

			Point position = e.GetPosition(LoadPhotoListBox);

			double itemHeight = LoadPhotoListBox.Items.Count * imageHeight;
			itemHeight += (LoadPhotoListBox.Items.Count - 1) * imageMargin;

			if (itemHeight < position.Y) {
				if (Hnc.VEFrame.VEFrameManager.Instance.IsExistOpenedAppBar()) {
					Hnc.VEFrame.VEFrameManager.Instance.SwitchAppBarState(false);
				} else {
					Hnc.VEFrame.VEFrameManager.Instance.SwitchAppBarState(true);
				}
			}

			e.Handled = true;
		}

		private void Sort_ID_Click(object sender, RoutedEventArgs e) {
			LoadPhotoListBox.Sort(PhotoListBox.SortType.Id_Asc);
			SortIDBtn.IsEnabled = false;
			SortNameBtn.IsEnabled = true;
			SortDateBtn.IsEnabled = true;
		}

		private void Sort_Name_Click(object sender, RoutedEventArgs e) {
			LoadPhotoListBox.Sort(PhotoListBox.SortType.Name_Acs);
			SortIDBtn.IsEnabled = true;
			SortNameBtn.IsEnabled = false;
			SortDateBtn.IsEnabled = true;
		}

		private void Sort_Date_Click(object sender, RoutedEventArgs e) {
			LoadPhotoListBox.Sort(PhotoListBox.SortType.Date_Acs);
			SortIDBtn.IsEnabled = true;
			SortNameBtn.IsEnabled = true;
			SortDateBtn.IsEnabled = false;
		}
	}
}