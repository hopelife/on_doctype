﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Index = System.Int32;
using Grid = System.Windows.Controls.Grid;

using Hnc.VideoEditor.Base.Type;

namespace Hnc.VideoEditor.Appbar {
    // ----------------------------------------------
    // 사운드 설정 창
    // ----------------------------------------------
    public partial class SoundAppbar : Grid {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        #region 속성
        private static readonly Index NonSelectedInfo = -1;
        private Index _selectedInfoID = NonSelectedInfo;
        private TimelineInfo _selectedInfo = null;
        #endregion

        // ----------------------------------------------
        // 프로퍼티
        // ----------------------------------------------
        #region 프로퍼티
        public Index SelectedInfoID {
            get { return _selectedInfoID; }
            set { _selectedInfoID = value; }
        }

        public TimelineInfo SelectedInfo {
            get { return _selectedInfo; }
            set {
                if (value != null) {
                    _selectedInfo = value.Clone();
                } else {
                    _selectedInfo = null;
                }
            }
        }
        #endregion

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        #region 생성자
        public SoundAppbar() {
            InitializeComponent();
            _selectedInfoID = NonSelectedInfo;
            _selectedInfo = null;
        }
        #endregion
    }
}
