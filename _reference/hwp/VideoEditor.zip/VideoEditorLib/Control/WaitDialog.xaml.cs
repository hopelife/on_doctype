﻿using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System;

namespace Hnc.Control {
    public partial class WaitDialog : Window {

        #region -> Fields

        private Timer timer;

        #endregion

        #region -> Events

        /// <summary>
        /// 취소 버튼을 클릭했을 때 발생하는 이벤트입니다.
        /// </summary>
        public event EventHandler Canceled;

        #endregion

        #region -> Properties

        public String Message {
            set { message.Text = value; }
        }

        public String Percentage {
            set { percentage.Text = value; }
        }

        #endregion

        #region -> Constructors

        public WaitDialog() {

            InitializeComponent();

            this.Owner = Application.Current.MainWindow;

            if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
                this.WindowState = WindowState.Maximized;
            } else {
                this.Width = Application.Current.MainWindow.ActualWidth;
                this.Height = Application.Current.MainWindow.ActualHeight;
				//this.BGGrid.Background = Brushes.Blue;
            }

            this.Loaded += new RoutedEventHandler(WaitDialog_Loaded);
            this.Closed += new EventHandler(WaitDialog_Closed);
        }

        public WaitDialog(bool enableBackground, bool enabledCancel) {

            InitializeComponent();

            this.Owner = Application.Current.MainWindow;

            if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
                this.WindowState = WindowState.Maximized;
            } else {
                this.Width = Application.Current.MainWindow.ActualWidth;
                this.Height = Application.Current.MainWindow.ActualHeight;
            }

            this.Loaded += new RoutedEventHandler(WaitDialog_Loaded);
            this.Closed += new EventHandler(WaitDialog_Closed);

			if (!enableBackground)
				this.Background = Brushes.Red;
                //this.Background = Brushes.Transparent;

            if (enabledCancel)
                this.cancelBtn.Visibility = Visibility.Visible;
        }

        #endregion

        private void WaitDialog_Loaded(object sender, RoutedEventArgs e) {
            timer = new Timer(100);
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            timer.Start();
        }

        private void WaitDialog_Closed(object sender, EventArgs e) {
            timer.Stop();
            timer.Close();
        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e) {
            this.Dispatcher.Invoke(new Action(delegate() {

                SpinnerRotate.Angle += 30;

                if (SpinnerRotate.Angle == 360)
                    SpinnerRotate.Angle = 0;

            }), DispatcherPriority.Render);
        }

        private void OnCanceled() {
            if (Canceled != null)
                Canceled(this, null);
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e) {
            OnCanceled();
        }
    }
}
