﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using Count = System.Int32;
using Index = System.Int32;

using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace Hnc.Type {

    // Map에 저장되는 Key-Value 쌍
    // 혹은 쌍으로 관리되어야 하는 데이터
    // key는 !null
    public sealed class MapPair<TKey, TValue> {
        public readonly TKey key;
        public TKey Key { get { return key; } }

        public TValue Value { get; set; }
                

        private MapPair(TKey key, TValue value) {
            Debug.AssertThrow(key != null, eErrorCode.NullArgument);

            this.key = key;
            Value = value;
        }
        public static MapPair<TKey, TValue> Create(TKey key, TValue value) {
            return new MapPair<TKey, TValue>(key, value);
        }
    }

    // Key-Value 쌍 저장
    public sealed class Map<TKey, TValue> : IEnumerable<MapPair<TKey, TValue>>, System.IDisposable {


        #region Enumerator - Map 열거자

        public sealed class Enumerator : IEnumerator<MapPair<TKey, TValue>> {

            // ----------------------------------------------
            // 속성
            // ----------------------------------------------
            private Index Pos { get; set; }
            private Dictionary<TKey, TValue> Collection { get; set; }

            public MapPair<TKey, TValue> Current {
                get {
                    Debug.Assert(Collection != null);
                   
                    KeyValuePair<TKey, TValue> pair = Collection.ElementAt<KeyValuePair<TKey, TValue>>(Pos); // System.Core, throw 발생

                    return MapPair<TKey, TValue>.Create(pair.Key, pair.Value);
                }

            }
            object System.Collections.IEnumerator.Current {
                get {
                    return Current;
                }
            }

            // ----------------------------------------------
            // 생성자 / 연산자
            // ----------------------------------------------
            private Enumerator(System.Collections.Generic.Dictionary<TKey, TValue> collection) {
                Debug.AssertThrow(collection != null, eErrorCode.NullArgument);
                Collection = collection;
                Pos = -1;
            }
            public static Enumerator Create(Dictionary<TKey, TValue> collection) {
                return new Enumerator(collection);
            }

            // ----------------------------------------------
            // 메서드
            // ----------------------------------------------

            public void Dispose() {
            }

            public Bool MoveNext() {
                Debug.Assert(Collection != null);

                ++Pos;
                if (Pos == Collection.Count) return false;
                return true;
            }
            public void Reset() {
                Pos = -1;
            }

        }
        #endregion

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Dictionary<TKey, TValue> collection = new Dictionary<TKey, TValue>();
        private Dictionary<TKey, TValue> Collection {
            get {
                Debug.Assert(collection != null);
                return collection;
            }
        }

        public TValue this[TKey key] {
            get {
                Debug.Assert(Collection != null);
                Debug.AssertThrow(key != null, eErrorCode.NullArgument);

                return Collection[key];
            }
            set {
                Debug.Assert(Collection != null);
                Debug.AssertThrow(key != null, eErrorCode.NullArgument);
                Debug.AssertThrow(value != null, eErrorCode.NullArgument);

                Collection[key] = value;
            }
        }
        public Count Count {
            get {
                Debug.Assert(Collection != null);

                return Collection.Count; 
            }
        }
        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Map() {
        }
        public static Map<TKey, TValue> Create() {
            return new Map<TKey, TValue>();
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
         #region IDispose
        public void Dispose() {
            Debug.Assert(Collection != null);

            foreach (var item in Collection) {
                if (item.Value != null && item.Value is System.IDisposable) {
                    (item.Value as System.IDisposable).Dispose();
                }
            }
            Collection.Clear();
        }
        #endregion
        
        #region IEnumerable 구현 - foreach 지원
        public IEnumerator<MapPair<TKey, TValue>> GetEnumerator() {
            Debug.Assert(Collection != null);

            return Enumerator.Create(Collection);
        }
        IEnumerator IEnumerable.GetEnumerator() {
            return GetEnumerator();
        }
        #endregion



        public Bool ContainsKey(TKey key) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(key != null, eErrorCode.NullArgument);
            
            return Collection.ContainsKey(key);
        }
        public Bool Remove(TKey key) {
            Debug.Assert(Collection != null);
            Debug.AssertThrow(key != null, eErrorCode.NullArgument);

            return Collection.Remove(key);
        }

    }
}
