﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Controls {
	using Int = System.Int32;
	using System.Windows.Controls;
	using System.Windows;

	public partial class SpinControl : UserControl {

		#region 멤버변수
		private Int _value;
		#endregion // 멤버변수

		#region 프로퍼티
		public Int Value {
			get {
				return _value;
			}
			set {
				_value = value;
				textBox.Text = _value.ToString();
			}
		}

		// Min
		public Int Min {
			get {
				return (Int)GetValue(MinProperty);
			}
			set {
				SetValue(MinProperty, value);
			}
		}

		public static readonly DependencyProperty MinProperty =
			 DependencyProperty.Register(
				  "Min",
				  typeof(Int),
				  typeof(SpinControl),
				  new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsRender));

		// Max
		public Int Max {
			get {
				return (Int)GetValue(MaxProperty);
			}
			set {
				SetValue(MaxProperty, value);
			}
		}

		public static readonly DependencyProperty MaxProperty =
			 DependencyProperty.Register(
				  "Max",
				  typeof(Int),
				  typeof(SpinControl),
				  new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsRender));

		// Start
		public Int Start {
			get {
				return (Int)GetValue(StartProperty);
			}
			set {
				SetValue(StartProperty, value);
			}
		}

		public static readonly DependencyProperty StartProperty =
			 DependencyProperty.Register(
				  "Start",
				  typeof(Int),
				  typeof(SpinControl),
				  new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsRender));

		// Increment
		public Int Increment {
			get {
				return (Int)GetValue(IncrementProperty);
			}
			set {
				SetValue(IncrementProperty, value);
			}
		}

		public static readonly DependencyProperty IncrementProperty =
			 DependencyProperty.Register(
				  "Increment",
				  typeof(Int),
				  typeof(SpinControl),
				  new FrameworkPropertyMetadata(1, FrameworkPropertyMetadataOptions.AffectsRender));

		#endregion // 프로퍼티

		#region 생성자
		public SpinControl() {
			InitializeComponent();
		}
		#endregion // 생성자

		#region 멤버함수
		private void UpdateButtonState() {
			if (_value <= Min) {
				if (incrementButton.IsEnabled == true) {
					incrementButton.IsEnabled = false;
				}
			} else {
				if (incrementButton.IsEnabled == false) {
					incrementButton.IsEnabled = true;
				}
			}

			if (_value >= Max) {
				if (decrementButton.IsEnabled == true) {
					decrementButton.IsEnabled = false;
				}
			} else {
				if (decrementButton.IsEnabled == false) {
					decrementButton.IsEnabled = true;
				}
			}
		}

		private void Increment_Click(object sender, System.Windows.RoutedEventArgs e) {
			if ((_value - Increment) <= Min) {
				_value = Min;
			} else {
				_value -= Increment;
			}

			textBox.Text = _value.ToString();

			UpdateButtonState();
		}

		private void Decrement_Click(object sender, System.Windows.RoutedEventArgs e) {
			if ((_value + Increment) >= Max) {
				_value = Max;
			} else {
				_value += Increment;
			}

			textBox.Text = _value.ToString();

			UpdateButtonState();
		}

		private void Load(object sender, RoutedEventArgs e) {
			_value = Start;
			textBox.Text = Start.ToString();

			UpdateButtonState();
		}
		#endregion // 멤버함수
	}
}