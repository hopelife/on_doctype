﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using String = System.String;
using Bool = System.Boolean;
using UndoItem = Hnc.DataLogic.UndoItem;
using Hnc.VideoEditor.Base.Type;

namespace Hnc.VideoEditor.Engine {
	// Undo를 ServiceLayer가 아닌 BusinessLayer 에 둔 이유
	// BusinessLayer에 있는 Transaction이 Undo를 만들어 반환을 해야 하는데
	// 만약 Undo가 ServiceLayer에 있다면 Transaction 에서는 ServiceLayer에 있는 Undo에
	// 접근 할 수 없기 때문에 Undo를 만들 수가 없다.
	// 따라서 Undo를 ServiceLayer가 아닌 BusinessLayer에서 만들어서 Transaction이 접근 할 수
	// 있도록 하였다.
	// 하지만 그에 따른 문제점으로 view에서 Undo의 상태를 확인 하기위한 방법이 
	// 애매해졌다.
	public sealed class UndoAddInfo : UndoItem {
		// 멤버변수
		TimelineInfo _addInfo;


		// 생성자
		private UndoAddInfo(TimelineInfo addInfo) {
			_addInfo = addInfo;
		}

		public static UndoAddInfo Create(TimelineInfo addInfo) {
			return new UndoAddInfo(addInfo);
		}

		// Undo Redo 함수
		public void Undo() {
			MarkerUtil.GetMarker().RemoveInfo(_addInfo.ID);
		}

		public void Redo() {
			if (MarkerUtil.GetMarker().AddInfo(_addInfo) < 0) {
				Hnc.Type.Debug.Assert(false, "Undo AddInfo를 실패하였습니다.");
				NotifyMessageQueue.EnQueueMessage("타임라인에 추가하지 못하였습니다.");
			}
		}
	}

	public sealed class UndoPropertyChangedInfo : UndoItem {
		// 멤버변수
		TimelineInfo _oldInfo;
		TimelineInfo _newInfo;

		// 생성자
		private UndoPropertyChangedInfo(TimelineInfo oldInfo, TimelineInfo newInfo) {
			_oldInfo = oldInfo;
			_newInfo = newInfo;
		}

		public static UndoPropertyChangedInfo Create(TimelineInfo oldInfo, TimelineInfo newInfo) {
			return new UndoPropertyChangedInfo(oldInfo, newInfo);
		}

		// Undo Redo 함수
		public void Undo() {
			MarkerUtil.GetMarker().PropertyChangedInfo(_oldInfo);
		}

		public void Redo() {
			MarkerUtil.GetMarker().PropertyChangedInfo(_newInfo);
		}
	}

	public sealed class UndoRemoveInfo : UndoItem {
		// 멤버변수
		TimelineInfo _deleteInfo;

		// 생성자
		private UndoRemoveInfo(TimelineInfo deleteInfo) {
			_deleteInfo = deleteInfo;
		}

		public static UndoRemoveInfo Create(TimelineInfo deleteInfo) {
			return new UndoRemoveInfo(deleteInfo);
		}

		// Undo Redo 함수
		public void Undo() {
			if (MarkerUtil.GetMarker().AddInfo(_deleteInfo) < 0) {
				Hnc.Type.Debug.Assert(false, "Undo AddInfo를 실패하였습니다.");
				NotifyMessageQueue.EnQueueMessage("타임라인에 추가하지 못하였습니다.");
			}
		}

		public void Redo() {
			MarkerUtil.GetMarker().RemoveInfo(_deleteInfo.ID);
		}
	}
}