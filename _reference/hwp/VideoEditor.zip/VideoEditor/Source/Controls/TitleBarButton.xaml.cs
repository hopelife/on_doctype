﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hnc.VideoEditor.Controls {
    /// <summary>
    /// TitleBarButton.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class TitleBarButton : Button {
        public TitleBarButton() {
            InitializeComponent();
        }

        public double BorderRadius {
            get { return (double)GetValue(BorderRadiusProperty); }
            set { SetValue(BorderRadiusProperty, value); }
        }

        public static readonly DependencyProperty BorderRadiusProperty =
            DependencyProperty.Register(
                "BorderRadius",
                typeof(double),
                typeof(TitleBarButton),
                new PropertyMetadata(0.0)
            );

        public Brush CaptionBorderFill {
            get { return (Brush)GetValue(CaptionBorderFillProperty); }
            set { SetValue(CaptionBorderFillProperty, value); }
        }

        public static readonly DependencyProperty CaptionBorderFillProperty =
            DependencyProperty.Register(
                "CaptionBorderFill",
                typeof(Brush),
                typeof(TitleBarButton),
                new PropertyMetadata(Brushes.Transparent)
            );

        public Brush CaptionBorderStroke {
            get { return (Brush)GetValue(CaptionBorderStrokeProperty); }
            set { SetValue(CaptionBorderStrokeProperty, value); }
        }

        public static readonly DependencyProperty CaptionBorderStrokeProperty =
            DependencyProperty.Register(
                "CaptionBorderStroke",
                typeof(Brush),
                typeof(TitleBarButton),
                new PropertyMetadata(Brushes.Transparent)
            );

        public System.Windows.Media.ImageSource ImageSource {
            get { return (System.Windows.Media.ImageSource)GetValue(ImageSourceProperty); }
            set { SetValue(ImageSourceProperty, value); }
        }

        public static readonly DependencyProperty ImageSourceProperty =
            DependencyProperty.Register(
                "ImageSource",
                typeof(System.Windows.Media.ImageSource),
                typeof(TitleBarButton),
                new PropertyMetadata(null)
            );

        public System.Windows.Media.ImageSource HoverImage {
            get { return (System.Windows.Media.ImageSource)GetValue(HoverImageProperty); }
            set { SetValue(HoverImageProperty, value); }
        }

        public static readonly DependencyProperty HoverImageProperty =
           DependencyProperty.Register(
               "HoverImage",
               typeof(System.Windows.Media.ImageSource),
               typeof(TitleBarButton),
               new PropertyMetadata(null)
               );

        public System.Windows.Media.ImageSource PressedImage {
            get {
                return (System.Windows.Media.ImageSource)GetValue(PressedImageProperty);
            }
            set {
                SetValue(PressedImageProperty, value);
            }
        }

        public static readonly DependencyProperty PressedImageProperty =
           DependencyProperty.Register(
               "PressedImage",
               typeof(System.Windows.Media.ImageSource),
               typeof(TitleBarButton),
               new PropertyMetadata(null)
               );


        public Thickness ImageMargin {
            get { return (Thickness)GetValue(ImageMarginProperty); }
            set { SetValue(ImageMarginProperty, value); }
        }

        public static readonly DependencyProperty ImageMarginProperty =
            DependencyProperty.Register(
                "ImageMargin",
                typeof(Thickness),
                typeof(TitleBarButton),
                new PropertyMetadata(new Thickness(0, 0, 0, 0))
            );
    }
}
