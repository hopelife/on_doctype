/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "stdafx.h"

class TimelineInfo {
public:
	Bool emptyFrame;
	Char filePath[MAX_FILEPATH];
	AVRational timebase;
	Int64_t startFrame;
	Int64_t endFrame;
	Int64_t lengthFrame;
	Int videoStreamIndex;
	Int audioStreamIndex;
	AVFormatContext* inputFormatContext;
	AVCodecContext* inputVideoCodecContext;
	AVCodecContext* inputAudioCodecContext;

	int frameRate;

	Effect enumEffect;
	Bool isMSCodec;
	int loop;

public:
	TimelineInfo();
	TimelineInfo(const Char* path, Effect enumEffect, Int64_t start, Int64_t end);

	~TimelineInfo();
};
