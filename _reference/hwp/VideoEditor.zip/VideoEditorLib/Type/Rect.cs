﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using Float = System.Single;
using Bool = System.Boolean;


namespace Hnc.Type {

    // x, y, width, height 관리
    // value Compare
    public sealed class Rect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        public Int X { get; set; }
        public Int Y { get; set; }
        public Int Width { get; set; }
        public Int Height { get; set; }

        public Int Left { get { return X; } }
        public Int Top { get { return Y; } }
        public Int Right { get { return X + Width; } }
        public Int Bottom { get { return Y + Height; } }

        public Point LeftTop { get { return Point.Create(Left, Top); } }
        public Point LeftBottom { get { return Point.Create(Left, Bottom); } }
        public Point RightTop { get { return Point.Create(Right, Top); } }
        public Point RightBottom { get { return Point.Create(Right, Bottom); } }

        public Point Center { get { return Point.Create(X + Width / 2, Y + Height / 2); } }
        public Size Size { get { return Size.Create(Width, Height); } }


        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Rect(Int x, Int y, Int w, Int h) {
            X = x;
            Y = y;
            Width = w;
            Height = h;
        }

        public static Rect Create(Int x, Int y, Int w, Int h) {
            return new Rect(x, y, w, h);
        }

        public static Rect CreateFromCenter(Point center, Int w, Int h) {
            Debug.Assert(center != null);

            return Create(center.X - w / 2, center.Y - h / 2, w, h);
        }
        public Rect Clone() {
            return Create(X, Y, Width, Height);
        }

        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            Rect other = obj as Rect;
            Debug.Assert(other != null);

            return (X == other.X) && (Y == other.Y) && (Width == other.Width) && (Height == other.Height);
        }
        public static Bool operator ==(Rect left, Rect right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Rect left, Rect right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }



        public void Normalize() {
            if (Width < 0) {
                FlipWidth();
            }
            if (Height < 0) {
                FlipHeight();
            }
        }
        public void FlipWidth() {
            X = X + Width;
            Width = -Width;
        }
        public void FlipHeight() {
            Y = Y + Height;
            Height = -Height;
        }
        // 주어진 점을 포함하는지의 여부
        public Bool Contains(Int x, Int y) {

            Int left = Left < Right ? Left : Right;
            Int right = Left < Right ? Right : Left;

            Int top = Top < Bottom ? Top : Bottom;
            Int bottom = Top < Bottom ? Bottom : Top;

            return
                (left <= x) && (x < right) &&
                (top <= y) && (y < bottom);

        }

        // other와 영역을 합친다.
        public void Union(Rect other) {

            Int left = Left < Right ? Left : Right;
            Int right = Left < Right ? Right : Left;

            Int top = Top < Bottom ? Top : Bottom;
            Int bottom = Top < Bottom ? Bottom : Top;

            Int otherLeft = other.Left < other.Right ? other.Left : other.Right;
            Int otherRight = other.Left < other.Right ? other.Right : other.Left;

            Int otherTop = other.Top < other.Bottom ? other.Top : other.Bottom;
            Int otherBottom = other.Top < other.Bottom ? other.Bottom : other.Top;


            Int l = left < otherLeft ? left : otherLeft;
            Int t = top < otherTop ? top : otherTop;
            Int r = right < otherRight ? right : otherRight;
            Int b = bottom < otherBottom ? bottom : otherBottom;

            X = l;
            Y = t;
            Width = r - l;
            Height = b - t;
        }
    }

    public sealed class RectF {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        public Float X { get; set; }
        public Float Y { get; set; }
        public Float Width { get; set; }
        public Float Height { get; set; }

        public Float Left { get { return X; } }
        public Float Top { get { return Y; } }
        public Float Right { get { return X + Width; } }
        public Float Bottom { get { return Y + Height; } }

        public PointF LeftTop { get { return PointF.Create(Left, Top); } }
        public PointF LeftBottom { get { return PointF.Create(Left, Bottom); } }
        public PointF RightTop { get { return PointF.Create(Right, Top); } }
        public PointF RightBottom { get { return PointF.Create(Right, Bottom); } }

        public PointF Center { get { return PointF.Create(X + Width / 2, Y + Height / 2); } }
        public SizeF Size { get { return SizeF.Create(Width, Height); } }


        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private RectF(Float x, Float y, Float w, Float h) {
            X = x;
            Y = y;
            Width = w;
            Height = h;
        }

        public static RectF Create(Float x, Float y, Float w, Float h) {
            return new RectF(x, y, w, h);
        }

        public static RectF CreateFromCenter(PointF center, Float w, Float h) {
            Debug.Assert(center != null);

            return Create(center.X - w / 2, center.Y - h / 2, w, h);
        }

        public RectF Clone() {
            return Create(X, Y, Width, Height);
        }

        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            Rect other = obj as Rect;
            Debug.Assert(other != null);

            return (X == other.X) && (Y == other.Y) && (Width == other.Width) && (Height == other.Height);
        }
        public static Bool operator ==(RectF left, RectF right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(RectF left, RectF right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }


        public void Normalize() {
            if (Width < 0) {
                FlipWidth();
            }
            if (Height < 0) {
                FlipHeight();
            }
        }
        public void FlipWidth() {
            X = X + Width;
            Width = -Width;
        }
        public void FlipHeight() {
            Y = Y + Height;
            Height = -Height;
        }
        // 주어진 점을 포함하는지의 여부
        public Bool Contains(Float x, Float y) {

            Float left = Left < Right ? Left : Right;
            Float right = Left < Right ? Right : Left;

            Float top = Top < Bottom ? Top : Bottom;
            Float bottom = Top < Bottom ? Bottom : Top;

            return
                (left <= x) && (x < right) &&
                (top <= y) && (y < bottom);
        }

        // other와 영역을 합친다.
        public void Union(RectF other) {

            Float left = Left < Right ? Left : Right;
            Float right = Left < Right ? Right : Left;

            Float top = Top < Bottom ? Top : Bottom;
            Float bottom = Top < Bottom ? Bottom : Top;

            Float otherLeft = other.Left < other.Right ? other.Left : other.Right;
            Float otherRight = other.Left < other.Right ? other.Right : other.Left;

            Float otherTop = other.Top < other.Bottom ? other.Top : other.Bottom;
            Float otherBottom = other.Top < other.Bottom ? other.Bottom : other.Top;


            Float l = left < otherLeft ? left : otherLeft;
            Float t = top < otherTop ? top : otherTop;
            Float r = right < otherRight ? otherRight : right;
            Float b = bottom < otherBottom ? otherBottom : bottom;

            X = l;
            Y = t;
            Width = r - l;
            Height = b - t;
        }

    }
}
