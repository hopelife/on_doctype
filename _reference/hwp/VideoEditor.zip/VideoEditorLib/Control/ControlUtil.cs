﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;

namespace Hnc.Control
{
	public class ControlUtil
	{
		public static Point GetControlPoint(FrameworkElement control)
		{
			Window controlWindow = Window.GetWindow(control);
			if (controlWindow == null)
				return new Point();


			Point controlPoint = new Point();
			try
			{
				controlPoint = control.TransformToAncestor(controlWindow).Transform(new Point(0, 0));
			}
			catch
			{
				return controlPoint;
			}

			return controlPoint;
		}

		public static Rect GetControlRect(FrameworkElement control)
		{
			Point point = GetControlPoint(control);

			return new Rect(point.X, point.Y, control.ActualWidth, control.ActualHeight);

		}

		public static Point GetControlScreenPoint(FrameworkElement control)
		{
			Window controlWindow = Window.GetWindow(control);
			if (controlWindow == null)
				return new Point();

			return controlWindow.PointToScreen(control.TransformToAncestor(controlWindow).Transform(new Point(0, 0)));
		}

		public static Rect GetControlScreenRect(FrameworkElement control)
		{
			Point point = GetControlScreenPoint(control);

			return new Rect(point.X, point.Y, control.ActualWidth, control.ActualHeight);

		}
	}
}
