﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {
    // GaussianBlur 보다 빠르고 품질은 유사함
    public class BoxBlur {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        Count Radius;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private BoxBlur(Count radius) {
            Radius = (radius < 1) ? 1 : radius;

        }
        public static BoxBlur Create(Count radius) {

            return new BoxBlur(radius);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            Debug.Assert(1 <= Radius);

            Count width = pixels.Width;
            Count height = pixels.Height;
            Index xMax = width - 1;
            Index yMax = height - 1;
            Count radiusPlusOne = Radius + 1;

            Count kernelCount = Radius * 2 + 1; // 항상 홀수임
            Byte[] average = new Byte[256 * kernelCount];
            Index[] curFirst = new Index[MathUtil.Max(width, height)]; // 현 픽셀 평균값을 구할때 사용한 픽셀 위치
            Index[] nextFirst = new Index[MathUtil.Max(width, height)]; // 다음 픽셀 평균값을 구할때 사용할 픽셀 위치
            Int[] a = new Int[width * height];
            Int[] r = new Int[width * height];
            Int[] g = new Int[width * height];
            Int[] b = new Int[width * height];

            Index pos = 0;
            Index targetPixelPos;
            Index startPos;

            Index nextIndex;
            Index prevIndex;

            Int aTotal;
            Int rTotal;
            Int gTotal;
            Int bTotal;



            // 색상값은 다음과 같이 계산되므로 해당 수식의 결과값을 미리 계산해 둔다.
            // kernel 갯수가 5이고 p3을 결정할때 주변 인접픽셀의 값을 이용하여 다음과 같이 평균값을 사용한다.
            // 
            // (p1 + p2 + p3 + p4 + p5) / 5  
            //
            // 따라서 각 픽셀의 합계는 256 * 5를 넘지 않으며 
            // 픽셀합계에 대한 평균값은 다음과 같이 미리 계산해두어 속도를 향상시킨다.
            for (Index i = 0; i < 256 * kernelCount; i++) {
                average[i] = (Byte)((Float)i / kernelCount);
            }

            // 가로방향
            startPos = 0; // x = 0인 픽셀 위치
            targetPixelPos = 0;
            for (Index y = 0; y < height; ++y) {
                aTotal = 0;
                rTotal = 0;
                gTotal = 0;
                bTotal = 0;

                // kernelCount 만큼의 합계를 미리 계산해 둔다.
                // 추후 이값을 바탕으로 앞의 항목은 빼고 뒤의 항목을 더해서 
                // 빨리 계산할 수 있다.
                for (Index k = -Radius; k <= Radius; ++k) {
                    pos = startPos + MathUtil.Min(xMax, MathUtil.Max(k, 0)); // startPos == y * width
                    aTotal += pixels.A[pos];
                    rTotal += pixels.R[pos];
                    gTotal += pixels.G[pos];
                    bTotal += pixels.B[pos];
                }

                for (Index x = 0; x < width; ++x) {
                    a[targetPixelPos] = average[aTotal];
                    r[targetPixelPos] = average[rTotal];
                    g[targetPixelPos] = average[gTotal];
                    b[targetPixelPos] = average[bTotal];

                    // x값만 계산하면 되므로 y = 0 일때 한번만 계산
                    if (y == 0) {
                        curFirst[x] = MathUtil.Max(x - Radius, 0);
                        nextFirst[x] = MathUtil.Min(x + radiusPlusOne, xMax);
                    }

                    // 평균에 사용한 시작 값은 빼고 다음 시작값을 더한다.
                    prevIndex = startPos + curFirst[x];
                    nextIndex = startPos + nextFirst[x];

                    aTotal += pixels.A[nextIndex] - pixels.A[prevIndex]; 
                    rTotal += pixels.R[nextIndex] - pixels.R[prevIndex];
                    gTotal += pixels.G[nextIndex] - pixels.G[prevIndex];
                    bTotal += pixels.B[nextIndex] - pixels.B[prevIndex];
                    ++targetPixelPos;
                }
                startPos += width;
            }

            // 세로방향
            startPos = 0;
            targetPixelPos = 0;
            for (Index x = 0; x < width; ++x) {
                aTotal = 0;
                rTotal = 0;
                gTotal = 0;
                bTotal = 0;
                startPos = -Radius * width;
                for (Index k = -Radius; k <= Radius; ++k) {

                    if (height <= k) {
                        pos = (height - 1) * width + x;
                    }
                    else {
                        pos = MathUtil.Max(0, startPos) + x; // -radius ~ 0 구간에는 y == 0번 위치의 픽셀이 사용하고 height ~ radius 구간은 y = height - 1을 사용
                    }

                    aTotal += a[pos];
                    rTotal += r[pos];
                    gTotal += g[pos];
                    bTotal += b[pos];
                    startPos += width;
                }
                targetPixelPos = x;
                for (Index y = 0; y < height; ++y) {

                    pixels.A[targetPixelPos] = (Byte)average[aTotal];
                    pixels.R[targetPixelPos] = (Byte)average[rTotal];
                    pixels.G[targetPixelPos] = (Byte)average[gTotal];
                    pixels.B[targetPixelPos] = (Byte)average[bTotal];


                    // y값만 계산하면 되므로 x = 0 일때 한번만 계산
                    if (x == 0) {
                        curFirst[y] = MathUtil.Max(y - Radius, 0) * width;
                        nextFirst[y] = MathUtil.Min(y + radiusPlusOne, yMax) * width;
                    }
                    prevIndex = x + curFirst[y];
                    nextIndex = x + nextFirst[y];

                    aTotal += a[nextIndex] - a[prevIndex]; 
                    rTotal += r[nextIndex] - r[prevIndex];
                    gTotal += g[nextIndex] - g[prevIndex];
                    bTotal += b[nextIndex] - b[prevIndex];

                    targetPixelPos += width;
                }
            }
        }

        static public void Apply(Byte[] pixels, Count width, Count height, Count radius) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);
            Debug.Assert(1 <= radius);

            Index xMax = width - 1;
            Index yMax = height - 1;
            Count radiusPlusOne = radius + 1;

            Count kernelCount = radius * 2 + 1; // 항상 홀수임
            Byte[] average = new Byte[256 * kernelCount];
            Index[] curFirst = new Index[MathUtil.Max(width, height)]; // 현 픽셀 평균값을 구할때 사용한 픽셀 위치
            Index[] nextFirst = new Index[MathUtil.Max(width, height)]; // 다음 픽셀 평균값을 구할때 사용할 픽셀 위치

            Int[] pixel = new Int[width * height];


            Index pos;
            Index targetPixelPos;
            Index startPos;

            Index nextIndex;
            Index prevIndex;

            Int pixelTotal;




            // 색상값은 다음과 같이 계산되므로 해당 수식의 결과값을 미리 계산해 둔다.
            // kernel 갯수가 5이고 p3을 결정할때 주변 인접픽셀의 값을 이용하여 다음과 같이 평균값을 사용한다.
            // 
            // (p1 + p2 + p3 + p4 + p5) / 5  
            //
            // 따라서 각 픽셀의 합계는 256 * 5를 넘지 않으며 
            // 픽셀합계에 대한 평균값은 다음과 같이 미리 계산해두어 속도를 향상시킨다.
            for (Index i = 0; i < 256 * kernelCount; i++) {
                average[i] = (Byte)((Float)i / kernelCount);
            }

            // 가로방향
            startPos = 0; // x = 0인 픽셀 위치
            targetPixelPos = 0;
            for (Index y = 0; y < height; ++y) {
                pixelTotal = 0;

                // kernelCount 만큼의 합계를 미리 계산해 둔다.
                // 추후 이값을 바탕으로 앞의 항목은 빼고 뒤의 항목을 더해서 
                // 빨리 계산할 수 있다.
                for (Index k = -radius; k <= radius; ++k) {
                    pos = startPos + MathUtil.Min(xMax, MathUtil.Max(k, 0)); // startPos == y * width
                    pixelTotal += pixels[pos];
                }

                for (Index x = 0; x < width; ++x) {
                    pixel[targetPixelPos] = average[pixelTotal];

                    // x값만 계산하면 되므로 y = 0 일때 한번만 계산
                    if (y == 0) {
                        curFirst[x] = MathUtil.Max(x - radius, 0);
                        nextFirst[x] = MathUtil.Min(x + radiusPlusOne, xMax);
                    }

                    // 평균에 사용한 시작 값은 빼고 다음 시작값을 더한다.
                    prevIndex = startPos + curFirst[x];
                    nextIndex = startPos + nextFirst[x];

                    pixelTotal += pixels[nextIndex] - pixels[prevIndex];

                    ++targetPixelPos;
                }
                startPos += width;
            }

            // 세로방향
            startPos = 0;
            targetPixelPos = 0;
            for (Index x = 0; x < width; ++x) {
                pixelTotal = 0;
                startPos = -radius * width;
                for (Index k = -radius; k <= radius; ++k) {
                    pos = MathUtil.Max(0, startPos) + x; // -radius ~ 0 구간에는 y == 0번 위치의 픽셀이 사용된다.
                    pixelTotal += pixel[pos];
                    startPos += width;
                }
                targetPixelPos = x;
                for (Index y = 0; y < height; ++y) {

                    pixels[targetPixelPos] = (Byte)average[pixelTotal];

                    // y값만 계산하면 되므로 x = 0 일때 한번만 계산
                    if (x == 0) {
                        curFirst[y] = MathUtil.Max(y - radius, 0) * width;
                        nextFirst[y] = MathUtil.Min(y + radiusPlusOne, yMax) * width;
                    }
                    prevIndex = x + curFirst[y];
                    nextIndex = x + nextFirst[y];

                    pixelTotal += pixel[nextIndex] - pixel[prevIndex];

                    targetPixelPos += width;
                }
            }
        }

    }
}