﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System;

namespace Hnc.VideoEditor.Controls {
    public partial class VideoEditorSlider : UserControl {
        public VideoPlayer videoPlayer;
        public VideoEditorSlider() {
            InitializeComponent();

       //     timeLineSlider.Value = 0;
      //      timeLineSlider.Maximum = 100;
      //      timeLineSlider.IsEnabled = true;

            //StartPosition.Visibility = Visibility.Hidden;
            //EndPosition.Visibility = Visibility.Hidden;

            StartPosition.PreviewMouseDown += new MouseButtonEventHandler(Event_StartPositionPreviewMouseDown);
            StartPosition.PreviewMouseUp += new MouseButtonEventHandler(Event_StartPositionPreviewMouseUp);

            EndPosition.PreviewMouseDown += new MouseButtonEventHandler(Event_EndPositionPreviewMouseDown);
            EndPosition.PreviewMouseUp += new MouseButtonEventHandler(Event_EndPositionPreviewMouseUp);

            timeLineSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(Event_TimelineSliderValueChanged);

            timeLineSlider.PreviewMouseMove += new MouseEventHandler(Event_TimelineSliderPreviewMouseMove);

            timeLineSlider.PreviewMouseLeftButtonUp += new MouseButtonEventHandler(Event_TimelineSliderPreviewMouseUp);
        }

        private void OnLoaded(object sender, RoutedEventArgs e) {
            StartPosition.SetValue(Canvas.LeftProperty, -5.0);
            EndPosition.SetValue(Canvas.LeftProperty, this.ActualWidth - 5.0);
        }

        double ToSliderValue(double value) {
            double sliderValue = 0.0;
            try {
                sliderValue = (timeLineSlider.Maximum * value) / timeLineSlider.ActualWidth;
            } catch (DivideByZeroException) {
                Hnc.Type.Debug.Assert(false, "ToSliderValue 0으로 나누려고 했습니다.");
                sliderValue = 0.0;
            }
            return sliderValue;
        }

        double ToWidthValue(double value) {
            double widthValue = 0.0;
            try {
                widthValue = (timeLineSlider.ActualWidth * value) / timeLineSlider.Maximum;
            } catch (DivideByZeroException) {
                Hnc.Type.Debug.Assert(false, "ToWidthValue 0으로 나누려고 했습니다.");
                widthValue = 0.0;
            }
            return widthValue;
        }

        private void Event_TimelineSliderValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            double changeValue = e.OldValue - e.NewValue;
            double widthValue = ToWidthValue(e.NewValue);

            if (changeValue < 0) {
                // 오른쪽으로 이동
                double endValue = (double) EndPosition.GetValue(Canvas.LeftProperty);
                if (widthValue > endValue) {
                    double sliderValue = ToSliderValue(endValue);
                    timeLineSlider.Value = sliderValue;


                    videoPlayer.isTimelineMove = false;
                    if (!videoPlayer.isClose) {
                        videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                    }
                }
            } else {
                // 왼쪽으로 이동
                double startValue = (double)StartPosition.GetValue(Canvas.LeftProperty);
                if (widthValue < startValue) {
                    double sliderValue = ToSliderValue(startValue);
                    timeLineSlider.Value = sliderValue;


                    videoPlayer.isTimelineMove = false;
                    if (!videoPlayer.isClose) {
                        videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                    }
                }
            }
        }

        private void Event_TimelineSliderPreviewMouseMove(object sender, MouseEventArgs e) {
         //   if (!videoPlayer.isTimelineMove) {
         //       if (!videoPlayer.isClose) {
                    videoPlayer.mediaTimer.Start();
                    videoPlayer.screen.Play();
                    videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                    videoPlayer.mediaTimer.Stop();
                    videoPlayer.screen.Pause();
        //        }
       //    }
        }

        private void Event_TimelineSliderPreviewMouseUp(object sender, MouseButtonEventArgs e) {
            videoPlayer.isTimelineMove = false;
            if (!videoPlayer.isPause && !videoPlayer.isClose) {
                videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                videoPlayer.mediaTimer.Start();
                videoPlayer.screen.Play();
            }
        }

        private void Event_StartPositionPreviewMouseDown(object sender, MouseEventArgs e) {
            StartPosition.CaptureMouse();
            StartPosition.PreviewMouseMove += Event_StartPositionPreviewMouseMove;

            videoPlayer.isTimelineMove = true;
            if (!videoPlayer.isClose) {
                videoPlayer.mediaTimer.Stop();
                videoPlayer.screen.Pause();
            }
        }

        private void Event_StartPositionPreviewMouseUp(object sender, MouseButtonEventArgs e) {
            StartPosition.ReleaseMouseCapture();
            StartPosition.PreviewMouseMove -= Event_StartPositionPreviewMouseMove;

            if (!videoPlayer.isPause && !videoPlayer.isClose) {
                videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                videoPlayer.mediaTimer.Start();
                videoPlayer.screen.Play();
            }
        }

        private void Event_StartPositionPreviewMouseMove(object sender, MouseEventArgs e) {
            Point currentPosition = e.GetPosition(this);

            if (currentPosition.X >= 0) {
                double sliderValue = ToSliderValue(currentPosition.X);
                if (sliderValue > timeLineSlider.Value) {
                    timeLineSlider.Value = sliderValue;
                }

                StartPosition.SetValue(Canvas.LeftProperty, currentPosition.X);
            } else {
                StartPosition.SetValue(Canvas.LeftProperty, -5.0);
            }
        }

        private void Event_EndPositionPreviewMouseDown(object sender, MouseEventArgs e) {
            EndPosition.CaptureMouse();
            EndPosition.PreviewMouseMove += Event_EndPositionPreviewMouseMove;

            videoPlayer.isTimelineMove = true;
            if (!videoPlayer.isClose) {
                videoPlayer.mediaTimer.Stop();
                videoPlayer.screen.Pause();
            }
        }

        private void Event_EndPositionPreviewMouseUp(object sender, MouseButtonEventArgs e) {
            EndPosition.ReleaseMouseCapture();
            EndPosition.PreviewMouseMove -= Event_EndPositionPreviewMouseMove;

            if (!videoPlayer.isPause && !videoPlayer.isClose) {
                videoPlayer.screen.Position = TimeSpan.FromSeconds(timeLineSlider.Value);
                videoPlayer.mediaTimer.Start();
                videoPlayer.screen.Play();
            }
        }

        private void Event_EndPositionPreviewMouseMove(object sender, MouseEventArgs e) {
            Point currentPosition = e.GetPosition(this);

            if (currentPosition.X  <= this.ActualWidth) {
                double sliderValue = ToSliderValue(currentPosition.X);
                if (sliderValue < timeLineSlider.Value) {
                    timeLineSlider.Value = sliderValue;
                }

                EndPosition.SetValue(Canvas.LeftProperty, currentPosition.X);
            } else {
                EndPosition.SetValue(Canvas.LeftProperty, this.ActualWidth - 5.0);
            }
        }
    }
}
