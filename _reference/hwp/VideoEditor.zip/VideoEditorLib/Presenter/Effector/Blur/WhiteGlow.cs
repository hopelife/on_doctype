﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/


using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Count = System.Int32;
using Ratio = System.Single;
using Index = System.Int32;
using Byte = System.Byte;
using Int = System.Int32;

namespace Hnc.Presenter.ImageEffect {

    // 그림을 Blur를 주어 뿌옇게 한 후 결합을 하여 뽀샤시 효과를 준다.
    public class WhiteGlow {

        public enum eType {
            Add,
            Screen,
            Overlay,
            SoftLighten
        }
        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private eType Type = eType.Add;
        private Count Radius = 30; // 반경. 블러링되는 영역. 1~
        private Ratio Opacity = 0.3F; // 투명도 0~1

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // opacity : 1이면 불투명
        private WhiteGlow(eType type, Count radius, Ratio opacity) {
            Type = type;
            Radius = (radius < 1) ? 1 : radius;
            Opacity = MathUtil.Clamp(opacity, 0, 1);
        }
        public static WhiteGlow Create(eType type, Count radius, Ratio opacity) {
            return new WhiteGlow(type, radius, opacity);

        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {

            // 원본복사
            ArgbChannel blur = pixels.Clone();

            // 블러를 주어 뿌옇게 만듬
            BoxBlur.Create(Radius).Apply(blur);


            Count width = pixels.Width;
            Count height = pixels.Height;
            Count length = pixels.Width * pixels.Height;

            switch (Type) {
                case eType.Add: {

                        // Opacity에 따른 LookupTable 미리계산
                        LookupTable table = LookupTable.Create();
                        for (Index i = 0; i < 256; ++i) {
                            table.Data[i] = (Byte)MathUtil.Clamp(Opacity * i, 0, 255);
                        }

                        for (Index i = 0; i < length; ++i) {

                            pixels.R[i] = (Byte)MathUtil.Min(255, table.Data[blur.R[i]] + pixels.R[i]);
                            pixels.G[i] = (Byte)MathUtil.Min(255, table.Data[blur.G[i]] + pixels.G[i]);
                            pixels.B[i] = (Byte)MathUtil.Min(255, table.Data[blur.B[i]] + pixels.B[i]);

                        }
                    }
                    break;
                case eType.Screen:
                    for (Index i = 0; i < length; ++i) {

                        Blend.Screen(
                            ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                            blur.A[i], blur.R[i], blur.G[i], blur.B[i],
                            Opacity
                        );
                    }
                    break;
                case eType.Overlay:
                    for (Index i = 0; i < length; ++i) {

                        Blend.Overlay(
                            ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                            blur.A[i], blur.R[i], blur.G[i], blur.B[i],
                            Opacity
                        );
                    }
                    break;
                case eType.SoftLighten:
                    for (Index i = 0; i < length; ++i) {

                        Blend.SoftLighten(
                            ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                            blur.A[i], blur.R[i], blur.G[i], blur.B[i],
                            Opacity
                        );
                    }
                    break;

            }

        }
    }
}
