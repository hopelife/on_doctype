﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.IO;
using String = System.String;
using Int = System.Int32;
using Bool = System.Boolean;
using Byte = System.Byte;
using Index = System.Int32;
using Count = System.Int32;

namespace Hnc.Type {
    public sealed class Stream : System.IDisposable {

        //  파일 경로 처리
        public static Bool ExistsFile(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);

            return File.Exists(pathName);
        }

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private readonly System.IO.MemoryStream data;
        public System.IO.MemoryStream Data {
            get {
                Debug.Assert(data != null);
                return data;
            }
        }
         // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Stream(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(ExistsFile(pathName), eErrorCode.FileNotFound);

            using (System.IO.FileStream fs = new System.IO.FileStream(pathName, System.IO.FileMode.Open, System.IO.FileAccess.Read) ) {
                Debug.Assert(fs != null);
                
                Byte[] bytes = new Byte[fs.Length];

                //!! 대용량인 경우 분할 저장해야 함
                fs.Read(bytes, 0, (Int)fs.Length);

                data = new System.IO.MemoryStream(bytes);                
            }
        }

        public static Stream Load(String pathName) {
            return new Stream(pathName);
        }

        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            Stream other = obj as Stream;
            Debug.Assert(other != null);


            // 크기가 같아야 한다.
            if (Data.Length != other.Data.Length) {
                return false;
            }

            Data.Seek(0, System.IO.SeekOrigin.Begin);
            other.Data.Seek(0, System.IO.SeekOrigin.Begin);

            Count count = 0;
            

            while (count < Data.Length) {
                if (Data.ReadByte() != other.Data.ReadByte()) {
                   
                    Data.Seek(0, System.IO.SeekOrigin.Begin);
                    other.Data.Seek(0, System.IO.SeekOrigin.Begin);

                    return false;
                }
                ++count;
            }

            Data.Seek(0, System.IO.SeekOrigin.Begin);
            other.Data.Seek(0, System.IO.SeekOrigin.Begin);

            return true;
        }
        public static Bool operator ==(Stream left, Stream right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Stream left, Stream right) {
            return !(left == right);
        }
        #endregion

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }        
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        #region IDisposable 구현
        void System.IDisposable.Dispose() {
            Debug.Assert(Data != null);

            Data.Dispose();
        }
        #endregion

        public void Save(String pathName) {
            Debug.AssertThrow(pathName != null && pathName != "", eErrorCode.InvalidPathName);
            Debug.AssertThrow(!ExistsFile(pathName), eErrorCode.ExistsFile);
            Debug.Assert(Data != null);
            
            using (System.IO.FileStream fs = new System.IO.FileStream(pathName, System.IO.FileMode.CreateNew)) {
                Data.WriteTo(fs);
                fs.Flush();
            }
        
        }

    }
}
