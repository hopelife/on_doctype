/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

typedef bool			Bool;
typedef int				Int;
typedef float			Float;
typedef double			Double;
typedef char			Byte;
typedef char			Char;
typedef unsigned char	UChar;
typedef unsigned long	ULong;
typedef signed __int16	Int16_t;
typedef signed __int64	Int64_t;
typedef unsigned __int8	UInt8_t;