﻿#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "Debug.h"
#include "FFMpegLib.h"

int Round(double d) {
	int n = (int) d;
	d = d - n;

	if (d>= 0.5) {
		n++;
	}

	return n;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// 생성자 & 소멸자
FFMpegLib::FFMpegLib(void) {
	static int isStart = 0;

	if (isStart == 0) {
		av_register_all();
		++isStart;
	}

	NewTimeline();
	
	sws_flags = SWS_BICUBIC;
}

FFMpegLib::~FFMpegLib(void) {
}

//////////////////////////////////////////////////////////////////////////////////////////////////
// 멤버 함수
void FFMpegLib::NewTimeline() {
	int size = timelineInfoList.size();
	for(int i=0; i<size; ++i) {
		delete timelineInfoList[i];
	}

	timelineInfoList.clear();

	outputFileInfo = NULL;
}

int FFMpegLib::AddTimelineInfo(TimelineInfo* info) {
	try {
		int ret = 0;

		// 변환 할 비디오 파일 열기
		if (avformat_open_input(&info->inputFormatContext, info->filePath, NULL, NULL) < 0) {
			fprintf(stderr, "Could not open source file %s\n", info->filePath);
			return FAILED;
		}

		// 스트림 정보 찾기
		if (avformat_find_stream_info(info->inputFormatContext, NULL) < 0) {
			fprintf(stderr, "Could not find stream information\n");
			return FAILED;
		}

		// 비디오 타입 스트림의 인덱스 찾기
		info->videoStreamIndex = av_find_best_stream(info->inputFormatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
		if (info->videoStreamIndex < 0) {
			fprintf(stderr, "Could not find video stream in file\n");
			return FAILED;
		}

		// decoder Codec 찾기
		AVStream* videoStream = info->inputFormatContext->streams[info->videoStreamIndex];
		info->inputCodecContext = videoStream->codec;
		info->decoderCodec = avcodec_find_decoder(info->inputCodecContext->codec_id);

		if (info->decoderCodec == NULL) {
			fprintf(stderr, "Failed to find decoder codec\n");
			return FAILED;
		}

		if ((ret = avcodec_open2(info->inputCodecContext, info->decoderCodec, NULL)) < 0) {
			fprintf(stderr, "Failed to open codec\n");
			return FAILED;
		}

		timelineInfoList.push_back(info);

	} catch(...) {
#ifdef _DEBUG
		Debug::Trace("AddTimelineInfo 예외발생!!!");
#endif
	}

	return SUCCESSED;
}

// 생성
int FFMpegLib::CreateOutputfileInfo() {
	outputFileInfo = new OutputFileInfo();

	if (outputFileInfo == NULL) {
		return FAILED;
	}

	return SUCCESSED;
}

// outputFilePath 설정
int FFMpegLib::SetOuputFilePath(const char* outputFilePath) {
	
	outputFileInfo->filePath = new char[strlen(outputFilePath)];
	strcpy_s(outputFileInfo->filePath, strlen(outputFileInfo->filePath), outputFilePath);

	return SUCCESSED;
}

// 확장자 설정
int FFMpegLib::SetExtName(const char* extName) {
	outputFileInfo->extName = new char[strlen(extName)];
	strcpy_s(outputFileInfo->extName, strlen(outputFileInfo->extName), extName);

	return SUCCESSED;
}

// encoder 코덱 설정
int FFMpegLib::SetVideoEncoderInfo(AVCodecID) {
//	int ret;
	return SUCCESSED;
}
int FFMpegLib::SetAudioEncoderInfo(AVCodecID){
//	int ret;
	return SUCCESSED;
}
	// 프레임 속도 설정
//int FFMpegLib::SetFrameRate(AVCodecContext* outputCodecContext, int frameRate) {
//	int ret;
//	return SUCCESSED;
//}
	// 쓰기 파일 열기
int FFMpegLib::OpenOutputFile() {
//	int ret;
	return SUCCESSED;
}

int FFMpegLib::SetOuputFileInfo(const char* outputFilePath) {

	int ret;

	//outputFileInfo = new OutputFileInfo();

	outputFileInfo->encoderCodec = avcodec_find_encoder(timelineInfoList[0]->inputCodecContext->codec_id);
	if (outputFileInfo->encoderCodec == NULL) {
		fprintf(stderr, "Failed to find encoder codec\n");
		return FAILED;
	}

	if ((ret = avformat_alloc_output_context2(&outputFileInfo->outputFormatContext, NULL, "avi", outputFilePath)) < 0) {
		fprintf(stderr, "Failed to alloc Context\n");
		return FAILED;
	}

	if (outputFileInfo->outputFormatContext == NULL) {
		fprintf(stderr, "Failed to instead format_name and filename \n");
		return FAILED;
	}

	// 쓰기 할 파일 정보 세팅 - 첫번째 파일로 하지 않고 설정되로 변경
	// 코덱들 테스트
	outputFileInfo->outputFormatContext->oformat->audio_codec = CODEC_ID_NONE;
	outputFileInfo->outputFormatContext->oformat->video_codec = timelineInfoList[0]->inputCodecContext->codec_id;
	outputFileInfo->outputFormatContext->audio_codec_id = CODEC_ID_NONE;
	outputFileInfo->outputFormatContext->video_codec_id = timelineInfoList[0]->inputCodecContext->codec_id;
	outputFileInfo->outputFormatContext->duration = timelineInfoList[0]->inputFormatContext->duration;

	//	av_dict_copy(&(outputFormatContext->metadata), inputFormatContext->metadata, 0);
	//	av_dict_set(&(outputFormatContext->metadata), "Author", "VPI", 0 );
		
	AVStream* stream = avformat_new_stream(outputFileInfo->outputFormatContext, outputFileInfo->encoderCodec);
    AVCodecContext* c = avcodec_alloc_context3(outputFileInfo->encoderCodec);
	outputFileInfo->outputCodecContext = stream->codec;
	// avcodec_copy_context( outputCodecContext, inputCodecContext );
	outputFileInfo->outputCodecContext->pix_fmt = timelineInfoList[0]->inputCodecContext->pix_fmt;

	outputFileInfo->outputCodecContext->width = timelineInfoList[0]->inputCodecContext->width;
	outputFileInfo->outputCodecContext->height = timelineInfoList[0]->inputCodecContext->height;

	// put sample parameters
    outputFileInfo->outputCodecContext->bit_rate = 400000;
    // resolution must be a multiple of two
    //c->width = 352;
    //c->height = 288;
    // frames per second

	AVRational temp;
	temp.num = 1;
	temp.den = 30;
    outputFileInfo->outputCodecContext->time_base= temp;
    outputFileInfo->outputCodecContext->gop_size = 10; // emit one intra frame every ten frames
    outputFileInfo->outputCodecContext->max_b_frames=1;

	/*
	outputCodecContext->bit_rate = inputCodecContext->bit_rate;
	outputCodecContext->bit_rate_tolerance = inputCodecContext->bit_rate_tolerance;
	outputCodecContext->qmax = inputCodecContext->qmax;
	outputCodecContext->qmin = inputCodecContext->qmin;	
	*/

	// 프레임 속도 설정
	SetFrameRate(outputFileInfo->outputCodecContext, 30);

	// videoStream->r_frame_rate.num / (double) videoStream->r_frame_rate.den;

	if (outputFileInfo->outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
		outputFileInfo->outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	// 쓰기할 파일 열기
	if ((ret = avcodec_open2(outputFileInfo->outputCodecContext, outputFileInfo->encoderCodec, NULL)) < 0) {
		fprintf(stderr, "Failed to open codec\n");
		return FAILED;
	}
	
	if ((ret = avio_open(&(outputFileInfo->outputFormatContext->pb), outputFileInfo->outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
		fprintf(stderr, "Failed to avio_open\n");
		return FAILED;
	}

	if ((ret = avformat_write_header(outputFileInfo->outputFormatContext, NULL)) < 0) {
		fprintf(stderr, "Failed to header\n");
		return FAILED;
	}

	return SUCCESSED;
}

int FFMpegLib::Export(const char* outputFilePath) {

	if (timelineInfoList.size() == 0) {
		return FAILED;
	}

	int ret;

	AVFormatContext* outputFormatContext = NULL;
	AVCodecContext* outputCodecContext = NULL;
	AVCodec* encoderCodec = NULL;

	// 쓰기 할 코덱 찾기
	encoderCodec = avcodec_find_encoder(timelineInfoList[0]->inputCodecContext->codec_id);
	if (encoderCodec == NULL) {
		fprintf(stderr, "Failed to find encoder codec\n");
		return FAILED;
	}

	if ((ret = avformat_alloc_output_context2(&outputFormatContext, NULL, "avi", outputFilePath)) < 0) {
		fprintf(stderr, "Failed to alloc Context\n");
		return FAILED;
	}

	if (outputFormatContext == NULL) {
		fprintf(stderr, "Failed to instead format_name and filename \n");
		return FAILED;
	}
	
	// 쓰기 할 파일 정보 세팅 - 첫번째 파일로 하지 않고 설정되로 변경
	// 코덱들 테스트
	outputFormatContext->oformat->audio_codec = CODEC_ID_NONE;
	outputFormatContext->oformat->video_codec = timelineInfoList[0]->inputCodecContext->codec_id;
	outputFormatContext->audio_codec_id = CODEC_ID_NONE;
	outputFormatContext->video_codec_id = timelineInfoList[0]->inputCodecContext->codec_id;
	outputFormatContext->duration = timelineInfoList[0]->inputFormatContext->duration;
	
//	av_dict_copy(&(outputFormatContext->metadata), inputFormatContext->metadata, 0);
//	av_dict_set(&(outputFormatContext->metadata), "Author", "VPI", 0 );
	
	AVStream* stream = avformat_new_stream(outputFormatContext, encoderCodec);
    AVCodecContext* c = avcodec_alloc_context3(encoderCodec);
	outputCodecContext = stream->codec;
	// avcodec_copy_context( outputCodecContext, inputCodecContext );
	outputCodecContext->pix_fmt = timelineInfoList[0]->inputCodecContext->pix_fmt;

	outputCodecContext->width = timelineInfoList[0]->inputCodecContext->width;
	outputCodecContext->height = timelineInfoList[0]->inputCodecContext->height;

	// put sample parameters
    outputCodecContext->bit_rate = 400000;
    // resolution must be a multiple of two
    //c->width = 352;
    //c->height = 288;
    // frames per second
	
	AVRational temp;
	temp.num = 1;
	temp.den = 30;
    outputCodecContext->time_base= temp;
    outputCodecContext->gop_size = 10; // emit one intra frame every ten frames
    outputCodecContext->max_b_frames=1;

	/*
	outputCodecContext->bit_rate = inputCodecContext->bit_rate;
	outputCodecContext->bit_rate_tolerance = inputCodecContext->bit_rate_tolerance;
	outputCodecContext->qmax = inputCodecContext->qmax;
	outputCodecContext->qmin = inputCodecContext->qmin;	
	*/

	// 프레임 속도 설정
	SetFrameRate(outputCodecContext, 30);

	// videoStream->r_frame_rate.num / (double) videoStream->r_frame_rate.den;

	if (outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
		outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	// 쓰기할 파일 열기
	if ((ret = avcodec_open2(outputCodecContext, encoderCodec, NULL)) < 0) {
		fprintf(stderr, "Failed to open codec\n");
		return FAILED;
	}
	
	if ((ret = avio_open(&(outputFormatContext->pb), outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
		fprintf(stderr, "Failed to avio_open\n");
		return FAILED;
	}

	if ((ret = avformat_write_header(outputFormatContext, NULL)) < 0) {
		fprintf(stderr, "Failed to header\n");
		return FAILED;
	}

	/*
	// outputFileInfo가 활당되었는지 확인
	if (outputFileInfo == NULL) {
		return FAILED;
	}

	// outputFileInfo의 쓰기 정보가 저장된 outputFormatContext가 제대로 생성되었는지 확인
	if (outputFileInfo->outputFormatContext == NULL) {
		return FAILED;
	}
	*/


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 쓰기
	int64_t frameCount = 0;
	int64_t frameDts = 0;

	int size = timelineInfoList.size();
	for (int i=0; i<size; ++i) {
		AVPacket packet;
		av_init_packet(&packet);

		int64_t selectInfoFrameCount = 0;

		while (true) {
			if (packet.data != NULL) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// read를 해서 packet를 가져오는데 한개 프레임에 대한 packet를 다 받으면
			// bitmap으로 변환
			// bitmap 변환 후 이미지 효과 및 자막을 넣고
			// 해당 bitmap을 다시 packet으로 변환 
			// 변환된 packet를 하나씩 Write

			
			AVFrame* frame = avcodec_alloc_frame();

			if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				return false;
			}

	//		++frameCount;
	//		++frameDts;

			if (timelineInfoList[i]->startFrame <= selectInfoFrameCount && timelineInfoList[i]->endFrame >= selectInfoFrameCount) {
				AVPacket encodePacket;
				av_init_packet(&encodePacket);

				if (GetEncodeVideoFrame(outputCodecContext, frame, &encodePacket) == false) {
					return false;
				}

			//	ret = av_interleaved_write_frame(outputFormatContext, &encodePacket);

				encodePacket.dts = frameDts;
				ret = av_write_frame(outputFormatContext, &encodePacket);
				++frameCount;
				++frameDts;

			//	ret = av_write_frame(outputFormatContext, &encodePacket);

				++selectInfoFrameCount;

				av_free_packet(&encodePacket);
			}

			if (timelineInfoList[i]->endFrame < selectInfoFrameCount) {
				av_free(frame);
				break;
			}
		}

/*
		do {
			if (NULL != packet.data) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// read를 해서 packet를 가져오는데 한개 프레임에 대한 packet를 다 받으면
			// bitmap으로 변환
			// bitmap 변환 후 이미지 효과 및 자막을 넣고
			// 해당 bitmap을 다시 packet으로 변환 
			// 변환된 packet를 하나씩 Write
			AVFrame* frame = avcodec_alloc_frame();
			

			if (GetDecodeVideoFrame(timelineInfoList[i]->inputFormatContext, timelineInfoList[i]->inputCodecContext, timelineInfoList[i]->videoStreamIndex, frame) == false) {
				return false;
			}

			AVPacket encodePacket;
			av_init_packet(&encodePacket);

			if (GetEncodeVideoFrame(outputFormatContext, frame, encodePacket) == false) {
				return false;
			}

			ret = av_write_frame(outputFormatContext, &encodePacket);
			++frameCount;
			++frameDts;


			if (av_read_frame(timelineInfoList[i]->inputFormatContext, &packet) < 0 ) {
				break;
			}

			if (packet.stream_index == timelineInfoList[i]->videoStreamIndex) {

				AVFrame* frame;
				frame = avcodec_alloc_frame();

				int frameFinished = 0;
				int got_output;

				
				if (avcodec_decode_video2(timelineInfoList[i]->inputCodecContext, frame, &frameFinished, &packet) < 0) {
					fprintf(stderr, "Error while decoding frame\n");
					return false;
				}

				if (frameFinished == 0) {
					av_free_packet(&packet);
					continue;
				}

				int po = avcodec_encode_video2(outputCodecContext, &packet, frame, &got_output);




				if (got_output) {
					if (timelineInfoList[i]->startFrame <= infoFrameCount && timelineInfoList[i]->endFrame >= infoFrameCount) {
						packet.dts = frameDts;
						ret = av_write_frame(outputFormatContext, &packet);
						++frameCount;
						++frameDts;
					}

					++infoFrameCount;
				}

				if (timelineInfoList[i]->endFrame < infoFrameCount) {
					av_free(frame);
					break;
				}

				//++infoFrameCount;
				av_free_packet(&packet);
		//		av_free(frame);
			}
		} while (true);
		*/

		if (packet.data != NULL) {
			av_free_packet(&packet);
			packet.data = NULL;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 완료
	av_write_trailer(outputFormatContext);

	avcodec_close(outputCodecContext);
	avio_close(outputFormatContext->pb);
	outputFormatContext->pb = NULL;
	avformat_free_context(outputFormatContext);




	return SUCCESSED;
}




int FFMpegLib::SDLPlay(const char* filePath) {
	return SUCCESSED;
}

bool FFMpegLib::SaveFrame(AVFrame* frame, enum PixelFormat fmt, int width, int height, int index) {
	AVFrame* frameRGB;
	int numBytes;
	uint8_t* buffer;

	if (fmt != PIX_FMT_RGB24) {
		frameRGB = avcodec_alloc_frame();

		if (frameRGB == NULL) {
			return FAILED;
		}

		numBytes = avpicture_get_size(PIX_FMT_RGB24, width, height);
		buffer = new uint8_t[numBytes];
		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, width, height);


		struct SwsContext* toRGBContext = sws_getContext(width,
																					height,
																					fmt,
																					width,
																					height,
																					PIX_FMT_RGB24,
																					SWS_BICUBIC,
																					NULL,
																					NULL,
																					NULL);

			if (toRGBContext != NULL) {
				sws_scale(toRGBContext, frame->data, frame->linesize, 0, height, frameRGB->data, frameRGB->linesize);
			}
	} else {
		frameRGB = frame;
	}

	FILE* pFile = NULL;
//	char filePath[32];
	int y;

	//sprintf(filePath, "c:\\frame%d.ppm", index);
//pFile = fopen(filePath, "wb");

	if (pFile == NULL) {
		return FAILED;
	}

	fprintf(pFile, "P6\n%d %d\n255\n", width, height);

	for (y=0; y<height; ++y) {
		fwrite(frameRGB->data[0] + y * frameRGB->linesize[0], 1, width*3, pFile);
	}

	fclose(pFile);

	return SUCCESSED;
}

int FFMpegLib::GetVideoInfo(const char* inputFilePath, VideoInfo* info) {
	try {
		AVFormatContext* formatContext = NULL;
		
		// 비디오 파일 열기
		if (avformat_open_input(&formatContext, inputFilePath, NULL, NULL) < 0) {
			fprintf(stderr, "Could not open source file %s\n", inputFilePath);
			return FAILED;
		}

		// 스트림 정보 찾기
		if (avformat_find_stream_info(formatContext, NULL) < 0) {
			fprintf(stderr, "Could not find stream information\n");
			return FAILED;
		}

		// 스트림 중 비디오 타입의 인덱스 찾기
		int stream_idx = av_find_best_stream(formatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
		if (stream_idx < 0) {
			fprintf(stderr, "Could not find video stream in file\n");
			return FAILED;
		}

		AVStream* videoStream = formatContext->streams[stream_idx];
		AVCodecContext* codecContext = videoStream->codec;
		AVCodec* codec = avcodec_find_decoder(codecContext->codec_id);

		if (codec == NULL) {
			return FAILED;
		}

		// 정보 가져오기
		info->width = codecContext->width;
		info->height = codecContext->height;
		info->videoCodec = codec->name;

		if (videoStream->r_frame_rate.den != 0) {

			double frameRate = (double) videoStream->r_frame_rate.num / (double) videoStream->r_frame_rate.den;

			double temp = (double) videoStream->time_base.num / (double) videoStream->time_base.den;

			double runningTime = (double) videoStream->duration * temp;

			info->FrameRate = Round(frameRate);
			int time = Round(runningTime);

			info->runningTime.hour = time / 3600;
			info->runningTime.minute = (time % 3600) / 60;
			info->runningTime.second = (time % 3600) % 60;
		} else {
			info->FrameRate = 0;
			info->runningTime.hour = 0;
			info->runningTime.minute = 0;
			info->runningTime.second = 0;
		}

		strcpy_s(info->filePath, sizeof(info->filePath), inputFilePath);

		avcodec_close(codecContext);
		// av_close_input_file(formatContext);
		avformat_close_input(&formatContext);

	} catch(...) {
#ifdef _DEBUG
		Debug::Trace("GetVideoInfo 예외발생!!!");
#endif
	}

	return SUCCESSED;
}

int FFMpegLib::GetFrame(const char* inputFilePath, int count, int* frameIndex, Frame** output, int width, int height) {
	/*
	try {
//	avcodec_init();
		AVFormatContext* formatContext = NULL;

		if (av_open_input_file(&formatContext, inputFilePath, NULL, 0, NULL) != 0) {
			return FAILED;
		}

		if (av_find_stream_info(formatContext) < 0) {
			return FAILED;
		}

		dump_format(formatContext, 0, inputFilePath, false);

		AVCodecContext* codecContext;

		int videoStream = -1;

		for (int i=0; formatContext->nb_streams; ++i) {
			if (formatContext->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
				videoStream = i;
				break;
			}
		}

		if (videoStream == -1) {
			return FAILED;
		}

		codecContext = formatContext->streams[videoStream]->codec;

		AVCodec* codec;
		codec = avcodec_find_decoder(codecContext->codec_id);

		if (codec == NULL) {
			return FAILED;
		}

		if (codec->capabilities & CODEC_CAP_TRUNCATED) {
			codecContext->flags |= CODEC_FLAG_TRUNCATED;
		}

		if (avcodec_open(codecContext, codec) < 0) {
			return FAILED;
		}

		AVFrame* frameRGB;
		int numBytes;
		uint8_t* buffer;

		frameRGB = avcodec_alloc_frame();
		if (frameRGB == NULL) {
			return FAILED;
		}

		numBytes = avpicture_get_size(PIX_FMT_RGB24, codecContext->width, codecContext->height);
		buffer = new uint8_t[numBytes];
		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, codecContext->width, codecContext->height);

		AVFrame* frame;
		frame = avcodec_alloc_frame();

		// output 크기 설정
		if (width <= 0 && height <= 0) {
			width = codecContext->width;
			height = codecContext->height;
		}

		unsigned int idX = 0;
		AVRational one;
		one.num = 1;
		one.den = AV_TIME_BASE;

		double duration = (double) formatContext->duration / AV_TIME_BASE;
		AVStream* tmpStream = formatContext->streams[videoStream];

		if( duration <= 0) {
			double tmpDuration = 0.0;
			
			if (tmpStream->codec->bit_rate > 0 && formatContext->file_size > 0) {
				if (tmpStream->codec->bit_rate >= 8) {
					tmpDuration = 0.9 * formatContext->file_size / (tmpStream->codec->bit_rate / 8);
				}
				if (tmpDuration > 0) {
					duration = tmpDuration;
				}
			}
		}

		if (duration <= 0) {
			return FAILED;
		}

		for (int i=0; i<count; ++i) {
			int64_t seek_target = frameIndex[i];
			int retval = av_seek_frame(formatContext, videoStream, seek_target, 0);

			if (GetVideoFrame(formatContext, codecContext, videoStream, frame) == true) {
				struct SwsContext* toRGBContext = sws_getContext(codecContext->width,
																				codecContext->height,
																				codecContext->pix_fmt,
																				width,
																				height,
																				PIX_FMT_RGB24,
																				SWS_BICUBIC,
																				NULL,
																				NULL,
																				NULL);

				if (toRGBContext != NULL) {
					sws_scale(toRGBContext, frame->data, frame->linesize, 0, codecContext->height, frameRGB->data, frameRGB->linesize);
				}

				AVFrameToImage(frameRGB, width, height, output[i]);
				
				sws_freeContext(toRGBContext);
			}
		}

		delete [] buffer;
		av_free(frameRGB);
		av_free(frame);
		avcodec_close(codecContext);
		av_close_input_file(formatContext);

	} catch(...) {
#ifdef _DEBUG
		Debug::Trace("GetFrame 예외발생!!!");
#endif
	}
*/
	return SUCCESSED;
}

int64_t FFMpegLib::SeekMS(AVStream* videoStream, int ms) {
	int64_t frameIndex = av_rescale(ms, videoStream->time_base.den, videoStream->time_base.num);
	frameIndex /= 1000;

	return frameIndex;
}

int FFMpegLib::GetFrame(const char* inputFilePath, int frameIndex, Frame* output, int width, int height) {
	try {
		int ret = 0;
		AVFormatContext* formatContext = NULL;
		
		// 비디오 파일 열기
		if (avformat_open_input(&formatContext, inputFilePath, NULL, NULL) < 0) {
			fprintf(stderr, "Could not open source file %s\n", inputFilePath);
			return FAILED;
		}

		// 스트림 정보 찾기
		if (avformat_find_stream_info(formatContext, NULL) < 0) {
			fprintf(stderr, "Could not find stream information\n");
			return FAILED;
		}

		// 스트림 중 비디오 타입의 인덱스 찾기
		int stream_idx = av_find_best_stream(formatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
		if (stream_idx < 0) {
			fprintf(stderr, "Could not find video stream in file\n");
			return FAILED;
		}

		AVStream* videoStream = formatContext->streams[stream_idx];
		AVCodecContext* codecContext = videoStream->codec;
		AVCodec* codec = avcodec_find_decoder(codecContext->codec_id);

		if (codec == NULL) {
			return FAILED;
		}

		if ((ret = avcodec_open2(codecContext, codec, NULL)) < 0) {
			fprintf(stderr, "Failed to open codec\n");
			return FAILED;
		}

		av_dump_format(formatContext, 0, inputFilePath, 0);

		AVFrame* frame;
		frame = avcodec_alloc_frame();

		// output 크기 설정
		if (width <= 0 && height <= 0) {
			width = codecContext->width;
			height = codecContext->height;
		}

		ret = av_seek_frame(formatContext, stream_idx, frameIndex, 0);

		AVFrame* frameRGB;
		int numBytes;
		uint8_t* buffer;

		frameRGB = avcodec_alloc_frame();

		if (frameRGB == NULL) {
			return FAILED;
		}

		numBytes = avpicture_get_size(PIX_FMT_RGB24, codecContext->width, codecContext->height);
		buffer = new uint8_t[numBytes];
		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, codecContext->width, codecContext->height);

		if (GetVideoFrame(formatContext, codecContext, stream_idx, frame) == true) {
			struct SwsContext* toRGBContext = sws_getContext(codecContext->width,
																			codecContext->height,
																			codecContext->pix_fmt,
																			width,
																			height,
																			PIX_FMT_RGB24,
																			SWS_BICUBIC,
																			NULL,
																			NULL,
																			NULL);

			if (toRGBContext != NULL) {
				sws_scale(toRGBContext, frame->data, frame->linesize, 0, codecContext->height, frameRGB->data, frameRGB->linesize);
			}

			AVFrameToImage(frameRGB, width, height, output);
			
			sws_freeContext(toRGBContext);
		}

		delete [] buffer;
		av_free(frameRGB);
		av_free(frame);
		avcodec_close(codecContext);
		av_close_input_file(formatContext);
	} catch(...) {
#ifdef _DEBUG
		Debug::Trace("GetFrame 예외발생!!!");
#endif
	}
	

	return SUCCESSED;
}

/*
int FFMpegLib::GetFrame(const char* inputFilePath, int frameIndex, Frame* output, int width, int height) {
	try {
		avcodec_init();
		AVFormatContext* formatContext = NULL;

		if (av_open_input_file(&formatContext, inputFilePath, NULL, 0, NULL) != 0) {
			return FAILED;
		}

		if (av_find_stream_info(formatContext) < 0) {
			return FAILED;
		}

		dump_format(formatContext, 0, inputFilePath, false);

		AVCodecContext* codecContext;

		int videoStream = -1;

		for (int i=0; formatContext->nb_streams; ++i) {
			if (formatContext->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
				videoStream = i;
				break;
			}
		}

		if (videoStream == -1) {
			return FAILED;
		}

		codecContext = formatContext->streams[videoStream]->codec;

		AVCodec* codec;
		codec = avcodec_find_decoder(codecContext->codec_id);

		if (codec == NULL) {
			return FAILED;
		}

		if (codec->capabilities & CODEC_CAP_TRUNCATED) {
			codecContext->flags |= CODEC_FLAG_TRUNCATED;
		}

		if (avcodec_open(codecContext, codec) < 0) {
			return FAILED;
		}

		AVFrame* frameRGB;
		int numBytes;
		uint8_t* buffer;

		frameRGB = avcodec_alloc_frame();
		if (frameRGB == NULL) {
			return FAILED;
		}
		numBytes = avpicture_get_size(PIX_FMT_RGB24, codecContext->width, codecContext->height);
		buffer = new uint8_t[numBytes];
		avpicture_fill((AVPicture*) frameRGB, buffer, PIX_FMT_RGB24, codecContext->width, codecContext->height);

		AVFrame* frame;
		frame = avcodec_alloc_frame();

		// output 크기 설정
		if (width <= 0 && height <= 0) {
			width = codecContext->width;
			height = codecContext->height;
		}

		unsigned int idX = 0;
		AVRational one;
		one.num = 1;
		one.den = AV_TIME_BASE;

		double duration = (double) formatContext->duration / AV_TIME_BASE;
		AVStream* tmpStream = formatContext->streams[videoStream];

		if( duration <= 0) {
			double tmpDuration = 0.0;
			
			if (tmpStream->codec->bit_rate > 0 && formatContext->file_size > 0) {
				if (tmpStream->codec->bit_rate >= 8) {
					tmpDuration = 0.9 * formatContext->file_size / (tmpStream->codec->bit_rate / 8);
				}
				if (tmpDuration > 0) {
					duration = tmpDuration;
				}
			}
		}

		if (duration <= 0) {
			return FAILED;
		}

		int64_t seek_target = frameIndex;


		// seek_target = av_rescale_q(seek_target, one, tmpStream->time_base);
		int retval = av_seek_frame(formatContext, videoStream, seek_target, 0);

		if (GetVideoFrame(formatContext, codecContext, videoStream, frame) == true) {
			struct SwsContext* toRGBContext = sws_getContext(codecContext->width,
																			codecContext->height,
																			codecContext->pix_fmt,
																			width,
																			height,
																			PIX_FMT_RGB24,
																			SWS_BICUBIC,
																			NULL,
																			NULL,
																			NULL);

			if (toRGBContext != NULL) {
				sws_scale(toRGBContext, frame->data, frame->linesize, 0, codecContext->height, frameRGB->data, frameRGB->linesize);
			}

			AVFrameToImage(frameRGB, width, height, output);
			
			sws_freeContext(toRGBContext);
		}

		delete [] buffer;
		av_free(frameRGB);
		av_free(frame);
		avcodec_close(codecContext);
		av_close_input_file(formatContext);
	} catch(...) {
#ifdef _DEBUG
		Debug::Trace("GetFrame 예외발생!!!");
#endif
	}

	return SUCCESSED;
}
*/

////////////////////////////////////////////////////////
// 다음 Frame 이동 
/*
bool FFMpegLib::GetVideoFrame(AVFormatContext *pFormatCtx, AVCodecContext *pCodecCtx, int videoStream, AVFrame *pFrame)
{
	
	static AVPacket packet;
	static int bytesRemaining=0;
	static uint8_t *rawData;
	static bool fFirstTime=true;
	int bytesDecoded;
	int frameFinished;

	if (fFirstTime) {
		fFirstTime = false;
		packet.data = NULL;
	}

	while (true) {
		while (bytesRemaining > 0) {
			bytesDecoded = avcodec_decode_video2(pCodecCtx, pFrame, &frameFinished, &packet);

			if (bytesDecoded < 0) {
				fprintf(stderr, "Error while decoding frame\n");
				return false;
			}

			bytesRemaining-=bytesDecoded;
			rawData+=bytesDecoded;

			if (frameFinished) {
				return true;
			}
		} 
		
		do { 
			if (packet.data!=NULL) {
				av_free_packet(&packet); 
			}
			
			if (av_read_packet(pFormatCtx, &packet)<0) {
				goto loop_exit; 
			}
	
		} while (packet.stream_index!=videoStream); 

		bytesRemaining=packet.size; 
		rawData=packet.data; 
	}

	loop_exit:     

	if(packet.data!=NULL) {
		av_free_packet(&packet); 
	}
	
	return (frameFinished!=0);
	
	return true;
}
*/


bool FFMpegLib::SetVideoFrame(int64_t dts, AVFormatContext* formatContext, AVStream* stream, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* inputFrame) {
	// encode the image
	int ret;
	int got_output;
	

/*
    AVPacket pkt;
    av_init_packet(&pkt);
	static int64_t frameDts = 0;

	avcodec_encode_video2(codecContext, &pkt, inputFrame, &got_output);
	//	pkt.dts = frameDts;
	//	frameDts++;
		//if (got_output) {
	pkt.stream_index = stream->index;

            // Write the compressed frame to the media file.
	ret = av_interleaved_write_frame(formatContext, &pkt);
	//	ret = av_write_frame(formatContext, &pkt);
	*/
	    AVPacket pkt;

        av_init_packet(&pkt);
        pkt.data = NULL;    // packet data will be allocated by the encoder
        pkt.size = 0;
		
		static int64_t frameDts = 0;

		while (avcodec_encode_video2(codecContext, &pkt, inputFrame, &got_output) >= 0) {


			// If size is zero, it means the image was buffered.
			if (got_output) {
				if (codecContext->coded_frame->pts != AV_NOPTS_VALUE) {
					pkt.pts = av_rescale_q(codecContext->coded_frame->pts, codecContext->time_base, stream->time_base);
				}

				if (codecContext->coded_frame->key_frame) {
					pkt.flags |= AV_PKT_FLAG_KEY;
				}

		//		pkt.dts = frameDts;
		//		frameDts++;

				pkt.stream_index = videoStreamIndex;

				// Write the compressed frame to the media file.
				ret = av_write_frame(formatContext, &pkt);
				break;
			} 
		}


	/*
	while (avcodec_encode_video2(codecContext, &pkt, inputFrame, &got_output) >= 0) {

		pkt.stream_index = stream->index;
		pkt.dts = frameDts;
		ret = av_write_frame(formatContext, &pkt);
		frameDts++;
		// If size is zero, it means the image was buffered.
		if (got_output) {

			// Write the compressed frame to the media file.
			
			break;
		} 
	}
	*/


	return SUCCESSED;
}

bool FFMpegLib::GetVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* outputFrame)
{
	AVPacket packet;
	int frameFinished = 0;

	av_init_packet(&packet);

	while (av_read_frame(formatContext, &packet) >= 0) {
		if (packet.stream_index == videoStreamIndex) {
			
			if (avcodec_decode_video2(codecContext, outputFrame, &frameFinished, &packet) < 0) {
				fprintf(stderr, "Error while decoding frame\n");
				return false;
			}

			if (frameFinished != 0) {
				break;
			}
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

bool FFMpegLib::GetDecodeVideoFrame(AVFormatContext* formatContext, AVCodecContext* codecContext, int videoStreamIndex, AVFrame* outputFrame)
{
	AVPacket packet;
	int frameFinished = 0;

	av_init_packet(&packet);

	while (av_read_frame(formatContext, &packet) >= 0) {
		if (packet.stream_index == videoStreamIndex) {
			
			if (avcodec_decode_video2(codecContext, outputFrame, &frameFinished, &packet) < 0) {
				fprintf(stderr, "Error while decoding frame\n");
				return false;
			}

			if (frameFinished != 0) {
				break;
			}
		}
	}

	av_free_packet(&packet);

	return (frameFinished!=0);
}

bool FFMpegLib::GetEncodeVideoFrame(AVCodecContext* codecContext, const AVFrame* frame, AVPacket* packet) {

	int gotOutput;

	
	av_new_packet(packet, 1200*1000);
	av_init_packet(packet);

	while (true) {
		if (packet->data != NULL) {
			av_free_packet(packet);
			packet->data = NULL;

			av_new_packet(packet, 1200*1000);
			av_init_packet(packet);
		}

		int ret = avcodec_encode_video2(codecContext, packet, frame, &gotOutput);

		if (ret != 0) {
			int result = 0;
			result = 1;
		}

		if (gotOutput) {
			return true;
		}
	}

	return false;
}


int FFMpegLib::AVFrameToImage(AVFrame* frame, int width, int height, Frame* output) {
	
	output->height = height;
	output->width = width;

	//output->pixel = new uint8_t* [height];
	output->pixel = 0;
	output->pixel = (uint8_t**) malloc(sizeof(uint8_t*)*height);

	if (output->pixel == 0) {
		return FAILED;
	}

	for (int i=0; i<height; ++i) {
		output->pixel[i] = 0;
		output->pixel[i] = (uint8_t*) malloc(sizeof(uint8_t)*width*3);

		if (output->pixel[i] == 0) {
			return FAILED;
		}
	}
	
	uint8_t* inputImage = frame->data[0];
	uint8_t* outputImage = output->pixel[0];

	int size = frame->linesize[0];

	for (int y=0; y<height; ++y) {
		// output->pixel[y] = new uint8_t [width*3];

	//	fwrite(frame->data[0] + y * frame->linesize[0], 1, width*3, outputFile);
		memcpy(output->pixel[y], frame->data[0] + y * frame->linesize[0], width*3);
	}

	return SUCCESSED;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// audio output

// add an audio output stream 
AVStream* FFMpegLib::AddAudioStream(AVFormatContext *oc, AVCodec **codec, enum AVCodecID codec_id) {
    AVCodecContext* c;
    AVStream* st;

    // find the audio encoder
    *codec = avcodec_find_encoder(codec_id);
    if (!(*codec)) {
        fprintf(stderr, "codec not found\n");
        return NULL;
    }

	st = avformat_new_stream(oc, *codec);
    if (!st) {
        fprintf(stderr, "Could not alloc stream\n");
        return NULL;
    }

    st->id = 1;
    c = st->codec;

    // put sample parameters
    c->sample_fmt = AV_SAMPLE_FMT_S16;
    c->bit_rate = 64000;
    c->sample_rate = 44100;
    c->channels = 2;

    // some formats want stream headers to be separate
	if (oc->oformat->flags & AVFMT_GLOBALHEADER) {
        c->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

    return st;
}

int FFMpegLib::OpenAudio(AVFormatContext* oc, AVCodec* codec, AVStream* st) {
    AVCodecContext* c;
    c = st->codec;

    // open it
    if (avcodec_open2(c, codec, NULL) < 0) {
        fprintf(stderr, "could not open codec\n");
        return FAILED;
    }

    // init signal generator
    t     = 0;
    tincr = (float) (2 * M_PI * 110.0 / c->sample_rate);
    // increment frequency by 110 Hz per second
    tincr2 = (float) (2 * M_PI * 110.0 / c->sample_rate / c->sample_rate);

	if (c->codec->capabilities & CODEC_CAP_VARIABLE_FRAME_SIZE) {
        audio_input_frame_size = 10000;
	} else {
        audio_input_frame_size = c->frame_size;
	}

    samples = (int16_t*) av_malloc(audio_input_frame_size * av_get_bytes_per_sample(c->sample_fmt) * c->channels);

	return SUCCESSED;
}

// prepare a 16 bit dummy audio frame of 'frame_size' samples and
// 'nb_channels' channels
int FFMpegLib::GetAudioFrame(int16_t* samples, int frame_size, int nb_channels) {
    int j, i, v;
    int16_t* q;

    q = samples;

    for (j = 0; j < frame_size; j++) {
        v = (int)(sin(t) * 10000);

		for (i = 0; i < nb_channels; i++) {
            *q++ = v;
		}

        t     += tincr;
        tincr += tincr2;
    }

	return SUCCESSED;
}

int FFMpegLib::CloseAudio(AVFormatContext* oc, AVStream* st) {
    avcodec_close(st->codec);
    av_free(samples);

	return SUCCESSED;
}

int FFMpegLib::WriteAudioFrame(AVFormatContext* oc, AVStream* st) {
    AVCodecContext* c;
    AVPacket pkt = { 0 }; // data and size must be 0;
    AVFrame* frame = avcodec_alloc_frame();
    int got_packet;

    av_init_packet(&pkt);
    c = st->codec;

    GetAudioFrame(samples, audio_input_frame_size, c->channels);
    frame->nb_samples = audio_input_frame_size;
    avcodec_fill_audio_frame(frame, c->channels, c->sample_fmt, (uint8_t *)samples,
                                        audio_input_frame_size * av_get_bytes_per_sample(c->sample_fmt) * c->channels, 1);

    avcodec_encode_audio2(c, &pkt, frame, &got_packet);
	if (!got_packet) {
        return SUCCESSED;
	}

    pkt.stream_index = st->index;

    // Write the compressed frame to the media file.
    if (av_interleaved_write_frame(oc, &pkt) != 0) {
        fprintf(stderr, "Error while writing audio frame\n");
        return FAILED;
    }

	return SUCCESSED;
}

/////////////////////////////////////////////////////////////////////////////////////
// video output

// add a video output stream
AVStream* FFMpegLib::AddVideoStream(AVFormatContext* oc, AVCodec** codec, enum AVCodecID codec_id) {
    AVCodecContext* c;
    AVStream* st;

    // find the video encoder
    *codec = avcodec_find_encoder(codec_id);
    if (!(*codec)) {
        fprintf(stderr, "codec not found\n");
        return NULL;
    }

    st = avformat_new_stream(oc, *codec);
    if (!st) {
        fprintf(stderr, "Could not alloc stream\n");
        return NULL;
    }

    c = st->codec;

    avcodec_get_context_defaults3(c, *codec);

    c->codec_id = codec_id;

    // Put sample parameters.
    c->bit_rate = 400000;
    // Resolution must be a multiple of two.
    c->width    = 352;
    c->height   = 288;
    // timebase: This is the fundamental unit of time (in seconds) in terms
    // of which frame timestamps are represented. For fixed-fps content,
    // timebase should be 1/framerate and timestamp increments should be
    // identical to 1.
    c->time_base.den = STREAM_FRAME_RATE;
    c->time_base.num = 1;
    c->gop_size      = 12; // emit one intra frame every twelve frames at most
    c->pix_fmt       = STREAM_PIX_FMT;
    if (c->codec_id == AV_CODEC_ID_MPEG2VIDEO) {
        // just for testing, we also add B frames
        c->max_b_frames = 2;
    }

    if (c->codec_id == AV_CODEC_ID_MPEG1VIDEO) {
        // Needed to avoid using macroblocks in which some coeffs overflow.
        // This does not happen with normal video, it just happens here as
        // the motion of the chroma plane does not match the luma plane.
        c->mb_decision = 2;
    }
    // Some formats want stream headers to be separate.
	if (oc->oformat->flags & AVFMT_GLOBALHEADER) {
        c->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

    return st;
}

AVFrame* FFMpegLib::AllocPicture(enum PixelFormat pix_fmt, int width, int height) {
    AVFrame* picture = avcodec_alloc_frame();

	if (!picture || avpicture_alloc((AVPicture *)picture, pix_fmt, width, height) < 0) {
        av_freep(&picture);
	}

    return picture;
}

int FFMpegLib::OpenVideo(AVFormatContext* oc, AVCodec* codec, AVStream* st) {
    AVCodecContext* c;
    c = st->codec;

    // open the codec
    if (avcodec_open2(c, codec, NULL) < 0) {
        fprintf(stderr, "could not open codec\n");
        return FAILED;
    }

    video_outbuf = NULL;
    if (!(oc->oformat->flags & AVFMT_RAWPICTURE)) {
        // Allocate output buffer.
        // XXX: API change will be done.
        // Buffers passed into lav* can be allocated any way you prefer,
        // as long as they're aligned enough for the architecture, and
        // they're freed appropriately (such as using av_free for buffers
        // allocated with av_malloc).
        video_outbuf_size = 200000;
        video_outbuf = (uint8_t*) av_malloc(video_outbuf_size);
    }

    // Allocate the encoded raw picture.
    picture = AllocPicture(c->pix_fmt, c->width, c->height);
    if (!picture) {
        fprintf(stderr, "Could not allocate picture\n");
        return FAILED;
    }

    // If the output format is not YUV420P, then a temporary YUV420P
    // picture is needed too. It is then converted to the required
    // output format.
    tmp_picture = NULL;
    if (c->pix_fmt != PIX_FMT_YUV420P) {
        tmp_picture = AllocPicture(PIX_FMT_YUV420P, c->width, c->height);
        if (!tmp_picture) {
            fprintf(stderr, "Could not allocate temporary picture\n");
            return FAILED;
        }
    }
	
	return SUCCESSED;
}

// prepare a dummy image
int FFMpegLib::FillYuvImage(AVFrame* pict, int frame_index, int width, int height) {
    int x, y, i;
    i = frame_index;

    // Y
	for (y = 0; y < height; y++) {
		for (x = 0; x < width; x++) {
            pict->data[0][y * pict->linesize[0] + x] = 0;
		}
	}

    // Cb and Cr
    for (y = 0; y < height / 2; y++) {
        for (x = 0; x < width / 2; x++) {
            pict->data[1][y * pict->linesize[1] + x] = 0;
            pict->data[2][y * pict->linesize[2] + x] = 0;
        }
    }

	return SUCCESSED;
}

int FFMpegLib::CloseVideo(AVFormatContext* oc, AVStream* st) {
    avcodec_close(st->codec);
    av_free(picture->data[0]);
    av_free(picture);

    if (tmp_picture) {
        av_free(tmp_picture->data[0]);
        av_free(tmp_picture);
    }

    av_free(video_outbuf);

	return SUCCESSED;
}

int FFMpegLib::WriteVideoFrame(AVFormatContext* oc, AVStream* st) {
    int ret;
    AVCodecContext* c;
    static struct SwsContext* img_convert_ctx;

    c = st->codec;

    if (frame_count >= STREAM_NB_FRAMES) {
        // No more frames to compress. The codec has a latency of a few
        // frames if using B-frames, so we get the last frames by
        // passing the same picture again.
    } else {
        if (c->pix_fmt != PIX_FMT_YUV420P) {
            // as we only generate a YUV420P picture, we must convert it
            // to the codec pixel format if needed
            if (img_convert_ctx == NULL) {
                img_convert_ctx = sws_getContext(c->width, c->height,
                                                 PIX_FMT_YUV420P,
                                                 c->width, c->height,
                                                 c->pix_fmt,
                                                 sws_flags, NULL, NULL, NULL);

                if (img_convert_ctx == NULL) {
                    fprintf(stderr, "Cannot initialize the conversion context\n");
                    return FAILED;   
                }
            }

            FillYuvImage(tmp_picture, frame_count, c->width, c->height);
            sws_scale(img_convert_ctx,
                      (const uint8_t * const *)tmp_picture->data, tmp_picture->linesize,
                      0, c->height, picture->data, picture->linesize);
        } else {
            FillYuvImage(picture, frame_count, c->width, c->height);
        }
    }

    if (oc->oformat->flags & AVFMT_RAWPICTURE) {
        // Raw video case - the API will change slightly in the near
        // future for that.
        AVPacket pkt;
        av_init_packet(&pkt);
        pkt.flags |= AV_PKT_FLAG_KEY;
        pkt.stream_index = st->index;
        pkt.data = (uint8_t *)picture;
        pkt.size = sizeof(AVPicture);
        ret = av_interleaved_write_frame(oc, &pkt);
    } else {
        // encode the image
        AVPacket pkt;
        int got_output;

        av_init_packet(&pkt);
        pkt.data = NULL;    // packet data will be allocated by the encoder
        pkt.size = 0;

        ret = avcodec_encode_video2(c, &pkt, picture, &got_output);
        if (ret < 0) {
            fprintf(stderr, "error encoding frame\n");
            return FAILED;                               
        }

        // If size is zero, it means the image was buffered.
        if (got_output) {
			if (c->coded_frame->pts != AV_NOPTS_VALUE) {
                pkt.pts = av_rescale_q(c->coded_frame->pts, c->time_base, st->time_base);
			}

			if (c->coded_frame->key_frame) {
                pkt.flags |= AV_PKT_FLAG_KEY;
			}

            pkt.stream_index = st->index;

            // Write the compressed frame to the media file.
            ret = av_interleaved_write_frame(oc, &pkt);
        } else {
            ret = 0;
        }
    }
    if (ret != 0) {
        fprintf(stderr, "Error while writing video frame\n");
        return FAILED;
    }

    frame_count++;

	return SUCCESSED;
}

int FFMpegLib::Export(const char* inputFilePath, const char* outputFilePath) {
	int ret;
	int videoStreamIndex = -1;

	AVFormatContext* inputFormatContext = NULL;
	AVCodecContext* inputCodecContext = NULL;
	AVCodec* decoderCodec = NULL;

	int videoStreamIndex2 = -1;
	AVFormatContext* inputFormatContext2 = NULL;
	AVCodecContext* inputCodecContext2 = NULL;
	AVCodec* decoderCodec2 = NULL;

	AVFormatContext* outputFormatContext = NULL;
	AVCodecContext* outputCodecContext = NULL;
	AVCodec* encoderCodec = NULL;

	// 변환 할 비디오 파일 열기
	if (avformat_open_input(&inputFormatContext, inputFilePath, NULL, NULL) < 0) {
		fprintf(stderr, "Could not open source file %s\n", inputFilePath);
		return FAILED;
	}

	// 스트림 정보 찾기
	if (avformat_find_stream_info(inputFormatContext, NULL) < 0) {
		fprintf(stderr, "Could not find stream information\n");
		return FAILED;
	}

	// 비디오 타입 스트림의 인덱스 찾기
	videoStreamIndex = av_find_best_stream(inputFormatContext, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (videoStreamIndex < 0) {
		fprintf(stderr, "Could not find video stream in file\n");
		return FAILED;
	}

	// decoder Codec 찾기
	AVStream* videoStream = inputFormatContext->streams[videoStreamIndex];
	inputCodecContext = videoStream->codec;
	decoderCodec = avcodec_find_decoder(inputCodecContext->codec_id);

	if (decoderCodec == NULL) {
		fprintf(stderr, "Failed to find decoder codec\n");
		return FAILED;
	}

	if ((ret = avcodec_open2(inputCodecContext, decoderCodec, NULL)) < 0) {
		fprintf(stderr, "Failed to open codec\n");
		return FAILED;
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 변환 할 비디오 파일 열기
	if (avformat_open_input(&inputFormatContext2, "C:\\0\\4.avi", NULL, NULL) < 0) {
		fprintf(stderr, "Could not open source file %s\n", "C:\\0\\4.avi");
		return FAILED;
	}

	// 스트림 정보 찾기
	if (avformat_find_stream_info(inputFormatContext2, NULL) < 0) {
		fprintf(stderr, "Could not find stream information\n");
		return FAILED;
	}

	// 비디오 타입 스트림의 인덱스 찾기
	videoStreamIndex2 = av_find_best_stream(inputFormatContext2, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	if (videoStreamIndex2 < 0) {
		fprintf(stderr, "Could not find video stream in file\n");
		return FAILED;
	}

	// decoder Codec 찾기
	AVStream* videoStream2 = inputFormatContext2->streams[videoStreamIndex2];
	inputCodecContext2 = videoStream2->codec;
	decoderCodec2 = avcodec_find_decoder(inputCodecContext2->codec_id);

	if (decoderCodec2 == NULL) {
		fprintf(stderr, "Failed to find decoder codec\n");
		return FAILED;
	}

	if ((ret = avcodec_open2(inputCodecContext2, decoderCodec2, NULL)) < 0) {
		fprintf(stderr, "Failed to open codec\n");
		return FAILED;
	}



	// 쓰기 할 코덱 찾기
	encoderCodec = avcodec_find_encoder(inputCodecContext->codec_id);
	if (encoderCodec == NULL) {
		fprintf(stderr, "Failed to find encoder codec\n");
		return FAILED;
	}

	if ((ret = avformat_alloc_output_context2(&outputFormatContext, NULL, "avi", outputFilePath)) < 0) {
		fprintf(stderr, "Failed to alloc Context\n");
		return FAILED;
	}

	if (outputFormatContext == NULL) {
		fprintf(stderr, "Failed to instead format_name and filename \n");
		return FAILED;
	}
	
	// 쓰기 할 파일 정보 세팅
	outputFormatContext->oformat->audio_codec = CODEC_ID_NONE;
	outputFormatContext->oformat->video_codec = inputCodecContext->codec_id;
	outputFormatContext->audio_codec_id = CODEC_ID_NONE;
	outputFormatContext->video_codec_id = inputCodecContext->codec_id;
	outputFormatContext->duration = inputFormatContext->duration;
		
//	av_dict_copy(&(outputFormatContext->metadata), inputFormatContext->metadata, 0);
//	av_dict_set(&(outputFormatContext->metadata), "Author", "VPI", 0 );
	
	AVStream* stream = avformat_new_stream(outputFormatContext, encoderCodec);
	
    AVCodecContext* c = avcodec_alloc_context3(encoderCodec);

	outputCodecContext = stream->codec;
	// avcodec_copy_context( outputCodecContext, inputCodecContext );
	outputCodecContext->pix_fmt = inputCodecContext->pix_fmt;

	outputCodecContext->width = inputCodecContext->width;
	outputCodecContext->height = inputCodecContext->height;

	int width = 320;
	int height = 240;

	// put sample parameters
    outputCodecContext->bit_rate = 400000;
    // resolution must be a multiple of two
    //c->width = 352;
    //c->height = 288;
    // frames per second
	AVRational temp;
	temp.num = 1;
	temp.den = 30;
    outputCodecContext->time_base= temp;
    outputCodecContext->gop_size = 10; // emit one intra frame every ten frames
    outputCodecContext->max_b_frames=1;

	/*
	outputCodecContext->bit_rate = inputCodecContext->bit_rate;
	outputCodecContext->bit_rate_tolerance = inputCodecContext->bit_rate_tolerance;
	outputCodecContext->qmax = inputCodecContext->qmax;
	outputCodecContext->qmin = inputCodecContext->qmin;	
	*/

	// 프레임 속도 설정
	SetFrameRate(outputCodecContext, 30);

	// videoStream->r_frame_rate.num / (double) videoStream->r_frame_rate.den;

	if (outputFormatContext->oformat->flags & AVFMT_GLOBALHEADER) {
		outputCodecContext->flags |= CODEC_FLAG_GLOBAL_HEADER;
	}

	// 쓰기할 파일 열기
	if ((ret = avcodec_open2(outputCodecContext, encoderCodec, NULL)) < 0) {
		fprintf(stderr, "Failed to open codec\n");
		return FAILED;
	}
	
	if ((ret = avio_open(&(outputFormatContext->pb), outputFormatContext->filename, AVIO_FLAG_WRITE)) < 0) {
		fprintf(stderr, "Failed to avio_open\n");
		return FAILED;
	}

	if ((ret = avformat_write_header(outputFormatContext, NULL)) < 0) {
		fprintf(stderr, "Failed to header\n");
		return FAILED;
	}
	
	AVPacket packet;
	av_init_packet(&packet);

	int64_t frameCount = 0;
	int64_t frameDts = 0;

/*
	struct SwsContext* toContext = sws_getContext(inputCodecContext->width,
																inputCodecContext->height,
																inputCodecContext->pix_fmt,
																width,
																height,
																inputCodecContext->pix_fmt,
																SWS_BICUBIC,
																NULL,
																NULL,
																NULL);
	*/

	do {
		if (NULL != packet.data) {
			av_free_packet(&packet);
			packet.data = NULL;
		}

		
		if (frameCount < 100) {
			// 읽기
			if (av_read_frame(inputFormatContext, &packet) < 0 ) {
				break;
			}
		} else if (frameCount == 100) {
			avcodec_close(inputCodecContext);
			avio_close(inputFormatContext->pb);
			inputFormatContext->pb = NULL;
			avformat_close_input(&inputFormatContext);

			av_init_packet(&packet);
			if (NULL != packet.data) {
				av_free_packet(&packet);
				packet.data = NULL;
			}

			// 읽기
			if ((ret = av_read_frame(inputFormatContext2, &packet)) < 0 ) {
				break;
			}
		} else {
			// 읽기
			if ((ret = av_read_frame(inputFormatContext2, &packet)) < 0 ) {
				break;
			}
		}
		


		/*
		AVFrame* frame;
		frame = avcodec_alloc_frame();

		AVFrame* changedFrame;
		changedFrame = avcodec_alloc_frame();

		int numBytes;
		uint8_t* buffer;


		if (GetVideoFrame(inputFormatContext, inputCodecContext, videoStreamIndex, frame) == true) {
			if (toContext != NULL) {
			//	numBytes = avpicture_get_size(inputCodecContext->pix_fmt, inputCodecContext->width, inputCodecContext->height);
			//	buffer = new uint8_t[numBytes];
			//	avpicture_fill((AVPicture*) changedFrame, buffer, inputCodecContext->pix_fmt, inputCodecContext->width, inputCodecContext->height);

			//	sws_scale(toContext, frame->data, frame->linesize, 0, inputCodecContext->height, changedFrame->data, changedFrame->linesize);
			}

			if (frameDts == 20) {
				SaveFrame(frame, inputCodecContext->pix_fmt, inputCodecContext->width, inputCodecContext->height, frameDts);
			}

			if (SetVideoFrame(frameDts, outputFormatContext, stream, outputCodecContext, videoStreamIndex, frame) == true) {
				++frameDts;
			} else {
				int aaa = 10;
				aaa = 20;
			}

		//	delete [] buffer;

			av_free(frame);
			av_free(changedFrame);
		} else {
			av_free(frame);
			av_free(changedFrame);
			break;
		}
*/





		// 쓰기
		if (packet.stream_index == videoStreamIndex) {
			packet.dts = frameDts;

			ret = av_write_frame(outputFormatContext, &packet);

			++frameCount;
			++frameDts;
		} else {
			if (frameCount == 100) {
				++frameCount;
				frameDts += 100;
			}
		}

		if (frameCount > 1000) {
			break;
		}

	} while (true);


//	sws_freeContext(toContext);

	av_write_trailer(outputFormatContext);

	avcodec_close(outputCodecContext);
	avio_close(outputFormatContext->pb);
	outputFormatContext->pb = NULL;
	avformat_free_context(outputFormatContext);



	avcodec_close(inputCodecContext2);
	avio_close(inputFormatContext2->pb);
	inputFormatContext2->pb = NULL;
	avformat_close_input(&inputFormatContext2);

	if (packet.data != NULL) {
		av_free_packet(&packet);
		packet.data = NULL;
	}

	return SUCCESSED;
}

int FFMpegLib::SetFrameRate(AVCodecContext* outputCodecContext, int frameRate) {
	if (outputCodecContext == NULL) {
		return FAILED;
	}

	outputCodecContext->time_base.num = 1;
	outputCodecContext->time_base.den = frameRate;

	return SUCCESSED;
}

/*
int FFMpegLib::VideoEncoder(const char* filename, enum AVCodecID codec_id) {
    AVCodec* codec;
    AVCodecContext* c= NULL;
    int i, ret, x, y, got_output;
    FILE* f;
    AVFrame* picture;
    AVPacket pkt;
    uint8_t endcode[] = { 0, 0, 1, 0xb7 };

    printf("Encode video file %s\n", filename);

    // find the mpeg1 video encoder
    codec = avcodec_find_encoder(codec_id);
    if (!codec) {
        fprintf(stderr, "codec not found\n");
        return FAILED;       
    }

    c = avcodec_alloc_context3(codec);

    // put sample parameters
    c->bit_rate = 400000;
    // resolution must be a multiple of two
    c->width = 352;
    c->height = 288;
    // frames per second
	AVRational temp;
	temp.num = 1;
	temp.den = 25;
    c->time_base= temp;
    c->gop_size = 10; // emit one intra frame every ten frames
    c->max_b_frames=1;
    c->pix_fmt = PIX_FMT_YUV420P;

	if(codec_id == AV_CODEC_ID_H264) {
        av_opt_set(c->priv_data, "preset", "slow", 0);
	}

    // open it
    if (avcodec_open2(c, codec, NULL) < 0) {
        fprintf(stderr, "could not open codec\n");
        return FAILED;
    }

    f = fopen(filename, "wb");
    if (!f) {
        fprintf(stderr, "could not open %s\n", filename);
        return FAILED;
    }

    picture = avcodec_alloc_frame();
    if (!picture) {
        fprintf(stderr, "Could not allocate video frame\n");
        return FAILED;
    }
    picture->format = c->pix_fmt;
    picture->width  = c->width;
    picture->height = c->height;

    // the image can be allocated by any means and av_image_alloc() is
    // just the most convenient way if av_malloc() is to be used
    ret = av_image_alloc(picture->data, picture->linesize, c->width, c->height, c->pix_fmt, 32);
    if (ret < 0) {
        fprintf(stderr, "could not alloc raw picture buffer\n");
        return FAILED;
    }

    // encode 1 second of video
    for(i=0;i<25;i++) {
        av_init_packet(&pkt);
        pkt.data = NULL;    // packet data will be allocated by the encoder
        pkt.size = 0;

        fflush(stdout);
        // prepare a dummy image
        // Y
        for(y=0;y<c->height;y++) {
            for(x=0;x<c->width;x++) {
                picture->data[0][y * picture->linesize[0] + x] = x + y + i * 3;
            }
        }

        // Cb and Cr
        for(y=0;y<c->height/2;y++) {
            for(x=0;x<c->width/2;x++) {
                picture->data[1][y * picture->linesize[1] + x] = 128 + y + i * 2;
                picture->data[2][y * picture->linesize[2] + x] = 64 + x + i * 5;
            }
        }

        picture->pts = i;

        // encode the image
        ret = avcodec_encode_video2(c, &pkt, picture, &got_output);
        if (ret < 0) {
            fprintf(stderr, "error encoding frame\n");
            return FAILED;
        }

        if (got_output) {
            printf("encoding frame %3d (size=%5d)\n", i, pkt.size);
            fwrite(pkt.data, 1, pkt.size, f);
            av_free_packet(&pkt);
        }
    }

    // get the delayed frames
    for (got_output = 1; got_output; i++) {
        fflush(stdout);

        ret = avcodec_encode_video2(c, &pkt, NULL, &got_output);
        if (ret < 0) {
            fprintf(stderr, "error encoding frame\n");
            return FAILED;
        }

        if (got_output) {
            printf("write frame %3d (size=%5d)\n", i, pkt.size);
            fwrite(pkt.data, 1, pkt.size, f);
            av_free_packet(&pkt);
        }
    }

    // add sequence end code to have a real mpeg file
    fwrite(endcode, 1, sizeof(endcode), f);
    fclose(f);

    avcodec_close(c);
    av_free(c);
    av_freep(&picture->data[0]);
    av_free(picture);
    printf("\n");

	return SUCCESSED;
}
*/


int FFMpegLib::VideoEncoder(const char* filename, enum AVCodecID codec_id) {
/*
    AVCodec* encoderCodec;
    AVCodecContext* encoderCodecContext= NULL;
    int i, ret, x, y, got_output;
    FILE* f;
    AVFrame* picture;
    AVPacket pkt;
    uint8_t endcode[] = { 0, 0, 1, 0xb7 };

    printf("Encode video file %s\n", filename);

    // find the mpeg1 video encoder
    encoderCodec = avcodec_find_encoder(codec_id);
    if (!encoderCodec) {
        fprintf(stderr, "codec not found\n");
        return FAILED;       
    }

    encoderCodecContext = avcodec_alloc_context3(encoderCodec);

    // put sample parameters
    encoderCodecContext->bit_rate = 400000;
    // resolution must be a multiple of two
    encoderCodecContext->width = 352;
    encoderCodecContext->height = 288;
    // frames per second
	AVRational temp;
	temp.num = 1;
	temp.den = 25;
    encoderCodecContext->time_base= temp;
    encoderCodecContext->gop_size = 10; // emit one intra frame every ten frames
    encoderCodecContext->max_b_frames=1;
    encoderCodecContext->pix_fmt = PIX_FMT_YUV420P;

	if(codec_id == AV_CODEC_ID_H264) {
        av_opt_set(c->priv_data, "preset", "slow", 0);
	}

    // open it
    if (avcodec_open2(encoderCodecContext, encoderCodec, NULL) < 0) {
        fprintf(stderr, "could not open codec\n");
        return FAILED;
    }

    f = fopen(filename, "wb");
    if (!f) {
        fprintf(stderr, "could not open %s\n", filename);
        return FAILED;
    }

    picture = avcodec_alloc_frame();
    if (!picture) {
        fprintf(stderr, "Could not allocate video frame\n");
        return FAILED;
    }
    picture->format = encoderCodecContext->pix_fmt;
    picture->width  = encoderCodecContext->width;
    picture->height = encoderCodecContext->height;

    // the image can be allocated by any means and av_image_alloc() is
    // just the most convenient way if av_malloc() is to be used
    ret = av_image_alloc(picture->data, picture->linesize, encoderCodecContext->width, encoderCodecContext->height, encoderCodecContext->pix_fmt, 32);
    if (ret < 0) {
        fprintf(stderr, "could not alloc raw picture buffer\n");
        return FAILED;
    }

    // encode 1 second of video
    for(i=0;i<25;i++) {
        av_init_packet(&pkt);
        pkt.data = NULL;    // packet data will be allocated by the encoder
        pkt.size = 0;

        fflush(stdout);
        // prepare a dummy image
        // Y
        for(y=0;y<c->height;y++) {
            for(x=0;x<c->width;x++) {
                picture->data[0][y * picture->linesize[0] + x] = x + y + i * 3;
            }
        }

        // Cb and Cr
        for(y=0;y<c->height/2;y++) {
            for(x=0;x<c->width/2;x++) {
                picture->data[1][y * picture->linesize[1] + x] = 128 + y + i * 2;
                picture->data[2][y * picture->linesize[2] + x] = 64 + x + i * 5;
            }
        }

        picture->pts = i;

        // encode the image
        ret = avcodec_encode_video2(encoderCodecContext, &pkt, picture, &got_output);
        if (ret < 0) {
            fprintf(stderr, "error encoding frame\n");
            return FAILED;
        }

        if (got_output) {
            printf("encoding frame %3d (size=%5d)\n", i, pkt.size);
            fwrite(pkt.data, 1, pkt.size, f);
            av_free_packet(&pkt);
        }
    }

    // get the delayed frames
    for (got_output = 1; got_output; i++) {
        fflush(stdout);

        ret = avcodec_encode_video2(c, &pkt, NULL, &got_output);
        if (ret < 0) {
            fprintf(stderr, "error encoding frame\n");
            return FAILED;
        }

        if (got_output) {
            printf("write frame %3d (size=%5d)\n", i, pkt.size);
            fwrite(pkt.data, 1, pkt.size, f);
            av_free_packet(&pkt);
        }
    }

    // add sequence end code to have a real mpeg file
    fwrite(endcode, 1, sizeof(endcode), f);
    fclose(f);

    avcodec_close(c);
    av_free(c);
    av_freep(&picture->data[0]);
    av_free(picture);
    printf("\n");
*/
	return SUCCESSED;
}