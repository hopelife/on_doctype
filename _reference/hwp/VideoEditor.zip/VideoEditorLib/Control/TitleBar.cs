﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Diagnostics;
using System.Windows.Input;

namespace Hnc.Control
{    
    //public class TitleBar : StackPanel {

    //    private Window mainWindow = Application.Current.MainWindow;

    //    private void ChangeStateMainWindow() {
    //        Debug.Assert(mainWindow != null);

    //        WindowState state = mainWindow.WindowState;

    //        if (state == WindowState.Normal) {
    //            mainWindow.Margin = new Thickness(0);
    //            mainWindow.WindowState = WindowState.Maximized;
    //        } else if (state == WindowState.Maximized) {
    //            mainWindow.Margin = new Thickness(0, 0, 10, 10);
    //            mainWindow.WindowState = WindowState.Normal;
    //        }
    //    }

    //    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) {
    //        base.OnMouseLeftButtonDown(e);

    //        // 더블 클릭인 경우 윈도우 상태 변경
    //        if (e.ClickCount == 2) {
    //            ChangeStateMainWindow();
    //        }
    //    }

    //    protected override void OnMouseMove(MouseEventArgs e) {

    //        // 타이틀 바의 빈 영역(그리드나 라벨로 한정)을 클릭한 상태에서만 이동
    //        if (e.LeftButton == MouseButtonState.Pressed &&
    //            (e.Source is TitleBar || e.Source is Grid || e.Source is Label || e.Source is TextBlock)) {

    //            if (mainWindow.WindowState == System.Windows.WindowState.Maximized)
    //                mainWindow.WindowState = System.Windows.WindowState.Normal;

    //            mainWindow.DragMove();
    //        }

    //        base.OnMouseMove(e);
    //    }
    //}
}
