﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Ratio = System.Single;
using Int = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Type {

    // 사각 데이터로부터 떨어진 값을 관리. Inset 방향으로 증가
    // immutable
    // value Compare
    public sealed class OffsetRect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        // Inset 방향 비율을 저장
        private readonly Ratio? left;
        public Ratio? Left { get { return left; } }

        private readonly Ratio? top;
        public Ratio? Top { get { return top; } }

        private readonly Ratio? right;
        public Ratio? Right { get { return right; } }

        private readonly Ratio? bottom;
        public Ratio? Bottom { get { return bottom; } }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private OffsetRect(Ratio? l, Ratio? t, Ratio? r, Ratio? b) {
            this.left = l;
            this.top = t;
            this.right = r;
            this.bottom = b;
        }

        public static OffsetRect Create(Ratio? l, Ratio? t, Ratio? r, Ratio? b) {
            return new OffsetRect(l, t, r, b);
        }
        public OffsetRect Clone() {
            return Create(Left, Top, Right, Bottom);
        }
        #region 비교연산
        public override Bool Equals(System.Object obj) {

            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }

            OffsetRect other = obj as OffsetRect;
            Debug.Assert(other != null);

            return (Left == other.Left) && (Top == other.Top) && (Right == other.Right) && (Bottom == other.Bottom);
        }

        public static Bool operator ==(OffsetRect left, OffsetRect right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(OffsetRect left, OffsetRect right) {
            return !(left == right);
        }
        #endregion
      
        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }
 

    }
}
