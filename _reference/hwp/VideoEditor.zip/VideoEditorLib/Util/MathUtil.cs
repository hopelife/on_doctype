﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;

using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Ratio = System.Single;
using Bool = System.Boolean;


namespace Hnc.Util {

    // 수학 처리 관련 유틸리티
    public static class MathUtil {

        public static Float PI = 3.141592653589793238463F;
        public static Float TWO_PI = 3.141592653589793238463F * 2;
        public static Float HALF_PI = 3.141592653589793238463F / 2;


        // 빗면의 길이
        public static Float GetInclinedPlane(Float w, Float h) {
            return (Float)System.Math.Sqrt(w * w + h * h);
        }

        // start - last 인 직선의 각도 
        // 동일한 좌표 위치면 0도를 리턴한다.
 	    public static Degree GetSeta(PointF start, PointF last)
	    {
		    Float cx = last.X - start.X;
		    Float cy = last.Y - start.Y;

		    if (cx == 0) {
			    if (0 < cy) {
				    return Degree.Create(90);
			    } 
			    else if (cy == 0) {
				    return Degree.Create(0);
			    }
			    return Degree.Create(270);
		    } 
		    else {
			    Degree seta = Degree.Create(ToDegree((Float)System.Math.Atan(cy / cx)));

			    if (cx < 0 && cy >= 0) {		// 2 사분면
				    seta += Degree.Create(180);
			    } 
			    else if (cx < 0 && cy < 0) {	// 3 사분면
				    seta += Degree.Create(180);
			    } 
			    return seta;
		    }	
	    }



        // 최대/최소값 제약
        public static Byte Clamp(Byte val, Byte low, Byte high) {
            if (val < low) return low;
            else if (high < val) return high;

            return val;
        }
        public static Int Clamp(Int val, Int low, Int high) {
            if (val < low) return low;
            else if (high < val) return high;

            return val;
        }
        public static Float Clamp(Float val, Float low, Float high) {
            if (val < low) return low;
            else if (high < val) return high;

            return val;
        }
        public static Float Min(Float left, Float right) {
            return left < right ? left : right;
        }
        public static Int Min(Int left, Int right) {
            return left < right ? left : right;
        }
        public static Float Max(Float left, Float right) {
            return left < right ? right : left;
        }
        public static Int Max(Int left, Int right) {
            return left < right ? right : left;
        }
        // 올림
        public static Int Ceil(Float val) {
            return (Int)System.Math.Ceiling(val);
        }
        // 내림
        public static Int Floor(Float val) {
            return (Int)System.Math.Floor(val);
        }
        
        public static Int Round(Float val) {
            return (Int)System.Math.Round(val);
        }
        public static Int Abs(Int val) {
            return System.Math.Abs(val);
        }
        public static Float Abs(Float val) {
            return System.Math.Abs(val);
        }
        public static Float Cos(Float val) {
            return (Float)System.Math.Cos(val);
        }
        public static Float Sin(Float val) {
            return (Float)System.Math.Sin(val);
        }
        public static Float Acos(Float val) {
            return (Float)System.Math.Acos(val);
        }
        public static Float Asin(Float val) {
            return (Float)System.Math.Asin(val);
        }

        public static Float Atan(Float val) {
            return (Float)System.Math.Atan(val);
        }

        public static Float ToRadian(Float val) {
            return (Float)(val * 0.01745329251994329577); // PI / 180
        }
        public static Float ToDegree(Float val) {
            return (Float)(val * 57.2957795130823208768);
        }
        public static Float Exp(Float val) {
            return (Float)System.Math.Exp(val);
        }
        public static Float Sqrt(Float val) {
            return (Float)System.Math.Sqrt(val);
        }
        public static Rect GetRect(OffsetRect offsetRect, Rect rect) { 
            Debug.AssertThrow(offsetRect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);

            Ratio left = offsetRect.Left == null ? 0 : (Ratio)offsetRect.Left;
            Ratio top = offsetRect.Top == null ? 0 : (Ratio)offsetRect.Top;
            Ratio right = offsetRect.Right == null ? 0 : (Ratio)offsetRect.Right;
            Ratio bottom = offsetRect.Bottom == null ? 0 : (Ratio)offsetRect.Bottom;

            Int x1 = MathUtil.Round(rect.X + rect.Width * left);
            Int y1 = MathUtil.Round(rect.Y + rect.Height * top);

            Int x2 = MathUtil.Round(rect.Right - rect.Width * right);
            Int y2 = MathUtil.Round(rect.Bottom - rect.Height * bottom);

            return Rect.Create(x1, y1, x2 - x1, y2 - y1);
        }
        public static RectF GetRect(OffsetRect offsetRect, RectF rect) {
            Debug.AssertThrow(offsetRect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);

            Ratio left = offsetRect.Left == null ? 0 : (Ratio)offsetRect.Left;
            Ratio top = offsetRect.Top == null ? 0 : (Ratio)offsetRect.Top;
            Ratio right = offsetRect.Right == null ? 0 : (Ratio)offsetRect.Right;
            Ratio bottom = offsetRect.Bottom == null ? 0 : (Ratio)offsetRect.Bottom;

            Float x1 = rect.X + rect.Width * left;
            Float y1 = rect.Y + rect.Height * top;

            Float x2 = rect.Right - rect.Width * right;
            Float y2 = rect.Bottom - rect.Height * bottom;

            return RectF.Create(x1, y1, x2 - x1, y2 - y1);
        }
        // bounds 영역이 rect 가 되기 위한 offsetRect 리턴
        public static OffsetRect GetOffsetRect(RectF bounds, RectF rect) {

            Debug.AssertThrow(bounds != null, eErrorCode.NullArgument);
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(bounds.Width != 0 && bounds.Height != 0, eErrorCode.DevideZero);

            Ratio left = (rect.X -bounds.X) / bounds.Width;
            Ratio top = (rect.Y - bounds.Y) / bounds.Height;
            Ratio right = (bounds.Right - rect.Right) / bounds.Width;
            Ratio bottom = (bounds.Bottom - rect.Bottom) / bounds.Height;

            return OffsetRect.Create(left, top, right, bottom);
        }


        public static Float Tan(Float radian) {
            return (Float)System.Math.Tan(radian);
        }
        public static Float Pow(Float x, Float y) {
            return (Float)System.Math.Pow(x, y);
        }
        public static Float Log(Float val) {
            return (Float)System.Math.Log(val);
        }

        // rect가 angle만큼 회전하였을때에도 bounds 영역을 벗어나지 않도록 보정한 값리턴
        public static RectF ConstraintRect(RectF bounds, RectF rect, Degree angle) {
            Debug.AssertThrow(bounds != null, eErrorCode.NullArgument);
            Debug.AssertThrow(rect != null, eErrorCode.NullArgument);
            Debug.AssertThrow(angle != null, eErrorCode.NullArgument);
            Debug.AssertThrow(Cos(ToRadian(angle.Value)) != 0, eErrorCode.DevideZero);// 90도
            Debug.Assert(0 <= angle.Value && angle.Value < 45 || 315 <= angle.Value && angle.Value < 360, "알고리즘이 45이하일때만 동작함");

            RectF result = rect.Clone();
            result.Normalize();

            Transform2D transform2D = Transform2D.Create();
            transform2D.Rotate(angle, result.Center.X, result.Center.Y); 

            PointF leftTop = transform2D.GetTransformPoint(result.LeftTop);
            PointF rightTop = transform2D.GetTransformPoint(result.RightTop);
            PointF leftBottom = transform2D.GetTransformPoint(result.LeftBottom);
            PointF rightBottom = transform2D.GetTransformPoint(result.RightBottom);


            // 0 ~ 45
            if (0 <= angle.Value && angle.Value < 45 || 315 <= angle.Value && angle.Value < 360) {
                Debug.AssertThrow(Cos(ToRadian(angle.Value)) != 0, eErrorCode.DevideZero);// 90도
                if (bounds.Right < rightTop.X) {

                    Float dx = rightTop.X - bounds.Right;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Width -= length;
                    if (result.Width < 0) {
                        result.X += result.Width;
                        result.Width = 0;
                    }
                }
                if (bounds.Right < rightBottom.X) {

                    Float dx = rightBottom.X - bounds.Right;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Width -= length;
                    if (result.Width < 0) {
                        result.X += result.Width;
                        result.Width = 0;
                    }

                }
                if (leftTop.X < bounds.Left) {

                    Float dx = bounds.Left - leftTop.X;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.X += length;
                    result.Width -= length;
                    if (result.Width < 0) {
                        result.Width = 0;
                    }
                }

                if (leftBottom.X < bounds.Left) {

                    Float dx = bounds.Left - leftBottom.X;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.X += length;
                    result.Width -= length;
                    if (result.Width < 0) {
                        result.Width = 0;
                    }
                }


                if (rightTop.Y < bounds.Top) {

                    Float dx = bounds.Top - rightTop.Y;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Y += length;
                    result.Height -= length;
                    if (result.Height < 0) {
                        result.Height = 0;
                    }
                }

                if (bounds.Bottom < rightBottom.Y) {

                    Float dx = rightBottom.Y - bounds.Bottom;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Height -= length;
                    if (result.Height < 0) {
                        result.Y += result.Height;
                        result.Height = 0;
                    }
                }

                if (leftTop.Y < bounds.Top) {

                    Float dx = bounds.Top - leftTop.Y;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Y += length;
                    result.Height -= length;
                    if (result.Height < 0) {
                        result.Height = 0;
                    }
                }


                if (bounds.Bottom < leftBottom.Y) {

                    Float dx = leftBottom.Y - bounds.Bottom;
                    Float length = dx / Cos(ToRadian(angle.Value));

                    result.Height -= length;
                    if (result.Height < 0) {
                        result.Y += result.Height;
                        result.Height = 0;
                    }
                }

            }

            if (rect.Width < 0) {
                result.FlipWidth();
            }
            if (rect.Height < 0) {
                result.FlipHeight();
            }
            
            return result;

        }

        // left == right인지의 여부. 이때 surplus고려
        public static Bool Equals(Float left, Float right, Float surplus) {
            if ((Abs(right) - Abs(surplus)) <= Abs(left) && Abs(left) <= (Abs(right) + Abs(surplus))) {
                return true;
            }
            return false;
        }
        // 가까운쪽으로 회전되도록 방향을 바꿔준다.
        public static void ConstraintMinDistanceAngle(ref Float from, ref Float to) {
            Debug.AssertThrow(0 <= from && from < 360, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= to && to < 360, eErrorCode.OutOfBoundary);

            if (0 <= from && from < 180) {
                if ((from + 180) < to && to < 360) {
                    to = to - 360;
                }
            }
            else if (180 <= from && from < 360) {
                if (0 <= to && to < Degree.Create(from + 180).Value) {
                    from = from - 360;
                }
            }

            Debug.Assert(MathUtil.Abs(to - from) <= 180);
        }
    }

}
