﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Float = System.Single;
using Ratio = System.Single;
using Byte = System.Byte;
using Index = System.Int32;
using Int = System.Int32;
using Bool = System.Boolean;

namespace Hnc.Presenter.ImageEffect {

    // 필름같은 노이즈를 추가한다.
    public class FilmGrain {

        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Float Amount = 30F; // 0 ~ 100
        private Ratio Density = 0.2F; // 0 ~ 1

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private FilmGrain(Float amount, Ratio density) {
            Amount = MathUtil.Clamp(amount, 0, 100); // 0 100
            Density = MathUtil.Clamp(density, 0, 1);
        }

        public static FilmGrain Create(Float amount, Ratio density) {
            return new FilmGrain(amount, density);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            // 128의 회색조 이미지를 생성한다. - 추후 Overlay로 Blend 되어 128인 부분은 합성에서 제외된다.
            ArgbChannel noise = ArgbChannel.Create(pixels.Width, pixels.Height);
            for (Index i = 0; i < pixels.R.Length; ++i) {
                noise.A[i] = 255;
                noise.R[i] = 128;
                noise.G[i] = 128;
                noise.B[i] = 128;
            }
            NoiseEffect.Create(NoiseEffect.eType.Color, true, Amount, Density).Apply(noise);

            // noise 블러링
            BoxBlur.Create(1).Apply(noise);

            // 원본을 Background로 하여 noise와 합성. 이때 noise의 회색부분은 적용안됨
            for (Index i = 0; i < pixels.R.Length; ++i) {

                Blend.Overlay(
                    ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                    noise.A[i], noise.R[i], noise.G[i], noise.B[i],
                    0.8F
                );



            }




        }



    }

}