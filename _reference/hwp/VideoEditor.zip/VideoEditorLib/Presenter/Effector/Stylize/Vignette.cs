﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Index = System.Int32;
using Pixel = System.UInt32;
using Byte = System.Byte;
using Float = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Bool = System.Boolean;
using Ratio = System.Single;

namespace Hnc.Presenter.ImageEffect {



    // 그림 테두리에 검은 화상을 만든다.
    public class Vignette {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Ratio Center = 0.3F; // 중심 영역
        private Ratio Opacity = 0.7F; // 불투명도

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Vignette(Ratio center, Ratio opacity) {
            Center = MathUtil.Clamp(center, 0, 1);
            Opacity = MathUtil.Clamp(opacity, 0, 1);


        }
        public static Vignette Create(Ratio center, Ratio opacity) {

            return new Vignette(center, opacity);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            ArgbChannel mask = ArgbChannel.Create(pixels.Width, pixels.Height);

            CenterRadialGradient.Create(
                Pixels.ToPixel(0, 0, 0, 0),
                Pixels.ToPixel(255, 0, 0, 0),
                Center,
                0.05F
            ).Apply(mask);
            
            for (Index i = 0; i < pixels.R.Length; ++i) {
                Blend.Normal(
                    ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                    mask.A[i], mask.R[i], mask.G[i], mask.B[i],
                    Opacity
                );

                Blend.Normal(
                    ref pixels.A[i], ref pixels.R[i], ref pixels.G[i], ref pixels.B[i],
                    mask.A[i], mask.R[i], mask.G[i], mask.B[i],
                    Opacity
                );
            }
        }

    }
}
