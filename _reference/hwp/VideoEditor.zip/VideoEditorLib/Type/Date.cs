﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;


namespace Hnc.Type {

    // 년월일, 시분초 관리
    // immutable
    public sealed class Date {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private readonly Int year;
        public Int Year { 
            get { 
                return year; 
            } 
        }

        private readonly Int month;
        public Int Month { 
            get {
                Debug.Assert(1 <= month && month <= 12, "1 <= value && value <= 12");
                return month; 
            }
        }

        private readonly Int day;
        public Int Day { 
            get {
                Debug.Assert(1 <= day && day <= 31, "1 <= value && value <= 31");
                return day;
            }
        }

        private readonly Int hour;
        public Int Hour {
            get {
                Debug.Assert(0 <= hour && hour <= 24, "0 <= value && value <= 24"); 
                return hour;
            }
        }

        private readonly Int minute;
        public Int Minute { 
            get {
                Debug.Assert(0 <= minute && minute <= 60, "0 <= value && value <= 60");
                return minute;
            }
        }

        private readonly Int second;
        public Int Second { 
            get {
                Debug.AssertThrow(0 <= second && second <= 60, eErrorCode.OutOfBoundary); 
                return second;
            } 
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Date(Int year, Int month, Int day, Int hour, Int minute, Int second) {

            Debug.AssertThrow(1 <= month && month <= 12, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(1 <= day && day <= 31, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= hour && hour <= 24, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= minute && minute <= 60, eErrorCode.OutOfBoundary);
            Debug.AssertThrow(0 <= second && second <= 60, eErrorCode.OutOfBoundary);

            this.year = year;
            this.month = month;
            this.day = day;

            this.hour = hour;
            this.minute = minute;
            this.second = second;
        }
        public static Date Create(Int year, Int month, Int day, Int hour, Int minute, Int second) {
            return new Date(year, month, day, hour, minute, second);
        }
    }
}
