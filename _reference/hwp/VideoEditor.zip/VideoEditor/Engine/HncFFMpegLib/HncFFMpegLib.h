#pragma once

#include "Difine.h"

class FFMpegLib;

// C++ DLL - ���������� CLR�� ����Ǵ� Ŭ����
class DLLTYPE HncFFMpegLib
{
private:
	char* filePath;
	VideoInfo* videoInfo;

	FFMpegLib* lib;

public:
	// ������ & �Ҹ���
	HncFFMpegLib(void);
	~HncFFMpegLib(void);

	// set & get �Լ�
	void SetFilePath(const char* inputFilePath);
	const char* GetFilePath();

	const int GetWidth();
	const int GetHeight();
	const int GetFrameRate();
	const int GetPlayTime();
	const char* videoCodec();

	// ��� �Լ�
	int GetFrame(const char* inputFilePath, int frameIndex, Frame* output, int width = -1, int height = -1);
	int GetFrame(const char* inputFilePath, int count, int* frameIndex, Frame** output, int width = -1, int height = -1);
	int GetVideoInfo(const char* inputFilePath);
	int GetVideoInfo(const char* inputFilePath, VideoInfo* info);
	int DeleteFrame(Frame* output);
	int DeleteFrame(int count, Frame** output);
	int SDLPlay();

	int Export(const char* inputFilePath, const char* outputFilePath);

	void NewTimeline();
	int AddTimelineInfo(char* filePath, int startFrame, int endFrame);
	int Export(const char* outputFilePath);
};
