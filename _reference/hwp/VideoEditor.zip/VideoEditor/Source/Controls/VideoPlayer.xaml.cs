﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

using System.Windows.Threading;
using System.Collections.Generic;
using Hnc.VideoEditor.Base.Type;
using Hnc.VEFrame;


namespace Hnc.VideoEditor.Controls {
    public enum PlayerMode : int {
        PlayFile = 0,
        PlayEditor = 1,
        PlayClose = 2
    };

	/*
	                if (VEFrameManager.Instance.IsExistOpenedAppBar()) {
                    VEFrameManager.Instance.SwitchAppBarState(false);
                } else {
                    VEFrameManager.Instance.SwitchAppBarState(true);
                }
	 * */
    public partial class VideoPlayer : UserControl {
        public bool isImageMode = true;
        // 일시 정지
        public bool isPause = true;
        // 영상 종료
        public bool isClose = false;
        // 타임라인을 움직이는 중인지 여부
        public bool isTimelineMove = false;

        private String mediaFilePath;
        private String mediaFileName;
        
        private List<EditVideoInfo> editList = null;

        private DispatcherTimer tickTimer = new DispatcherTimer();

        // Slider 변경 타이머
        public DispatcherTimer mediaTimer = new DispatcherTimer();

        int videoIndex = -1;

        private double changingSeconds = -1.0;

		public VideoSlider GetVideoSlider {
			get {
				return videoSlider;
			}
			set {
				videoSlider = value;
			}
		}

        private PlayerMode playerMode = PlayerMode.PlayFile;

		public PlayerMode PlayerMode {
			get {
				return playerMode;
			}
			set {
				playerMode = value;
			}
		}

		public VideoPlayer() {
			InitializeComponent();

			videoSlider.videoPlayer = this;
			screen.Volume = 0.5;
			screen.IsMuted = false;

			sound.Volume = 0.5;
			sound.IsMuted = false;
			// Timer
			// mediaTimer.Tick += (s, e) => { videoEditorSlider.timeLineSlider.Value = (int)Math.Round(screen.Position.TotalSeconds); };
			mediaTimer.Tick += new EventHandler(MediaTimer);
			mediaTimer.Interval = TimeSpan.FromSeconds(1);

			// Media Play & Pause
			//playPauseButton.Click += new RoutedEventHandler(PlayPauseButtonHendler);

			// Media Open
			screen.MediaOpened += new RoutedEventHandler(MediaOpenedHendler);
			// Media End
			screen.MediaEnded += new RoutedEventHandler(MediaEndedHendler);

			screen.MediaFailed += new EventHandler<ExceptionRoutedEventArgs>(MediaFailedHendler);

			videoSlider.Thumb.MouseDown += new MouseButtonEventHandler(Event_ThumbMouseDown);
			videoSlider.Thumb.MouseUp += new MouseButtonEventHandler(Event_ThumbMouseUp);
			videoSlider.MouseUp += new MouseButtonEventHandler(Event_SliderMouseUp);

			screen.Stretch = Stretch.Uniform;
			controlBar.Visibility = Visibility.Hidden;
			screen.ScrubbingEnabled = true;
		}

        #region MediaOpened & MediaEnded

		void MediaFailedHendler(object sender, ExceptionRoutedEventArgs e) {
			if (VEFrameManager.IsLoaded == true) {
				if (VEFrameManager.Instance.MainPage != null) {
					VEFrameManager.Instance.MainPage.EndOpenTimer();
					VEFrameManager.Instance.MainPage.CloseWaitDlg(false, e.ErrorException.GetType().ToString());
					VEFrameManager.Instance.MainPage.LoadFirstVideo();
				}
			}
		}

        private void MediaOpenedHendler(object sender, RoutedEventArgs e) {
            //this.Width += Screen.NaturalVideoWidth - (ScreenBorder.ActualWidth - (ScreenBorder.BorderThickness.Left + ScreenBorder.BorderThickness.Right));
            //this.Height += Screen.NaturalVideoHeight - (ScreenBorder.ActualHeight - (ScreenBorder.BorderThickness.Top + ScreenBorder.BorderThickness.Bottom));

            TimeSpan totalTimeSpan = new TimeSpan();

            if (screen.NaturalDuration.HasTimeSpan) {
                //videoEditorSlider.timeLineSlider.Maximum = (int)screen.NaturalDuration.TimeSpan.TotalSeconds;
                
                // videoEditorSlider.FullTime.Text = screen.NaturalDuration.TimeSpan.ToString().Substring(0, 8);
                //videoEditorSlider.timeLineSlider.IsEnabled = true;
                isClose = false;

                if (playerMode == PlayerMode.PlayFile) {
                    videoSlider.TotalSeconds = screen.NaturalDuration.TimeSpan.TotalSeconds;
                    //videoSlider.InitVideoPlayer();
                    isOpened = true;

                    if (first == 0) {
						MediaPlay();
                        MediaPause();
                        ++first;
                    }
                } else if (playerMode == PlayerMode.PlayEditor) {

                    if (videoIndex == -1) {
                        return;
                    }

                    double totalSeconds = 0.0;
                    
                    for (int i = 0; i < editList.Count; ++i) {
                        totalSeconds += editList[i].LengthSeconds;
                    }

                    videoSlider.TotalSeconds = totalSeconds;

                //    MediaOpen();
                //    MediaPlay();
                    EditVideoInfo info = editList[videoIndex];

                    if (changingSeconds != -1.0) {
                        //screen.Position = TimeSpan.FromSeconds(changingSeconds);
						ScreenMove(changingSeconds);
                        changingSeconds = -1.0;
                        MediaPlay();
                    } else {
                        //screen.Position = TimeSpan.FromSeconds(info.StartSeconds);
						ScreenMove(info.StartSeconds);
                    }

                    isOpened = true;

			//		screen.Play();
			//		screen.Pause();
                    
                    /*
                    if (videoIndex != 0) {
                        MediaPause();
                    }
                    */
					
                //    MediaPause();
                }

                totalTimeSpan = TimeSpan.FromSeconds(videoSlider.TotalSeconds);
                videoSlider.FullTime.Text = totalTimeSpan.ToString().Substring(0, 8);
                // videoEditorSlider.FullTime.Text = screen.NaturalDuration.TimeSpan.ToString().Substring(0, 8);
				if (VEFrameManager.IsLoaded == true) {
					if (VEFrameManager.Instance.MainPage != null) {
						isStarting = true;
						VEFrameManager.Instance.MainPage.EndOpenTimer();
						VEFrameManager.Instance.MainPage.CloseWaitDlg(true, null);
						
					}
				}
            }
        }

        private void MediaEndedHendler(object sender, RoutedEventArgs e) {
            if (playerMode == PlayerMode.PlayFile) {
                MediaClose();
            } else if (playerMode == PlayerMode.PlayEditor) {
                if (editList.Count - 1 <= videoIndex) {
                    MediaClose();
                }
            }
        }

		public void SetCurrentBar(int index) {
			double seconds = 0.0;
			try {
				if (playerMode == PlayerMode.PlayEditor) {
					if (index >= 0) {
						double totalSeconds = 0.0;

						for (int i = 0; i < index; ++i) {
							totalSeconds += editList[i].LengthSeconds;
						}
						seconds = totalSeconds;
					}
				}
			} catch {
				seconds = 0.0;
			}

			videoSlider.ValueSeconds = seconds;
			videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
		}

        public double SetSliderBar() {
			try {
				if (playerMode == PlayerMode.PlayFile) {
					videoSlider.TotalSeconds = screen.NaturalDuration.TimeSpan.TotalSeconds;
				} else if (playerMode == PlayerMode.PlayEditor) {
					double totalSeconds = 0.0;

					for (int i = 0; i < editList.Count; ++i) {
						totalSeconds += editList[i].LengthSeconds;
					}

					videoSlider.TotalSeconds = totalSeconds;
				}
			} catch {
				videoSlider.TotalSeconds = 0.0;
			}

			TimeSpan totalTimeSpan = new TimeSpan();
			totalTimeSpan = TimeSpan.FromSeconds(videoSlider.TotalSeconds);
			videoSlider.FullTime.Text = totalTimeSpan.ToString().Substring(0, 8);

            double totalSeconds2 = 0.0;

            for (int i = 0; i < editList.Count; ++i) {
                totalSeconds2 += editList[i].LengthSeconds;
            }

            return totalSeconds2;

			//controlBar.Visibility = Visibility.Visible;
		}
		

		double blackScreenTimer = 0.0;

		private void MediaTimer(Object sender, EventArgs e) {
			double seconds = screen.Position.TotalSeconds;

			if (playerMode == PlayerMode.PlayFile) {
				if (videoSlider.EndSecondsValue <= seconds) {
					videoSlider.ValueSeconds = videoSlider.EndSecondsValue;
					videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
					MediaClose();
				} else {
					videoSlider.ValueSeconds = seconds;
					videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
				}
			} else if (playerMode == PlayerMode.PlayEditor) {
				if (videoIndex == -1) {
					MediaClose();
				}

				double addSeconds = 0.0;

				for (int i = 0; i < videoIndex; ++i) {
					addSeconds += editList[i].LengthSeconds;
				}

				if (screen.Source == null) {
					blackScreenTimer += 1.0;
				}

				seconds += blackScreenTimer;

				if (editList[videoIndex].EndSeconds <= seconds) {
					if (editList.Count - 1 <= videoIndex) {
						videoSlider.ValueSeconds = videoSlider.TotalSeconds;
						videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
						MediaClose();
						OpenEdit(videoIndex);
					} else {
						screen.Close();
						++videoIndex;

						EditVideoInfo info = editList[videoIndex];
						if (info.FilePath == null) {
							screen.Source = null;
							blackScreenTimer = 0.0;
						} else {
							screen.Source = new Uri(info.FilePath, UriKind.Absolute);
							blackScreenTimer = 0.0;
						}

						//             MediaOpen();
						MediaPlay();
					}
				} else {
					EditVideoInfo info = editList[videoIndex];
					videoSlider.ValueSeconds = addSeconds + (seconds - info.StartSeconds);
					videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);

					if (VEFrameManager.IsLoaded == true) {
						if (VEFrameManager.Instance.MainPage != null) {
							VEFrameManager.Instance.MainPage.SetTimelineSlider(videoSlider.ValueSeconds);
						}
					}
				}
			}
		}
        #endregion

        #region TimerlineSlider
		public void ChangeMode(PlayerMode mode) {
			playerMode = mode;

			if (playerMode == PlayerMode.PlayFile) {
				videoSlider.Visibility = Visibility.Visible;
				videoSlider.StartPosition.Visibility = Visibility.Visible;
				videoSlider.EndPosition.Visibility = Visibility.Visible;
				videoSlider.MiddleLineUp.Visibility = Visibility.Visible;
				videoSlider.MiddleLineDown.Visibility = Visibility.Visible;
				controlBar.Visibility = Visibility.Visible;
			} else if (playerMode == PlayerMode.PlayEditor) {
				videoSlider.Visibility = Visibility.Visible;
				videoSlider.StartPosition.Visibility = Visibility.Hidden;
				videoSlider.EndPosition.Visibility = Visibility.Hidden;
				videoSlider.MiddleLineUp.Visibility = Visibility.Hidden;
				videoSlider.MiddleLineDown.Visibility = Visibility.Hidden;
				controlBar.Visibility = Visibility.Visible;
			} else {
				if (isClose == true) {
					screen.Close();
					mediaTimer.Stop();
					blackScreenTimer = 0.0;
					videoIndex = 0;
					isClose = true;
				}

				videoSlider.Visibility = Visibility.Hidden;
				controlBar.Visibility = Visibility.Hidden;
			}
		}

		private void Event_ThumbMouseDown(object sender, MouseEventArgs e) {
			/*
			if (e.LeftButton == MouseButtonState.Pressed && !isTimelineMove) {
				isTimelineMove = true;
				if (!isClose) {
					mediaTimer.Stop();
					screen.Pause();
				}
			}
			*/
			if (playerMode == PlayerMode.PlayFile) {
				mediaTimer.Stop();
				screen.Pause();

				videoSlider.Thumb.MouseMove += new MouseEventHandler(Event_ThumbMouseMove);
			}
		}

		public void Event_ThumbMouseMove(object sender, MouseEventArgs e) {
			//ScreenMove(videoSlider.ValueSeconds);
		}

		public void ScreenMove(double seconds) {
			double screenPosition = 0.0;
			double sliderPosition = 0.0;

			if (playerMode == PlayerMode.PlayFile) {
				screenPosition = seconds;
				sliderPosition = videoSlider.ValueSeconds;
			} else {
				double addSeconds = 0.0;
				int selectIndex = -1;
				for (int i = 0; i < editList.Count; ++i) {
					if (videoSlider.ValueSeconds < (addSeconds + editList[i].LengthSeconds)) {
						selectIndex = i;
						break;
					}
					addSeconds += editList[i].LengthSeconds;
				}

				if (selectIndex != -1) {
					EditVideoInfo info = editList[selectIndex];
					videoIndex = selectIndex;

					if (info.FilePath == null) {
						screen.Source = null;
					} else {
						screenPosition = (videoSlider.ValueSeconds - addSeconds + info.StartSeconds);
						sliderPosition = videoSlider.ValueSeconds;

						if (screen.Source.LocalPath != info.FilePath) {
							screen.Source = new Uri(info.FilePath, UriKind.Absolute);
							MediaOpen(videoSlider.ValueSeconds, screenPosition);
						}
					}
				}
			}

			screen.Position = TimeSpan.FromSeconds(screenPosition);
			videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(sliderPosition).ToString().Substring(0, 8);
		}

        private void Event_ThumbMouseUp(object sender, MouseButtonEventArgs e) {
            isTimelineMove = false;

            if (playerMode == PlayerMode.PlayFile) {
                videoSlider.Thumb.MouseMove -= new MouseEventHandler(Event_ThumbMouseMove);
                ScreenMove(videoSlider.ValueSeconds);
                
                if (isPause == false) {
                    if (isOpened == true) {
                        mediaTimer.Start();
                    }
                    screen.Play();
                }
            } else {
                double addSeconds = 0.0;
                int selectIndex = -1;
                for (int i = 0; i < editList.Count; ++i) {
                    if (videoSlider.ValueSeconds <= (addSeconds + editList[i].LengthSeconds)) {
                        selectIndex = i;
                        break;
                    }
                    addSeconds += editList[i].LengthSeconds;
                }

                if (selectIndex != -1) {
                    EditVideoInfo info = editList[selectIndex];

                    if (selectIndex != videoIndex) {
                        videoIndex = selectIndex;

                        if (info.FilePath == null) {
                            screen.Source = null;
                        } else {
                            screen.Source = new Uri(info.FilePath, UriKind.Absolute);

                            changingSeconds = (videoSlider.ValueSeconds - addSeconds + info.StartSeconds);
							MediaOpen(videoSlider.ValueSeconds, changingSeconds);
                        }
                    }

                    if (screen.Source == null) {
                        //screen.Position = TimeSpan.FromSeconds(0.0);
						ScreenMove(0.0);
                        blackScreenTimer = videoSlider.ValueSeconds - addSeconds;
                    } else {
						ScreenMove(videoSlider.ValueSeconds);
                        //screen.Position = TimeSpan.FromSeconds(videoSlider.ValueSeconds - addSeconds + info.StartSeconds);
                    }
                }
            }

            videoSlider.IsMoved = false;
                
            if (!isPause && !isClose) {
                if (isOpened == true) {
                    mediaTimer.Start();
                }
                screen.Play();
            }
        }

        private void Event_SliderMouseUp(object sender, MouseButtonEventArgs e) {
            if (videoSlider.IsMoved == false) {
                videoSlider.IsMoved = true;
                return;
            }

            isTimelineMove = false;

            if (playerMode == PlayerMode.PlayFile) {
                ScreenMove(videoSlider.ValueSeconds);
            } else {
                double addSeconds = 0.0;
                int selectIndex = -1;
                for (int i = 0; i < editList.Count; ++i) {
                    if (videoSlider.ValueSeconds <= (addSeconds + editList[i].LengthSeconds)) {
                        selectIndex = i;
                        break;
                    }
                    addSeconds += editList[i].LengthSeconds;
                }

                if (selectIndex != -1) {
                    EditVideoInfo info = editList[selectIndex];

                    if (selectIndex != videoIndex) {
                        videoIndex = selectIndex;

                        if (info.FilePath == null) {
                            screen.Source = null;
                        } else {
                            screen.Source = new Uri(info.FilePath, UriKind.Absolute);
                            changingSeconds = (videoSlider.ValueSeconds - addSeconds + info.StartSeconds);
							MediaOpen(videoSlider.ValueSeconds, changingSeconds);
                        }
                    }
                    if (screen.Source == null) {
                        //screen.Position = TimeSpan.FromSeconds(0.0);
                        blackScreenTimer = videoSlider.ValueSeconds - addSeconds;
                    } else {
						ScreenMove(videoSlider.ValueSeconds);
                        //screen.Position = TimeSpan.FromSeconds(videoSlider.ValueSeconds - addSeconds + info.StartSeconds);
                    }
                }
            }

            if (!isPause && !isClose) {
                if (isOpened == true) {
                    mediaTimer.Start();
                }
                screen.Play();
            }
        }

        private void PreviewMouseMoveHendler(object sender, MouseEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed && !isTimelineMove) {
                isTimelineMove = true;
                if (!isClose) {
                    mediaTimer.Stop();
                    screen.Pause();
                }
            }
        }

        private void PreviewMouseUpHendler(object sender, MouseButtonEventArgs e) {
            isTimelineMove = false;
            if (!isPause && !isClose) {
              //  screen.Position = TimeSpan.FromSeconds(videoEditorSlider.timeLineSlider.Value);
                if (isOpened == true) {
                    mediaTimer.Start();
                }
                screen.Play();
            }
        }

        private void ValueChangedHendler(object sender, RoutedPropertyChangedEventArgs<double> e) {
            if (isTimelineMove && !isClose) {
				ScreenMove(e.NewValue);
                //screen.Position = TimeSpan.FromSeconds(e.NewValue);
            }

            //currentTime.Text = TimeSpan.FromSeconds(e.NewValue).ToString().Substring(0, 8);
        }
        #endregion

        #region Media Play & Pause & Close
        private void PlayPauseButtonHendler(object sender, RoutedEventArgs e) {
            if (screen.Source == null) {
                ShowFileDialog();
                return;
            }

            if (isPause == true || isClose == true) {
                MediaPlay();
            } else {
                MediaPause();
            }
        }

        int first = 0;

		public void MediaOpen(double seconds, double playSeconds) {
			//screen.Position = TimeSpan.FromSeconds(playSeconds);

			ScreenMove(seconds);
			screen.Play();
			screen.Pause();

			videoSlider.ValueSeconds = seconds;
			//videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
			isPause = true;
		}

		public void MediaOpen(int index, double seconds) {
			double addSeconds = 0.0;

			for (int i = 0; i < editList.Count; ++i) {
				if (i == index) {
					break;
				}
				addSeconds += editList[i].LengthSeconds;
			}

			videoSlider.ValueSeconds = addSeconds;

			screen.Play();
			screen.Pause();

			ScreenMove(seconds);
			screen.Play();
			screen.Pause();

			isPause = true;
		}

		public void MediaOpen(double seconds) {
			//screen.Position = TimeSpan.FromSeconds(seconds);

			ScreenMove(seconds);
			screen.Play();
			screen.Pause();

			videoSlider.ValueSeconds = seconds;
			//videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
			isPause = true;

			/*
			videoSlider.InitVideoPlayer();
			MediaPlay();
			if (first != 0) {
				MediaPause();
			}
			 */
		}

        public void MediaOpen() {
			double seconds = 0.0;

			ScreenMove(seconds);
            screen.Play();
            screen.Pause();
            // screen.Position = TimeSpan.FromSeconds(0.0);

            // double seconds = screen.Position.TotalSeconds;
            videoSlider.ValueSeconds = seconds;
            //videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);

            isPause = true;
            
            /*
            videoSlider.InitVideoPlayer();
            MediaPlay();
            if (first != 0) {
                MediaPause();
            }
             */
        }

        bool isOpened = false;

        public void MediaPlay() {
            if (isClose == true) {
             //   videoEditorSlider.timeLineSlider.Value = 0;
                videoSlider.ValueSeconds = 0;
                videoSlider.CurrentTime.Text = TimeSpan.FromSeconds(videoSlider.ValueSeconds).ToString().Substring(0, 8);
                screen.Close();
                videoSlider.InitVideoPlayer();
                isOpened = true;

                if (PlayerMode == PlayerMode.PlayEditor) {
                    if (VEFrameManager.IsLoaded == true) {
                        if (VEFrameManager.Instance.MainPage != null) {
                            VEFrameManager.Instance.MainPage.MediaEditPlay();
                        }
                    }
                    return;
                    
                }
            }

            if (isOpened == true) {
                mediaTimer.Start();
            }
            screen.Play();
            isPause = false;
            //playPauseButton.Visibility = Visibility.Hidden;
            //playPauseButton.Opacity = 0.0;
        }

        public void MediaPause() {
            // playPauseButton.Visibility = Visibility.Visible;
            //playPauseButton.Opacity = 1.0;
            
            mediaTimer.Stop();
            screen.Pause();
            isPause = true;
        }

		public void SetCloseOption(Boolean isClose) {
			this.isClose = isClose;
		}

		public Boolean GetCloseOption() {
			return this.isClose;
		}

        private void MediaClose() {
            mediaTimer.Stop();
            screen.Pause();

            blackScreenTimer = 0.0;
            videoIndex = -1;
            // videoSlider.InitVideoPlayer();
            //playPauseButton.Visibility = Visibility.Visible;

            // playPauseButton.IsChecked = true;
            // playPauseButton.Content = playImage;
            isClose = true;

            if (VEFrameManager.IsLoaded == true) {
                if (VEFrameManager.Instance.MainPage != null) {
                    VEFrameManager.Instance.MainPage.ChangePlayState(false);
                }
            }

            isOpened = false;
        }

        #endregion

        #region OpenFileDialog

        /// <summary>
        /// Show OpenFileDialog
        /// </summary>
        private void ShowFileDialog() {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();

            openFileDialog.Filter = "비디오 파일 (*.wmv, *.avi, *.mp4)|*.wmv;*.avi;*.mp4 |이미지 파일 (*.png, *.gif, *.bmp, *.jpeg, *.jpg)|*.png;*.gif;*.bmp;*.jpeg;*.jpg |All files (*.*) | *.*";

            if ((bool)openFileDialog.ShowDialog()) {
                mediaFilePath = openFileDialog.FileName;
                mediaFileName = openFileDialog.SafeFileName;

                OpenFile(mediaFilePath);
            }
        }

		public Boolean isStarting = true;

        public void OpenFile(String filePath) {
            if (filePath == null) {
                return;
            }

            if (screen.Source != null) {
                MediaClose();
            }

            isImageMode = KindMedia(filePath);

            // ChangeMode(isImageMode);
			ChangeMode(PlayerMode.PlayFile);

            screen.Source = new Uri(filePath, UriKind.Absolute);
            videoSlider.FilePath = filePath;

            // ChangeMode(PlayerMode.PlayFile);

            videoSlider.InitVideoPlayer();
            isOpened = true;
            MediaPlay();
            if (first != 0) {
                MediaPause();
            }

			isStarting = false;

            // MediaOpen();
        }

        public void StopVideoFile() {
            MediaClose();
        }

        public void NewVideoList() {
            if (editList == null) {
                editList = new List<EditVideoInfo>();
            } else {
                editList.Clear();
            }
        }

        public void AddVideoInfo(EditVideoInfo info) {
            if (editList == null) {
                editList = new List<EditVideoInfo>();
            }

            editList.Add(info);
        }

        public void OpenEdit(int index) {
            if (index == -1) {
                return;
            }

            if (editList == null) {
                return;
            }

            if (editList == null || editList.Count == 0) {
                return;
            }

            if (editList.Count < index) {
                return;
            }

            if (screen.Source != null) {
                MediaClose();
            }
			

            videoIndex = index;

            videoSlider.InitVideoPlayer();

            ChangeMode(PlayerMode.PlayEditor);

            EditVideoInfo info = editList[videoIndex];
			
            isImageMode = KindMedia(info.FilePath);
			
            //ChangeMode(isImageMode);
			if (screen.Source == null) {
				screen.Source = new Uri(info.FilePath, UriKind.Absolute);
			} else {
				if (screen.Source.LocalPath != info.FilePath) {
					screen.Source = new Uri(info.FilePath, UriKind.Absolute);
				}
			}
			
            isClose = false;
            isOpened = true;
			MediaOpen(index, info.StartSeconds);
			

            /*
            MediaPlay();
            MediaPause();

            screen.Play();
            screen.Position = TimeSpan.FromSeconds(info.StartSeconds);
            screen.Pause();
            */
        }

        private bool KindMedia(String filePath) {
            String extension = System.IO.Path.GetExtension(filePath);

            if (extension == ".jpg" | extension == ".png") {
                return true;
            }

            return false;
        }

        private void ChangeMode(bool mode) {
            // 이미지 모드
            if (mode == true) {
                //playPauseButton.Visibility = Visibility.Hidden;
                //controlBar.Visibility = Visibility.Hidden;
                /*
                muteButton.Visibility = Visibility.Hidden;
                timeLineSlider.Visibility = Visibility.Hidden;
                volumeSlider.Visibility = Visibility.Hidden;
                currentTime.Visibility = Visibility.Hidden;
                fullTime.Visibility = Visibility.Hidden;
                */

                //mouseMoveCount = 0.0;
                //playPauseButton.Opacity = 1.0;
                //tickTimer.Stop();
            } else {
                //playPauseButton.Visibility = Visibility.Visible;
                //controlBar.Visibility = Visibility.Visible;
                /*
                muteButton.Visibility = Visibility.Visible;
                timeLineSlider.Visibility = Visibility.Visible;
                volumeSlider.Visibility = Visibility.Visible;
                currentTime.Visibility = Visibility.Visible;
                fullTime.Visibility = Visibility.Visible;
                 */

                //mouseMoveCount = 0.0;
                //playPauseButton.Opacity = 1.0;
                //tickTimer.Start();
            }
        }
        #endregion

		private void PlayerClicked(object sender, MouseButtonEventArgs e) {
			/*
			if (VEFrameManager.Instance.IsExistOpenedAppBar()) {
				VEFrameManager.Instance.SwitchAppBarState(false);
			} else {
				VEFrameManager.Instance.SwitchAppBarState(true);
			}
			*/

			if (isPause == false && isClose == false) {
				if (VEFrameManager.IsLoaded == true) {
					if (VEFrameManager.Instance.MainPage != null) {
						VEFrameManager.Instance.MainPage.ChangePlayState(false);
					}
				}
			}

			e.Handled = true;
		}
    }

	public class EditVideoInfo {
		private string filePath = null;
		private double startSeconds = 0.0;
		private double endSeconds = 0.0;
		private double lengthSeconds = 0.0;

		public string FilePath {
			get {
				return filePath;
			}
			set {
				filePath = value;
			}
		}

		public double StartSeconds {
			get {
				return startSeconds;
			}
			set {
				startSeconds = value;
			}
		}

		public double EndSeconds {
			get {
				return endSeconds;
			}
			set {
				endSeconds = value;
			}
		}

		public double LengthSeconds {
			get {
				return lengthSeconds;
			}
			set {
				lengthSeconds = value;
			}
		}

		public EditVideoInfo(string filePath, double startSeconds, double endSeconds) {
			if (filePath == null) {
				this.filePath = null;
			} else {
				this.filePath = (string)filePath.Clone();
			}
			this.startSeconds = startSeconds;
			this.endSeconds = endSeconds;
			this.lengthSeconds = this.endSeconds - this.startSeconds;
		}

		public EditVideoInfo(TimelineInfo info) {
			VideoInfo videoInfo = info as VideoInfo;

			if (videoInfo != null) {
				filePath = (string)videoInfo.FilePath.Clone();
				startSeconds = FrameToSeconds(videoInfo.VideoScope.START, 30);
				endSeconds = FrameToSeconds(videoInfo.VideoScope.END, 30);

				this.lengthSeconds = this.endSeconds - this.startSeconds;
			}
		}

		private double FrameToSeconds(double frame, double frameRate) {
			double result = 0.0;
			try {
				result = frame / frameRate;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "FrameToSeconds 0으로 나누려고 했습니다.");
				result = 0.0;
			}
			return result;
		}

		private double SecondsToFrame(double seconds, double frameRate) {
			return seconds * frameRate;
		}
	};
}