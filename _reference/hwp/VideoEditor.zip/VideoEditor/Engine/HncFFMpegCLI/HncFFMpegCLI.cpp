// �⺻ DLL �����Դϴ�.

#include "stdafx.h"
#include "HncFFMpegCLI.h"

using namespace System;
using namespace System::Runtime::InteropServices;

namespace Hnc {
	namespace VideoEditor {
		namespace Engine {

			HncFFMpegCLI::HncFFMpegCLI() : hncFFMpegLib(new HncFFMpegLib) {

			}

			HncFFMpegCLI::~HncFFMpegCLI() {
				if (hncFFMpegLib != 0) {
					delete hncFFMpegLib;
					hncFFMpegLib = 0;
				}
			}

			void HncFFMpegCLI::SetName(int^ i) {
				this->index = i;
			}

			int HncFFMpegCLI::GetName() {
				return *(this->index);
			}

			void HncFFMpegCLI::ChangeName() {
				*(this->index) = 10;
			}

			Drawing::Bitmap^ HncFFMpegCLI::GetThumnail(System::String^ filePath, int frameIndex) {
				
				return GetThumnail(filePath, frameIndex, -1, -1);
			}

			void HncFFMpegCLI::NewTimeline() {
				hncFFMpegLib->NewTimeline();
			}

			void HncFFMpegCLI::AddTimelineInfo(System::String^ filePath, int startFrame, int endFrame) {
				System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
				char* pFilePath = (char*) (void*) ptr;

				hncFFMpegLib->AddTimelineInfo(pFilePath, startFrame, endFrame);
				Marshal::FreeHGlobal(ptr);
			}

			void HncFFMpegCLI::Export(System::String^ filePath) {
				System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);
				char* pFilePath = (char*) (void*) ptr;
				hncFFMpegLib->Export(pFilePath);
				Marshal::FreeHGlobal(ptr);
			}

			Drawing::Bitmap^ HncFFMpegCLI::GetThumnail(System::String^ filePath, int frameIndex, int width, int height) {

				System::IntPtr ptr =  Marshal::StringToHGlobalAnsi(filePath);

				char* pFilePath = (char*) (void*) ptr;

				Frame output;
				output.pixel = 0;
				output.height = 0;
				output.width = 0;
				
				if (hncFFMpegLib->GetFrame(pFilePath, frameIndex, &output, width, height) == 0) {
					Marshal::FreeHGlobal(ptr);
					return nullptr;
				}

				if (output.pixel == 0 || output.height <= 0 || output.width <= 0 || output.width > 1920 || output.height > 1080) {
					Marshal::FreeHGlobal(ptr);
					return nullptr;
				}

				Drawing::Bitmap^ bitmap = gcnew Drawing::Bitmap(output.width, output.height);

				for (int y=0; y<output.height; ++y) {

					int x = 0;
					
					for (int xPixel=0; xPixel<output.width*3; xPixel+=3) {
						Drawing::Color color = Drawing::Color().FromArgb(output.pixel[y][xPixel], output.pixel[y][xPixel+1], output.pixel[y][xPixel+2]);

						bitmap->SetPixel(x, y, color);

						++x;
					}
				}

				Marshal::FreeHGlobal(ptr);

				return bitmap;
			}
		}
	}
}

