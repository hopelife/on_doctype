﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// action 처리 하기 위한 클래스
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace Hnc.VideoEditor.Service {
	using Object = System.Object;
	// ----------------------------------------------
	// Action 인터페이스
	// ----------------------------------------------
	public interface IAction {
		bool Execute();
	}

	// ----------------------------------------------
	// Action 관리 클래스 - 싱글톤
	// ----------------------------------------------
	public class ActionManager {
		private static readonly Object thisLock = new Object();

		static ActionManager instance;
		public static ActionManager Instance {
			get {
				lock (thisLock) {
					if (instance == null) {
						instance = new ActionManager();
					}
				}
				return instance;
			}
		}

		// ----------------------------------------------
		// Action 기능 실행
		// ----------------------------------------------
		public bool Excute(IAction action) {
			if (action == null)
				return false;

			if (action.Execute() == false)
				return false;

			return true;
		}
	}
}