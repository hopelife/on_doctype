/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "stdafx.h"
#include "TimelineInfo.h"

class TimelineInfo;

class OutputFileInfo {
private:
	OutputFileInfo();

public:
	OutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID);
	OutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID, TimelineInfo* timelineInfo);
	OutputFileInfo(const Char* filePath, TimelineInfo* info, Int frameRate);
	~OutputFileInfo();

public:
	void CreateOutputFileInfo(const Char* filePath, Int width, Int height, Int frameRate, AVCodecID videoCodecID, AVCodecID audioCodecID, TimelineInfo* timelineInfo);
	Char* GetFilePath();
	Char* GetFileName();
	Char* GetExt();
	Int GetFrameRate();
	AVRational GetTimebase();
	AVFormatContext* GetOutputFormatContext();
	AVCodecContext* GetOutputCodecContext();
	AVCodecContext* GetOutputAudioCodecContext();
	AVCodec* GetOutputCodec();
	AVCodec* GetOutputAudioCodec();

	int GetVideoStreamIndex();
	int GetAudioStreamIndex();

	AVStream* GetVideoStream();
	AVStream* GetAudioStream();

	Int GetWidth();
	Int GetHeight();
	AVCodecID GetOuputVideoCodecID();
	AVCodecID GetOuputAudioCodecID();

	Int IsOpened();

private:
	void InitVar();

	Char filePath[MAX_FILEPATH];
	Char fileName[MAX_FILENAME];
	Char ext[MAX_EXTENSION];
	Int frameRate;
	AVRational timebase;

	AVOutputFormat* ouputFormat;
	AVFormatContext* outputFormatContext;
	AVCodecContext* outputCodecContext2;

	AVStream* videoStream;
	AVStream* audioStream;

	AVCodec* outputVideoCodec;
	AVCodecID ouputVideoCodecID;

	AVCodec* outputAudioCodec;
	AVCodecID ouputAudioCodecID;

	Int width;
	Int height;

	Int isOpen;

	AVStream* AddStream(AVFormatContext* oc, AVCodec** codec, AVCodecID codecID, TimelineInfo* timelineInfo);
	AVStream* AddStream(AVFormatContext* oc, AVCodec** codec, AVCodecID codecID);

	Bool OpenVideo();
	Bool OpenAudio();

	void GetAudioFrame(Int frameSize, Int bn_channels);
	Bool WriteAudioFrame(AVFormatContext* oc, AVStream* st);
};
