/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "stdafx.h"

#include <afx.h>
//#include <Windows.h>
//#include <WinNT.h>


#define FA_EXECUTE			55500
#define FA_OPEN_SUCCESS		100
#define FA_ALL_SUCCESS		101
#define FA_ERR_FILEOPEN		-1
#define FA_ERR_MAPPING		-2

class FileInfo {
public:
	FileInfo(const Char* fullFilePath);
	virtual ~FileInfo();
	Int InfoAll();

public:
	Bool IsOpened();
	Bool GetFileExcutablity();
	Char* GetFileModifyDate();
	Char* GetFileCreateDate();
	ULong GetFileSize();
	Char* GetFileExtension();
	Char* GetFileName();
	Char* GetFullFilePath();

private:
	Bool InfoFileAttribute();
	Bool InfoExcutableFile();
	void CloseFile();
	Int OpenFile();

private:
	PIMAGE_DOS_HEADER pstImageDosHeader;
    PIMAGE_NT_HEADERS pstImageNtHeader;
	
	Char* pcImage;
	HANDLE hFile;
    HANDLE hMapping;	

	Char fileName[MAX_FILEPATH];
	Char fullFilePath[MAX_FILEPATH];
	Char fileExtension[MAX_EXTENSION];
	Char fileModifyDate[MAX_DATE];
	Char fileCreateDate[MAX_DATE];
	
	ULong fileSize;
	Bool isExcutable;

	Bool isOpened;
};
