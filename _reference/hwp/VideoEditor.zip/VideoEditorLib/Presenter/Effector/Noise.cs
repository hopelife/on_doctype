﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Index = System.Int32;
using Pixel = System.UInt32;
using Bool = System.Boolean;
using Byte = System.Byte;


namespace Hnc.Presenter.ImageEffect {
      

    static class Noise {

        private static Bool Start = true;
        private static Int B = 0x100;
        private static Int BM = 0xff;
        private static Int N = 0x1000;
        private static Int[] p = new Int[B + B + 2];
        
        private static Float[] g1 = new Float[B + B + 2];
        private static Float[,] g2 = new Float[B + B + 2, 2];
        private static Float[,] g3 = new Float[B + B + 2, 3];
  
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        // 1D Perlin 노이즈
        // 리턴 : -1 ~ 1
        public static Float Perlin1D(Float x) {
            Int bx0, bx1;
            Float rx0, rx1, sx, t, u, v;

            if (Start) {
                Start = false;
                Init();
            }

            t = x + N;
            bx0 = ((Int)t) & BM;
            bx1 = (bx0 + 1) & BM;
            rx0 = t - (Int)t;
            rx1 = rx0 - 1.0f;

            sx = sCurve(rx0);

            u = rx0 * g1[p[bx0]];
            v = rx1 * g1[p[bx1]];
            return 2.3f * lerp(sx, u, v);
        }

      
        // 2D Perlin 노이즈
        public static Float Perlin2D(Float x, Float y) {
		    Int bx0, bx1, by0, by1, b00, b10, b01, b11;
		    Float rx0, rx1, ry0, ry1, sx, sy, a, b, t, u, v;
		    Int i, j;

		    if (Start) {
			    Start = false;
			    Init();
		    }

		    t = x + N;
		    bx0 = ((Int)t) & BM;
		    bx1 = (bx0+1) & BM;
		    rx0 = t - (int)t;
		    rx1 = rx0 - 1.0f;
    	
		    t = y + N;
		    by0 = ((Int)t) & BM;
		    by1 = (by0+1) & BM;
		    ry0 = t - (Int)t;
		    ry1 = ry0 - 1.0f;
    	
		    i = p[bx0];
		    j = p[bx1];

		    b00 = p[i + by0];
		    b10 = p[j + by0];
		    b01 = p[i + by1];
		    b11 = p[j + by1];

		    sx = sCurve(rx0);
		    sy = sCurve(ry0);

            u = rx0 * g2[b00, 0] + ry0 * g2[b00, 1];

            v = rx1 * g2[b10, 0] + ry0 * g2[b10, 1];

		    a = lerp(sx, u, v);

            u = rx0 * g2[b01, 0] + ry1 * g2[b01, 1];

            v = rx1 * g2[b11, 0] + ry1 * g2[b11, 1];

		    b = lerp(sx, u, v);

		    return 1.5f*lerp(sy, a, b);
	    }

        public static Float Perlin3D(Float x, Float y, Float z) {
		    Int bx0, bx1, by0, by1, bz0, bz1, b00, b10, b01, b11;
            Float rx0, rx1, ry0, ry1, rz0, rz1, sy, sz, a, b, c, d, t, u, v;
            Int i, j;

		    if (Start) {
			    Start = false;
			    Init();
		    }

		    t = x + N;
            bx0 = ((Int)t) & BM;
		    bx1 = (bx0+1) & BM;
            rx0 = t - (Int)t;
		    rx1 = rx0 - 1.0f;

		    t = y + N;
            by0 = ((Int)t) & BM;
		    by1 = (by0+1) & BM;
            ry0 = t - (Int)t;
		    ry1 = ry0 - 1.0f;
    	
		    t = z + N;
            bz0 = ((Int)t) & BM;
		    bz1 = (bz0+1) & BM;
            rz0 = t - (Int)t;
		    rz1 = rz0 - 1.0f;
    	
		    i = p[bx0];
		    j = p[bx1];

		    b00 = p[i + by0];
		    b10 = p[j + by0];
		    b01 = p[i + by1];
		    b11 = p[j + by1];

		    t  = sCurve(rx0);
		    sy = sCurve(ry0);
		    sz = sCurve(rz0);


            u = rx0 * g3[b00 + bz0, 0] + ry0 * g3[b00 + bz0, 1] + rz0 * g3[b00 + bz0, 2];


            v = rx1 * g3[b10 + bz0, 0] + ry0 * g3[b10 + bz0, 1] + rz0 * g3[b10 + bz0, 2];
		    a = lerp(t, u, v);

            u = rx0 * g3[b01 + bz0, 0] + ry1 * g3[b01 + bz0, 1] + rz0 * g3[b01 + bz0, 2];

		    
            v = rx1 * g3[b11 + bz0, 0] + ry1 * g3[b11 + bz0, 1] + rz0 * g3[b11 + bz0, 2];
		    b = lerp(t, u, v);

		    c = lerp(sy, a, b);

            u = rx0 * g3[b00 + bz1, 0] + ry0 * g3[b00 + bz1, 1] + rz1 * g3[b00 + bz1, 2];


            v = rx1 * g3[b10 + bz1, 0] + ry0 * g3[b10 + bz1, 1] + rz1 * g3[b10 + bz1, 2];
		    a = lerp(t, u, v);

            u = rx0 * g3[b01 + bz1, 0] + ry1 * g3[b01 + bz1, 1] + rz1 * g3[b01 + bz1, 2];


            v = rx1 * g3[b11 + bz1, 0] + ry1 * g3[b11 + bz1, 1] + rz1 * g3[b11 + bz1, 2];
		    b = lerp(t, u, v);

		    d = lerp(sy, a, b);

		    return 1.5f * lerp(sz, c, d);
	    }
        public static Float Turbulence3(Float x, Float y, Float z, Float octaves) {
            float t = 0.0f;

            for (Float f = 1.0f; f <= octaves; f *= 2) {
                t += MathUtil.Abs(Perlin3D(f * x, f * y, f * z)) / f;
            }
            return t;
        }


        private static void Init() {
            Int i, j, k;

            System.Random random = new System.Random();

            for (i = 0; i < B; i++) {
                p[i] = i;

                g1[i] = (Float)((random.Next() % (B + B)) - B) / B;

                for (j = 0; j < 2; j++)
                    g2[i, j] = (Float)((random.Next() % (B + B)) - B) / B;
                normalize2(ref g2[i, 0], ref g2[i, 1]);

                for (j = 0; j < 3; j++)
                    g3[i, j] = (Float)((random.Next() % (B + B)) - B) / B;
                normalize3(ref g3[i, 0], ref g3[i, 1], ref g3[i, 2]);
            }

            for (i = B - 1; i >= 0; i--) {
                k = p[i];
                p[i] = p[j = random.Next() % B];
                p[j] = k;
            }

            for (i = 0; i < B + 2; i++) {
                p[B + i] = p[i];
                g1[B + i] = g1[i];
                for (j = 0; j < 2; j++)
                    g2[B + i, j] = g2[i, j];
                for (j = 0; j < 3; j++)
                    g3[B + i, j] = g3[i, j];
            }
        }
        public static Float lerp(Float t, Float a, Float b) {
		    return a + t * (b - a);
	    }

	    private static void normalize2(ref Float a, ref Float b) {
		    Float s = MathUtil.Sqrt(a * a + b * b);
		    a = a / s;
		    b = b / s;
	    }

	    private static void normalize3(ref Float a, ref Float b, ref Float c) {
		    Float s = MathUtil.Sqrt(a * a + b * b + c * c);
		    a = a / s;
		    b = b / s;
		    c = c / s;
	    }
        private static Float sCurve(Float a) {
            return a * a * (3 - 2 * a);
        }

    }

}
