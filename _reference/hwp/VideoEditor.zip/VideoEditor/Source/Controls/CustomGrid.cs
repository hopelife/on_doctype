﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;

namespace Hnc.VideoEditor.Controls {
	class CustomGrid : Grid {
		static double lineGap = 5;

		static double startShortLine = 8.0;
		static double endShortLine = 14.0;

		static double startLongLine = 6.0;

        static double shortLineHeight = 6.0;
        static double longLineHeight = 10.0;


		protected override void OnRender(System.Windows.Media.DrawingContext drawingContext) {
			// 기본 - 배경색
			base.OnRender(drawingContext);

            drawingContext.DrawRectangle((SolidColorBrush)FindResource("Frame.TextColor5"), null, new Rect(0, 0, ActualWidth, ActualHeight));

			// 첫번째 라인
            drawingContext.DrawRectangle((SolidColorBrush)FindResource("Frame.TextColor6"), null, new Rect(0.5, startShortLine, 1, endShortLine));

			// 나머지 라인
			int count = 2;

            double lineStartY = startShortLine;
            double lineEndY = shortLineHeight;

            double lineStartX = lineGap;

			// 라인
			for (double i = lineGap; i < ActualWidth; i = i + lineGap) {
                drawingContext.DrawRectangle((SolidColorBrush)FindResource("Frame.TextColor6"), null, new Rect(lineStartX, lineStartY, 1, lineEndY));

				++count;

                lineStartX = lineStartX + lineGap;

				if (count % 15 == 0) {
                    lineStartY = startLongLine;
                    lineEndY = longLineHeight;
				} else {
                    lineStartY = startShortLine;
                    lineEndY = shortLineHeight;
				}
			}
		}
	}
}
