﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor.Controls {
	using Bool = System.Boolean;
	using Int = System.Int32;
	using Double = System.Double;
	using String = System.String;
	using Size = System.Windows.Size;
	using Point = System.Windows.Point;
	using Pen = System.Windows.Media.Pen;
	using Brush = System.Windows.Media.Brush;
	using SolidColorBrush = System.Windows.Media.SolidColorBrush;
	using System;
	using System.Globalization;
	using System.Windows;
	using System.Windows.Media;
	using Hnc.VideoEditor.Base.Enum;
	using Hnc.Manager;

	/// Ruler Control
	/// 줄자로 눈금의 색상, 글자의 출력 여부, 글자의 색상, 사이즈, cm or inch등의 단위 분류 등의 기능을 가지고 있다.
	/// 그리고 숫자의 단위를 변화 시키는 기능으로 어느 정도 zoom이 들어갔을 때는 숫자의 단위를 올릴 수 있도록
	/// 만들수 있다.
	public class Ruler : FrameworkElement {
		#region 상수
		//private Double gradationHeight;
		//private readonly Pen gradationColor = new Pen(Brushes.Blue, 1.0);
		//private readonly Pen thinGradationColor = new Pen(Brushes.Red, 0.5);
		// private readonly Pen borderColor = new Pen(Brushes.Blue, 1.0);
		// private readonly Pen positionBarColor = new Pen(Brushes.Red, 2.0);

		private Typeface fontName = null;
		private Brush borderFrameBG = null;
		private Brush textColor = null;
		#endregion // 상수

		#region Property
		#region NumberUnit
		public Int numberUnit {
			get {
				return (Int)GetValue(NumberUnitProperty);
			}
			set {
				SetValue(NumberUnitProperty, value);
			}
		}

		public static readonly DependencyProperty NumberUnitProperty =
			DependencyProperty.Register(
			"NumberUnit",
			typeof(Int),
			typeof(Ruler),
			new FrameworkPropertyMetadata(1, FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region ShowText
		public Bool showText {
			get {
				return (Bool)GetValue(ShowTextProperty);
			}
			set {
				SetValue(ShowTextProperty, value);
			}
		}

		public static readonly DependencyProperty ShowTextProperty =
			DependencyProperty.Register(
			"ShowText",
			typeof(Bool),
			typeof(Ruler),
			new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region Gradation
		public Pen gradation {
			get {
				return (Pen)GetValue(GradationProperty);
			}
			set {
				SetValue(GradationProperty, value);
			}
		}

		// 눈금 색깔
		public static readonly DependencyProperty GradationProperty =
			DependencyProperty.Register(
			"Gradation",
			typeof(Pen),
			typeof(Ruler),
			new FrameworkPropertyMetadata(new Pen(Brushes.Red, 1.0), FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region ThinGradation
		public Pen thinGradation {
			get {
				return (Pen)GetValue(ThinGradationProperty);
			}
			set {
				SetValue(ThinGradationProperty, value);
			}
		}

		public static readonly DependencyProperty ThinGradationProperty =
			DependencyProperty.Register(
			"ThinGradation",
			typeof(Pen),
			typeof(Ruler),
			new FrameworkPropertyMetadata(new Pen(Brushes.Black, 1.0), FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region GradationHeight
		public Double gradationHeight {
			get {
				return (Double)GetValue(GradationHeightrProperty);
			}
			set {
				SetValue(GradationHeightrProperty, value);
			}
		}

		public static readonly DependencyProperty GradationHeightrProperty =
			DependencyProperty.Register(
			"GradationHeight",
			typeof(Double),
			typeof(Ruler),
			new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region PositionBar
		public Pen positionBar {
			get {
				return (Pen)GetValue(PositionBarProperty);
			}
			set {
				SetValue(PositionBarProperty, value);
			}
		}

		public static readonly DependencyProperty PositionBarProperty =
			DependencyProperty.Register(
			"PositionBar",
			typeof(Pen),
			typeof(Ruler),
			new FrameworkPropertyMetadata(new Pen(Brushes.Red, 2.0), FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region Border
		public Pen border {
			get {
				return (Pen)GetValue(BorderProperty);
			}
			set {
				SetValue(BorderProperty, value);
			}
		}

		public static readonly DependencyProperty BorderProperty =
			DependencyProperty.Register(
			"Border",
			typeof(Pen),
			typeof(Ruler),
			new FrameworkPropertyMetadata(new Pen(new SolidColorBrush(Color.FromRgb(221, 221, 221)), 1.0), FrameworkPropertyMetadataOptions.AffectsRender));

		public Brush borderBG {
			get {
				return (Brush)GetValue(BorderBGProperty);
			}
			set {
				SetValue(BorderBGProperty, value);
			}
		}

		public static readonly DependencyProperty BorderBGProperty =
			DependencyProperty.Register(
			"BorderBG",
			typeof(Brush),
			typeof(Ruler),
			new FrameworkPropertyMetadata(new SolidColorBrush(Color.FromRgb(221, 221, 221)), FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region Length
		/// <summary>
		/// ruler의 길이 설정
		/// AutoSize : 자신이 속한 패널에 맞게 자동으로 설정 - AutoSize="True"
		/// Length   : 길이 만큼만 출력 - Length="7" AutoSize="False"
		/// </summary>
		public Double Length {
			get {
				if (this.AutoSize) {
					// return (Double)(Unit == Unit.Cm ? DipHelper.DipToCm(this.ActualWidth) : DipHelper.DipToInch(this.ActualWidth)) / this.Zoom;
					Double result = 0.0;
					try {
						result = CalculationToOther(Unit, this.ActualWidth) / this.Zoom;
					} catch (DivideByZeroException) {
						Hnc.Type.Debug.Assert(false, "Ruler_Length 0으로 나누려고 했습니다.");
						result = 0.0;
					}
					return result;
				} else {
					return (Double)GetValue(LengthProperty);
				}
			}
			set {
				SetValue(LengthProperty, value);
			}
		}

		/// <summary>
		/// Identifies the Length dependency property.
		/// </summary>
		public static readonly DependencyProperty LengthProperty =
			 DependencyProperty.Register(
				  "Length",
				  typeof(Double),
				  typeof(Ruler),
				  new FrameworkPropertyMetadata(20D, FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region AutoSize
		public Bool AutoSize {
			get {
				return (Bool)GetValue(AutoSizeProperty);
			}
			set {
				SetValue(AutoSizeProperty, value);
				this.InvalidateVisual();
			}
		}

		public static readonly DependencyProperty AutoSizeProperty =
			 DependencyProperty.Register(
				  "AutoSize",
				  typeof(Bool),
				  typeof(Ruler),
				  new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));
		#endregion

		#region Zoom
		public Double Zoom {
			get {
				return (Double)GetValue(ZoomProperty);
			}
			set {
				SetValue(ZoomProperty, value);
				this.InvalidateVisual();
			}
		}

		public static readonly DependencyProperty ZoomProperty =
			DependencyProperty.Register("Zoom", typeof(Double), typeof(Ruler),
			new FrameworkPropertyMetadata((Double)1.0,
				FrameworkPropertyMetadataOptions.AffectsRender));

		#endregion

		#region Chip
		public static readonly DependencyProperty ChipProperty =
			 DependencyProperty.Register("Chip", typeof(Double), typeof(Ruler),
				  new FrameworkPropertyMetadata((double)-1000,
						FrameworkPropertyMetadataOptions.AffectsRender));

		public Double Chip {
			get {
				return (Double)GetValue(ChipProperty);
			}
			set {
				SetValue(ChipProperty, value);
			}
		}
		#endregion

		#region CountShift
		public static readonly DependencyProperty CountShiftProperty =
			 DependencyProperty.Register("CountShift", typeof(Int), typeof(Ruler),
				  new FrameworkPropertyMetadata(0,
						FrameworkPropertyMetadataOptions.AffectsRender));

		public Int CountShift {
			get {
				return (Int)GetValue(CountShiftProperty);
			}
			set {
				SetValue(CountShiftProperty, value);
			}
		}

		#endregion

		#region Marks
		public static readonly DependencyProperty MarksProperty =
			 DependencyProperty.Register("Marks", typeof(MarksLocation), typeof(Ruler),
				  new FrameworkPropertyMetadata(MarksLocation.Up,
						 FrameworkPropertyMetadataOptions.AffectsRender));

		public MarksLocation Marks {
			get {
				return (MarksLocation)GetValue(MarksProperty);
			}
			set {
				SetValue(MarksProperty, value);
			}
		}

		#endregion

		#region Unit
		public Unit Unit {
			get {
				return (Unit)GetValue(UnitProperty);
			}
			set {
				SetValue(UnitProperty, value);
			}
		}

		public static readonly DependencyProperty UnitProperty =
			 DependencyProperty.Register(
				  "Unit",
				  typeof(Unit),
				  typeof(Ruler),
				  new FrameworkPropertyMetadata(Unit.Cm, FrameworkPropertyMetadataOptions.AffectsRender));

		#endregion
		#endregion // Property

		#region 생성자
		static Ruler() {
			HeightProperty.OverrideMetadata(typeof(Ruler), new FrameworkPropertyMetadata(20.0));
		}
		public Ruler() {
			gradationHeight = this.Height - 10;

			fontName = new Typeface(((FontFamily)FindResource("BaseFontFamily")).ToString());
			borderFrameBG = (SolidColorBrush)FindResource("Frame.BGColor6");
			textColor = (SolidColorBrush)FindResource("Frame.TextColor2");
		}
		#endregion // 생성자

		#region 멤버함수
		public Double CalculationToOther(Unit aUint, Double value) {
			Double retval = 0.0;

			if (aUint == Unit.Cm) {
				retval = DipHelper.DipToCm(value);
			} else if (aUint == Unit.Inch) {
				retval = DipHelper.DipToInch(value);
			} else {
				retval = DipHelper.DipToFrame(value);
			}

			return retval;
		}

		public Double CalculationToDip(Unit aUint, Double value) {
			Double retval = 0.0;

			if (aUint == Unit.Cm) {
				retval = DipHelper.CmToDip(value);
			} else if (aUint == Unit.Inch) {
				retval = DipHelper.InchToDip(value);
			} else {
				retval = DipHelper.FrameToDip(value);
			}

			return retval;
		}

		public double GetPositon(double seconds) {
			double d = DipHelper.FrameToDip(seconds / numberUnit * DipHelper.FrameCount) * this.Zoom;
			return d;
		}

		public double GetMaxFrameCount(double length) {
			return length / this.Zoom / 2 * numberUnit;
			//return DipHelper.DipToFrame(viewPortLength);
		}

		public int GetAutoNumberUnit(double frameCount, double length) {

			int j = 1;

			for (int i = 0; i < 100; i += 10) {
				j = 1;
				if (i != 0) {
					j = i;
				}

				double tempFrameCount = length / 1.0 / 2 * j;

				if (tempFrameCount > frameCount) {
					break;
				}
			}

			return j;
		}

		protected override void OnRender(DrawingContext drawingContext) {
			base.OnRender(drawingContext);

			// Double xDest = (Unit == Unit.Cm ? DipHelper.CmToDip(Length) : DipHelper.InchToDip(ㅋㅋ)) * this.Zoom;
			Double xDest = CalculationToDip(Unit, Length) * this.Zoom;

			drawingContext.DrawRectangle(borderFrameBG, border, new Rect(new Point(0.0, 0.0), new Point(xDest, Height)));
			// Double chip = Unit == Unit.Cm ? DipHelper.CmToDip(Chip) : DipHelper.InchToDip(Chip);
			Double chip = CalculationToDip(Unit, Chip);

			drawingContext.DrawLine(positionBar, new Point(chip, 0), new Point(chip, Height));

			double length = Length;
			
			for (Double dUnit = 0; dUnit <= length; ++dUnit) {
				Double d;
				Double realDistance;

				if (Unit == Unit.Cm) {
					d = DipHelper.CmToDip(dUnit) * this.Zoom;
					realDistance = DipHelper.CmToDip(dUnit);

					if (dUnit < Length) {
						for (Int i = 1; i <= 9; ++i) {
							if (i != 5) {
								Double dMm = DipHelper.CmToDip(dUnit + 0.1 * i) * this.Zoom;
								if (Marks == MarksLocation.Up)
									drawingContext.DrawLine(thinGradation, new Point(dMm, 0), new Point(dMm, gradationHeight / 3.0));
								else
									drawingContext.DrawLine(thinGradation, new Point(dMm, Height), new Point(dMm, Height - gradationHeight / 3.0));
							}
						}
						Double dMiddle = DipHelper.CmToDip(dUnit + 0.5) * this.Zoom;
						if (Marks == MarksLocation.Up)
							drawingContext.DrawLine(gradation, new Point(dMiddle, 0), new Point(dMiddle, gradationHeight * 2.0 / 3.0));
						else
							drawingContext.DrawLine(gradation, new Point(dMiddle, Height), new Point(dMiddle, Height - gradationHeight * 2.0 / 3.0));
					}
				} else if (Unit == Unit.Inch) {
					d = DipHelper.InchToDip(dUnit) * this.Zoom;
					realDistance = DipHelper.InchToDip(dUnit);

					if (dUnit < Length) {
						if (Marks == MarksLocation.Up) {
							Double dQuarter = DipHelper.InchToDip(dUnit + 0.25) * this.Zoom;
							drawingContext.DrawLine(thinGradation, new Point(dQuarter, 0),
															new Point(dQuarter, gradationHeight / 3.0));
							Double dMiddle = DipHelper.InchToDip(dUnit + 0.5) * this.Zoom;
							drawingContext.DrawLine(gradation, new Point(dMiddle, 0),
															new Point(dMiddle, gradationHeight * 2D / 3D));
							Double d3Quarter = DipHelper.InchToDip(dUnit + 0.75) * this.Zoom;
							drawingContext.DrawLine(thinGradation, new Point(d3Quarter, 0),
															new Point(d3Quarter, gradationHeight / 3.0));
						} else {
							Double dQuarter = DipHelper.InchToDip(dUnit + 0.25) * this.Zoom;
							drawingContext.DrawLine(thinGradation, new Point(dQuarter, Height),
															new Point(dQuarter, Height - gradationHeight / 3.0));
							Double dMiddle = DipHelper.InchToDip(dUnit + 0.5) * this.Zoom;
							drawingContext.DrawLine(gradation, new Point(dMiddle, Height),
															new Point(dMiddle, Height - gradationHeight * 2D / 3D));
							Double d3Quarter = DipHelper.InchToDip(dUnit + 0.75) * this.Zoom;
							drawingContext.DrawLine(thinGradation, new Point(d3Quarter, Height),
															new Point(d3Quarter, Height - gradationHeight / 3.0));
						}
					}
				} else {
					d = DipHelper.FrameToDip(dUnit * DipHelper.FrameCount) * this.Zoom;
					realDistance = DipHelper.FrameToDip(dUnit * DipHelper.FrameCount);

					/*
					if (Marks == MarksLocation.Up) {
						double temp = DipHelper.FrameCount / 5;
						for (int i = 0; i < 5; ++i) {
							double temp2 = DipHelper.FrameToDip((dUnit * DipHelper.FrameCount)+(temp*i)) * this.Zoom;
							drawingContext.DrawLine(thinGradation, new Point(temp2, 0), new Point(temp2, gradationHeight / 4.0));
						}
						//drawingContext.DrawLine(thinGradation, new Point(d, 0), new Point(d, gradationHeight));
					} else {
						drawingContext.DrawLine(gradation, new Point(d, Height), new Point(d, gradationHeight));
					}
					*/
				}

				if (realDistance >= Length) {
					break;
				}

				if (showText != false) {
					// 렌더링시 숫자 출력
					if ((dUnit < Length)) {
						String text;

						if (Unit == Unit.Frame) {
							Double total = ((dUnit + CountShift) * numberUnit);

							if (total == 0) {
								text = "0";
							} else {
								Int min = (Int)total / 60;
								Int sec = (Int)total % 60;
								text = String.Format("{0:00}:{1:00}", min, sec);
							}
						} else {
							text = ((dUnit + CountShift) * numberUnit).ToString(CultureManager.CurrentCultureInfo);
						}

						FormattedText ft = new FormattedText(
							 text,
							 CultureManager.CurrentCultureInfo,
							 FlowDirection.LeftToRight,
							 fontName,
							 DipHelper.PtToDip(9),
							 textColor);
						ft.SetFontWeight(FontWeights.Regular);

						if (d == 0.0) {
							ft.TextAlignment = TextAlignment.Left;
						} else {
							ft.TextAlignment = TextAlignment.Center;
						}

						if (Marks == MarksLocation.Up) {
							drawingContext.DrawText(ft, new Point(d, Height / 2 - ft.Height / 2));
						} else {
							drawingContext.DrawText(ft, new Point(d, Height / 2 - ft.Height / 2));
							// drawingContext.DrawText(ft, new Point(d, Height - gradationHeight - ft.Height));
						}
					}
				}
			}
			
		}

		protected override Size MeasureOverride(Size availableSize) {
			Size desiredSize;
			if (Unit == Unit.Cm) {
				desiredSize = new Size(DipHelper.CmToDip(availableSize.Width), Height);
			} else if (Unit == Unit.Inch) {
				desiredSize = new Size(DipHelper.InchToDip(availableSize.Width), Height);
			} else {
				desiredSize = new Size(DipHelper.FrameToDip(availableSize.Width) / 2, Height);
			}

			return desiredSize;
		}
		#endregion // 멤버함수
	}

	public static class DipHelper {
		public static Double MmToDip(Double mm) {
			return CmToDip(mm / 10.0);
		}

		public static Double CmToDip(Double cm) {
			return (cm * 96.0 / 2.54);
		}

		public static Double FrameToDip(Double frame) {
			return frame * 2;
			//return frame;
		}

		public static Double InchToDip(Double inch) {
			return (inch * 96.0);
		}

		public static Double DipToInch(Double dip) {
			return dip / 96D;
		}

		public static Double PtToDip(Double pt) {
			return (pt * 96.0 / 72.0);
		}

		public static Double DipToCm(Double dip) {
			return (dip * 2.54 / 96.0);
		}

		public static Double DipToMm(Double dip) {
			return DipToCm(dip) * 10.0;
		}

		public static Double DipToFrame(Double dip) {
			return dip;
		}

		private static Point GetSystemDpiFactor() {
			PresentationSource source = PresentationSource.FromVisual(Application.Current.MainWindow);
			Matrix m = source.CompositionTarget.TransformToDevice;
			return new Point(m.M11, m.M22);
		}

		private const Double DpiBase = 96.0;
		public static Double FrameCount = 30.0; 

		public static Point GetSystemDpi() {
			Point sysDpiFactor = GetSystemDpiFactor();
			return new Point(
				 sysDpiFactor.X * DpiBase,
				 sysDpiFactor.Y * DpiBase);
		}

		public static Point GetPhysicalDpi(Double diagonalScreenSize) {
			Point sysDpiFactor = GetSystemDpiFactor();
			Double pixelScreenWidth = SystemParameters.PrimaryScreenWidth * sysDpiFactor.X;
			Double pixelScreenHeight = SystemParameters.PrimaryScreenHeight * sysDpiFactor.Y;
			Double formatRate = 0.0;
			try {
				formatRate = pixelScreenWidth / pixelScreenHeight;
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "GetPhysicalDpi 0으로 나누려고 했습니다.");
				formatRate = 0.0;
			}

			Double inchHeight = 0.0;
			try {
				inchHeight = diagonalScreenSize / Math.Sqrt(formatRate * formatRate + 1.0);
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "GetPhysicalDpi 0으로 나누려고 했습니다.");
				inchHeight = 0.0;
			}

			Double inchWidth = formatRate * inchHeight;

			Double xDpi = 0.0;
			try {
				xDpi = Math.Round(pixelScreenWidth / inchWidth);
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "GetPhysicalDpi 0으로 나누려고 했습니다.");
				xDpi = 0.0;
			}

			Double yDpi = 0.0;
			try {
				yDpi = Math.Round(pixelScreenHeight / inchHeight);
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "GetPhysicalDpi 0으로 나누려고 했습니다.");
				yDpi = 0.0;
			}

			return new Point(xDpi, yDpi);
		}

		public static Point DpiToScaleFactor(Point dpi) {
			Point sysDpi = GetSystemDpi();
			Point newPoint;

			try {
				newPoint = new Point(dpi.X / sysDpi.X, dpi.Y / sysDpi.Y);
			} catch (DivideByZeroException) {
				Hnc.Type.Debug.Assert(false, "DpiToScaleFactor 0으로 나누려고 했습니다.");
				newPoint = dpi;
			}
			return newPoint;
		}

		public static Point GetScreenIndependentScaleFactor(Double diagonalScreenSize) {
			return DpiToScaleFactor(GetPhysicalDpi(diagonalScreenSize));
		}
	}
}