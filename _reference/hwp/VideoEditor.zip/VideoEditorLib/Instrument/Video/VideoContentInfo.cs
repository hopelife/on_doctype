﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.Instrument {

    public class VideoContentInfo {
        private string filePath;
        private string fileName;
        private int width;
        private int height;
        private double frameRate;
        private string runningTime;
        private string modifyDate;
        private string videoCodec;
        private string audioCodec;
        private double totalFrame;

        public VideoContentInfo() {
        }

        public string FilePath {
            get { return filePath; }
            set { filePath = value; }
        }

        public string FileName {
            get { return fileName; }
            set { fileName = value; }
        }

        public int Width {
            get { return width; }
            set { width = value; }
        }

        public int Height {
            get { return height; }
            set { height = value; }
        }

        public double FrameRate {
            get { return frameRate; }
            set { frameRate = value; }
        }

        public double TotalFrame {
            get { return totalFrame; }
            set { totalFrame = value; }
        }

        public string RunningTime {
            get { return runningTime; }
            set { runningTime = value; }
        }

        public string ModifyDate {
            get { return modifyDate; }
            set { modifyDate = value; }
        }

        public string VideoCodec {
            get { return videoCodec; }
            set { videoCodec = value; }
        }

        public string AudioCodec {
            get { return audioCodec; }
            set { audioCodec = value; }
        }
    }
}
