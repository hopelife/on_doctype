﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Int = System.Int32;
using Index = System.Int32;
using Grid = System.Windows.Controls.Grid;
using Exception = System.Exception;
using Debug = Hnc.Type.Debug;
using System.Windows;
using System.ComponentModel;
using Hnc.VEFrame;
using Hnc.Control;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Service;
using System.IO;
using Hnc.VideoEditor.Util;
using Hnc.Util;
using System.Runtime.InteropServices;
using System;
using Hnc.VideoEditor.Controls;

namespace Hnc.VideoEditor.Appbar {
    public partial class ExportAppbar : Grid {

        #region -> 한쇼 연동

        public const int WM_USER = 0x0400;
        public const int UM_INSERT_VIDEO_FROM_VIDEOEDITOR = WM_USER + 411;  // 한쇼의 HslFrameUserMessage.h와 일치해야함

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr FindWindow(string strClassName, string strWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int SendMessage(int hWnd, uint Msg, int wParam, int lParam);

        #endregion


        // ----------------------------------------------
		// 속성
		// ----------------------------------------------
		#region 속성
		private readonly double overTime = 600.0;

		private static readonly Index NonSelectedInfo = -1;
		private Index _selectedInfoID = NonSelectedInfo;
		private TimelineInfo _selectedInfo = null;
		private BackgroundWorker threadExport = new BackgroundWorker();
		private BackgroundWorker threadExportState = new BackgroundWorker();
		private readonly Int max = 100;
		private String _filePath = null;

		private Int _width = 0;
		private Int _height = 0;
		private Int _frameRate = 30; // Int.Parse(FrameRate.Text);
		private Int _videoCodec = 13;
		private Int _audioCodec = 0;

		private Bool _exportResult = true;
		private Bool isStartExportState = false;

		private Hnc.Type.Map<String, Int> videoCodecMap = null;
		private String[] extAVI = null;
		private String[] extMP4 = null;
		private String[] extMKV = null;
		private String[] extWMV = null;
		private String[] extTS = null;

		private Hnc.Type.Map<String, Int> widthMap = null;
		private Hnc.Type.Map<String, Int> heightMap = null;

		private CustomDialog customDialog = null;
		#endregion

		// ----------------------------------------------
		// 프로퍼티
		// ----------------------------------------------
		#region 프로퍼티
		public CustomDialog _CustomDialog {
			get {
				return customDialog;
			}
			set {
				customDialog = value;
			}
		}

		public Index SelectedInfoID {
			get {return _selectedInfoID;}
			set {_selectedInfoID = value;}
		}

		public TimelineInfo SelectedInfo {
			get {return _selectedInfo;}
			set {
				if (value != null) {
					_selectedInfo = value.Clone();
				} else {
					_selectedInfo = null;
				}
			}
		}
		#endregion

		// ----------------------------------------------
		// 생성자
		// ----------------------------------------------
		#region 생성자
		public ExportAppbar() {
			InitializeComponent();
			_selectedInfoID = NonSelectedInfo;
			_selectedInfo = null;
		}
		#endregion

		protected override void OnInitialized(System.EventArgs e) {
			base.OnInitialized(e);

			if (VideoEditor.IsHanShowMode == false) {
				extentionListBox.IsEnabled = true;
				videoCodecListBox.IsEnabled = true;
			} else {
				extentionListBox.IsEnabled = false;
				videoCodecListBox.IsEnabled = false;
			}

			videoCodecMap = Hnc.Type.Map<String, Int>.Create();
			videoCodecMap["MPEG-4 Video"] = 13;
			videoCodecMap["MPEG-4 AVC/H264"] = 28;
			videoCodecMap["Window Media Video 7 (wmv1)"] = 18;
			videoCodecMap["Window Media Video 8 (wmv2)"] = 19;
			videoCodecMap["Window Media Video 9 (wmv3)"] = 73;
			videoCodecMap["Microsoft MPEG-4 Video V1"] = 15;
			videoCodecMap["Microsoft MPEG-4 Video V2"] = 16;
			videoCodecMap["Microsoft MPEG-4 Video V3"] = 17;

			Int videoCodecID = videoCodecMap["Window Media Video 9 (wmv3)"];

			extAVI = new String[4];
			extMP4 = new String[2];
			extMKV = new String[7];
			extWMV = new String[7];
			extTS = new String[2];

			extAVI[0] = "MPEG-4 Video";
			extAVI[1] = "MPEG-4 AVC/H264";
			extAVI[2] = "Microsoft MPEG-4 Video V2";
			extAVI[3] = "Microsoft MPEG-4 Video V3";

			extMP4[0] = "MPEG-4 Video";
			extMP4[1] = "MPEG-4 AVC/H264";

			extMKV[0] = "MPEG-4 Video";
			extMKV[1] = "MPEG-4 AVC/H264";
			extMKV[2] = "Microsoft MPEG-4 Video V2";
			extMKV[3] = "Microsoft MPEG-4 Video V3";
			extMKV[4] = "Window Media Video 7 (wmv1)";
			extMKV[5] = "Window Media Video 8 (wmv2)";
			extMKV[6] = "Window Media Video 9 (wmv3)";

			extWMV[0] = "MPEG-4 Video";
			extWMV[1] = "MPEG-4 AVC/H264";
			extWMV[2] = "Microsoft MPEG-4 Video V2";
			extWMV[3] = "Microsoft MPEG-4 Video V3";
			extWMV[4] = "Window Media Video 7 (wmv1)";
			extWMV[5] = "Window Media Video 8 (wmv2)";
			extWMV[6] = "Window Media Video 9 (wmv3)";

			extTS[0] = "MPEG-4 Video";
			extTS[1] = "MPEG-4 AVC/H264";

			DropDownListItem item1 = new DropDownListItem();
			DropDownListItem item2 = new DropDownListItem();
			DropDownListItem item3 = new DropDownListItem();
			DropDownListItem item4 = new DropDownListItem();
			DropDownListItem item5 = new DropDownListItem();

			item1.Text = Application.Current.Resources["IDS_VideoExtentionAVI"] as String;
			item2.Text = Application.Current.Resources["IDS_VideoExtentionMP4"] as String;
			item3.Text = Application.Current.Resources["IDS_VideoExtentionWMV"] as String;
			item4.Text = Application.Current.Resources["IDS_VideoExtentionMKV"] as String;
			item5.Text = Application.Current.Resources["IDS_VideoExtentionTS"] as String;

			extentionListBox.Items.Add(item1);
			extentionListBox.Items.Add(item2);
			extentionListBox.Items.Add(item3);
			extentionListBox.Items.Add(item4);
			extentionListBox.Items.Add(item5);

			extentionListBox.SelectedIndex = 0;


			widthMap = Hnc.Type.Map<String, Int>.Create();
			heightMap = Hnc.Type.Map<String, Int>.Create();

			widthMap["320 X 240"] = 320;
			heightMap["320 X 240"] = 240;

			widthMap["640 X 480"] = 640;
			heightMap["640 X 480"] = 480;

			widthMap["800 X 600"] = 800;
			heightMap["800 X 600"] = 600;

			widthMap["1024 X 768"] = 1024;
			heightMap["1024 X 768"] = 768;

			widthMap["1280 X 720"] = 1280;
			heightMap["1280 X 720"] = 720;

			widthMap["1920 X 1080"] = 1920;
			heightMap["1920 X 1080"] = 1080;

			DropDownListItem item6 = new DropDownListItem();
			DropDownListItem item7 = new DropDownListItem();
			DropDownListItem item8 = new DropDownListItem();
			DropDownListItem item9 = new DropDownListItem();
			DropDownListItem item10 = new DropDownListItem();
			DropDownListItem item11 = new DropDownListItem();

			item6.Text = "320 X 240";
			item7.Text = "640 X 480";
			item8.Text = "800 X 600";
			item9.Text = "1024 X 768";
			item10.Text = "1280 X 720";
			item11.Text = "1920 X 1080";

			frameSizeListBox.Items.Add(item6);
			frameSizeListBox.Items.Add(item7);
			frameSizeListBox.Items.Add(item8);
			frameSizeListBox.Items.Add(item9);
			frameSizeListBox.Items.Add(item10);
			frameSizeListBox.Items.Add(item11);

			frameSizeListBox.SelectedIndex = 0;

			DropDownListItem item12 = new DropDownListItem();
			DropDownListItem item13 = new DropDownListItem();
			DropDownListItem item14 = new DropDownListItem();
			DropDownListItem item15 = new DropDownListItem();

			item12.Text = extAVI[0];
			item13.Text = extAVI[1];
			item14.Text = extAVI[2];
			item15.Text = extAVI[3];

			videoCodecListBox.Items.Add(item12);
			videoCodecListBox.Items.Add(item13);
			videoCodecListBox.Items.Add(item14);
			videoCodecListBox.Items.Add(item15);

			videoCodecListBox.SelectedIndex = 0;

			progress.Maximum = max;

			threadExportState.WorkerReportsProgress = true;
			threadExportState.WorkerSupportsCancellation = true;
			threadExportState.DoWork += new DoWorkEventHandler(ExportStateDoWork);
			threadExportState.ProgressChanged += new ProgressChangedEventHandler(ExportStateProgressChanged);
			threadExportState.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportStateCompleted);

			threadExport.WorkerSupportsCancellation = true;
			threadExport.DoWork += new DoWorkEventHandler(ExportDoWork);
			threadExport.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportCompleted);
			threadExport.ProgressChanged += new ProgressChangedEventHandler(ExportProgressChanged);
		}

		void ExportStateCompleted(object sender, RunWorkerCompletedEventArgs e) {
			threadExportState.DoWork -= ExportStateDoWork;
			threadExportState.ProgressChanged -= ExportStateProgressChanged;
			threadExportState.RunWorkerCompleted -= ExportStateCompleted;

			threadExportState.WorkerReportsProgress = true;
			threadExportState.WorkerSupportsCancellation = true;
			threadExportState.DoWork += new DoWorkEventHandler(ExportStateDoWork);
			threadExportState.ProgressChanged += new ProgressChangedEventHandler(ExportStateProgressChanged);
			threadExportState.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportStateCompleted);
		}

		void ExportStateProgressChanged(object sender, ProgressChangedEventArgs e) {
			Int value = e.ProgressPercentage;

			progress.Value = value;
			progressValue.Content = value.ToString() + "%";

			if (waitDlg != null) {
				waitDlg.Percentage = value.ToString();
			}
		}

		void ExportStateDoWork(object sender, DoWorkEventArgs e) {
			BackgroundWorker worker = sender as BackgroundWorker;

			while (isStartExportState) {
				Int state = 0;// Hnc.Instrument.VideoUtil.GetExportState();
				Int per = 0;
				per = Hnc.Instrument.VideoUtil.GetExportProgress();

				worker.ReportProgress(per);
				System.Threading.Thread.Sleep(10);

				if (state == 3 || state == 4) {
					worker.ReportProgress(0);
					break;
				}
			}

			worker.ReportProgress(0);
		}

		void ExportCompleted(object sender, RunWorkerCompletedEventArgs e) {
			isStartExportState = false;

			if (waitDlg != null) {
				waitDlg.Close();
            }            

            progressValue.Visibility = Visibility.Hidden;

			/*
			AppDialog dlg = null;
			if (_exportResult == true) {
				//    System.IO.File.Move(_tempFilePath, _filePath);
				// 한쇼 연동시에는 완료 메세지 없이 바로 한쇼로 전환
				if (VideoEditor.IsHanShowMode == false) {
					dlg = new AppDialog(Application.Current.Resources["IDS_Export"] as String,
                        Application.Current.Resources["IDS_ExportResultSucess"] as String,
                        Application.Current.Resources["IDS_Confirm"] as String);
				}
			} else {
				dlg = new AppDialog(Application.Current.Resources["IDS_Export"] as String,
                    Hnc.Instrument.VideoErrorCode.GetLastErrorMessage(),
                    Application.Current.Resources["IDS_Confirm"] as String);
			}
			*/

			//FilePath.Text = null;

			//progress.Value = 0.0;
			//progressValue.Content = "0%";

			//ExportButton.Content = Application.Current.Resources["IDS_Export"] as String;

			/*
			if (dlg != null) {
				try {
					dlg.ShowDialog();
				} catch (Exception ex) {
					Debug.Assert(false, ex.Message);
				}
			}
			*/

			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				//Hnc.VEFrame.VEFrameManager.Instance.MainPage.MainMenu.HideSubAppbar();
				_CustomDialog.Close();
			}

			//ExportButton.IsEnabled = true;
			//ExportButton.Content = "완료";
			//ExportButton.IsEnabled = false;

			threadExport.DoWork -= ExportDoWork;
			threadExport.RunWorkerCompleted -= ExportCompleted;
			threadExport.ProgressChanged -= ExportProgressChanged;

			threadExport.WorkerSupportsCancellation = true;
			threadExport.DoWork += new DoWorkEventHandler(ExportDoWork);
			threadExport.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportCompleted);
			threadExport.ProgressChanged += new ProgressChangedEventHandler(ExportProgressChanged);

			threadExportState.DoWork -= ExportStateDoWork;
			threadExportState.ProgressChanged -= ExportStateProgressChanged;
			threadExportState.RunWorkerCompleted -= ExportStateCompleted;

			threadExportState.WorkerReportsProgress = true;
			threadExportState.WorkerSupportsCancellation = true;
			threadExportState.DoWork += new DoWorkEventHandler(ExportStateDoWork);
			threadExportState.ProgressChanged += new ProgressChangedEventHandler(ExportStateProgressChanged);
			threadExportState.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportStateCompleted);

			// 한쇼 연동모드면 내보내기 후 바로 종료
			if (VideoEditor.IsHanShowMode == true && _exportResult == true) {
				if (VideoEditor.IsHanShowMode) {
					// 동영상을 내보낼 한쇼가 실행중인지 체크
					int hWnd = (int)FindWindow(VideoEditor.HanShowClassName, VideoEditor.HanShowWindowName);
					if (hWnd == 0) {
                        CustomDialog dialog = new CustomDialog();
                        string message = Application.Current.Resources["IDS_Message_21"] as String;

                        dialog.ChangeMessageBoxType("", message, 315.0,
                            Application.Current.Resources["IDS_Close"] as String,
                        Application.Current.Resources["IDS_Cancel"] as String);

                        dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);


                        if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                            ActionClose action = ActionClose.Create();
                            ActionManager.Instance.Excute(action);
                            return;
                        } else {
                            return;
                        }
					} else {
						// 한쇼에 동영상 삽입 커맨드 송신
						String outFileName = VideoEditor.LinkFilePath;
						outFileName = outFileName.Substring(outFileName.LastIndexOf(@"\"));
						outFileName = outFileName.Replace("Video", "");
						outFileName = outFileName.Replace(@"\", "");
						int wParam = int.Parse(outFileName.Substring(0, 8));    // 날짜 추출
						int lParam = int.Parse(outFileName.Substring(8, 6));    // 시각 추출

						SendMessage(hWnd, UM_INSERT_VIDEO_FROM_VIDEOEDITOR, wParam, lParam);

						ActionClose action = ActionClose.Create();
						ActionManager.Instance.Excute(action);
					}
				}
			}

		}

		void ExportProgressChanged(object sender, ProgressChangedEventArgs e) {
			Int value = e.ProgressPercentage;

			progress.Value = value;
			progressValue.Content = value.ToString() + "%";
		}

		String GetTempFilePath(String orginPath) {
			String appFolderPath = null;

			try {
				// 저장 파일의 확장자 가져오기
				Int index = orginPath.IndexOf('\\');
				if (index == -1) {
					_exportResult = false;
					return null;
				}
				String ext = System.IO.Path.GetExtension(orginPath);

				// 사용자 appdata 폴더 가져오기 및 존재하는지 확인
				appFolderPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData);
				appFolderPath += "\\Temp";

				// 폴더가 존재하지 않는다면 생성
				if (System.IO.Directory.Exists(appFolderPath) == false) {
					System.IO.Directory.CreateDirectory(appFolderPath);
				}

				appFolderPath += "\\tempVideofile" + ext;

				// 임시 파일이 존재하는지 확인하고 존재한다면 삭제
				if (System.IO.File.Exists(appFolderPath) == true) {
					System.IO.File.Delete(appFolderPath);
				}

				// 기존 파일이 존재하는지 확인하고 존재한다면 삭제
				if (System.IO.File.Exists(orginPath) == true) {
					System.IO.File.Delete(orginPath);
				}
			} catch(Exception ex) {
				Debug.Assert(false, ex.Message);
				appFolderPath = null;
			}

			return appFolderPath;
		}

		void ExportDoWork(object sender, DoWorkEventArgs e) {
			try {
				BackgroundWorker worker = sender as BackgroundWorker;

				String appFolderPath = GetTempFilePath(_filePath);

				if (appFolderPath == null) {
					_exportResult = false;
					return;
				}
				
				// ActionExport action = ActionExport.Create(_filePath, _width, _height, _frameRate, _videoCodec, _audioCodec);
				ActionExport action = ActionExport.Create(appFolderPath, _width, _height, _frameRate, _videoCodec, _audioCodec);

				if (ActionManager.Instance.Excute(action) == true) {
					_exportResult = true;
					System.IO.File.Move(appFolderPath, _filePath);
				} else {
					_exportResult = false;
				}

				// 임시 파일이 존재한다면 삭제
				if (System.IO.File.Exists(appFolderPath) == true) {
					System.IO.File.Delete(appFolderPath);
				}
			} catch (Exception ex) {
				Debug.Assert(false, ex.Message);
				_exportResult = false;
			}
		}

		private void videoCodecListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) {
		}

		private void frameSizeListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) {
			Int width = 800;
			Int height = 600;

			if (frameSizeListBox.Items.Count >= 0) {
				DropDownListItem selectedItem = frameSizeListBox.SelectedItem as DropDownListItem;

				if (selectedItem == null) {
					return;
				}

				string itemName = selectedItem.Text as string;

				width = widthMap[itemName];
				height = heightMap[itemName];
			}

			if (VEFrameManager.IsLoaded == true) {
				if (VEFrameManager.Instance.MainPage != null) {
					VEFrameManager.Instance.MainPage.SetStatusbar(width, height, 30);
				}
			}
		}

		private void extentionListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) {
			if (FilePath == null) {
				return;
			}

			if (FilePath.Text == null) {
				return;
			}

			DropDownListItem selectedItem = extentionListBox.SelectedItem as DropDownListItem;

			if (selectedItem == null) {
				return;
			}

			string itemName = selectedItem.Text as string;

			if (itemName == null) {
				return;
			}

			// '.' 찾기 - 없다면 마지막에 추가
			String filePath = (String)FilePath.Text;
			Int indexDot = filePath.LastIndexOf('.');

			if (indexDot != -1) {
				FilePath.Text = filePath.Remove(indexDot);
			}

			if (FilePath.Text.Length != 0) {
				FilePath.Text += itemName;
			}

			if (itemName == Application.Current.Resources["IDS_VideoExtentionAVI"] as String) {
				videoCodecListBox.Items.Clear();

				DropDownListItem item1 = new DropDownListItem();
				DropDownListItem item2 = new DropDownListItem();
				DropDownListItem item3 = new DropDownListItem();
				DropDownListItem item4 = new DropDownListItem();

				item1.Text = extAVI[0];
				item2.Text = extAVI[1];
				item3.Text = extAVI[2];
				item4.Text = extAVI[3];

				videoCodecListBox.Items.Add(item1);
				videoCodecListBox.Items.Add(item2);
				videoCodecListBox.Items.Add(item3);
				videoCodecListBox.Items.Add(item4);

				videoCodecListBox.SelectedIndex = 0;
			} else if (itemName == Application.Current.Resources["IDS_VideoExtentionMP4"] as String) {
				videoCodecListBox.Items.Clear();

				DropDownListItem item1 = new DropDownListItem();
				DropDownListItem item2 = new DropDownListItem();

				item1.Text = extMP4[0];
				item2.Text = extMP4[1];

				videoCodecListBox.Items.Add(item1);
				videoCodecListBox.Items.Add(item2);

				videoCodecListBox.SelectedIndex = 0;

			} else if (itemName == Application.Current.Resources["IDS_VideoExtentionWMV"] as String) {
				videoCodecListBox.Items.Clear();

				DropDownListItem item1 = new DropDownListItem();
				DropDownListItem item2 = new DropDownListItem();
				DropDownListItem item3 = new DropDownListItem();
				DropDownListItem item4 = new DropDownListItem();
				DropDownListItem item5 = new DropDownListItem();
				DropDownListItem item6 = new DropDownListItem();
				DropDownListItem item7 = new DropDownListItem();

				item1.Text = extWMV[0];
				item2.Text = extWMV[1];
				item3.Text = extWMV[2];
				item4.Text = extWMV[3];
				item5.Text = extWMV[4];
				item6.Text = extWMV[5];
				item7.Text = extWMV[6];

				videoCodecListBox.Items.Add(item1);
				videoCodecListBox.Items.Add(item2);
				videoCodecListBox.Items.Add(item3);
				videoCodecListBox.Items.Add(item4);
				videoCodecListBox.Items.Add(item5);
				videoCodecListBox.Items.Add(item6);
				videoCodecListBox.Items.Add(item7);

				videoCodecListBox.SelectedIndex = 0;
			} else if (itemName == Application.Current.Resources["IDS_VideoExtentionMKV"] as String) {
				videoCodecListBox.Items.Clear();

				DropDownListItem item1 = new DropDownListItem();
				DropDownListItem item2 = new DropDownListItem();
				DropDownListItem item3 = new DropDownListItem();
				DropDownListItem item4 = new DropDownListItem();
				DropDownListItem item5 = new DropDownListItem();
				DropDownListItem item6 = new DropDownListItem();
				DropDownListItem item7 = new DropDownListItem();

				item1.Text = extMKV[0];
				item2.Text = extMKV[1];
				item3.Text = extMKV[2];
				item4.Text = extMKV[3];
				item5.Text = extMKV[4];
				item6.Text = extMKV[5];
				item7.Text = extMKV[6];

				videoCodecListBox.Items.Add(item1);
				videoCodecListBox.Items.Add(item2);
				videoCodecListBox.Items.Add(item3);
				videoCodecListBox.Items.Add(item4);
				videoCodecListBox.Items.Add(item5);
				videoCodecListBox.Items.Add(item6);
				videoCodecListBox.Items.Add(item7);

				videoCodecListBox.SelectedIndex = 0;
			} else if (itemName == Application.Current.Resources["IDS_VideoExtentionTS"] as String) {
				videoCodecListBox.Items.Clear();

				DropDownListItem item1 = new DropDownListItem();
				DropDownListItem item2 = new DropDownListItem();

				item1.Text = extTS[0];
				item2.Text = extTS[1];

				videoCodecListBox.Items.Add(item1);
				videoCodecListBox.Items.Add(item2);

				videoCodecListBox.SelectedIndex = 0;
			} else {
				videoCodecListBox.Items.Clear();
			}
		}

		private void OnFileDialogClickedOK(object sender, RoutedEventArgs e) {
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			Grid grid1 = button.Parent as Grid;
			Grid grid2 = grid1.Parent as Grid;
			FileDialog dlg = grid2.Parent as FileDialog;

			if (dlg == null) {
				return;
			}

			// 추가적인 이벤트 내용
			ActionCompareFilePath action = ActionCompareFilePath.Create(dlg.GetFullPath());

			if (ActionManager.Instance.Excute(action) == true) {
				AppDialog appDlg = null;

				string message = StringUtil.GetAudoLengthMessage(dlg.GetFullPath());

				appDlg = new AppDialog(Application.Current.Resources["IDS_Export"] as String,
									message + Application.Current.Resources["IDS_Message_08"] as String + "\n" +
									Application.Current.Resources["IDS_Message_11"] as String,
									Application.Current.Resources["IDS_Confirm"] as String);

				if (appDlg != null) {
					try {
						appDlg.ShowDialog();
					} catch (Exception ex) {
						Debug.Assert(false, ex.Message);
					}
				}

				return;
			}

			dlg.BaseClickedOKFunction();
		}


		private bool GetEstimateTime() {
			if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
				double frameCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineFrameCount();

				if (frameCount > 0) {
					if (((frameCount / 30) / 60) > 15.0) {
                        CustomDialog dialog = new CustomDialog();
                        string message = Application.Current.Resources["IDS_Message_20"] as String;

                        dialog.ChangeMessageBoxType("", message, 315.0,
                            Application.Current.Resources["IDS_Execute"] as String,
                        Application.Current.Resources["IDS_Cancel"] as String);

                        dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);


                        if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                            return true;
                        }
					} else {
						return true;
					}
				}
			}

			return false;
		}

		private bool GetEstimateTime2() {
			if (frameSizeListBox.Items.Count >= 0) {
				DropDownListItem selectedItem = frameSizeListBox.SelectedItem as DropDownListItem;

				if (selectedItem == null) {
					return false;
				}

				string itemName = selectedItem.Text as string;

				int width = widthMap[itemName];
				int height = heightMap[itemName];

				if (Hnc.VEFrame.VEFrameManager.IsLoaded == true) {
					string filePath = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineInfoPath();
					double sec = Hnc.Instrument.VideoUtil.GetEstimateTime(filePath, width, height);
					double frameCount = Hnc.VEFrame.VEFrameManager.Instance.MainPage.GetTimelineFrameCount();

					double time = sec * frameCount;
					int min = (int) (time / 60.0);
					int hour = min / 60;

					string message;

					if (hour > 0) {
						min = min % 60;
						message = " " + hour + "시간 " + min + "분 ";
					} else {
						message = " " + min + "분 ";
					}

					if (time > overTime) {
                        CustomDialog dialog = new CustomDialog();
                        string message2 = Application.Current.Resources["IDS_Message_18"] as String +
											message +
											Application.Current.Resources["IDS_Message_19"] as String;

                        dialog.ChangeMessageBoxType("", message2, 315.0,
                            Application.Current.Resources["IDS_Confirm"] as String,
                        Application.Current.Resources["IDS_Cancel"] as String);

                        dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);


                        if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                            return true;
                        }
					} else {
						return true;
					}
				}
			}

			return false;
		}

		private void Export() {

			if (VideoEditor.IsHanShowMode) {
				// 동영상을 내보낼 한쇼가 실행중인지 체크
				int hWnd = (int)FindWindow(VideoEditor.HanShowClassName, VideoEditor.HanShowWindowName);

                if (hWnd == 0) {
                    CustomDialog dialog = new CustomDialog();
                    string message = Application.Current.Resources["IDS_Message_21"] as String;

                    dialog.ChangeMessageBoxType("", message, 315.0,
                        Application.Current.Resources["IDS_Close"] as String,
                    Application.Current.Resources["IDS_Cancel"] as String);

                    dialog.ShowDialog(Hnc.VideoEditor.Controls.CustomDialog.SUBDIALOG_STATE.MessageBox, null, null);


                    if (dialog.Result == Hnc.VideoEditor.Controls.CustomDialog.ResultType.OK) {
                        ActionClose action = ActionClose.Create();
                        ActionManager.Instance.Excute(action);
                        return;
                    } else {
                        return;
                    }
                }
			}

			// 내보낼 경로 지정
			_exportResult = true;

			if (GetEstimateTime() == false) {
				return;
			}

			DropDownListItem selectedExt = extentionListBox.SelectedItem as DropDownListItem;

			if (selectedExt == null) {
				_exportResult = false;
				return;
			}

			string ext = selectedExt.Text as string;

			// 한쇼 연동 모드일 경우는 프로그램 실행 시 인자로 입력된 경로로 내보냄
			if (VideoEditor.IsHanShowMode == true) {
				FilePath.Text = VideoEditor.LinkFilePath;
                FilePath.Visibility = System.Windows.Visibility.Hidden;
                progressValue.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			} else {
				/*
				FileDialog filePage =
					new FileDialog(FileDialog.Mode.Save, FileDialog.VideoExtentions, SetupManager.Instance.LastOpendDirectory, ext);
				filePage.SetClickedOK(new RoutedEventHandler(OnFileDialogClickedOK));

				if (filePage.ShowDialog() == true) {
				*/
                // progressValue.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                FilePath.Text = VideoEditor.LinkFilePath;
                FilePath.Visibility = System.Windows.Visibility.Hidden;
                progressValue.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;

				System.Windows.Forms.SaveFileDialog dlg = new System.Windows.Forms.SaveFileDialog();

                string mediaFiles = Application.Current.Resources["IDS_MediaFiles"] as String;
                mediaFiles += "|*" + ext;

                dlg.Filter = mediaFiles;
                dlg.Title = Application.Current.Resources["IDS_Export"] as String;
                

				if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
					
					//if (filePage.SaveFilePath != null) {
					if (dlg.FileName != null) {

						//SetupManager.Instance.LastOpendDirectory = filePage.CurrentPath;
						//FilePath.Text = filePage.SaveFilePath;
						FilePath.Text = dlg.FileName;

						if (ext == null) {
							//filePage.ClickedOKBack();
							_exportResult = false;
							return;
						}

						// '.' 찾기 - 없다면 마지막에 추가
						String filePath = (String)FilePath.Text;
						Int indexDot = filePath.LastIndexOf('.');

						if (indexDot != -1) {
							FilePath.Text = filePath.Remove(indexDot);
						}

						FilePath.Text += ext;
					}
				} else {
					//filePage.ClickedOKBack();
					_exportResult = false;
					return;
				}
				//filePage.ClickedOKBack();
				//System.IO.Directory.SetCurrentDirectory(filePage.CurrentPath);
			}

			// 내보내기
			_filePath = (String)FilePath.Text;

			if (frameSizeListBox.Items.Count >= 0) {
				DropDownListItem selectedItem = frameSizeListBox.SelectedItem as DropDownListItem;

				if (selectedItem == null) {
					_exportResult = false;
					return;
				}

				string itemName = selectedItem.Text as string;

				_width = widthMap[itemName];
				_height = heightMap[itemName];
			}

			_frameRate = 30; // Int.Parse(FrameRate.Text);

			if (videoCodecListBox.Items.Count >= 0) {
				DropDownListItem selectedItem = videoCodecListBox.SelectedItem as DropDownListItem;

				if (selectedItem == null) {
					_exportResult = false;
					return;
				}

				string itemName = selectedItem.Text as string;

				if (itemName == null) {
					_exportResult = false;
					return;
				}

				Int videoCodecID = videoCodecMap[itemName];

				_videoCodec = videoCodecID;
			} else {
				_videoCodec = 13;
			}

			_audioCodec = 86017;
//			_audioCodec = 0;

			isStartExportState = true;
			ExportButton.IsEnabled = false;

			//ExportButton.Content = Application.Current.Resources["IDS_ExportCancel"] as String;
			/*
			waitDlg = new WaitDialog(true, true);
			waitDlg.Show();
			waitDlg.Message = Application.Current.Resources["IDS_Message_09"] as String;
			waitDlg.Percentage = "";

			waitDlg.Canceled += new System.EventHandler(waitDlg_Canceled);
			*/

			progressValue.Visibility = Visibility.Visible;

			threadExport.RunWorkerAsync();
			threadExportState.RunWorkerAsync();
		}

		void waitDlg_Canceled(object sender, System.EventArgs e) {
			ExportCancel();

			progressValue.Visibility = Visibility.Hidden;
		}

		private void ExportCancel() {
			ActionExportCancel action = ActionExportCancel.Create();
			ActionManager.Instance.Excute(action);
		}

		// 내보내기
		private void Export(object sender, System.Windows.RoutedEventArgs e) {
			String ContentExport = Application.Current.Resources["IDS_Export"] as String;

			String ContentExportCancel = Application.Current.Resources["IDS_ExportCancel"] as String;
			

			String ExportButtonContent = ExportButton.Content as String;

			if (ExportButtonContent == null) {
				return;
			}

			if (ContentExport == null) {
				return;
			}

			if (ContentExportCancel == null) {
				return;
			}

			if (ExportButtonContent == ContentExport) {
				Export();
			} else if (ExportButtonContent == ContentExportCancel) {
				ExportCancel();
			}
		}

		private WaitDialog waitDlg = null;
    }
}
