﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Count = System.Int32;
using Index = System.Int32;
using Float = System.Single;
using Byte = System.Byte;

namespace Hnc.Presenter.ImageEffect {

    // 밝기 단계를 level 갯수로 조정하여 적은 색상으로 그려진 포스터처럼 만든다.
    public class Poster {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------

        private LookupTable Table = LookupTable.Create();

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // level : 밝기 단계. 1 ~ 255
        private Poster(Count level) {

            level = MathUtil.Clamp(level, 1, 255);

            Float temp;
            for (Index i = 0; i < 256; ++i) {
                temp = (Float)((i * level) / 256) * (255 / (level - 1));
                temp = (255 < temp) ? 255 : temp;
                Table.Data[i] = (Byte)temp;
            }

        }
        public static Poster Create(Count level) {
            return new Poster(level);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(Ycbcr255Channel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.Y.Length; ++i) {
                pixels.Y[i] = Table.Data[pixels.Y[i]];
            }

        }

    }
}
