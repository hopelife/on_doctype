﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Float = System.Single;
using Ratio = System.Single;
using Index = System.Int32;
using Int = System.Int32;
using Byte = System.Byte;

namespace Hnc.Presenter.ImageEffect {

    // 색온도 조정
    // 원래는 메트릭스 연산에 의해 주어진 whiteBalance 색과 대상 이미지의 Pixel을 colorScale을 하면 되나,
    // 메트릭스 연산은 실수연산이고, scale외에 다른 성분도 곱하기 연산을 하여 속도가 느리므로 
    // 이를 개선하기 위해 미리 scale된 값을 저장한 LookupTable을 이용하여 속도를 향상시킨다.

    public class ColorTemperature {


        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private LookupTable rTable; // 속도 향상을 위해 scale된 값을 미리 저장해 둔다.
        private LookupTable gTable;
        private LookupTable bTable;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // kelvin : 색온도. 1000 ~ 20000
        private ColorTemperature(Float kelvin) {

            // 색온도에 따른 Kelvin 색상
            Pixel whiteBalanceColor = ColorUtil.ColorTemperatureToRgb(MathUtil.Clamp(kelvin, 1000, 20000));

            // RGB 추출
            Ratio r = Pixels.GetR(whiteBalanceColor) / 255.0F;
            Ratio g = Pixels.GetG(whiteBalanceColor) / 255.0F;
            Ratio b = Pixels.GetB(whiteBalanceColor) / 255.0F;

            // scale 시킬 값에 따른 LookupTable을 미리 계산
            rTable = LookupTable.Create();
            for (Index i = 0; i < 256; ++i) {
                rTable.Data[i] = (Byte)MathUtil.Clamp(r * i, 0, 255);
            }

            gTable = LookupTable.Create();
            for (Index i = 0; i < 256; ++i) {
                gTable.Data[i] = (Byte)MathUtil.Clamp(g * i, 0, 255);
            } 
 
            bTable = LookupTable.Create();
            for (Index i = 0; i < 256; ++i) {
                bTable.Data[i] = (Byte)MathUtil.Clamp(b * i, 0, 255);
            }
        }

        public static ColorTemperature Create(Float kelvin) {
            return new ColorTemperature(kelvin);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            for (Index i = 0; i < pixels.R.Length; ++i) {

                pixels.R[i] = rTable.Data[pixels.R[i]];
                pixels.G[i] = gTable.Data[pixels.G[i]];
                pixels.B[i] = bTable.Data[pixels.B[i]];
            }
        } 
    }



    //public class ColorTemperature : MatrixEffect {

    //    // ----------------------------------------------
    //    // 생성자
    //    // ----------------------------------------------
    //    private ColorTemperature(Float kelvin) {

    //        // 색온도에 따른 Kelvin 색상
    //        Pixel whiteBalanceColor = ColorUtil.ColorTemperatureToRgb(kelvin);

    //        // RGB 추출
    //        Ratio r = Pixels.GetR(whiteBalanceColor) / 255.0F;
    //        Ratio g = Pixels.GetG(whiteBalanceColor) / 255.0F;
    //        Ratio b = Pixels.GetB(whiteBalanceColor) / 255.0F;

    //        M = Matrix3.Create();

    //        // Kevin 색에 따른 화이트발란스 메트릭스
    //        M.A[0, 0] = r; // rgb 값이 강조되도록 함
    //        M.A[1, 1] = g;
    //        M.A[2, 2] = b;
    //    }

    //    public static ColorTemperature Create(Float kelvin) {
    //        return new ColorTemperature(kelvin);
    //    }
    //}

}
