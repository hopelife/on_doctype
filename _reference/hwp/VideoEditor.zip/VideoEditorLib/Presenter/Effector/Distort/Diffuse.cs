﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;
using Index = System.Int32;


namespace Hnc.Presenter.ImageEffect {

    // 픽셀을 분산시켜 흩부린듯한 효과를 준다.
    public class Diffuse : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        Float[] SinTable = new Float[256];
        Float[] CosTable = new Float[256];

        System.Random Random = new System.Random();

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        // offset : 분산시킬 픽셀 거리
        private Diffuse(Float offset)
            : base() {

            Float angle;

            for (Int i = 0; i < 256; ++i) {
                angle = MathUtil.TWO_PI * i / 256F;
                SinTable[i] = (Float)(offset * MathUtil.Sin(angle));
                CosTable[i] = (Float)(offset * MathUtil.Cos(angle));
            }
        }
        public static Diffuse Create(Float offset) {
            return new Diffuse(offset);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {
            Index index = Random.Next(0, 255);
            Float distance = index / 255F; // 너무 정규화된것처럼 보이지 않도록 난수를 한번더 곱함

            originX = targetX + distance * SinTable[index];
            originY = targetY + distance * CosTable[index];
        }
        #endregion

    }
}
