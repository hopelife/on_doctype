﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;


using Float = System.Single;
using Ratio = System.Single;
using Int = System.Int32;
using Count = System.Int32;


namespace Hnc.Presenter.ImageEffect {

    // wave 를 준다
    public class Ripple : TransformEffect {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        public enum Type {
            Sin,
            Saw, // 톱니
            Triangle,
            Perlin
        }
        private Type WaveType { get; set; }
        private Count XWaveLength { get; set; } // 웨이브 간격 15 적정
        private Count YWaveLength { get; set; }

        private Float XAmplitude { get; set; } // 진폭 5 적정
        private Float YAmplitude { get; set; }

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private Ripple(Type waveType, Count xWaveLength, Count yWaveLength, Float xAmplitude, Float yAmplitude)
            : base() {
            WaveType = waveType;
            XWaveLength = xWaveLength;
            YWaveLength = yWaveLength;

            XAmplitude = xAmplitude;
            YAmplitude = yAmplitude;

        }
        public static Ripple Create(Type waveType, Count xWaveLength, Count yWaveLength, Float xAmplitude, Float yAmplitude) {
            return new Ripple(waveType, xWaveLength, yWaveLength, xAmplitude, yAmplitude);
        }

        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------

        #region TransformEffect
        // targetX, targetY를 만들어내는 원본좌표를 구함
        protected override void TransformInverse(Int targetX, Int targetY, ref Float originX, ref Float originY) {



            Float nx = (Float)targetY / XWaveLength;
            Float ny = (Float)targetX / YWaveLength;

            Float fx, fy;

            switch (WaveType) {
                case Type.Sin:
                default:
                    fx = (Float)MathUtil.Sin(nx);
                    fy = (Float)MathUtil.Sin(ny);
                    break;
                case Type.Saw:
                    fx = Mod(nx, 1);
                    fy = Mod(ny, 1);
                    break;
                case Type.Triangle:
                    fx = Triangle(nx);
                    fy = Triangle(ny);
                    break;
                case Type.Perlin:
                    fx = Noise.Perlin1D(nx);
                    fy = Noise.Perlin1D(ny);
                    break;
            }
		    originX = targetX + XAmplitude * fx;
            originY = targetY + YAmplitude * fy;


        }
        #endregion

        public static Float Mod(Float a, Float b) {
            Int n = (Int)(a / b);

            a -= n * b;
            if (a < 0)
                return a + b;
            return a;
        }
        public static float Triangle(Float x) {
            Float r = Mod(x, 1.0f);
            return 2.0f * (r < 0.5 ? r : 1 - r);
        }

     
    }
}
