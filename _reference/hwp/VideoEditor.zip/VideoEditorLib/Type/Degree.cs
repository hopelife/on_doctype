﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Int = System.Int32;
using Float = System.Single;
using Bool = System.Boolean;


namespace Hnc.Type {

    // 0~360사이의 각도. 범위를 벗어나면 보정
    // immutable
    // value Compare
    public sealed class Degree {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Float val = 0;
        public Float Value {
            get {
                return val;
            }
        }

        // ----------------------------------------------
        // 생성자 / 연산자
        // ----------------------------------------------
        private Degree(Float val) {
            this.val = Constraint(val);
        }

        public static Degree Create(Float val) {
            return new Degree(val);
        }
        public Degree Clone() {
            return new Degree(val);
        }
        #region 비교연산
        public override Bool Equals(System.Object obj) {
            if (obj == null) {
                return false;
            }
            if (System.Object.ReferenceEquals(this, obj)) {
                return true;
            }
            if (this.GetType() != obj.GetType()) {
                return false;
            }
            
            Degree other = obj as Degree;
            Debug.Assert(other != null);

            return (Value == other.Value);
        }
        public static Bool operator ==(Degree left, Degree right) {
            if (System.Object.ReferenceEquals(left, right)) { // left == right == null
                return true;
            }
            if ((left as object) == null) {
                return false;
            }

            return left.Equals(right);
        }
        public static Bool operator !=(Degree left, Degree right) {
            return !(left == right);
        }
        #endregion

        public static Degree operator +(Degree left, Degree right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return Degree.Create(left.Value + right.Value);
        }
        public static Degree operator -(Degree left, Degree right) {
            Debug.AssertThrow(left != null, eErrorCode.NullArgument);
            Debug.AssertThrow(right != null, eErrorCode.NullArgument);
            return Degree.Create(left.Value - right.Value);
        }
        public static Degree operator -(Degree left) {
            return Degree.Create(-left.Value);
        }

        public override Int GetHashCode() {
            throw new System.NotImplementedException();
        }

        public static Float Constraint(Float val) {
            // 0~360 사이의 값으로 보정
            if (val < 0 || 360 < val) {
                Float quotient = (Int)(val / 360);
                val = val - 360 * quotient;
                if (val < 0) {
                    val = 360 + val;
                }
            }
            if (val == 360) {
                val = 0;
            }

            return val;
        } 
    }
}
