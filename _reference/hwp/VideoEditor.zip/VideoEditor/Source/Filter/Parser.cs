﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Bool = System.Boolean;
using String = System.String;
using Hnc.Type;
using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Engine;
using System.Collections.ObjectModel;


namespace Hnc.VideoEditor.Filter {

	public interface IParser {
		Bool Save(String filePath, Collection<TimelineInfo> infoCollection);
		Bool Load(String filePath);
	}
}