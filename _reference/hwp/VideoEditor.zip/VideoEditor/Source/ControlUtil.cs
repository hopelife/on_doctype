﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

namespace Hnc.VideoEditor {
	using String = System.String;
	using System.Collections.Generic;
	using System.ComponentModel;
	using Hnc.Type;
	using Hnc.VideoEditor.Base.Type;
	using Hnc.VideoEditor.Controls;
	using Hnc.VideoEditor.Engine;
	using Hnc.VideoEditor.Service;
	using System.Windows.Controls;
	using System.Windows.Media;
	using System.Windows;

	public class ControlUtil {
		public static Image CreateImageControl(ImageSource source) {
			Image image = new Image();
			image.Source = source;
			image.Stretch = Stretch.UniformToFill;
			image.HorizontalAlignment = HorizontalAlignment.Center;
			image.VerticalAlignment = VerticalAlignment.Center;

			return image;
		}
	}
}