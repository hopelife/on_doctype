
#ifdef _DEBUG

#include <stdio.h>
#include <windows.h>

#include "Debug.h"

clock_t Debug::start = 0L;
clock_t Debug::end = 0L;
char* Debug::subject = "NoSubject";

Debug::Debug(void) {
}

Debug::Debug(const char* subject) {
	this->subject = (char*) subject;
}

Debug::~Debug(void) {
}

void Debug::Start() {
	start = clock();
}

void Debug::End() {
	end = clock();

	char debugString[100];
	sprintf_s(debugString, 100, "%s : %d\n", subject, end - start);
	OutputDebugString((const char*)debugString);
}

clock_t Debug::Result() {
	return end - start;
	return 0;
}

void Debug::Trace(const char* string) {
	OutputDebugString("Debug::");
	OutputDebugString(string);
	OutputDebugString("\n");
}

#endif