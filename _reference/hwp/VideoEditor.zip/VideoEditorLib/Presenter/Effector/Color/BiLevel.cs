﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Type;
using Hnc.Util;

using Pixel = System.UInt32;
using Ratio = System.Single;
using Byte = System.Byte;
using Int = System.Int32;
using Index = System.Int32;


namespace Hnc.Presenter.ImageEffect {
    // 흑백 효과
    public class BiLevel {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        private Byte ThresValue { get; set; } // 0 ~ 1

        private GrayscaleTable GrayscaleTable = GrayscaleTable.Instance;

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        private BiLevel(Ratio thres) {

            ThresValue = (Byte)MathUtil.Round(MathUtil.Clamp(thres, 0, 1) * 255); // 유효한 값으로 보정
        }

        public static BiLevel Create(Ratio thres) {
            return new BiLevel(thres);
        }
        // ----------------------------------------------
        // 메서드
        // ----------------------------------------------
        public void Apply(ArgbChannel pixels) {
            Debug.AssertThrow(pixels != null, eErrorCode.NullArgument);

            Byte temp;
            for (Index i = 0; i < pixels.R.Length; ++i) {
                temp = ThresValue < GrayscaleTable.GetAt(pixels.R[i], pixels.G[i], pixels.B[i]) ? (Byte)0xFF : (Byte)0x00;

                pixels.R[i] = temp;
                pixels.G[i] = temp;
                pixels.B[i] = temp;
            }
        }
     }
}
