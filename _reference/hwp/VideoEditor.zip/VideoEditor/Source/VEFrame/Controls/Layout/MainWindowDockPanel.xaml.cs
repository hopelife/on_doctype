﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;					// Image, Brush

namespace Hnc.VEFrame.Controls.Layout {
    /// <summary>
    /// MainWindowDockPanel.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindowDockPanel : DockPanel {

        // 상수 정의
        #region 상수 정의
		private const double TITLEBAR_HEIGHT = 64.0;
        private const double BAR_HEIGHT = 200.0;
        #endregion	// 상수 정의

        // 생성자
        #region Constructor

        // 기본 생성자
        public MainWindowDockPanel() {
            InitializeComponent();

            InitPanel();
        }

        // bar의 높이를 지정 할 수 있는 생성자
        public MainWindowDockPanel(int titleBarHeight, int stateBarHeight) {
            InitializeComponent();

            InitPanel(titleBarHeight, stateBarHeight);
        }

        #endregion // Constructor

        // 멤버변수 정의
        #region 멤버변수 정의
        private TitleBar titleBar;
        private StatusBar statusBar;
        private MainWindow mainWindow;
        private double titleBarHeight;
        private double statusBarHeight;
        #endregion	// 멤버변수 정의

        // 프로퍼티
        #region Properties
        public TitleBar TitleBar {
            get {
                return titleBar;
            }
            set {
                titleBar = value;
            }
        }

        public StatusBar StatusBar {
            get {
                return statusBar;
            }
            set {
                statusBar = value;
            }
        }

        public MainWindow MainWindow {
            get {
                return mainWindow;
            }
            set {
                mainWindow = value;
            }
        }
        #endregion // Properties

        // 멤버함수 정의
        #region 멤버변수 정의
        void InitPanel() {
			InitPanel(TITLEBAR_HEIGHT, BAR_HEIGHT);
        }

        // 프레임 초기 설정
        void InitPanel(double titleBarHeight, double statusBarHeight) {
            this.titleBarHeight = titleBarHeight;
            this.statusBarHeight = statusBarHeight;

            this.LastChildFill = true;

            // 타이틀바
            titleBar = new TitleBar();
            DockPanel.SetDock(titleBar, Dock.Top);
            titleBar.Height = this.titleBarHeight;
            this.Children.Add(titleBar);

            // 상태바
            statusBar = new StatusBar();
            DockPanel.SetDock(statusBar, Dock.Bottom);
            statusBar.Height = this.statusBarHeight;
            this.Children.Add(statusBar);

            // workspace
            mainWindow = new MainWindow();
            this.Children.Add(mainWindow);
            /*
            workSpaceGrid = new Grid();
            workSpaceGrid.Background = new SolidColorBrush(Colors.RosyBrown);
            this.Children.Add(workSpaceGrid);
             * */
        }
        #endregion	// 멤버함수 정의

        


        

    }
}
