﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Index = System.Int32;
using Int = System.Int32;
using Frame = System.Double;
using Visibility = System.Windows.Visibility;
using Grid = System.Windows.Controls.Grid;

using Hnc.VideoEditor.Base.Type;
using Hnc.VideoEditor.Service;

namespace Hnc.VideoEditor.Appbar {
    // ----------------------------------------------
    // 자막 설정 창
    // ----------------------------------------------
    public partial class SubtitleAppbar : Grid {
        // ----------------------------------------------
        // 속성
        // ----------------------------------------------
        #region 속성
        private static readonly Index NonSelectedInfo = -1;
        private Index _selectedInfoID = NonSelectedInfo;
        private TimelineInfo _selectedInfo = null;
        #endregion

        // ----------------------------------------------
        // 프로퍼티
        // ----------------------------------------------
        #region 프로퍼티         
        public Index SelectedInfoID {
            get { return _selectedInfoID; }
            set { 
                _selectedInfoID = value;
            }
        }

        public TimelineInfo SelectedInfo {
            get { return _selectedInfo; }
            set {
                if (value != null) {
                    _selectedInfo = value.Clone();
                } else {
                    _selectedInfo = null;
                }

                if (_selectedInfo == null) {
                    Sentence.Text = "";
                    timePicker.InitTime();
                    AddSubtitleButton.Visibility = Visibility.Visible;
                    EditSubtitleButton.Visibility = Visibility.Hidden;
                } else {
                    Sentence.Text = (_selectedInfo as SubtitleInfo).Sentence;
                    Frame frame = (_selectedInfo as SubtitleInfo).TimelineScope.LENGTH;
                    timePicker.FromSecond((Int) (frame / 30.0));
                    AddSubtitleButton.Visibility = Visibility.Hidden;
                    EditSubtitleButton.Visibility = Visibility.Visible;
                }
            }
        }
        #endregion

        // ----------------------------------------------
        // 생성자
        // ----------------------------------------------
        #region 생성자
        public SubtitleAppbar() {
            InitializeComponent();

            _selectedInfoID = NonSelectedInfo;
            _selectedInfo = null;
        }
        #endregion

        // ----------------------------------------------
        // 메소드
        // ----------------------------------------------
        #region 메소드
        private void AddSubtitleButton_Click(object sender, System.Windows.RoutedEventArgs e) {
            Int second = timePicker.ToSecond();
            Frame frame = second * 30.0;
            ActionAddSubtitleInfo action = new ActionAddSubtitleInfo(Sentence.Text, frame);

            if (ActionManager.Instance.Excute(action) == true) {
            }
        }

        private void DeleteSubtitleButton_Click(object sender, System.Windows.RoutedEventArgs e) {
            if (SelectedInfoID != NonSelectedInfo) {
                ActionRemoveInfo action = ActionRemoveInfo.Create(_selectedInfo.ID);

                if (ActionManager.Instance.Excute(action) == true) {
                }
            }
        }

        private void EditSubtitleButton_Click(object sender, System.Windows.RoutedEventArgs e) {
            if (_selectedInfo != null) {
                SubtitleInfo info = _selectedInfo as SubtitleInfo;

                if (info.Sentence.Equals(Sentence.Text) == false) {
                    info.Sentence = Sentence.Text;
                    ActionPropertyChangedInfo action = new ActionPropertyChangedInfo(info);

                    if (ActionManager.Instance.Excute(action) == true) {
                    }
                }
            }
        }
        #endregion
    }
}
