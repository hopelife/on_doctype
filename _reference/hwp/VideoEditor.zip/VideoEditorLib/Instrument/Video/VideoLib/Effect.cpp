/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#include "Effect.h"

UInt8_t EffectUtil::GetBrightness(UInt8_t value, Int percent) {

	if (value <= 0 || value > 255) {
		return 0;
	}

	if (percent <= 0) {
		return 0;
	}

	UInt8_t result = 0;

	result = (value * percent) / 100;

	if (result < 0) {
		return 0;
	}

	return result;
}

Int EffectUtil::FadeInOutEffect(UInt8_t* R, UInt8_t* G, UInt8_t* B, Int64_t frameCount, Int64_t frameLengh) {

	if (frameCount == FADEINOUT_NONE || frameLengh == FADEINOUT_NONE) {
		return FADEINOUT_NONE;
	}

	Int64_t fadeCount = -1;

	// fadeIn�� fadeOut �ð��� ��ģ�ٸ� ��ؾ� �ϳ�??
	// ex) frameLengh�� FADEINOUT_NUMBER 60�̶� ���ٸ�...
	// frameCount = 30;, frameLengh = 60
	// fadeIn���� �ɸ��� fadeOut���� �ɸ���..............

	// fadeIn
	if (frameCount < FADEINOUT_NUMBER) {
		fadeCount = frameCount;
	}

	// fadeOut
	if ((frameLengh - frameCount) < FADEINOUT_NUMBER) {
		fadeCount = frameLengh - frameCount;
	}

	if (fadeCount < 0) {
		return FADEINOUT_OVERFRAME;
	}

	Int percent = 0;
	if (FADEINOUT_NUMBER != 0) {
		percent = (Int) (100 * fadeCount) / FADEINOUT_NUMBER;
	}

	*R = GetBrightness(*R, percent);
	*G = GetBrightness(*G, percent);
	*B = GetBrightness(*B, percent);

	return true;
}

Bool None::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool None::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			EffectUtil::FadeInOutEffect((frame->data[0] + y * frame->linesize[0] + x + 0), 
										(frame->data[0] + y * frame->linesize[0] + x + 1),
										(frame->data[0] + y * frame->linesize[0] + x + 2),
										frameCount, frameLengh);
		}
	}

	return true;
}

Bool Gray::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Gray::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	UInt8_t R = 0;
	UInt8_t G = 0;
	UInt8_t B = 0;

	Int gR = 0;
	Int gG = 0;
	Int gB = 0;

	UInt8_t result = 0;

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			R = *(frame->data[0] + y * frame->linesize[0] + x + 0);
			G = *(frame->data[0] + y * frame->linesize[0] + x + 1);
			B = *(frame->data[0] + y * frame->linesize[0] + x + 2);

			gR = R * 218; // 218 = 0.2126*1024
			gG = G * 732; // 732 = 0.7152*1024
			gB = B * 73;  //  73 = 0.0712*1024

			result = (UInt8_t)((gR + gG + gB) >> 10);

			*(frame->data[0] + y * frame->linesize[0] + x + 0) = result;
			*(frame->data[0] + y * frame->linesize[0] + x + 1) = result;
			*(frame->data[0] + y * frame->linesize[0] + x + 2) = result;
		}
	}

	return true;
}

Bool Red::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Red::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			*(frame->data[0] + y * frame->linesize[0] + x + 1) = 0; // G
			*(frame->data[0] + y * frame->linesize[0] + x + 2) = 0; // B
		}
	}

	return true;
}

Bool Green::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Green::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			*(frame->data[0] + y * frame->linesize[0] + x + 0) = 0; // R
			*(frame->data[0] + y * frame->linesize[0] + x + 2) = 0; // G
		}
	}

	return true;
}

Bool Blue::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Blue::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			*(frame->data[0] + y * frame->linesize[0] + x + 0) = 0; // R
			*(frame->data[0] + y * frame->linesize[0] + x + 1) = 0; // G
		}
	}

	return true;
}

Bool Yellow::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Yellow::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			*(frame->data[0] + y * frame->linesize[0] + x + 2) = 0; // B
		}
	}

	return true;
}

Bool Orange::Apply(AVFrame* frame) {
	return Apply(frame, FADEINOUT_NONE, FADEINOUT_NONE);
}

Bool Orange::Apply(AVFrame* frame, Int64_t frameCount, Int64_t frameLengh) {
	if (frame == NULL) {
		return false;
	}

	if (frame->format != PIX_FMT_RGB24) {
		return false;
	}

	UInt8_t G = 0;
	for (Int y=0; y<frame->height; ++y) {
		for (Int x=0; x<frame->width*3; x += 3) {
			G = *(frame->data[0] + y * frame->linesize[0] + x + 1);

			*(frame->data[0] + y * frame->linesize[0] + x + 1) = G/2; // G
			*(frame->data[0] + y * frame->linesize[0] + x + 2) = 0; // B
		}
	}

	return true;
}






