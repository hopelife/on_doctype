﻿/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

using Hnc.Util;
namespace Hnc.VideoEditor {
	class StringUtil {
		static readonly int CheckFullPathLefgth1 = 70;
		static readonly int CheckFullPathLefgth2 = 150;

		static readonly int CheckFileNameLength = 60;

		public static string GetAudoLengthMessage(string filePath) {
			string message = null;

			int fullPathLength = filePath.Length;

			if (fullPathLength < CheckFullPathLefgth1) {
				message = "\'" + filePath + "\'";
			} else if (fullPathLength > CheckFullPathLefgth2) {
				int fileNameLength = PathUtil.ParseFileName(filePath).Length;

				string fileName = PathUtil.ParseFileName(filePath);

				if (fileNameLength < CheckFileNameLength) {
					message = "\'" + fileName + "\'";
				} else {
					message = "\'" + fileName + "\'\n";
				}
			} else {
				message = "\'" + filePath + "\'\n";
			}

			return message;
		}
	}
}
