/*
 * This program is licensed under GPL 3.0(GNU General Public License).
 * Copyright 2018. Hancom Inc.All rights reserved.
*/

#pragma once

#include "stdafx.h"

#define DEFAULT_SIZE 0
#define FADE_NONE -1
#define FADE_CHECK 60

class IEffect;

class VEFrame {
public:
	VEFrame();
	VEFrame(AVFrame* frame, enum PixelFormat fmt);
	~VEFrame();

public:
	AVFrame* GetFrame();
	AVFrame* GetOriginalFrame();
	AVFrame* GetChangeFrame();
	Bool ApplyFrame();
	void SetFadeInFadeOut(Int64_t frameCount, Int64_t frameLengh);
	void SetSize(Int width, Int height);
	void SetEffect(enum Effect);

private:
	Effect enumEffect;
	IEffect* effect;
	Int originalWidth;
	Int originalHeight;
	Int changeWidth;
	Int changeHeight;
	Int64_t frameCount;
	Int64_t frameLengh;

	Int numBytes;
	UInt8_t* buffer;
	AVFrame* originalFrame;
	AVFrame* changeFrame;

	Bool change;

	enum PixelFormat frameFmt;

	Bool EffectFrame();
	Bool ResizeFrame(enum PixelFormat dstFmt, enum PixelFormat srcFmt);
};
